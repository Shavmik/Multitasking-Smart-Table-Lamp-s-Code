@echo off
cd /d "%~dp0"
title Smart Desk Lamp voice listener
where py >nul 2>nul
if %errorlevel%==0 (set PY=py -3) else (set PY=python)
%PY% voice_listener.py
echo.
echo The voice listener has stopped. Press any key to close this window.
pause >nul
