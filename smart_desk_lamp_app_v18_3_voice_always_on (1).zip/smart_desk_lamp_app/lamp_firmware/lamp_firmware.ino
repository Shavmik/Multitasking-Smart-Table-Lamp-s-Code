/*
  SMART DESK LAMP - ESP32-S3 firmware  (camera + TFT + touch, driven by the laptop app)

  The ESP32 is a "smart peripheral": the laptop does all the thinking (OCR, QR, cube solver,
  calculator, handwriting...) and the board only does five jobs:
     1. take camera pictures            2. show a live preview on the TFT
     3. show any picture the laptop sends (menus, keypads, results)
     4. report finger touches           5. draw quick lines (handwriting feedback)

  Libraries (Arduino IDE -> Library Manager):  "LovyanGFX" by lovyan03

  Tools menu:
     Board ............ ESP32S3 Dev Module        USB CDC On Boot .. Enabled
     PSRAM ............ OPI PSRAM (try QSPI PSRAM if the camera fails)
     Flash Size ....... 16MB (N16R8)              Core Debug Level . None

  WIRING (all pins can be changed in the block below - the app does not care):
     TFT SCK   + T_CLK  -> GPIO 41          TFT D/C  -> GPIO 21
     TFT SDI   + T_DIN  -> GPIO 42          TFT CS   -> GPIO 1
     T_OUT (touch data) -> GPIO 14          TFT RESET-> GPIO 2
     T_CS               -> GPIO 47          T_IRQ    -> not connected (touch is polled)
     TFT VCC -> 5V pin      TFT LED -> 3V3      TFT GND -> GND      TFT SDO -> not connected

  PROTOCOL (laptop -> board, one letter, optional data; board -> laptop answers)
     'P'                      ping            -> "PONG SD=x TOUCH=1\n"
     'V'                      preview frame   -> "IMG!" + u32 length + JPEG   (or "ERR!")
     'C'                      full photo      -> "IMG!" + u32 length + JPEG   (saved on SD too)
     'X'                      read touch      -> "TCH!" + u8 pressed + i16 x + i16 y   (little endian)
     'M' + u8                 0 = preview/photos are drawn on the TFT, 1 = hold (draw nothing)
     'J' + u32 len + JPEG     draw a 320x240 picture on the TFT (menus, results ...)
     'T' + u16 len + text     text page: "Title\nBody"
     'K' + r g b              fill the screen with a colour
     'L' + i16 x0 y0 x1 y1 + r g b + u8 width    draw a line (handwriting)
     'Z'                      touch calibration (tap the 4 corner arrows) -> "CAL!"
     'H' + u8 len + text      LIVE CLOCK: big white digits on black, redrawn IN PLACE each call
                               (only the digit box is repainted, never the whole screen) - the
                               fastest possible update, call it once a second for a ticking clock
     'S' + u16 len + scene    NATIVE BUTTON SCREEN (v15): boxes, text and buttons drawn by the board itself - no
                               picture at all. The board then handles the finger by itself (a pressed button
                               changes colour at once) and remembers taps; the laptop collects them with 'E'.
                                 payload: u8 gen, u8 touchFlags(bit0 flipX, bit1 flipY, bit2 swapXY), bg rgb, u8 count,
                                 then per widget: u8 kind (1 box, 2 label, 3 button), i16 x y, u16 w h, and
                                   box:    u8 radius, rgb c1, rgb c2, u8 grad(0 none,1 vertical,2 horizontal), u8 outline?, rgb
                                   label:  rgb colour, rgb background, u8 font(1-5), u8 align(0 left,1 centre,2 right), u8 len, text
                                   button: u8 radius, rgb c1, rgb c2, u8 grad, rgb text, u8 font, u8 flags(bit0 enabled,
                                           bit1 busy spinner, bit2 invisible hit area), rgb outline, u8 len, text
     'U' + u8 id + u8 flags + u8 len + text    change the text (and button flags) of ONE widget - only that widget is repainted
     'D' + u8 on               SCREEN ON / OFF: 0 = black screen (and the LED pin low, if PIN_TFT_BL is wired), 1 = on again.
                              Used by the voice command "turn on / off the smart desk lamp".
     'B' + i16 x, i16 y, u16 w, u16 h, u16 ms   ALWAYS-ON CAMERA BOX: the board itself draws a small live camera picture in this
                              box (about every `ms`), on top of whatever screen is shown. w = 0 switches it off.
     'E'                      read taps       -> "EVT!" + u8 n + n x (u8 gen, u8 widget id)
     'N' + native menu        draw a title + coloured button boxes DIRECTLY on the TFT (no JPEG,
                               so this is near-instant even over slow jumper wires). Some buttons
                               can "breathe" (pulsing colour), animated locally by the board itself
                               so it stays smooth without the laptop sending anything more. Layout:
                                 bg r g b
                                 title: u8 len + bytes, r g b, u8 font(1-4), u8 flags(bit0=animated)
                                 u8 buttonCount, then per button:
                                   u16 x y w h (little endian)
                                   fill r g b, text r g b
                                   u8 font(1-4), u8 flags(bit0=animated)
                                   u8 labelLen + bytes
*/

#include "esp_camera.h"
#include "img_converters.h"
#include "FS.h"
#include "SD_MMC.h"
#include <Preferences.h>
#include <math.h>

#define LGFX_USE_V1
#include <LovyanGFX.hpp>

// ============================ SCREEN PINS (match your wires) ============================
#define PIN_TFT_SCLK  41   // screen SCK   and touch T_CLK  (two wires, one GPIO)
#define PIN_TFT_MOSI  42   // screen SDI   and touch T_DIN  (two wires, one GPIO)
#define PIN_TFT_MISO  14   // touch T_OUT  (screen SDO is NOT connected)
#define PIN_TFT_DC    21
#define PIN_TFT_CS     1
#define PIN_TFT_RST    2
#define PIN_TOUCH_CS  47
#define PIN_TOUCH_IRQ -1   // -1 = poll (no wire). Use 48 if you wire T_IRQ.
#define PIN_TFT_BL    -1   // -1 = LED pin wired straight to 3V3 (then "off" is a black screen; wire the LED pin to a GPIO and put its number here for a real backlight off)
#define BOOT_SCREEN_OFF 1  // 1 = after power-up the screen stays dark until the laptop app switches it on (voice: "turn on the smart desk lamp"). 0 = show "Ready" at once

#define TFT_ROTATION      1       // 1 = landscape 320x240, 3 = landscape upside down
#define TFT_INVERT        false   // true if black and white look swapped
#define TFT_RGB_ORDER     false   // true if red and blue are swapped
#define TOUCH_OFFSET_ROT  0       // 0..7: try other values if the touch axes are swapped/mirrored
//#define PANEL_ST7789            // uncomment if your screen stays white with the ILI9341 driver
// ========================================================================================

// ---- camera + SD pins: Freenove-style ESP32-S3 WROOM CAM boards ----
#define SD_MMC_CLK 39
#define SD_MMC_CMD 38
#define SD_MMC_D0  40
#define PWDN_GPIO_NUM  -1
#define RESET_GPIO_NUM -1
#define XCLK_GPIO_NUM  15
#define SIOD_GPIO_NUM   4
#define SIOC_GPIO_NUM   5
#define Y9_GPIO_NUM    16
#define Y8_GPIO_NUM    17
#define Y7_GPIO_NUM    18
#define Y6_GPIO_NUM    12
#define Y5_GPIO_NUM    10
#define Y4_GPIO_NUM     8
#define Y3_GPIO_NUM     9
#define Y2_GPIO_NUM    11
#define VSYNC_GPIO_NUM  6
#define HREF_GPIO_NUM   7
#define PCLK_GPIO_NUM  13

// ------------------------------- TFT + touch driver -------------------------------
class LGFX : public lgfx::LGFX_Device {
#if defined(PANEL_ST7789)
  lgfx::Panel_ST7789 _panel;
#else
  lgfx::Panel_ILI9341 _panel;
#endif
  lgfx::Bus_SPI _bus;
  lgfx::Touch_XPT2046 _touch;
public:
  LGFX() {
    {
      auto cfg = _bus.config();
      cfg.spi_host    = SPI2_HOST;
      cfg.spi_mode    = 0;
      cfg.freq_write  = 20000000;   // long jumper wires: try 10000000 if the picture is noisy
      cfg.freq_read   = 8000000;
      cfg.spi_3wire   = false;
      cfg.use_lock    = true;
      cfg.dma_channel = SPI_DMA_CH_AUTO;
      cfg.pin_sclk    = PIN_TFT_SCLK;
      cfg.pin_mosi    = PIN_TFT_MOSI;
      cfg.pin_miso    = PIN_TFT_MISO;
      cfg.pin_dc      = PIN_TFT_DC;
      _bus.config(cfg);
      _panel.setBus(&_bus);
    }
    {
      auto cfg = _panel.config();
      cfg.pin_cs           = PIN_TFT_CS;
      cfg.pin_rst          = PIN_TFT_RST;
      cfg.pin_busy         = -1;
      cfg.panel_width      = 240;
      cfg.panel_height     = 320;
      cfg.offset_x         = 0;
      cfg.offset_y         = 0;
      cfg.offset_rotation  = 0;
      cfg.dummy_read_pixel = 8;
      cfg.dummy_read_bits  = 1;
      cfg.readable         = false;
      cfg.invert           = TFT_INVERT;
      cfg.rgb_order        = TFT_RGB_ORDER;
      cfg.dlen_16bit       = false;
      cfg.bus_shared       = true;    // the touch chip shares this SPI bus
      _panel.config(cfg);
    }
    {
      auto cfg = _touch.config();
      cfg.x_min           = 300;
      cfg.x_max           = 3900;
      cfg.y_min           = 200;
      cfg.y_max           = 3900;
      cfg.pin_int         = PIN_TOUCH_IRQ;
      cfg.bus_shared      = true;
      cfg.offset_rotation = TOUCH_OFFSET_ROT;
      cfg.spi_host        = SPI2_HOST;
      cfg.freq            = 1000000;
      cfg.pin_sclk        = PIN_TFT_SCLK;
      cfg.pin_mosi        = PIN_TFT_MOSI;
      cfg.pin_miso        = PIN_TFT_MISO;
      cfg.pin_cs          = PIN_TOUCH_CS;
      _touch.config(cfg);
      _panel.setTouch(&_touch);
    }
    setPanel(&_panel);
  }
};

LGFX tft;
Preferences prefs;
uint16_t calData[8];

#define MAX_TEXT    600
#define MAX_UI_JPEG 65536
static const framesize_t PREVIEW_SIZE = FRAMESIZE_QVGA;   // 320x240 = exactly the screen

bool sdOk = false;
bool jpegMode = true;    // false = sensor cannot make JPEG, the ESP32 converts
bool holdScreen = false; // true = the laptop owns the screen, previews are not drawn
uint32_t nextIndex = 1;
framesize_t photoSize   = FRAMESIZE_UXGA;
framesize_t currentSize = FRAMESIZE_UXGA;
static uint8_t *uiBuf = nullptr;

extern bool nativeActive;                       // defined in the native-menu section below
extern bool sceneActive;                        // defined in the native button screens section below
static bool readN(uint8_t *dst, size_t n);      // defined further down

// ------------------------------- live clock (fastest possible update) -------------------------------
// Black screen, big white digits, and every tick only the digit box itself is repainted (never
// tft.fillScreen over the whole 320x240) - so a 1-per-second call is instant and flicker-free.
bool clockActive = false;
char clockLast[16] = "";
int16_t clockBoxX, clockBoxY, clockBoxW, clockBoxH;

// --- native button screen types: defined BEFORE the first function, because the Arduino IDE puts the automatic
// --- function prototypes there (a prototype that mentions 'Wid' needs the type to exist already)
#define MAX_WID    96
#define MAX_WTEXT  40
#define MAX_EVT    8
enum { W_BOX = 1, W_LABEL = 2, W_BUTTON = 3 };
struct Wid {
  uint8_t  kind, radius, grad, font, align, flags, outline;
  int16_t  x, y;
  uint16_t w, h;
  uint16_t c1, c2, fg, bgc, line;
  char     text[MAX_WTEXT + 1];
};

void handleClockTime() {                   // 'H'
  nativeActive = false;
  sceneActive = false;
  uint8_t len;
  if (!readN(&len, 1)) return;
  char buf[16];
  size_t k = len > 15 ? 15 : len;
  if (k && !readN((uint8_t *)buf, k)) return;
  buf[k] = 0;
  for (size_t i = k; i < len; i++) { uint8_t d; if (!readN(&d, 1)) break; }
  holdScreen = true;

  if (!clockActive) {                      // first frame: paint the black background ONCE
    tft.fillScreen(TFT_BLACK);
    clockBoxW = 300; clockBoxH = 64;
    clockBoxX = (tft.width() - clockBoxW) / 2;
    clockBoxY = (tft.height() - clockBoxH) / 2;
    clockActive = true;
    clockLast[0] = 0;
  }
  if (strcmp(buf, clockLast) == 0) return;           // same second already shown: nothing to redraw
  strncpy(clockLast, buf, sizeof(clockLast) - 1); clockLast[sizeof(clockLast) - 1] = 0;

  tft.startWrite();
  tft.fillRect(clockBoxX, clockBoxY, clockBoxW, clockBoxH, TFT_BLACK);   // erase just the digit box
  tft.setFont(&fonts::Font4);
  tft.setTextSize(2);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextDatum(middle_center);
  tft.drawString(buf, tft.width() / 2, tft.height() / 2);
  tft.setTextDatum(top_left);
  tft.endWrite();
}

// ------------------------------- native menu (fast, no JPEG) -------------------------------
#define MAX_NBTN 10
struct NBtn {
  uint16_t x, y, w, h;
  uint16_t fillCol, fgCol;
  uint8_t  fontSize;   // 1-4
  uint8_t  flags;      // bit0 = animated (pulsing text colour)
  char     label[25];
};
NBtn nbtn[MAX_NBTN];
uint8_t nbtnCount = 0;
bool nativeActive = false;
char nTitle[49] = "";
uint16_t nTitleCol = 0, nBg = 0;
uint8_t nTitleFontSize = 2, nTitleFlags = 0;
uint32_t nAnimPhase = 0, nLastAnim = 0;

void applyFontSize(uint8_t sz) {           // 4 simple sizes built from 2 GFX fonts
  switch (sz) {
    case 1: tft.setFont(&fonts::Font2); tft.setTextSize(1); break;
    case 3: tft.setFont(&fonts::Font4); tft.setTextSize(1); break;
    case 4: tft.setFont(&fonts::Font4); tft.setTextSize(2); break;
    default: tft.setFont(&fonts::Font2); tft.setTextSize(2); break;   // 2 = default
  }
}

uint16_t pulseColor(uint16_t col, float k) {   // k = 0.0..1.0 brightness
  uint8_t r5 = (col >> 11) & 0x1F, g6 = (col >> 5) & 0x3F, b5 = col & 0x1F;
  return tft.color565((uint8_t)(r5 * 8 * k), (uint8_t)(g6 * 4 * k), (uint8_t)(b5 * 8 * k));
}

uint16_t lightenColor565(uint16_t col, float amt) {   // amt 0.0..1.0 -> blend toward white
  uint8_t r5 = (col >> 11) & 0x1F, g6 = (col >> 5) & 0x3F, b5 = col & 0x1F;
  float r = r5 * 8, g = g6 * 4, b = b5 * 8;
  r += (255 - r) * amt; g += (255 - g) * amt; b += (255 - b) * amt;
  return tft.color565((uint8_t)r, (uint8_t)g, (uint8_t)b);
}

// Flat glossy "app button" look: a full pill (or circle, for small square buttons) with a
// lighter sheen band across the top third, matching simple mobile-game-style button art.
void drawNBtnBox(uint8_t i) {
  NBtn &b = nbtn[i];
  uint16_t rad = (b.w < b.h ? b.w : b.h) / 2;
  tft.fillRoundRect(b.x, b.y, b.w, b.h, rad, b.fillCol);
  int sx = b.x + (int)(b.w * 0.12f), sw = (int)(b.w * 0.76f);
  int sy = b.y + (int)(b.h * 0.08f), sh = (int)(b.h * 0.34f);
  if (sw > 3 && sh > 3) {
    tft.fillRoundRect(sx, sy, sw, sh, sh / 2, lightenColor565(b.fillCol, 0.5f));
  }
  tft.drawRoundRect(b.x, b.y, b.w, b.h, rad, TFT_WHITE);
}

void drawNBtnLabel(uint8_t i, uint16_t col) {
  NBtn &b = nbtn[i];
  applyFontSize(b.fontSize);
  tft.setTextColor(col, b.fillCol);
  tft.setTextDatum(middle_center);
  tft.drawString(b.label, b.x + b.w / 2, b.y + b.h / 2);
  tft.setTextDatum(top_left);
}

void drawNTitle(uint16_t col) {
  applyFontSize(nTitleFontSize);
  tft.setTextColor(col, nBg);
  tft.setTextDatum(top_left);
  tft.drawString(nTitle, 4, 4);
}

void animateNative() {
  if (!nativeActive || millis() - nLastAnim < 90) return;
  nLastAnim = millis();
  nAnimPhase++;
  float k = 0.55f + 0.45f * (0.5f + 0.5f * sinf(nAnimPhase * 0.18f));
  if (nTitleFlags & 0x01) drawNTitle(pulseColor(nTitleCol, k));
  for (uint8_t i = 0; i < nbtnCount; i++) {
    if (nbtn[i].flags & 0x01) drawNBtnLabel(i, pulseColor(nbtn[i].fgCol, k));
  }
}

// ------------------------------- TFT helpers -------------------------------
void initTFT() {
  if (PIN_TFT_BL >= 0) { pinMode(PIN_TFT_BL, OUTPUT); digitalWrite(PIN_TFT_BL, HIGH); }
  tft.init();
  tft.setRotation(TFT_ROTATION);
  tft.fillScreen(TFT_BLACK);
  prefs.begin("lamp", true);
  size_t n = prefs.getBytes("cal", calData, sizeof(calData));
  prefs.end();
  if (n == sizeof(calData)) tft.setTouchCalibrate(calData);
}

void showTextPage(const String &msg) {
  int nl = msg.indexOf('\n');
  String title = (nl >= 0) ? msg.substring(0, nl) : msg;
  String body  = (nl >= 0) ? msg.substring(nl + 1) : String("");
  tft.fillScreen(TFT_BLACK);
  tft.setFont(&fonts::Font2);
  tft.setTextWrap(true, false);
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  tft.setCursor(4, 4);
  tft.print(title);
  tft.drawFastHLine(0, 24, tft.width(), tft.color565(90, 90, 90));
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setCursor(4, 30);
  tft.print(body);
}

// small "< BACK" tag on live preview frames (tapping that corner = back in the app)
void drawBackHint() {
  tft.fillRect(0, 0, 58, 22, TFT_BLACK);
  tft.drawRect(0, 0, 58, 22, TFT_YELLOW);
  tft.setFont(&fonts::Font2);
  tft.setTextColor(TFT_YELLOW, TFT_BLACK);
  tft.setCursor(5, 3);
  tft.print("< BACK");
}

static bool readN(uint8_t *dst, size_t n) { return Serial.readBytes(dst, n) == n; }

void handleText() {
  nativeActive = false;
  sceneActive = false;
  clockActive = false;
  uint8_t hdr[2];
  if (!readN(hdr, 2)) return;
  size_t n = hdr[0] | (hdr[1] << 8);
  size_t keep = n > MAX_TEXT ? MAX_TEXT : n;
  static char buf[MAX_TEXT + 1];
  size_t got = Serial.readBytes(buf, keep);
  buf[got] = 0;
  for (size_t i = keep; i < n; i++) { uint8_t d; if (!readN(&d, 1)) break; }  // drop the rest
  showTextPage(String(buf));
}

void handleNativeMenu() {                  // 'N' - colour boxes drawn directly, no JPEG at all
  nativeActive = false;
  sceneActive = false;                    // stop animating the old menu while this one loads
  clockActive = false;
  uint8_t bg[3];
  if (!readN(bg, 3)) return;
  nBg = tft.color565(bg[0], bg[1], bg[2]);

  uint8_t tlen;
  if (!readN(&tlen, 1)) return;
  size_t tk = tlen > 48 ? 48 : tlen;
  if (tk && !readN((uint8_t *)nTitle, tk)) return;
  nTitle[tk] = 0;
  for (size_t i = tk; i < tlen; i++) { uint8_t d; if (!readN(&d, 1)) break; }

  uint8_t tc[3];
  if (!readN(tc, 3)) return;
  nTitleCol = tft.color565(tc[0], tc[1], tc[2]);
  if (!readN(&nTitleFontSize, 1)) return;
  if (!readN(&nTitleFlags, 1)) return;

  uint8_t count;
  if (!readN(&count, 1)) return;
  uint8_t keep = count > MAX_NBTN ? MAX_NBTN : count;
  for (uint8_t i = 0; i < count; i++) {
    uint8_t geo[8];
    if (!readN(geo, 8)) return;
    uint8_t fc[3], gc[3], fs, fl, ll;
    if (!readN(fc, 3) || !readN(gc, 3) || !readN(&fs, 1) || !readN(&fl, 1) || !readN(&ll, 1)) return;
    char lbuf[25];
    size_t lk = ll > 24 ? 24 : ll;
    if (lk && !readN((uint8_t *)lbuf, lk)) return;
    lbuf[lk] = 0;
    for (size_t k = lk; k < ll; k++) { uint8_t d; if (!readN(&d, 1)) break; }
    if (i < keep) {
      NBtn &b = nbtn[i];
      b.x = geo[0] | (geo[1] << 8); b.y = geo[2] | (geo[3] << 8);
      b.w = geo[4] | (geo[5] << 8); b.h = geo[6] | (geo[7] << 8);
      b.fillCol = tft.color565(fc[0], fc[1], fc[2]);
      b.fgCol   = tft.color565(gc[0], gc[1], gc[2]);
      b.fontSize = fs; b.flags = fl;
      strncpy(b.label, lbuf, sizeof(b.label) - 1); b.label[sizeof(b.label) - 1] = 0;
    }
  }
  nbtnCount = keep;
  holdScreen = true;

  tft.startWrite();
  tft.fillScreen(nBg);
  drawNTitle(nTitleCol);
  for (uint8_t i = 0; i < nbtnCount; i++) {
    drawNBtnBox(i);
    drawNBtnLabel(i, nbtn[i].fgCol);
  }
  tft.endWrite();
  nAnimPhase = 0;
  nLastAnim = millis();
  nativeActive = true;                     // loop() now keeps the pulsing buttons alive on its own
}


// ============================ NATIVE BUTTON SCREENS (v15) ============================
// The laptop describes a screen as a short list of boxes, labels and buttons (a few hundred bytes).
// The board draws them itself with plain rectangles and text - no JPEG, no picture decoding - and
// reacts to the finger on its own: a pressed button changes colour within a few milliseconds, the tap
// is remembered and the laptop picks it up with 'E'. Changing one text ('U') repaints only that widget.
Wid wid[MAX_WID];
uint8_t widCount = 0;
bool sceneActive = false;
uint8_t sceneGen = 0, sceneTouchFlags = 0;
uint16_t sceneBg = 0;
int8_t pressedIdx = -1;
bool fingerDown = false;
uint8_t touchMiss = 0;
uint32_t lastTouchPoll = 0, lastSpin = 0;
uint8_t spinPhase = 0;
uint8_t evtQ[MAX_EVT][2];
uint8_t evtN = 0;

uint16_t rgb565(const uint8_t *c) { return tft.color565(c[0], c[1], c[2]); }

uint16_t mix565(uint16_t a, uint16_t b, float t) {          // t = 0 -> a, 1 -> b
  float ar = ((a >> 11) & 0x1F) * 8, ag = ((a >> 5) & 0x3F) * 4, ab = (a & 0x1F) * 8;
  float br = ((b >> 11) & 0x1F) * 8, bg = ((b >> 5) & 0x3F) * 4, bb = (b & 0x1F) * 8;
  return tft.color565((uint8_t)(ar + (br - ar) * t), (uint8_t)(ag + (bg - ag) * t), (uint8_t)(ab + (bb - ab) * t));
}

void useFont(uint8_t f) {
  switch (f) {
    case 1:  tft.setFont(&fonts::DejaVu9);  break;
    case 3:  tft.setFont(&fonts::DejaVu18); break;
    case 4:  tft.setFont(&fonts::DejaVu24); break;
    case 5:  tft.setFont(&fonts::DejaVu40); break;
    default: tft.setFont(&fonts::DejaVu12); break;
  }
}

// a rounded box filled with a gradient: the same round rect is painted in a few clipped bands
void fillGrad(int x, int y, int w, int h, int r, uint16_t c1, uint16_t c2, uint8_t grad) {
  if (r > w / 2) r = w / 2;
  if (r > h / 2) r = h / 2;
  if (grad == 0 || c1 == c2) { tft.fillRoundRect(x, y, w, h, r, c1); return; }
  int steps = (grad == 1) ? (h >= 40 ? 6 : 4) : (w >= 120 ? 8 : 5);
  for (int i = 0; i < steps; i++) {
    uint16_t col = mix565(c1, c2, steps > 1 ? (float)i / (steps - 1) : 0);
    if (grad == 1) { int y0 = y + h * i / steps, y1 = y + h * (i + 1) / steps; tft.setClipRect(x, y0, w, y1 - y0); }
    else           { int x0 = x + w * i / steps, x1 = x + w * (i + 1) / steps; tft.setClipRect(x0, y, x1 - x0, h); }
    tft.fillRoundRect(x, y, w, h, r, col);
  }
  tft.clearClipRect();
}

void drawLabelText(const Wid &d, uint16_t bgcol) {
  useFont(d.font);
  tft.setTextColor(d.fg, bgcol);
  int tx = d.x, ty = d.y + d.h / 2;
  switch (d.align) {
    case 1:  tft.setTextDatum(middle_center); tx = d.x + d.w / 2; break;
    case 2:  tft.setTextDatum(middle_right);  tx = d.x + d.w;     break;
    default: tft.setTextDatum(middle_left);   break;
  }
  tft.drawString(d.text, tx, ty);
  tft.setTextDatum(top_left);
}

void drawWid(uint8_t i, bool pressed) {
  Wid &d = wid[i];
  if (d.kind == W_BOX) {
    fillGrad(d.x, d.y, d.w, d.h, d.radius, d.c1, d.c2, d.grad);
    if (d.outline) tft.drawRoundRect(d.x, d.y, d.w, d.h, d.radius, d.line);
  } else if (d.kind == W_LABEL) {
    tft.fillRect(d.x, d.y, d.w, d.h, d.bgc);
    drawLabelText(d, d.bgc);
  } else if (d.kind == W_BUTTON) {
    if (d.flags & 0x04) return;                                  // invisible hit area
    bool en = d.flags & 0x01;
    uint16_t a = d.c1, b = d.c2, f = d.fg;
    if (!en) { a = mix565(a, sceneBg, 0.65f); b = mix565(b, sceneBg, 0.65f); f = mix565(f, sceneBg, 0.45f); }
    else if (pressed) { a = mix565(a, 0, 0.30f); b = mix565(b, 0, 0.30f); }
    fillGrad(d.x, d.y, d.w, d.h, d.radius, a, b, d.grad);
    if (d.outline) tft.drawRoundRect(d.x, d.y, d.w, d.h, d.radius, d.line);
    useFont(d.font);
    tft.setTextColor(f);
    tft.setTextDatum(middle_center);
    tft.drawString(d.text, d.x + d.w / 2, d.y + d.h / 2);
    tft.setTextDatum(top_left);
  }
}

void drawScene() {
  tft.startWrite();
  tft.fillScreen(sceneBg);
  for (uint8_t i = 0; i < widCount; i++) drawWid(i, false);
  tft.endWrite();
}

int hitButton(int x, int y, int slack) {
  for (int i = widCount - 1; i >= 0; i--) {
    Wid &d = wid[i];
    if (d.kind != W_BUTTON || !(d.flags & 0x01)) continue;
    if (x >= d.x - slack && x < d.x + d.w + slack && y >= d.y - slack && y < d.y + d.h + slack) return i;
  }
  return -1;
}

bool inButton(int i, int x, int y, int slack) {
  Wid &d = wid[i];
  return x >= d.x - slack && x < d.x + d.w + slack && y >= d.y - slack && y < d.y + d.h + slack;
}

void queueEvent(uint8_t id) {
  if (evtN < MAX_EVT) { evtQ[evtN][0] = sceneGen; evtQ[evtN][1] = id; evtN++; }
}

void drawSpinners() {                                            // 8 dots chasing round: "working..."
  for (uint8_t i = 0; i < widCount; i++) {
    Wid &d = wid[i];
    if (d.kind != W_BUTTON || !(d.flags & 0x02) || (d.flags & 0x04)) continue;
    useFont(d.font);
    int tw = tft.textWidth(d.text);
    int cx = d.x + d.w / 2 - tw / 2 - 12, cy = d.y + d.h / 2;
    if (cx < d.x + 10) cx = d.x + 10;
    for (uint8_t k = 0; k < 8; k++) {
      float ang = k * 0.7854f;
      uint8_t age = (spinPhase + 8 - k) & 7;
      uint16_t col = mix565(d.c2, d.fg, 1.0f - age * 0.12f);
      tft.fillCircle(cx + (int)(7 * cosf(ang)), cy + (int)(7 * sinf(ang)), 2, col);
    }
  }
}

void uiTick() {                                                  // called all the time from loop()
  if (!sceneActive) return;
  uint32_t now = millis();
  if (now - lastSpin >= 90) { lastSpin = now; spinPhase++; drawSpinners(); }
  if (now - lastTouchPoll < 8) return;
  lastTouchPoll = now;
  int32_t x = 0, y = 0;
  bool down = tft.getTouch(&x, &y) > 0;
  if (down) {
    if (sceneTouchFlags & 4) { int32_t t = x; x = y; y = t; }
    if (sceneTouchFlags & 1) x = tft.width() - 1 - x;
    if (sceneTouchFlags & 2) y = tft.height() - 1 - y;
    touchMiss = 0;
    if (!fingerDown) {
      fingerDown = true;
      pressedIdx = (int8_t)hitButton(x, y, 3);
      if (pressedIdx >= 0) drawWid(pressedIdx, true);            // pressed colour at once
    } else if (pressedIdx >= 0 && !inButton(pressedIdx, x, y, 9)) {
      drawWid(pressedIdx, false);                                // finger slid off: cancel the tap
      pressedIdx = -1;
    }
  } else if (fingerDown && ++touchMiss >= 2) {                   // one empty reading is only noise
    fingerDown = false; touchMiss = 0;
    if (pressedIdx >= 0) {
      drawWid(pressedIdx, false);
      queueEvent(pressedIdx);
      pressedIdx = -1;
    }
  }
}

static void skipBytes(uint32_t n) { uint8_t d; while (n--) if (!readN(&d, 1)) break; }

void handleScene() {                                             // 'S'
  nativeActive = false; clockActive = false;
  uint8_t h[2];
  if (!readN(h, 2)) return;
  uint32_t n = h[0] | (h[1] << 8);
  static uint8_t buf[8192];
  if (n < 8 || n > sizeof(buf)) { skipBytes(n); return; }
  if (Serial.readBytes(buf, n) != n) return;
  const uint8_t *p = buf, *end = buf + n;
  sceneGen = p[0]; sceneTouchFlags = p[1];
  sceneBg = rgb565(p + 2);
  uint8_t count = p[5];
  p += 6;
  uint8_t kept = 0;
  for (uint8_t i = 0; i < count; i++) {
    if (end - p < 9) break;
    Wid d;
    memset(&d, 0, sizeof(d));
    d.kind = p[0];
    d.x = (int16_t)(p[1] | (p[2] << 8)); d.y = (int16_t)(p[3] | (p[4] << 8));
    d.w = p[5] | (p[6] << 8);            d.h = p[7] | (p[8] << 8);
    p += 9;
    uint8_t len = 0;
    if (d.kind == W_BOX) {
      if (end - p < 12) break;
      d.radius = p[0]; d.c1 = rgb565(p + 1); d.c2 = rgb565(p + 4); d.grad = p[7]; d.outline = p[8]; d.line = rgb565(p + 9);
      p += 12;
    } else if (d.kind == W_LABEL) {
      if (end - p < 10) break;
      d.fg = rgb565(p); d.bgc = rgb565(p + 3); d.font = p[6]; d.align = p[7]; len = p[8];
      p += 9;
    } else if (d.kind == W_BUTTON) {
      if (end - p < 17) break;
      d.radius = p[0]; d.c1 = rgb565(p + 1); d.c2 = rgb565(p + 4); d.grad = p[7]; d.fg = rgb565(p + 8);
      d.font = p[11]; d.flags = p[12]; d.outline = 1; d.line = rgb565(p + 13); len = p[16];
      p += 17;
    } else break;
    if (len) {
      if (end - p < len) break;
      size_t k = len > MAX_WTEXT ? MAX_WTEXT : len;
      memcpy(d.text, p, k); d.text[k] = 0;
      p += len;
    }
    if (kept < MAX_WID) wid[kept++] = d;
  }
  widCount = kept;
  evtN = 0; pressedIdx = -1; fingerDown = false; touchMiss = 0;
  holdScreen = true;
  drawScene();
  sceneActive = true;
}

void handleUpdate() {                                            // 'U' - repaint just one widget
  uint8_t h[3];
  if (!readN(h, 3)) return;
  char t[MAX_WTEXT + 1];
  size_t k = h[2] > MAX_WTEXT ? MAX_WTEXT : h[2];
  if (k && Serial.readBytes((uint8_t *)t, k) != k) return;
  t[k] = 0;
  skipBytes(h[2] - k);
  if (!sceneActive || h[0] >= widCount) return;
  Wid &d = wid[h[0]];
  if (d.kind == W_LABEL) {
    if (strcmp(d.text, t) == 0) return;
    strcpy(d.text, t);
    tft.startWrite(); drawWid(h[0], false); tft.endWrite();
  } else if (d.kind == W_BUTTON) {
    if (strcmp(d.text, t) == 0 && d.flags == h[1]) return;
    strcpy(d.text, t); d.flags = h[1];
    tft.startWrite(); drawWid(h[0], pressedIdx == h[0]); tft.endWrite();
  }
}

void handleEvents() {                                            // 'E'
  uint8_t out[4 + 1 + MAX_EVT * 2];
  memcpy(out, "EVT!", 4);
  out[4] = evtN;
  for (uint8_t i = 0; i < evtN; i++) { out[5 + i * 2] = evtQ[i][0]; out[6 + i * 2] = evtQ[i][1]; }
  Serial.write(out, 5 + evtN * 2);
  evtN = 0;
}

void handleImage() {                       // 'J'
  nativeActive = false;
  sceneActive = false;
  clockActive = false;
  uint8_t h[4];
  if (!readN(h, 4)) return;
  uint32_t n = h[0] | (h[1] << 8) | (h[2] << 16) | ((uint32_t)h[3] << 24);
  if (!uiBuf) uiBuf = (uint8_t *)ps_malloc(MAX_UI_JPEG);
  if (!uiBuf) uiBuf = (uint8_t *)malloc(MAX_UI_JPEG);
  if (!uiBuf || n == 0 || n > MAX_UI_JPEG) {   // cannot keep it: read and throw away
    uint8_t d;
    for (uint32_t i = 0; i < n; i++) if (!readN(&d, 1)) break;
    return;
  }
  if (Serial.readBytes(uiBuf, n) == n) tft.drawJpg(uiBuf, n, 0, 0);
}

void handleLine() {                        // 'L' (handwriting ink keeps the native menu's animation paused)
  nativeActive = false;
  sceneActive = false;
  clockActive = false;
  uint8_t b[12];
  if (!readN(b, 12)) return;
  int16_t x0 = (int16_t)(b[0] | (b[1] << 8)), y0 = (int16_t)(b[2] | (b[3] << 8));
  int16_t x1 = (int16_t)(b[4] | (b[5] << 8)), y1 = (int16_t)(b[6] | (b[7] << 8));
  uint32_t col = tft.color565(b[8], b[9], b[10]);
  float r = b[11] / 2.0f;
  if (r < 1) r = 1;
  tft.fillCircle(x0, y0, (int)r, col);
  tft.drawWideLine(x0, y0, x1, y1, r, col);
  tft.fillCircle(x1, y1, (int)r, col);
}

void handleClear() {                       // 'K'
  nativeActive = false;
  sceneActive = false;
  clockActive = false;
  uint8_t c[3];
  if (!readN(c, 3)) return;
  tft.fillScreen(tft.color565(c[0], c[1], c[2]));
}

void handleTouch() {                       // 'X'
  int32_t x = 0, y = 0;
  bool pressed = tft.getTouch(&x, &y) > 0;
  if (!pressed) { x = 0; y = 0; }
  uint8_t out[9] = {'T', 'C', 'H', '!', (uint8_t)(pressed ? 1 : 0),
                    (uint8_t)(x & 0xFF), (uint8_t)((x >> 8) & 0xFF),
                    (uint8_t)(y & 0xFF), (uint8_t)((y >> 8) & 0xFF)};
  Serial.write(out, sizeof(out));
}

void handleCalibrate() {                   // 'Z'
  nativeActive = false;
  sceneActive = false;
  clockActive = false;
  tft.fillScreen(TFT_BLACK);
  tft.setFont(&fonts::Font2);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setCursor(30, 110);
  tft.print("Touch the tip of each arrow");
  delay(1200);
  tft.calibrateTouch(calData, TFT_WHITE, TFT_BLACK, 15);
  prefs.begin("lamp", false);
  prefs.putBytes("cal", calData, sizeof(calData));
  prefs.end();
  tft.fillScreen(TFT_BLACK);
  Serial.write((const uint8_t *)"CAL!", 4);
}

// ------------------------------- SD card -------------------------------
bool initSD() {
  SD_MMC.setPins(SD_MMC_CLK, SD_MMC_CMD, SD_MMC_D0);
  if (!SD_MMC.begin("/sdcard", true)) return false;   // 1-bit mode
  return SD_MMC.cardType() != CARD_NONE;
}

uint32_t findNextIndex() {
  uint32_t maxIdx = 0;
  File root = SD_MMC.open("/");
  if (!root) return 1;
  File f = root.openNextFile();
  while (f) {
    String n = f.name();
    int a = n.indexOf("img_");
    if (a >= 0) {
      uint32_t v = (uint32_t)n.substring(a + 4).toInt();
      if (v > maxIdx) maxIdx = v;
    }
    f.close();
    f = root.openNextFile();
  }
  root.close();
  return maxIdx + 1;
}

void saveToSD(const uint8_t *buf, size_t len) {
  if (!sdOk) return;
  char path[32];
  snprintf(path, sizeof(path), "/img_%05lu.jpg", (unsigned long)nextIndex);
  File f = SD_MMC.open(path, FILE_WRITE);
  if (!f) return;
  f.write(buf, len);
  f.close();
  nextIndex++;
}

// ------------------------------- camera -------------------------------
static void fillConfig(camera_config_t &config, bool jpeg, framesize_t rgbSize) {
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer   = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk  = XCLK_GPIO_NUM;
  config.pin_pclk  = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href  = HREF_GPIO_NUM;
  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn  = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.grab_mode    = CAMERA_GRAB_LATEST;

  if (jpeg) {
    config.pixel_format = PIXFORMAT_JPEG;
    if (psramFound()) {
      config.frame_size = FRAMESIZE_UXGA; config.jpeg_quality = 10;
      config.fb_count = 2; config.fb_location = CAMERA_FB_IN_PSRAM;
    } else {
      config.frame_size = FRAMESIZE_SVGA; config.jpeg_quality = 12;
      config.fb_count = 1; config.fb_location = CAMERA_FB_IN_DRAM;
    }
  } else {
    config.pixel_format = PIXFORMAT_RGB565;   // sensors like the GC2145: raw picture, converted here
    config.frame_size   = rgbSize;
    config.jpeg_quality = 12;
    config.fb_count     = 1;
    config.fb_location  = psramFound() ? CAMERA_FB_IN_PSRAM : CAMERA_FB_IN_DRAM;
  }
}

void applySensorSettings(bool announce) {
  sensor_t *s = esp_camera_sensor_get();
  if (!s) return;
  if (announce) Serial.printf("CAMERA_OK MODE=%s PID=0x%x\n", jpegMode ? "JPEG" : "RGB565", s->id.PID);
  // Picture upside down or mirrored? Uncomment what you need:
  // s->set_vflip(s, 1);
  // s->set_hmirror(s, 1);
}

bool initCamera() {
  camera_config_t config;
  memset(&config, 0, sizeof(config));
  fillConfig(config, true, PREVIEW_SIZE);
  esp_err_t err = esp_camera_init(&config);
  if (err == ESP_OK) {
    jpegMode = true;
  } else {
    Serial.printf("CAM_ERR 0x%x in JPEG mode, trying RGB565 mode...\n", err);
    esp_camera_deinit();
    memset(&config, 0, sizeof(config));
    fillConfig(config, false, PREVIEW_SIZE);
    err = esp_camera_init(&config);
    if (err != ESP_OK) { Serial.printf("CAM_ERR 0x%x\n", err); return false; }
    jpegMode = false;
  }
  currentSize = config.frame_size;
  photoSize = jpegMode ? config.frame_size : (psramFound() ? FRAMESIZE_SXGA : FRAMESIZE_VGA);
  applySensorSettings(true);
  return true;
}

bool restartRawCamera(framesize_t fs) {      // raw sensors cannot change size on the fly
  esp_camera_deinit();
  camera_config_t config;
  memset(&config, 0, sizeof(config));
  fillConfig(config, false, fs);
  if (esp_camera_init(&config) != ESP_OK) return false;
  currentSize = fs;
  applySensorSettings(false);
  for (int i = 0; i < 3; i++) { camera_fb_t *t = esp_camera_fb_get(); if (t) esp_camera_fb_return(t); }
  return true;
}

bool setFrameSize(framesize_t fs, int flushFrames) {
  if (fs == currentSize) return true;
  if (!jpegMode) return restartRawCamera(fs);
  sensor_t *s = esp_camera_sensor_get();
  if (!s) return false;
  s->set_framesize(s, fs);
  currentSize = fs;
  for (int i = 0; i < flushFrames; i++) { camera_fb_t *t = esp_camera_fb_get(); if (t) esp_camera_fb_return(t); }
  return true;
}

// RGB565 -> JPEG into a growing buffer (the built-in helper stops at 128 KB)
struct JpgBuf { uint8_t *buf; size_t len; size_t cap; bool failed; };

static size_t jpgCollect(void *arg, size_t index, const void *data, size_t len) {
  JpgBuf *b = (JpgBuf *)arg;
  if (index == 0) b->len = 0;
  if (b->failed) return len;
  if (b->len + len > b->cap) {
    size_t newCap = b->cap ? b->cap : 65536;
    while (newCap < b->len + len) newCap *= 2;
    uint8_t *nb = (uint8_t *)heap_caps_realloc(b->buf, newCap, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!nb) nb = (uint8_t *)realloc(b->buf, newCap);
    if (!nb) { b->failed = true; return len; }
    b->buf = nb; b->cap = newCap;
  }
  memcpy(b->buf + b->len, data, len);
  b->len += len;
  return len;
}

bool rgbToJpeg(camera_fb_t *fb, uint8_t quality, uint8_t **outBuf, size_t *outLen) {
  JpgBuf b = {nullptr, 0, 0, false};
  bool ok = frame2jpg_cb(fb, quality, jpgCollect, &b);
  if (!ok || b.failed || b.len == 0) { if (b.buf) free(b.buf); return false; }
  *outBuf = b.buf; *outLen = b.len;
  return true;
}

uint32_t lastLaptopCam = 0;   // millis() of the last picture the laptop took (the camera box rests while it does)

void captureAndSend(bool preview) {
  lastLaptopCam = millis();
  bool sizeOk = preview ? setFrameSize(PREVIEW_SIZE, 1) : setFrameSize(photoSize, 3);
  if (!sizeOk) { Serial.write((const uint8_t *)"ERR!", 4); return; }
  if (!preview) {                              // drop stale frames: fresh, well exposed photo
    for (int i = 0; i < 2; i++) { camera_fb_t *t = esp_camera_fb_get(); if (t) esp_camera_fb_return(t); }
  }
  camera_fb_t *fb = esp_camera_fb_get();
  if (!fb) { Serial.write((const uint8_t *)"ERR!", 4); return; }

  const uint8_t *out = fb->buf;
  size_t outLen = fb->len;
  uint8_t *converted = nullptr;
  const int frameW = fb->width, frameH = fb->height;

  if (!jpegMode) {
    size_t cl = 0;
    if (!rgbToJpeg(fb, preview ? 50 : 85, &converted, &cl)) {
      esp_camera_fb_return(fb);
      Serial.write((const uint8_t *)"ERR!", 4);
      return;
    }
    out = converted; outLen = cl;
    esp_camera_fb_return(fb);   // give the buffer back BEFORE sending (driver warnings would corrupt the stream)
    fb = nullptr;
  }

  if (!preview) saveToSD(out, outLen);

  uint32_t len = (uint32_t)outLen;
  Serial.write((const uint8_t *)"IMG!", 4);
  Serial.write((const uint8_t *)&len, 4);
  size_t sent = 0;
  while (sent < len) {
    size_t n = len - sent;
    if (n > 1024) n = 1024;
    Serial.write(out + sent, n);
    sent += n;
  }
  Serial.flush();

  if (!holdScreen) {
    if (preview) {
      tft.drawJpg(out, outLen, 0, 0, tft.width(), tft.height());
      drawBackHint();
    } else {
      tft.drawJpg(out, outLen, 0, 0, tft.width(), tft.height(), 0, 0,
                  (float)tft.width() / frameW, (float)tft.height() / frameH);
    }
  }
  if (converted) free(converted);
  if (fb) esp_camera_fb_return(fb);
}


// ------------------------------- screen on / off (v17) -------------------------------
bool displayOff = false;

void setDisplay(bool on) {
  if (PIN_TFT_BL >= 0) digitalWrite(PIN_TFT_BL, on ? HIGH : LOW);
  if (!on) {
    displayOff = true;
    nativeActive = false; clockActive = false; sceneActive = false; fingerDown = false; pressedIdx = -1;
    tft.fillScreen(0);
  } else {
    displayOff = false;
    showTextPage("Smart Desk Lamp\nStarting...");        // a first sign of life; the laptop draws the interface right after
  }
}

void handleDisplay() {                     // 'D'
  uint8_t m;
  if (readN(&m, 1)) setDisplay(m != 0);
}

// ------------------------------- always-on camera box (v16) -------------------------------
// A small live picture of the camera in one corner of the screen, drawn by the board alone (no serial traffic).
bool camBoxOn = false;
int16_t camX = 0, camY = 0;
uint16_t camW = 0, camH = 0, camMs = 200;
uint32_t lastCamBox = 0;

void handleCamBox() {                      // 'B'
  uint8_t h[10];
  if (!readN(h, 10)) return;
  camX = (int16_t)(h[0] | (h[1] << 8)); camY = (int16_t)(h[2] | (h[3] << 8));
  camW = h[4] | (h[5] << 8);            camH = h[6] | (h[7] << 8);
  camMs = h[8] | (h[9] << 8);
  if (camMs < 80) camMs = 80;
  camBoxOn = camW >= 16 && camH >= 12;
  lastCamBox = 0;
}

void camBoxTick() {
  if (!camBoxOn || displayOff || fingerDown || evtN > 0) return;                  // never delay a finger
  uint32_t now = millis();
  if (now - lastCamBox < camMs || now - lastLaptopCam < 400) return;   // the laptop is using the camera right now
  lastCamBox = now;
  if (currentSize != PREVIEW_SIZE && !setFrameSize(PREVIEW_SIZE, 1)) return;
  camera_fb_t *fb = esp_camera_fb_get();
  if (!fb) return;
  const uint8_t *src = fb->buf;
  size_t len = fb->len;
  uint8_t *converted = nullptr;
  const int fw = fb->width, fh = fb->height;
  if (!jpegMode) {                                                  // raw sensor: make a small JPEG first
    size_t cl = 0;
    bool ok = rgbToJpeg(fb, 40, &converted, &cl);
    esp_camera_fb_return(fb);
    fb = nullptr;
    if (!ok) return;
    src = converted; len = cl;
  }
  tft.startWrite();
  tft.drawJpg(src, len, camX, camY, camW, camH, 0, 0, (float)camW / fw, (float)camH / fh);
  tft.drawRect(camX - 1, camY - 1, camW + 2, camH + 2, 0xFFFF);     // thin white frame
  tft.endWrite();
  if (converted) free(converted);
  if (fb) esp_camera_fb_return(fb);
}

// -------------------------------- main --------------------------------
void setup() {
  esp_log_level_set("*", ESP_LOG_NONE);   // keep log text out of the USB data stream
  Serial.setRxBufferSize(4096);           // room for pictures sent by the laptop
  Serial.begin(115200);
  Serial.setTimeout(500);
  unsigned long t0 = millis();
  while (!Serial && millis() - t0 < 3000) delay(10);

  initTFT();
  showTextPage("Smart Desk Lamp\nStarting camera...");

  if (!initCamera()) {
    showTextPage("CAMERA ERROR\nCheck the PSRAM setting and that the camera ribbon cable is fully inserted.");
    while (true) { Serial.println("CAMERA_INIT_FAILED"); delay(2000); }
  }
  sdOk = initSD();
  if (sdOk) nextIndex = findNextIndex();

  if (BOOT_SCREEN_OFF) setDisplay(false);
  else showTextPage("Smart Desk Lamp\nReady.\nStart the Python app on the laptop.");
  Serial.printf("READY SD=%d\n", sdOk ? 1 : 0);
}

void loop() {
  if (Serial.available()) {
    char c = (char)Serial.read();
    switch (c) {
      case 'V': captureAndSend(true);  break;
      case 'C': captureAndSend(false); break;
      case 'X': handleTouch();         break;
      case 'J': handleImage();         break;
      case 'T': handleText();          break;
      case 'L': handleLine();          break;
      case 'K': handleClear();         break;
      case 'Z': handleCalibrate();     break;
      case 'N': handleNativeMenu();    break;
      case 'H': handleClockTime();     break;
      case 'S': handleScene();         break;
      case 'U': handleUpdate();        break;
      case 'E': handleEvents();        break;
      case 'B': handleCamBox();        break;
      case 'D': handleDisplay();       break;
      case 'M': { uint8_t m; if (readN(&m, 1)) { holdScreen = (m != 0); if (!holdScreen) { nativeActive = false; clockActive = false; sceneActive = false; } } } break;
      case 'P': Serial.printf("PONG SD=%d TOUCH=1 UI=1 CB=1 DP=1\n", sdOk ? 1 : 0); break;
      default: break;
    }
  } else {
    animateNative();    // local, zero-traffic "breathing" buttons - keeps the screen feeling alive
    delay(1);
  }
  uiTick();             // native button screens: finger -> instant pressed colour -> tap kept for the laptop
  camBoxTick();         // always-on camera box (skipped while a finger is on the screen)
}
