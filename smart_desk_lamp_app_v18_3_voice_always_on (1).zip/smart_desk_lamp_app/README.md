# Smart Desk Lamp app  (full-screen interface)

Double-click **Install first time.bat** once, then use the **Smart Desk Lamp** shortcut on the desktop.
The lamp port is found automatically. The app opens full size; **F11** = true full screen.
It also works without the lamp (clock, calculator, translator, read-aloud, Spotify, ERP, "Open picture..." for OCR):
`python -m lamp_app --no-lamp`.

## What is on the dashboard
| Tile | What it does |
|---|---|
| India Standard Time | live IST clock (digital + analog), 12/24-hour switch, can say the time |
| Spotify | opens the Spotify app (or web player), search, prev / play-pause / next, volume (Windows media keys) |
| Read text | lamp photo or any picture -> OCR -> read aloud, translate, search, copy, save |
| Read aloud | big-text reader for low vision (pyttsx3), speed slider, last scanned text |
| Translator | instant translation as you type (deep-translator); also used by Read text / QR / Handwriting |
| QR scanner | automatic scan of the live picture, outline drawn on the code, open link |
| Cube solver | scan 6 faces, review what was understood, step-by-step solution |
| Handwriting | write with mouse/pen/finger, OCR reads it, sums are solved |
| Calculator | keypad + keyboard + history |
| College ERP | https://erp.psit.ac.in/ loaded inside the app (Chromium); login is remembered; downloads go to Downloads |
| Settings | lamp port/connect, touch calibration, voice speed/volume, OCR languages (English / Hindi+English), captures folder |

Results of reading and translating are also printed in the terminal window.

## New in this version
| Page | What it does |
|---|---|
| Modes | **Study / Focus / Gaming**. Study and Focus force-close the apps on your list (Discord, Steam, Instagram, YouTube app...) via AppOpener + psutil, close browser tabs whose title matches a blocked site (e.g. youtube) and switch off other apps' pop-ups (Windows). Winotify / Plyer show the app's own notices. Lists are editable. The in-app browser also refuses blocked sites. |
| Timers & Tracker | Stopwatch with laps, countdown timer, activity tracker. **Set the timer from a picture**: Tesseract / EasyOCR read "25 min" or "1:30:00". Every tracked session feeds the planner. |
| Smart Planner | Weekly timetable, time estimates and an AI day plan. scikit-learn (GradientBoosting + RandomForest) learns how long your tasks really take and in which hours you focus best. Under 12 logged sessions it uses simple rules and says so. |
| Gaming hub | Rubik's cube, **Chess** (play the built-in engine or Stockfish, analyse a FEN/PGN, open chess.com in the app) and **Sudoku** (type or scan a puzzle). Locked while Study / Focus is on. |
| Google Search | Google inside the app. The Search button after Read text / QR / Handwriting opens here. |
| Osiris AI | Chat assistant through an OpenAI-compatible endpoint (default: Ollama at http://localhost:11434/v1) plus the Osiris dashboard (default http://localhost:3000). Set both in the page. |
| Search bar (top, **Ctrl+K**) | Finds any page or action: "sudoku", "timer", "dark mode", "start study mode". |
| Light / Dark | Button in the top bar and in Settings. |

### Extra programs to install (not pip packages)
* **Tesseract OCR** (Windows build from UB-Mannheim) - then Settings > Text reading engine > Test Tesseract.
* Optional: **Stockfish** (set its path in Settings) for stronger chess; **Ollama** with a model (e.g. `ollama pull llama3.2`) for Osiris.

Study-mode blocking works on Windows. On other systems the apps are closed through psutil, tab closing and pop-up silencing are skipped.

## Classic window
The old 320x240 OpenCV interface is still there: `python -m lamp_app --classic`.

## Add a page
Create `lamp_app/gui/pages/my_page.py` with a class that extends `Page` (see `calculator.py`), then add it to the
list in `gui/window.py` and `NAV`.

## Pictures
`tools/prepare_assets.py` rebuilds `lamp_app/assets/*.png` (upscaled, backgrounds made transparent) from the original pictures.

## v5: animated interface (built from the reference videos and pictures)
| Reference | Where it is now |
|---|---|
| Anime Windows-11 desktop picture | **Home** is a desktop: blurred city wallpaper, glass window, round app rail, clock + calendar, mascot, picture cards, music player, magnifying **dock**. The dock's first button opens the old tile grid ("All apps") |
| Chibi character video | The animated mascot in the middle of Home and the avatar on Profile |
| Red-eye video | Osiris AI page and the Profile banner (with scanning line) |
| Cube video | `Cube3D`: shiny exploding cube on the scan page; real colours + turning layers for every move in Review and Solution |
| Graph picture | Smart Planner header: the picture is the backdrop, red bars/lines/boxes show your real minutes of the last 7 days |
| Search-button video | Top bar: the search button grows into the search bar (Ctrl+K) |
| Light/dark toggle video | Top bar glass toggle; the whole window cross-fades |
| Loader pack video | Spinner kinds (circle, dots, fade, ball, clock, wifi) shown on the button that started a background job, plus a spinner in the top bar |
| Progress-ring video | Timer countdown ring, XP ring on Profile |
| Home-button video | Sidebar: rainbow rim light + sliding label |
| Follower-counter video | Odometer numbers (planner boxes, Profile stats) |
| Keyboard picture | Calculator keys |
| Steam profile picture | **Profile** page (level, XP, badges). Click your name pill on Home |
| Dot-matrix dashboard | Dot ring gauge (focus rate on Profile) |
| Discord icon / sniper art / lamp sketch / anime Translate icon | Gaming + Modes, Focus banner, lamp card in Settings, Translator tile |
EVERY button also gets a hover shine and a press ripple (`fx.install_button_fx`).
`tools/prepare_fx_assets.py` rebuilds `assets/fx` from the original videos.

## v9: lamp touchscreen shows only the main controls
The lamp TFT is small and slow, so it shows just the main controls of the open page (Home: the dock, Calculator: keypad, Clock: the clock face, Timers: the timer, Spotify: the player buttons, Settings: the connection row, Handwriting: the writing area...). Touch works on what you see. About 5 pictures a second.
On camera pages (Cube solver, Read text, QR scanner) the live camera is a small box at the bottom right of the TFT.
* Another page's TFT view: in its class set `tft_names = ("widget_attr", ...)` (attribute names of the widgets to show). No names = the whole page.
* Camera box at the bottom left instead: in `gui/tftlink.py` change `x0 = W - bw - 4` to `x0 = 4`.
* Calibrate once: Settings > "Calibrate the lamp's touch screen". Wrong axes: TOUCH_FLIP_X / TOUCH_FLIP_Y / TOUCH_SWAP_XY in `config.py`; `TFT_DEBUG = True` prints touches.

## v10: lamp touchscreen re-flows the controls (readable on 320x240)
Before, the controls of a page were cut out as ONE rectangle and shrunk to fit, so a wide row of buttons (e.g. Settings
connection row, 830 px wide) became a thin strip with tiny text. Now every control is cut out on its own and packed into rows
(`gui/tftlayout.py`), so the screen is filled and the text is as big as possible (Settings: 0.37x -> 0.86x). Small text is sharpened
after shrinking, the picture is sent at higher JPEG quality, and the bars around the controls take the page's own background colour.
Touch maps through the same tiles, and sliders / spin boxes / drop-downs can be set by tapping (left half of a spin box = less, right
half = more; slider = tap the position; drop-down = next entry).

| Page | Shown on the lamp screen |
|---|---|
| Home | the dock as a grid of big icons (tap = open the page) |
| Settings | status, port, Refresh / Connect / Disconnect, Calibrate, and the Dark / Light switch |
| Spotify | prev / play-pause / next, volume - / mute / + |
| Modes | current mode, time left, session length, Stop, Start Study / Focus / Gaming |
| Timers | ring, time, 5/10/25/45/60 m presets, Start / Reset |
| Planner | the three red boxes + the red graph |
| QR / Read text | title + status, text box (top part), Capture / Open / Read buttons, live camera in the corner |
| Translator / Read aloud | text boxes (top part) + Paste / Last scanned text / Clear / Read |
| Calculator | display + whole keypad |
| Clock | digital time, date, analog clock, 12/24 h and Say |
| Cube solver | the step that is open: net + Scan / Undo / Start over, review, or solution moves |
| Profile / Osiris | profile card + red eye banner / chat + Send |
| Chess | status, engine option + level, board, New game / Undo / Flip / Best move |
| ERP | Back / Reload / Home + the login form (found automatically; top-left of the page when there is no form) |
| Handwriting | writing area + Read / Undo / Clear (result shown for 8 s) |

Change what a page shows: in its class set `tft_names = ("attr", ("a", "b"), "panel.edit", ...)` - one name = one control (the packer may
put it in any row), a tuple = controls that stay side by side, a dot reaches inside another widget. For a crop of a widget override
`tft_units()` (see `qr.py`, `planner.py`). Tune `MAX_SCALE`, `GAP`, `MARGIN` in `gui/tftlayout.py`.
Camera box position: `CAM_W, CAM_H` and `x0` in `gui/tftlink.py`.

## v10.1: lighter lamp-screen updates
`config.py`: `TFT_REFRESH_MS = 5000` (redraw every 5 s; a tap redraws after 0.4 s), `TFT_QUALITY = 0.75` (0.5 = lowest detail, fastest), `TFT_TARGET_BYTES = 16000`.

## v14: the lamp's 2.8-inch touchscreen has its own buttons
Built from the button pictures and the Arduino TFT video (big touch buttons, one job per screen).
The lamp screen no longer just mirrors the desktop: it draws its own screens (`lamp_app/tftui/`, Pillow only, no Qt):

| TFT screen | Buttons |
|---|---|
| Home | Dark/Light glass toggle, IST clock chip, 15 app tiles (2 pages, the `1/2` button flips them) |
| Clock | live IST time, **Switch to 24-hour / 12-hour**, **Say the time** |
| Read text | **Capture and read** (purple), **Open picture...**, **Translate** (orange), the text found |
| Translate | language `<  >`, source text, translation, **Translate**, **Say it** |
| Modes | red cards **Focus today / Open tasks / Sessions logged**, **Mode: Normal**, **Start Study mode**, **Start Focus mode** |
| Lamp | **Connect**, **Disconnect**, **Refresh**, calibrate touch |
| Cube | the cube net (tap a face, the green frame follows), Scan / Solve / Open |

* Tiles without their own TFT screen (Calculator, Spotify, ERP, Timers, Planner, Chess, Sudoku, Read aloud) still mirror the desktop page; a small **< HOME** chip (bottom left) returns to the buttons.
* Every button shows a spinner while it works (photo, reading, translating, connecting) and a pressed colour while touched; sliding the finger off a button cancels the tap.
* Only changed pictures are sent to the lamp (about 12-15 KB each); a tap redraws at once.
* Old behaviour: `TFT_UI = False` in `config.py`.
* See every screen without the lamp: `python -m lamp_app.tftui.preview` writes PNGs (dark and light) into `tft_preview/`.
* Add a TFT screen: write `_myscreen(self, c, pal)` in `tftui/engine.py` (use `self.button(...)`), add it to the dict in `render()`, and add its desktop page key to `NATIVE_FOR_PAGE`.

## v15: the lamp draws its own buttons (no pictures) - fastest
Before, the laptop painted every lamp screen as a JPEG and sent it. Now the laptop only sends a **description**
(boxes, text, coloured buttons: 300-1500 bytes) and the **firmware draws it itself**, like a macro pad:
* **Press = instant.** The board watches the finger by itself: a pressed button changes colour at once (no laptop round trip). The tap is then collected by the laptop (about every 12 ms) which does the real work (say the time, capture, start Study mode...).
* **Only what changed is sent.** The ticking clock sends one small text, not a whole picture.
* Screens (all text + colour, no icons / images): Home (3x3 tiles, 2 pages), Clock, Read text, Translate, Modes (Study / Focus / **Gaming**), Lamp, Cube, **Calculator**, **Spotify**, **Timers**. Other pages (Handwriting, ERP, Planner...) are still mirrored.
* **Re-flash the firmware once** (`lamp_firmware/lamp_firmware.ino`, it also fixes a compile error in v14: `nativeActive` was used before it was declared). Old firmware is detected (`PONG ... UI=1`) and the picture version is used automatically.
* Limits: the lamp fonts are ASCII only. Hindi / Urdu... translations are therefore not drawn on the lamp (it says so; "Say it" and the laptop still work). Camera pages (Cube scan, Read text camera) keep the small live camera box.
* `config.py`: `TFT_NATIVE = False` goes back to the picture version. `TOUCH_FLIP_X/Y`, `TOUCH_SWAP_XY` are sent to the board with every screen (no re-flash). `TFT_DEBUG = True` prints taps.
* **See the screens without the lamp:** `tft_preview/*.png` (made by `python tests/test_native.py`, which also checks the byte format and the sender).
* Change a screen: `lamp_app/tftui/native.py` (`_home`, `_clock`, `_modes`...: `self.btn(sc, pal, "id", (x, y, w, h), "Label", "primary")`). Button styles: glass, primary, orange, red, green, key, tile. A new button's action goes in `NativeUi.tap` or `TftUi._activate`.

## v16: always-on camera box (bottom right of the lamp screen)
A small LIVE camera picture is shown in the bottom-right corner of the lamp screen on every screen. The BOARD draws it by itself (about 5 pictures a second, no serial traffic), so it does not slow the buttons: it rests while a finger is on the screen and while the laptop is using the camera (Cube scan, QR...; those pages show the camera through the laptop instead).
* **Re-flash the firmware** (new command `B`; ping now says `UI=1 CB=1`). Old firmware: no box.
* All native screens keep out of that corner (Home shows 8 tiles per page; the layouts are a little tighter).
* `config.py`: `TFT_CAM_ALWAYS = False` switches it off, `TFT_CAM_BOX = (x, y, w, h)` moves / resizes it (put it bottom left: `(4, 188, 64, 48)`, keep other widgets clear of it), `TFT_CAM_MS` = refresh time.
* The previews in `tft_preview/` show where the box is ("CAMERA" placeholder).

## v17: voice - "turn on the smart desk lamp"
Say **"turn on the smart desk lamp"** and Windows starts the app, the app connects the lamp and the lamp screen turns on.
* **voice_listener.py** is a small always-running program. It uses the **Windows speech recogniser** (built into the operating system, works offline, no extra install). It only listens for a fixed list of phrases (`lamp_app/voice/phrases.py`), which is far more reliable than free dictation.
* Try it: double-click **Start voice listener.bat**, say the phrase. To have Windows start it at every sign-in: **Install voice autostart.bat** (undo: Remove voice autostart.bat).
* Phrases: *turn on / switch on / start / open / wake up the smart desk lamp*, *hey smart desk lamp* (starts the app if it is not running) - *turn off the smart desk lamp / good night smart desk lamp* (screen goes black, app keeps running) - *close the smart desk lamp app*. While the app runs also: *open the clock / calculator / spotify / timers / translator / read text / modes / cube solver*, *go home*, *start study / focus / gaming mode*, *stop mode*, *say the time*, *capture and read*.
* The listener says "Okay" when it understood. Starting the app twice just wakes the running one.
* **Screen on/off needs the new firmware** (command `D`, ping shows `DP=1`). After power-up the screen now stays dark until the app switches it on (`BOOT_SCREEN_OFF` in the firmware; set it to 0 for the old "Ready" page). Closing the app switches the screen off (`TFT_OFF_WHEN_APP_CLOSES` in config.py). The TFT's LED pin is wired straight to 3V3, so "off" is a black screen; wire the LED pin to a GPIO and set `PIN_TFT_BL` for a real backlight off.
* If it does not react: Windows Settings > Privacy > Microphone > allow **desktop apps**; check the default microphone; a speech recogniser language must be installed (Settings > Time & language > Speech). The listener prints what it heard and how sure it was; raise or lower `VOICE_CONFIDENCE` in config.py (default 0.70).
* The app listens only on 127.0.0.1 (this computer), port `VOICE_PORT`. `python tests/test_voice.py` tests the phrase table, the protocol and the listener logic without a microphone.
* **Check that the microphone works: double-click `Test microphone.bat`.** It shows a live bar that moves with your voice, what Windows thinks you said, and whether a phrase would run. Nothing is started.

## v18: cardboard cut-out desktop (see your real Windows desktop)
Home no longer paints its own wallpaper. It is now a few pieces of corrugated cardboard (a side panel with clock, calendar,
cards and music player, the dock strip, and a small tab) lying on top of your **real** desktop. Everything between the pieces is
a hole: your desktop icons, files, the taskbar and any other open program show through and can be clicked normally.
* How: while Home is open the window is frameless + always-on-top, sized to the screen minus the taskbar, and clipped to the
  cardboard outlines with `QWidget.setMask()` (`gui/cutout.py`, `MainWindow.set_cutout`). Every other page is the normal window again.
* The tab: **Hide** folds the cardboard away (only the tab stays), **Swap** moves it to the other side, **Theme** = dark/light
  board, **Classic** = the old wallpaper look. Settings > Appearance > *Desktop style* switches the same way.
* "All apps" (dock start button) and Ctrl+K search briefly use the normal window, then Home brings the cardboard back.
* Shapes/texture are in `gui/cutout_shapes.py`; `python tests/test_cutout_shapes.py` checks them and writes a preview picture.

### v18.1: smoother cut-out + taskbar hidden
* The window is no longer re-created when Home opens / closes (it stays true full screen and is just kept on top), so there is no
  flicker. Pieces and the window mask now change in the same step (Hide / Show / Swap / resize), so nothing is clipped mid-move;
  the cardboard texture is cached; switching Theme no longer fades the whole screen.
* The taskbar is hidden while the cardboard is showing (Settings > Appearance, tick box). **Hide** on the tab folds the cardboard
  away and brings the taskbar back. It is always restored when you leave Home or quit the app.

## v18.2: laptop camera fallback
If the lamp is not connected, the camera pages (Read text, QR scanner, Cube solver, Sudoku, Timers "from a picture") use the laptop's own camera automatically. When the lamp connects, the lamp camera takes over again.
Settings are at the bottom of `lamp_app/config.py`: `LAPTOP_CAMERA_FALLBACK` (True/False) and `LAPTOP_CAMERA_INDEX` (None = auto, or 1, 2... for another camera).
Windows must allow camera access for desktop apps (Settings > Privacy > Camera).

## v18.3: voice listener always on, visible, and stoppable
* The listener keeps the microphone open from sign-in until you end it. To stop it: **Task Manager > Details > SmartDeskLampVoice.exe (or pythonw.exe) > End task**. The microphone process dies with it (no orphan keeps listening). Starting a second listener just closes the second one.
* **Build voice exe.bat** (optional, small, no PyTorch) makes `voice_exe\SmartDeskLampVoice\SmartDeskLampVoice.exe`, so the Task Manager shows a proper name. Then run **Install voice autostart.bat** again - it uses the .exe when it exists.
* **Voice status.bat** shows whether the listener runs and the last lines of its log `%APPDATA%\SmartDeskLamp\voice.log` (what it heard and how sure it was). Windows 10/11 also shows a microphone icon in the tray while it records, and Settings > Privacy > Microphone lists the app under recent activity.
