@echo off
cd /d "%~dp0"
title Smart Desk Lamp - fix video window
where py >nul 2>nul
if %errorlevel%==0 (set PY=py -3) else (set PY=python)
%PY% -m pip uninstall -y opencv-python opencv-python-headless
%PY% -m pip install opencv-python
echo.
echo Done. Now start Smart Desk Lamp again.
pause
