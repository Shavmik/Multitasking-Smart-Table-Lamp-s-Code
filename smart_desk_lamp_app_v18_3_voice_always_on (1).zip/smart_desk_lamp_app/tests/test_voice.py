"""Voice control without a microphone: phrase table, command protocol, the listener's decisions and the socket client."""
import os, socketserver, sys, threading
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from lamp_app.voice.phrases import COMMANDS, lookup, WAKE
from lamp_app.voice.protocol import parse
from lamp_app.voice.listener import Listener
from lamp_app.voice import client

# every phrase maps to a command the app understands
for phrase, cmd in COMMANDS.items():
    assert parse(cmd)[0] is not None, (phrase, cmd)
    assert phrase == phrase.lower() and "  " not in phrase, phrase
assert lookup("Turn on the Smart Desk Lamp.") == "WAKE"
assert lookup("turn on the smart desk lamp") == "WAKE" and lookup("good morning") is None
assert parse("TAP shutdown")[0] is None and parse("GO nowhere")[0] is None and parse("rm -rf")[0] is None
print("phrases:", len(COMMANDS), "all valid")

# the socket client against a fake app
class H(socketserver.StreamRequestHandler):
    def handle(self):
        line = self.rfile.readline().decode().strip()
        got.append(line)
        self.wfile.write(b"PONG\n" if line == "PING" else b"OK\n")
got = []
srv = socketserver.TCPServer(("127.0.0.1", 0), H); port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
assert client.is_running(port) and client.send("WAKE", port) == "OK" and got[-1] == "WAKE"
srv.shutdown(); srv.server_close()
assert client.send("PING", port, timeout=0.5) is None            # nothing listening -> None, no crash
print("client OK")

# listener decisions
t = [1000.0]
def make(running_state):
    log = {"sent": [], "said": [], "launched": 0}
    def launch(): log["launched"] += 1; running_state["up"] = True
    L = Listener(port=1, confidence=0.7, say=log["said"].append, launch=launch,
                 send=lambda c, p: (log["sent"].append(c), "OK")[1], running=lambda p: running_state["up"], clock=lambda: t[0])
    return L, log
st = {"up": False}
L, log = make(st)
assert L.handle("turn on the smart desk lamp", 0.50) == "too unsure" and log["launched"] == 0
assert L.handle("what a nice day", 0.99) == "not a command"
assert L.handle("open the calculator", 0.95) == "app not running" and not log["sent"]       # only WAKE starts the app
import lamp_app.voice.listener as lm
lm.time.sleep = lambda s: None
assert L.handle("turn on the smart desk lamp", 0.91) == "started app" and log["launched"] == 1 and log["sent"] == ["WAKE"]
assert L.handle("turn off the smart desk lamp", 0.95) == "ignored (just spoke)"              # it must not hear itself
t[0] += 5
assert L.handle("open the calculator", 0.95).startswith("sent GO calc")
t[0] += 5
assert L.handle("turn off the smart desk lamp", 0.95).startswith("sent SLEEP")
t[0] += 5
assert L.handle("turn on the smart desk lamp", 0.95) == "woke app" and log["launched"] == 1   # already running: no second start
print("listener OK:", log["sent"])
print("ALL OK")

# microphone test formatting
from lamp_app.voice.listener import format_test_line
assert "####" in format_test_line("LEVEL|60") and format_test_line("LEVEL|x") is None
assert "WOULD RUN: WAKE" in format_test_line("HEARD|0.91|turn on the smart desk lamp")
assert "too unsure" in format_test_line("HEARD|0.40|turn on the smart desk lamp")
assert "not a command" in format_test_line("HEARD|0.90|hello there")
assert "did not match" in format_test_line("REJECTED|0.20|")
print("test-mode formatting OK")
