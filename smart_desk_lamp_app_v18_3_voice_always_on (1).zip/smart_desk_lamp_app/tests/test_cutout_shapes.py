"""Checks the cardboard cut-out shapes and texture without Qt.  Writes a preview picture to /tmp/cutout_preview.png
(cardboard pieces on a fake desktop, holes shown as the desktop colour) - needs Pillow only for the picture."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from lamp_app.gui.cutout_shapes import cut_outline, cardboard_array, bounds, BOARD_DARK, INK, UNDER_DARK

# ---- outline: stays near its rectangle, is repeatable, differs per seed ----
a = cut_outline(10, 20, 300, 400, seed=5)
b = cut_outline(10, 20, 300, 400, seed=5)
c = cut_outline(10, 20, 300, 400, seed=6)
assert a == b and a != c
x0, y0, x1, y1 = bounds(a)
assert 10 - 4 <= x0 and y0 >= 20 - 4 and x1 <= 310 + 4 and y1 <= 420 + 4, (x0, y0, x1, y1)
assert x1 - x0 > 290 and y1 - y0 > 390
assert len(a) > 12
tiny = cut_outline(0, 0, 30, 20, seed=1)                     # very small piece must not break
assert len(tiny) >= 8

# ---- texture ----
t = cardboard_array(200, 120, True, seed=3)
assert t.shape == (120, 200, 4) and t.dtype.name == "uint8" and (t[:, :, 3] == 255).all()
mean = t[:, :, :3].reshape(-1, 3).mean(axis=0)
assert all(abs(mean[i] - BOARD_DARK[i]) < 14 for i in range(3)), mean
tl = cardboard_array(200, 120, False, seed=3)
assert tl[:, :, :3].mean() > t[:, :, :3].mean() + 40      # light theme = paler board
print("shapes + texture OK")

try:
    from PIL import Image, ImageDraw
except Exception:
    sys.exit(0)

def preview(dark, path):
    W, H = 1280, 720
    img = Image.new("RGB", (W, H), (40, 90, 150))              # stands in for the user's real wallpaper
    d = ImageDraw.Draw(img)
    for i in range(6):                                           # fake desktop icons on the left
        d.rounded_rectangle((24, 24 + i * 96, 84, 84 + i * 96), 10, fill=(230, 230, 240))
        d.text((24, 88 + i * 96), "File %d" % (i + 1), fill=(255, 255, 255))
    d.rectangle((0, H - 40, W, H), fill=(20, 20, 30))             # taskbar stays visible
    pieces = [(11, 912, 14, 352, 62), (11 + 1, 912, 86, 352, 560), (23, 250, 590, 640, 120)]
    for seed, x, y, w, h in pieces:
        lift = 7
        under = cut_outline(x + lift, y + lift, w - 2, h - 2, seed + 101, step=46, jitter=2.1, corner=18)
        body = cut_outline(x, y, w - lift, h - lift, seed, step=46, jitter=2.1, corner=18)
        d.polygon(under, fill=UNDER_DARK if dark else (150, 108, 64), outline=INK)
        tex = Image.fromarray(cardboard_array(w, h, dark, seed), "RGBA").convert("RGB")
        m = Image.new("L", (W, H), 0)
        ImageDraw.Draw(m).polygon(body, fill=255)
        full = Image.new("RGB", (W, H)); full.paste(tex, (x, y))
        img.paste(full, (0, 0), m)
        d.line(body + [body[0]], fill=INK, width=3)
    img.save(path)

preview(True, "/tmp/cutout_preview.png")
preview(False, "/tmp/cutout_preview_light.png")
print("preview written")
