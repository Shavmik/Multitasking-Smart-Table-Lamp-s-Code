"""Checks the native button screens without any hardware: every screen is built, encoded, decoded the way the
firmware reads it, drawn by the simulator (PNG files in /tmp/native_preview) and the sender thread is run on a fake board."""
import os, sys, time, struct
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from datetime import datetime
from lamp_app.tftui.native import NativeUi, NativeRunner, Scene, simulate, MAX_WIDGETS
from lamp_app.tftui.engine import FEATURES

state = {"dark": True, "mode": "normal", "h24": False, "log": []}
def L(name):
    return lambda *a: state["log"].append((name,) + a)
hooks = dict(
    now=lambda: datetime(2026, 10, 20, 14, 16, 55), h24=lambda: state["h24"], dark=lambda: state["dark"],
    set_dark=lambda v: state.update(dark=v), toggle_h24=lambda: state.update(h24=not state["h24"]), say_time=L("say_time"),
    lamp_connected=lambda: True, lamp_status=lambda: "Connected on COM6", connect=L("connect"), disconnect=L("disconnect"),
    refresh=L("refresh"), calibrate=L("calibrate"), capture=L("capture"), open_picture=L("open_picture"),
    last_text=lambda: "The quick brown fox jumps over the lazy dog. Smart desk lamp reads this page under the camera for you.",
    speak=L("speak"), translate=lambda t, c, cb: cb("Namaste duniya", None),
    stats=lambda: {"focus_min": 49, "open_tasks": 3, "sessions": 4}, mode=lambda: state["mode"], mode_elapsed=lambda: 12,
    start_mode=lambda m: state.update(mode=m), end_mode=lambda: state.update(mode="normal"), open_page=L("open_page"),
    cube_faces=lambda: {"U": [[(255, 255, 255)] * 3] * 3, "F": [[(0, 155, 72)] * 3] * 3},
    calc_text=lambda: ("12*(3+4)", ""), calc_press=L("calc_press"), spotify_key=L("spotify_key"),
    timer_state=lambda: {"time": "25:00", "button": "Start"}, timer_do=L("timer_do"),
)
hooks["native_ok"] = lambda: True
ui = NativeUi(hooks)
os.makedirs("/tmp/native_preview", exist_ok=True)
sizes = {}
for dark in (True, False):
    state["dark"] = dark
    for scr in ("home", "clock", "read", "translate", "modes", "lamp", "cube", "calc", "spotify", "timers"):
        ui.screen = scr
        ui.tr_src = "Hello world"; ui.tr_out = "Namaste duniya"
        sc = ui.build()
        assert len(sc.w) <= MAX_WIDGETS, (scr, len(sc.w))
        from lamp_app import config as _c
        cx, cy, cw, ch = _c.TFT_CAM_BOX
        for wd in sc.w:                      # no widget may touch the camera box (the board draws the live picture there)
            assert wd.x + wd.w <= cx - 1 or wd.y + wd.h <= cy - 1 or wd.x >= cx + cw + 1 or wd.y >= cy + ch + 1, (scr, wd.kind, wd.bid, wd.x, wd.y, wd.w, wd.h)
        data = sc.encode(1, 0)
        sizes[scr] = (len(sc.w), len(data))
        # decode like the firmware does (same offsets as handleScene) to prove the byte layout
        n = data[5]; p = 6; seen = 0
        for _ in range(n):
            kind = data[p]; p += 9
            if kind == 1: p += 12
            elif kind == 2: ln = data[p + 8]; p += 9 + ln
            elif kind == 3: ln = data[p + 16]; p += 17 + ln
            else: raise SystemExit("bad kind")
            seen += 1
        assert seen == n and p == len(data), (scr, p, len(data))
        simulate(sc).resize((640, 480)).save(f"/tmp/native_preview/{scr}_{'dark' if dark else 'light'}.png")
print("screens (widgets, bytes):", sizes)

# OLD firmware (no UI=1): the picture engine must still work with the very same object (this crashed in v15)
hooks["native_ok"] = lambda: False
old = NativeUi(hooks)
for dark in (True, False):
    state["dark"] = dark
    for scr in ("home", "clock", "read", "translate", "modes", "lamp", "cube"):
        old.screen = scr
        frame = old.render()
        assert frame.shape == (240, 320, 3), (scr, frame.shape)
old.screen = "home"; old.tap("tile9")                 # Calculator: not drawable by the old firmware -> mirrored page
assert old.screen == "mirror", old.screen
hooks["native_ok"] = lambda: True
print("picture fallback OK")

# taps -> actions
state["dark"] = True; ui.screen = "home"
ui.tap("tile3"); print("tile3 ->", ui.screen, state["log"][-1:])
ui.screen = "modes"; ui.tap("gaming"); assert state["mode"] == "gaming"; ui.tap("gaming"); assert state["mode"] == "normal"
ui.screen = "calc"; ui.tap("k:7"); assert state["log"][-1] == ("calc_press", "7")
ui.screen = "clock"; ui.tap("fmt"); assert state["h24"]
ui.screen = "spotify"; ui.tap("sp_next"); assert state["log"][-1] == ("spotify_key", "next")
ui.tap("home"); assert ui.screen == "home"

# sender thread on a fake board: layout change -> one full screen; only a text changed -> one small update
class FakeBoard:
    native_ok = True
    def __init__(s): s.calls = []; s.events = []
    def scene(s, payload): s.calls.append(("S", len(payload)))
    def scene_update(s, i, f, t): s.calls.append(("U", i, t))
    def poll_events(s): e, s.events = s.events, []; return e
fb = FakeBoard(); taps = []
r = NativeRunner(lambda: fb, lambda: True, taps.append)
ui.screen = "clock"; state["h24"] = False
ui_now = [datetime(2026, 10, 20, 14, 16, 55)]
hooks["now"] = lambda: ui_now[0]
r.submit(ui.build()); time.sleep(0.2)
ui_now[0] = datetime(2026, 10, 20, 14, 16, 56)
r.submit(ui.build()); time.sleep(0.2)
ui.screen = "modes"; r.submit(ui.build()); time.sleep(0.2)
print("board got:", fb.calls)
assert [c[0] for c in fb.calls] == ["S", "U", "S"], fb.calls
bid_idx = [i for i, b in r._bids.items() if b == "study"][0]
fb.events.append((r._gen, bid_idx)); fb.events.append((r._gen + 1, bid_idx)); time.sleep(0.2)
assert taps == ["study"], taps          # the stale one (wrong screen generation) is ignored
r.stop(); print("ALL OK")
