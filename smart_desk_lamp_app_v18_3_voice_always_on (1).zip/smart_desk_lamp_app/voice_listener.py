"""Starts the voice listener ("turn on the smart desk lamp"). See README, section v17."""
import sys

from lamp_app.voice.listener import main

if __name__ == "__main__":
    sys.exit(main())
