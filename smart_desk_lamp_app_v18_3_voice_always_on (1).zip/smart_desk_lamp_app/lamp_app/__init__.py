"""Smart Desk Lamp - one app for the ESP32-S3 camera + touchscreen lamp."""
__version__ = "4.0"
