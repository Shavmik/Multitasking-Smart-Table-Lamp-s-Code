"""Touch calculator. Works with the touchscreen, the mouse and the keyboard."""
import ast
import operator

from ..core.ui import blank, button, draw_back, in_rect, is_back, put, W, H
from .base import Feature

_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
        ast.Div: operator.truediv, ast.Pow: operator.pow, ast.Mod: operator.mod,
        ast.FloorDiv: operator.floordiv}


def safe_eval(expr):
    """Evaluate + - * / // % ** and brackets only (never runs arbitrary code)."""
    def ev(n):
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
            return n.value
        if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Pow) and abs(b) > 100:
                raise ValueError("exponent too big")
            return _OPS[type(n.op)](a, b)
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.UAdd, ast.USub)):
            v = ev(n.operand)
            return v if isinstance(n.op, ast.UAdd) else -v
        raise ValueError("bad expression")
    return ev(ast.parse(expr.replace("^", "**").replace("x", "*"), mode="eval"))


def fmt(v):
    if isinstance(v, float) and v.is_integer() and abs(v) < 1e15:
        return str(int(v))
    return f"{v:.10g}" if isinstance(v, float) else str(v)


KEYS = [["C", "(", ")", "/"],
        ["7", "8", "9", "*"],
        ["4", "5", "6", "-"],
        ["1", "2", "3", "+"],
        ["0", ".", "<", "="]]
KX, KY, KW, KH = 0, 52, 80, 37


class Calculator(Feature):
    name = "Calculator"
    icon = "+-"
    key = "c"
    color = (120, 60, 120)
    order = 40

    def run(self, ctx):
        ui = ctx.ui
        expr, result = "", ""

        def press(k):
            nonlocal expr, result
            if k == "C":
                expr, result = "", ""
            elif k == "<":
                expr = expr[:-1]
            elif k == "=":
                try:
                    result = fmt(safe_eval(expr)) if expr else ""
                except ZeroDivisionError:
                    result = "divide by 0"
                except Exception:
                    result = "error"
                if result and result not in ("error", "divide by 0"):
                    expr = result
            else:
                if result and k in "0123456789.(":      # typing a number starts a new sum
                    expr, result = "", ""
                expr += k
                result = ""

        while not ui.closed():
            img = blank((24, 20, 20))
            draw_back(img)
            shown = expr[-18:] or "0"
            put(img, shown, (W - 12 - 17 * len(shown), 34), 0.9, (255, 255, 255), 2)
            if result:
                put(img, "= " + result, (70, 14), 0.5, (0, 255, 255))
            for r, row in enumerate(KEYS):
                for c, k in enumerate(row):
                    fill = (90, 60, 20) if k in "/*-+=" else (60, 40, 40) if k in "C<" else (55, 55, 55)
                    button(img, (KX + c * KW + 2, KY + r * KH + 2, KW - 4, KH - 4), k, fill, scale=0.7)
            ui.show(img)
            for ev in ui.events():
                if is_back(ev):
                    return
                if ev.type == "key":
                    k = ev.key
                    if k in "0123456789.+-*/()^%":
                        press(k)
                    elif k == "x":
                        press("*")
                    elif k in ("enter", "="):
                        press("=")
                    elif k == "backspace":
                        press("<")
                    elif k == "c":
                        press("C")
                elif ev.type == "down" and ev.y >= KY:
                    c, r = (ev.x - KX) // KW, (ev.y - KY) // KH
                    if 0 <= r < 5 and 0 <= c < 4:
                        press(KEYS[r][c])
