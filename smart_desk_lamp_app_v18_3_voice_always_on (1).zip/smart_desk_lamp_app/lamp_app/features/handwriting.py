"""Write on the touchscreen (finger) or in the window (mouse); EasyOCR reads what you wrote."""
import re

import cv2
import numpy as np

from ..core.textflow import result_screen
from ..core.ui import blank, button, draw_back, in_rect, is_back, W, H
from .base import Feature
from .calculator import fmt, safe_eval

TOOLBAR_H = 26
CLEAR_RECT = (64, 0, 70, 24)
READ_RECT = (140, 0, 70, 24)
PEN = 6


def fresh_canvas():
    img = np.full((H, W, 3), 255, np.uint8)
    draw_back(img)
    button(img, CLEAR_RECT, "CLEAR", (60, 60, 160), scale=0.45)
    button(img, READ_RECT, "READ", (40, 120, 40), scale=0.45)
    cv2.line(img, (0, TOOLBAR_H - 1), (W, TOOLBAR_H - 1), (150, 150, 150), 1)
    return img


class Handwriting(Feature):
    name = "Handwriting"
    icon = "Abc"
    key = "w"
    color = (40, 100, 150)
    order = 50

    def run(self, ctx):
        ui, board = ctx.ui, ctx.board
        canvas = fresh_canvas()
        ui.show(canvas, force=True)
        prev = None
        while not ui.closed():
            ui.show(canvas, tft=False)           # laptop only; the board draws strokes live itself
            for ev in ui.events():
                if is_back(ev):
                    return
                if ev.type == "key":
                    if ev.key == "c":
                        canvas = fresh_canvas(); ui.show(canvas, force=True); prev = None
                    elif ev.key in ("enter", "r"):
                        self.read(ctx, canvas); ui.show(canvas, force=True)
                    continue
                if ev.type == "down" and in_rect(ev.x, ev.y, CLEAR_RECT):
                    canvas = fresh_canvas(); ui.show(canvas, force=True); prev = None
                elif ev.type == "down" and in_rect(ev.x, ev.y, READ_RECT):
                    self.read(ctx, canvas); ui.show(canvas, force=True); prev = None
                elif ev.type in ("down", "move") and ev.y >= TOOLBAR_H + PEN:
                    p = (ev.x, ev.y)
                    a = prev if (ev.type == "move" and prev) else p
                    cv2.line(canvas, a, p, (0, 0, 0), PEN, cv2.LINE_AA)
                    board.line(a[0], a[1], p[0], p[1], (0, 0, 0), PEN)   # instant feedback on the TFT
                    prev = p
                elif ev.type == "up":
                    prev = None

    def read(self, ctx, canvas):
        board = ctx.board
        board.text("Reading", "Reading your handwriting...")
        reader = ctx.ocr()
        crop = cv2.cvtColor(canvas[TOOLBAR_H:], cv2.COLOR_BGR2GRAY)
        crop = cv2.copyMakeBorder(crop, 20, 20, 20, 20, cv2.BORDER_CONSTANT, value=255)
        crop = cv2.resize(crop, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
        text, err = ctx.ui.run_bg(lambda: " ".join(reader.readtext(crop, detail=0, paragraph=False)).strip())
        if err or not text:
            board.text("Nothing read", "Write bigger, with thick clear letters, then try again.")
            ctx.ui.pump(1500)
            return
        if re.fullmatch(r"[0-9\s+\-*/().^xX=]+", text):      # looks like a sum? solve it
            try:
                text = f"{text.rstrip('= ')} = {fmt(safe_eval(text.rstrip('= ')))}"
            except Exception:
                pass
        result_screen(ctx, "Handwriting", text)
