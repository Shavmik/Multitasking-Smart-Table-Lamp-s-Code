class Feature:
    """Base class for everything on the lamp's menu.

    To add a feature: create a new file in this folder with a class that extends Feature.
    It appears on the menu automatically (on the laptop and on the touchscreen).
    """
    name = "Unnamed"      # menu label
    icon = "?"            # short text drawn on the tile
    key = None            # keyboard shortcut on the menu
    color = (90, 90, 90)  # tile colour (B, G, R)
    order = 100           # menu position (small = first)

    def run(self, ctx):
        """ctx.board = camera/screen/touch,  ctx.ui = window + events,  ctx.ocr() = EasyOCR reader.
        Return when the user presses BACK (use `is_back(event)` from core.ui)."""
        raise NotImplementedError
