"""Rubik's cube solver: scan the 6 faces under the lamp camera, get the solution step by step
on the laptop AND on the touchscreen."""
import os
from datetime import datetime

import cv2
import numpy as np

from .. import config
from ..core.board import BoardError
from ..core.cube_solver import solve_cube
from ..core.ui import (BACK_RECT, W, H, blank, button, draw_back, in_rect, is_back,
                       overlay, put, wrap)
from .base import Feature

CUBE_GRID_FRAC = 0.50        # size of the green guide grid (fraction of picture height)
CUBE_FRAMES_PER_FACE = 3     # frames averaged for each face (less noise)
CUBE_FAR_SIDE = "u"          # side of the VIDEO that is the far side of the desk: u / d / l / r
SCAN_ORDER = ["U", "F", "D", "B", "L", "R"]
FACELET_ORDER = "URFDLB"
FACE_ROT = {"U": 0, "F": 0, "D": 0, "B": 2, "L": 1, "R": 3}
FAR_SIDE_ROT = {"u": 0, "r": 1, "d": 2, "l": 3}
LAB_WEIGHTS = (0.5, 1.0, 1.0)   # lightness counts less than colour (light changes between faces)
FACE_NAMES = {"U": "TOP", "D": "BOTTOM", "F": "FRONT", "B": "BACK", "L": "LEFT", "R": "RIGHT"}

STEP_TEXT = {
    "U": "Put the cube under the camera. Pick any face as TOP and the face you want as FRONT toward YOU.",
    "F": "Flip the cube forward (away from you) one quarter turn. The front face is now on top.",
    "D": "Flip the cube forward again, one more quarter turn.",
    "B": "Flip the cube forward again, one more quarter turn.",
    "L": "Flip forward once more (back to the start), then roll the cube to the RIGHT (its top goes to your right).",
    "R": "Roll the cube to the RIGHT two more times (a half turn).",
}
FROM_START_TEXT = {
    "U": "Return the cube to the starting position (first face on top, front toward you).",
    "F": "From the starting position, flip the cube forward ONCE.",
    "D": "From the starting position, flip the cube forward TWICE.",
    "B": "From the starting position, flip the cube forward THREE times.",
    "L": "From the starting position, roll the cube to the RIGHT once.",
    "R": "From the starting position, roll the cube to the LEFT once.",
}
NET_POS = {"U": (1, 0), "L": (0, 1), "F": (1, 1), "R": (2, 1), "B": (3, 1), "D": (1, 2)}
_state = {"far": None, "geo": {"frac": CUBE_GRID_FRAC, "dx": 0.0, "dy": 0.0}}


# ---------------------------- geometry and colour measuring ----------------------------
def grid_box(w, h, geo):
    side = int(geo["frac"] * min(w, h))
    cx, cy = int(w / 2 + geo["dx"] * w), int(h / 2 + geo["dy"] * h)
    x0 = min(max(cx - side // 2, 0), w - side)
    y0 = min(max(cy - side // 2, 0), h - side)
    return x0, y0, side


def draw_grid(img, geo):
    h, w = img.shape[:2]
    x0, y0, s = grid_box(w, h, geo)
    cs = s / 3.0
    cv2.rectangle(img, (x0, y0), (x0 + s, y0 + s), (0, 255, 0), 2)
    for i in (1, 2):
        cv2.line(img, (int(x0 + i * cs), y0), (int(x0 + i * cs), y0 + s), (0, 255, 0), 1)
        cv2.line(img, (x0, int(y0 + i * cs)), (x0 + s, int(y0 + i * cs)), (0, 255, 0), 1)
    for r in range(3):
        for c in range(3):
            cv2.circle(img, (int(x0 + (c + 0.5) * cs), int(y0 + (r + 0.5) * cs)), 3, (0, 255, 255), -1)


def sample_face(frames, geo):
    """Median colour (BGR) of the 9 stickers inside the guide grid -> (3,3,3) array."""
    grids = []
    for f in frames:
        h, w = f.shape[:2]
        x0, y0, s = grid_box(w, h, geo)
        cs = s / 3.0
        g = np.zeros((3, 3, 3), np.float32)
        for r in range(3):
            for c in range(3):
                xa, xb = int(x0 + c * cs + cs * 0.3), int(x0 + c * cs + cs * 0.7)
                ya, yb = int(y0 + r * cs + cs * 0.3), int(y0 + r * cs + cs * 0.7)
                patch = f[ya:max(yb, ya + 1), xa:max(xb, xa + 1)].reshape(-1, 3)
                g[r, c] = np.median(patch, axis=0)
        grids.append(g)
    return np.mean(grids, axis=0)


def orient_grid(grid, far_k, face):
    g = np.rot90(grid, far_k, axes=(0, 1))
    return np.rot90(g, FACE_ROT[face], axes=(0, 1))


def to_lab(bgr):
    arr = np.asarray(bgr, np.float32).reshape(-1, 1, 3) / 255.0
    return cv2.cvtColor(arr, cv2.COLOR_BGR2LAB).reshape(-1, 3)


def balanced_labels(d):
    """d: 48x6 distances. Every colour must be used exactly 8 times (plus its centre)."""
    try:
        from scipy.optimize import linear_sum_assignment
        rows, cols = linear_sum_assignment(np.repeat(d, 8, axis=1))
        labels = np.zeros(d.shape[0], int)
        labels[rows] = cols // 8
        return labels
    except ImportError:
        return d.argmin(axis=1)


def classify_cube(faces):
    """faces: letter -> (3,3,3) BGR grid. Returns (54-letter string, letter -> 3x3 labels)."""
    letters = FACELET_ORDER
    wts = np.array(LAB_WEIGHTS, np.float32)
    lab = {f: to_lab(faces[f]).reshape(3, 3, 3) for f in letters}
    centers = np.array([lab[f][1, 1] for f in letters])
    for i in range(6):
        for j in range(i + 1, 6):
            if np.linalg.norm((centers[i] - centers[j]) * wts) < 12:
                raise ValueError(f"The centre colours of faces {letters[i]} and {letters[j]} look the "
                                 f"same to the camera. Rescan them with better light.")
    items = [(f, r, c) for f in letters for r in range(3) for c in range(3) if (r, c) != (1, 1)]
    X = np.array([lab[f][r, c] for f, r, c in items])
    cen = centers.copy()
    labels = None
    for _ in range(4):
        d = np.linalg.norm((X[:, None, :] - cen[None, :, :]) * wts, axis=2)
        labels = balanced_labels(d)
        for k in range(6):
            members = X[labels == k]
            cen[k] = (members.sum(axis=0) + centers[k]) / (len(members) + 1)
    out = {f: [["?"] * 3 for _ in range(3)] for f in letters}
    for f in letters:
        out[f][1][1] = f
    for (f, r, c), k in zip(items, labels):
        out[f][r][c] = letters[k]
    string = "".join(out[f][r][c] for f in letters for r in range(3) for c in range(3))
    for f in letters:
        if string.count(f) != 9:
            raise ValueError("Some colours were counted the wrong number of times. "
                             "Rescan the faces with even light and no glare.")
    return string, out


def print_net(out):
    print()
    for r in range(3):
        print("        " + " ".join(out["U"][r]))
    print()
    for r in range(3):
        print("   ".join(" ".join(out[f][r]) for f in "LFRB"))
    print()
    for r in range(3):
        print("        " + " ".join(out["D"][r]))
    print()


def draw_net(img, grids, x, y, cell):
    for f, (fx, fy) in NET_POS.items():
        g = grids.get(f)
        for r in range(3):
            for c in range(3):
                x1, y1 = x + (fx * 3 + c) * cell, y + (fy * 3 + r) * cell
                color = (70, 70, 70) if g is None else tuple(int(v) for v in g[r, c])
                cv2.rectangle(img, (x1, y1), (x1 + cell - 1, y1 + cell - 1), color, -1)
                cv2.rectangle(img, (x1, y1), (x1 + cell - 1, y1 + cell - 1), (0, 0, 0), 1)


def describe_move(m):
    face = FACE_NAMES[m[0]]
    if m.endswith("2"):
        return f"Turn the {face} face a HALF turn (180 degrees)"
    if m.endswith("'"):
        return f"Turn the {face} face a quarter turn COUNTER-clockwise"
    return f"Turn the {face} face a quarter turn CLOCKWISE"


# ---------------------------- the feature ----------------------------
class RubiksSolver(Feature):
    name = "Cube solver"
    icon = "3x3"
    key = "r"
    color = (30, 40, 170)
    order = 30

    def run(self, ctx):
        try:
            self.cube_mode(ctx)
        except (TimeoutError, BoardError) as e:
            print(f"Camera problem during the cube scan: {e}")

    # ---- scanning one face ----
    def scan_face(self, ctx, face, step_text, title, geo, faces, far_k):
        """Returns (status, grid, raw_frame). status = 'ok', 'undo' or 'cancel'."""
        ui, board = ctx.ui, ctx.board
        errors = 0
        keys_line = "SPACE/tap=scan U=undo +/-=size WASD=move"
        while not ui.closed():
            try:
                frame = board.frame()
                errors = 0
            except (TimeoutError, BoardError):
                errors += 1
                if errors >= 10:
                    raise
                continue
            big = cv2.resize(frame, None, fx=config.SCALE, fy=config.SCALE)
            draw_grid(big, geo)
            h, w = big.shape[:2]
            cv2.rectangle(big, (w - 122, 4), (w - 4, 4 + 9 * 9 + 8), (30, 30, 30), -1)
            draw_net(big, faces, w - 116, 8, 9)
            big = overlay(big, [title], (0, 255, 0))
            big = overlay(big, wrap(step_text, 48) + [keys_line], (0, 255, 255), top=False)
            ui.show_big(big)
            for ev in ui.events():
                if is_back(ev):
                    return "cancel", None, None
                if ev.type == "key":
                    k = ev.key
                    if k == "u" or k == "backspace":
                        return "undo", None, None
                    if k in ("+", "="):
                        geo["frac"] = min(0.95, geo["frac"] + 0.03)
                    elif k == "-":
                        geo["frac"] = max(0.20, geo["frac"] - 0.03)
                    elif k == "w":
                        geo["dy"] -= 0.02
                    elif k == "s":
                        geo["dy"] += 0.02
                    elif k == "a":
                        geo["dx"] -= 0.02
                    elif k == "d":
                        geo["dx"] += 0.02
                    elif k not in ("space", "enter"):
                        continue
                    else:
                        return self._grab(board, frame, geo, far_k, face)
                elif ev.type == "down":
                    return self._grab(board, frame, geo, far_k, face)
        return "cancel", None, None

    @staticmethod
    def _grab(board, frame, geo, far_k, face):
        frames = [frame]
        for _ in range(CUBE_FRAMES_PER_FACE - 1):
            try:
                frames.append(board.frame())
            except (TimeoutError, BoardError):
                pass
        grid = orient_grid(sample_face(frames, geo), far_k, face)
        return "ok", grid, frames[-1]

    # ---- showing the solution (laptop + touchscreen) ----
    def show_solution(self, ctx, moves):
        ui = ctx.ui
        i, n = 0, len(moves)
        left, right = (0, 24, 106, 180), (214, 24, 106, 180)
        while not ui.closed():
            img = blank((24, 20, 20))
            draw_back(img)
            put(img, "Start: 1st face TOP, front toward you", (64, 15), 0.38, (0, 200, 255))
            if i < n:
                put(img, f"Move {i + 1} of {n}", (110, 44), 0.6, (255, 255, 255), 1)
                put(img, moves[i], (95, 130), 3.2, (0, 255, 0), 6)
                for k, line in enumerate(wrap(describe_move(moves[i]), 36)):
                    put(img, line, (10, 158 + 16 * k), 0.45, (255, 255, 255))
                nxt = "  ".join(moves[i + 1:i + 5])
                if nxt:
                    put(img, "next: " + nxt, (10, 196), 0.5, (200, 200, 200))
            else:
                put(img, "SOLVED!", (40, 140), 2.0, (0, 255, 0), 4)
            button(img, (0, 208, 100, 30), "< PREV", (60, 60, 60), scale=0.5)
            button(img, (220, 208, 100, 30), "NEXT >" if i < n else "DONE", (40, 110, 40), scale=0.5)
            ui.show(img)
            for ev in ui.events():
                nxt_ = prv_ = False
                if is_back(ev):
                    return
                if ev.type == "key":
                    nxt_ = ev.key in ("space", "enter", "n")
                    prv_ = ev.key == "b"
                elif ev.type == "down":
                    nxt_ = ev.y > 40 and ev.x >= W // 2
                    prv_ = ev.y > 40 and ev.x < W // 2
                if nxt_:
                    if i < n:
                        i += 1
                    else:
                        return
                elif prv_ and i > 0:
                    i -= 1

    # ---- the whole cube session ----
    def cube_mode(self, ctx):
        ui, board = ctx.ui, ctx.board
        print("\n" + "=" * 56)
        print("  RUBIK'S CUBE SOLVER   (BACK / ESC = cancel)")
        print("=" * 56)
        print("You will scan 6 faces. Keep the SAME hand position for the whole solve:")
        print("the first face you scan is TOP, the face toward you is FRONT.")

        first = board.frame()
        ui.show_big(overlay(cv2.resize(first, None, fx=2, fy=2), ["Answer in the terminal window"]))
        if _state["far"] is None:
            ans = ui.ask("In the live video, which side of the picture is the FAR side of the desk "
                         "(away from you)?  u=top d=bottom l=left r=right  [ENTER = "
                         + CUBE_FAR_SIDE + "]: ").strip().lower()
            _state["far"] = ans if ans in FAR_SIDE_ROT else CUBE_FAR_SIDE
        far_k = FAR_SIDE_ROT[_state["far"]]
        geo = _state["geo"]

        session = os.path.join(config.SAVE_DIR, datetime.now().strftime("cube_%Y%m%d_%H%M%S"))
        faces = {}

        def save_raw(face, raw):
            os.makedirs(session, exist_ok=True)
            cv2.imwrite(os.path.join(session, f"face_{face}.jpg"), raw)

        i = 0
        while i < len(SCAN_ORDER):
            face = SCAN_ORDER[i]
            title = f"CUBE  face {i + 1} of 6:  {FACE_NAMES[face]} ({face})"
            status, grid, raw = self.scan_face(ctx, face, STEP_TEXT[face], title, geo, faces, far_k)
            if status == "cancel":
                print("Cube solver cancelled.")
                return
            if status == "undo":
                if i > 0:
                    i -= 1
                    faces.pop(SCAN_ORDER[i], None)
                continue
            faces[face] = grid
            save_raw(face, raw)
            print(f"  face {face} ({FACE_NAMES[face]}) scanned")
            i += 1

        while True:
            try:
                facelets, labels = classify_cube(faces)
            except ValueError as e:
                print(f"\n{e}")
                facelets = None
            if facelets:
                print("\nWhat the solver understood (letters = which centre colour each sticker matches):")
                print_net(labels)
                understood = {f: np.array([[faces[labels[f][r][c]][1, 1] for c in range(3)]
                                           for r in range(3)]) for f in FACELET_ORDER}
                review = blank((0, 0, 0))
                put(review, "LEFT: measured    RIGHT: understood", (10, 14), 0.45)
                draw_net(review, faces, 6, 40, 13)
                draw_net(review, understood, 170, 40, 13)
                put(review, "Compare RIGHT with your real cube.", (10, 200), 0.45, (0, 255, 255))
                put(review, "Answer in the terminal window.", (10, 222), 0.45, (0, 255, 255))
                ui.show(review, force=True)
                ans = ui.ask("Does the RIGHT picture match your real cube? "
                             "(y = solve, n = rescan some faces, c = cancel): ").strip().lower()
                if ans in ("c", "cancel"):
                    print("Cube solver cancelled.")
                    return
                if ans in ("y", "yes", ""):
                    if facelets == "".join(f * 9 for f in FACELET_ORDER):
                        print("This cube is already solved!")
                        return
                    busy = blank()
                    put(busy, "Solving the cube...", (50, 110), 0.8, (0, 255, 0), 2)
                    put(busy, "(a few seconds)", (95, 140), 0.5, (200, 200, 200))
                    ui.show(busy, force=True)
                    print("\nSolving... (it searches for a short solution for a few seconds)")
                    moves, err = ui.run_bg(lambda: solve_cube(facelets))
                    if err is not None:
                        print(f"\nThis is not a possible cube: {err}" if isinstance(err, ValueError)
                              else f"\nThe solver failed: {err}")
                        print("This almost always means one colour was read wrong or a face was")
                        print("scanned in the wrong orientation.")
                        moves = None
                    if moves:
                        print(f"\nSOLUTION ({len(moves)} moves):\n\n   " + " ".join(moves) + "\n")
                        print("Notation: letter = face (U top, D bottom, F front, B back, L left, R right).")
                        print("Plain = quarter turn clockwise looking at that face, ' = counter-clockwise, 2 = half.")
                        os.makedirs(session, exist_ok=True)
                        with open(os.path.join(session, "solution.txt"), "w") as fh:
                            fh.write(f"cube: {facelets}\nmoves ({len(moves)}): {' '.join(moves)}\n")
                        print(f"(Saved in {session})")
                        self.show_solution(ctx, moves)
                        return
            blank_img = blank((0, 0, 0))
            draw_net(blank_img, faces, 6, 40, 13)
            ans = ui.ask("Faces to rescan, e.g.  U F   (ENTER = cancel the cube solver): ").strip().upper()
            wanted = []
            for ch in ans.replace(",", " ").split():
                if ch in FACELET_ORDER and ch not in wanted:
                    wanted.append(ch)
            if not wanted:
                print("Cube solver cancelled.")
                return
            for face in wanted:
                while True:
                    status, grid, raw = self.scan_face(ctx, face, FROM_START_TEXT[face],
                                                       f"RESCAN  {FACE_NAMES[face]} ({face})",
                                                       geo, faces, far_k)
                    if status == "cancel":
                        print("Cube solver cancelled.")
                        return
                    if status == "ok":
                        faces[face] = grid
                        save_raw(face, raw)
                        break
