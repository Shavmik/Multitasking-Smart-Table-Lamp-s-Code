"""Read printed text with EasyOCR, then search / edit / save it."""
import os
import time
from datetime import datetime

import cv2

from .. import config
from ..core.board import BoardError
from ..core.textflow import result_screen
from ..core.ui import is_back, overlay
from .base import Feature


class OcrReader(Feature):
    name = "Read text"
    icon = "Aa"
    key = "t"
    color = (150, 90, 20)
    order = 10

    def run(self, ctx):
        ui, board = ctx.ui, ctx.board
        reader = ctx.ocr()
        errors = 0
        while not ui.closed():
            try:
                frame = board.frame()
                errors = 0
            except (TimeoutError, BoardError):
                errors += 1
                if errors >= 10:
                    raise RuntimeError("Lost the camera. Check the USB cable.")
                continue
            big = cv2.resize(frame, None, fx=config.SCALE, fy=config.SCALE)
            ui.show_big(overlay(big, ["READ TEXT", "SPACE / tap = take photo    ESC = back"]))
            for ev in ui.events():
                if is_back(ev):
                    return
                if (ev.type == "key" and ev.key in ("space", "enter")) or ev.type == "down":
                    self.capture(ctx, reader)
                    break

    def capture(self, ctx, reader):
        ui, board = ctx.ui, ctx.board
        print("\nTaking photo...")
        try:
            img, jpeg = board.photo()
        except (TimeoutError, BoardError) as e:
            print(f"Error: {e}")
            return
        os.makedirs(config.SAVE_DIR, exist_ok=True)
        path = os.path.join(config.SAVE_DIR, datetime.now().strftime("capture_%Y%m%d_%H%M%S.jpg"))
        with open(path, "wb") as f:
            f.write(jpeg)
        print(f"Saved on laptop: {path}")
        board.text("Photo captured", "Reading text...")
        shown = cv2.resize(img, (config.TFT_W * config.SCALE, config.TFT_H * config.SCALE))
        ui.show_big(overlay(shown, ["READING TEXT..."], (0, 200, 255)))

        text, err = ui.run_bg(lambda: " ".join(reader.readtext(img, detail=0, paragraph=True)).strip())
        if err:
            print(f"OCR error: {err}")
            return
        if not text:
            print("No text found. Try better light, less glare, and keep the text in focus.")
            board.text("No text found", "Try better light, less glare and keep the text in focus.")
            ui.show_big(overlay(shown, ["NO TEXT FOUND - try better light"], (0, 0, 255)))
            for _ in range(30):
                ui.pump(50)
            return
        result_screen(ctx, "Text found", text)
