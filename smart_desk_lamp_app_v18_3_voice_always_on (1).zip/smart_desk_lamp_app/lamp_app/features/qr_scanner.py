"""QR scanner: scans the live picture automatically; SPACE / tap scans a sharper full photo."""
import time

import cv2
import numpy as np

from ..core.board import BoardError
from ..core.textflow import result_screen
from ..core.ui import is_back, overlay
from .base import Feature


def decode_qr(img, deep=True):
    """Returns (text, corner_points) or (None, None). deep=True also tries several scales."""
    detector = cv2.QRCodeDetectorAruco() if hasattr(cv2, "QRCodeDetectorAruco") else cv2.QRCodeDetector()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    variants = [(img, 1.0), (gray, 1.0)]
    if deep:
        for scale in (0.5, 0.75, 1.5):
            interp = cv2.INTER_AREA if scale < 1 else cv2.INTER_CUBIC
            variants.append((cv2.resize(gray, None, fx=scale, fy=scale, interpolation=interp), scale))
        _, otsu = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        variants.append((otsu, 1.0))
    for picture, scale in variants:
        try:
            text, points, _ = detector.detectAndDecode(picture)
        except cv2.error:
            continue
        if text:
            if points is not None:
                points = points.reshape(-1, 2) / scale
            return text.strip(), points
    return None, None


def as_url(text):
    t = text.strip()
    low = t.lower()
    if low.startswith(("http://", "https://")):
        return t
    if low.startswith("www.") and " " not in t:
        return "https://" + t
    return None


class QrScanner(Feature):
    name = "QR scanner"
    icon = "QR"
    key = "g"
    color = (60, 120, 40)
    order = 20

    def run(self, ctx):
        ui, board = ctx.ui, ctx.board
        last_text, last_time, notice, notice_until = "", 0.0, "", 0.0
        errors = 0
        while not ui.closed():
            try:
                frame = board.frame()
                errors = 0
            except (TimeoutError, BoardError):
                errors += 1
                if errors >= 10:
                    raise RuntimeError("Lost the camera. Check the USB cable.")
                continue
            text, pts = decode_qr(frame, deep=False)
            if not text:
                for ev in ui.events():
                    if is_back(ev):
                        return
                    if (ev.type == "key" and ev.key in ("space", "enter")) or ev.type == "down":
                        text, pts = self.deep_scan(ctx)
                        if not text:
                            notice, notice_until = "No QR code found - get closer", time.time() + 2
                        break
            if text and not (text == last_text and time.time() - last_time < 4):
                self.found(ctx, frame, text, pts)
                last_text, last_time = text, time.time()
                continue
            big = cv2.resize(frame, None, fx=2, fy=2)
            lines = ["QR SCANNER  (automatic)", "SPACE / tap = sharp photo scan    ESC = back"]
            if time.time() < notice_until:
                lines.append(notice)
            ui.show_big(overlay(big, lines))

    def deep_scan(self, ctx):
        try:
            img, _ = ctx.board.photo()
        except (TimeoutError, BoardError) as e:
            print(f"Error: {e}")
            return None, None
        return decode_qr(img, deep=True)[0], None

    def found(self, ctx, frame, text, pts):
        print("\n----- QR code found -----")
        big = cv2.resize(frame, None, fx=2, fy=2)
        if pts is not None:
            cv2.polylines(big, [(pts * 2).astype(np.int32).reshape(-1, 1, 2)], True, (0, 255, 0), 4)
        ctx.ui.show_big(overlay(big, ["QR CODE FOUND"], (0, 255, 0)))
        ctx.ui.pump(400)
        url = as_url(text)
        result_screen(ctx, "QR code (link)" if url else "QR code (text)", text, url=url)
