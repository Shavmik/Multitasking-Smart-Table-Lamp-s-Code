import importlib
import pkgutil
import traceback

from .base import Feature


def discover():
    """Find every Feature class in this folder, sorted for the menu."""
    found = []
    for info in pkgutil.iter_modules(__path__):
        if info.name == "base":
            continue
        try:
            mod = importlib.import_module(f"{__name__}.{info.name}")
        except Exception:                       # a broken feature must not stop the app
            print(f"[warning] feature '{info.name}' could not be loaded:")
            traceback.print_exc()
            continue
        for obj in vars(mod).values():
            if (isinstance(obj, type) and issubclass(obj, Feature) and obj is not Feature
                    and obj.__module__ == mod.__name__):
                found.append(obj())
    return sorted(found, key=lambda f: (f.order, f.name))
