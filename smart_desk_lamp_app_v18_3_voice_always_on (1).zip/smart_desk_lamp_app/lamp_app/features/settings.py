"""Touch calibration and a touch test."""
from ..core.ui import blank, draw_back, is_back, put, W, H
from .base import Feature


class TouchSetup(Feature):
    name = "Touch setup"
    icon = "+"
    key = "z"
    color = (80, 80, 80)
    order = 90

    def run(self, ctx):
        ui, board = ctx.ui, ctx.board
        img = blank()
        put(img, "TOUCH CALIBRATION", (50, 100), 0.6, (0, 255, 255))
        put(img, "Tap the tip of each arrow on the", (30, 130), 0.5)
        put(img, "lamp screen with a finger or stylus", (30, 150), 0.5)
        ui.show(img, force=True)
        _, err = ui.run_bg(board.calibrate)
        if err:
            print(f"Calibration failed: {err}")
        print("Touch test: tap the screen. BACK (top-left) to exit.")
        last = None
        while not ui.closed():
            img = blank((20, 20, 20))
            draw_back(img)
            put(img, "TOUCH TEST - tap anywhere", (70, 120), 0.5, (200, 200, 200))
            if last:
                import cv2
                cv2.circle(img, last, 8, (0, 255, 0), -1)
                put(img, f"x={last[0]} y={last[1]}", (110, 150), 0.5, (0, 255, 0))
            ui.show(img)
            for ev in ui.events():
                if is_back(ev):
                    return
                if ev.type in ("down", "move"):
                    last = (ev.x, ev.y)
