"""v14 lamp touchscreen interface (320x240): real buttons built from the reference pictures.

No Qt in this package - everything is drawn with Pillow + numpy, so it can be tested on any PC
(`python -m lamp_app.tftui.preview` writes PNG pictures of every screen).
"""
from .engine import TftUi  # noqa: F401
