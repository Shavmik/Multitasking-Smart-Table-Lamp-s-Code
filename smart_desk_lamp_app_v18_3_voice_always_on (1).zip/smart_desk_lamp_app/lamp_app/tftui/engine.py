"""The lamp's touchscreen interface (320x240). Screens are drawn from the reference button pictures:
glass buttons, purple->blue primary buttons, orange buttons, red stat cards, glass dark/light toggle,
IST clock chip, cube net. No Qt: the app gives it `hooks` (plain functions) for everything it can do.

    ui = TftUi(hooks)            # hooks: dict name -> callable, all optional (see HOOKS below)
    frame = ui.render()          # 320x240 BGR numpy picture, send it to the lamp
    ui.touch("down"/"up", x, y)  # finger events in screen pixels
"""
import threading
import time
from datetime import datetime

import numpy as np

from .draw import Canvas, icon, mix, shade

W, H = 320, 240

# HOOKS the app can provide (every one is optional; missing = the button just shows a short notice)
#   now() -> datetime            h24() -> bool            toggle_h24()          say_time()
#   dark() -> bool               set_dark(bool)
#   lamp_connected() -> bool     lamp_status() -> str     lamp_connecting() -> bool
#   connect()  disconnect()  refresh()  calibrate()
#   capture()  open_picture()    last_text() -> str       ocr_busy() -> bool    speak(text)
#   translate(text, code, cb)    cb(result, error)
#   stats() -> {"focus_min", "open_tasks", "sessions"}    mode() -> str    mode_elapsed() -> minutes
#   start_mode(name)  end_mode()
#   cube_faces() -> {letter: 3x3 grid of (r, g, b)}
#   open_page(key)

PALETTES = {
    "dark": dict(bg=(15, 15, 25), glass1=(70, 72, 92), glass2=(40, 42, 58), border=(104, 108, 132), text=(238, 238, 248),
                 sub=(150, 154, 178), card=(28, 30, 44), card_line=(58, 62, 86), knob=(235, 235, 245)),
    "light": dict(bg=(238, 236, 246), glass1=(248, 246, 248), glass2=(204, 204, 213), border=(255, 255, 255),
                  text=(28, 28, 40), sub=(108, 110, 130), card=(251, 251, 254), card_line=(214, 214, 228), knob=(255, 255, 255)),
}
PURPLE, BLUE, ORANGE, ORANGE2 = (139, 92, 246), (59, 130, 246), (255, 160, 100), (255, 138, 61)
RED1, RED2 = (232, 44, 58), (186, 18, 36)

# label, icon, accent, native TFT screen (None = the desktop page is mirrored), desktop page key
FEATURES = [
    ("Clock", "clock", (139, 92, 246), "clock", "clock"),
    ("Read text", "camera", (255, 138, 61), "read", "ocr"),
    ("Translate", "translate", (59, 155, 255), "translate", "translate"),
    ("Modes", "check", (52, 211, 153), "modes", "modes"),
    ("Cube", "cube", (240, 70, 80), "cube", "cube"),
    ("Lamp", "wifi", (45, 190, 210), "lamp", "settings"),
    ("Read aloud", "speaker", (255, 200, 61), None, "reader"),
    ("Calculator", "calc", (160, 120, 250), "calc", "calc"),
    ("Spotify", "music", (52, 211, 153), "spotify", "spotify"),
    ("College ERP", "globe", (80, 200, 140), None, "erp"),
    ("Timers", "clock", (255, 138, 61), "timers", "timers"),
    ("Planner", "folder", (240, 70, 80), None, "planner"),
    ("Chess", "chess", (200, 200, 220), None, "chess"),
    ("Sudoku", "grid", (59, 155, 255), None, "sudoku"),
    ("Settings", "gear", (150, 155, 180), None, "settings"),
]
PER_PAGE = 8
NATIVE_FOR_PAGE = {"clock": "clock", "ocr": "read", "translate": "translate", "modes": "modes",
                   "settings": "lamp", "home": "home", "calc": "calc", "spotify": "spotify", "timers": "timers"}   # (cube is not listed: its desktop page needs the camera picture)
TITLES = {"clock": "India Standard Time", "read": "Read text", "translate": "Translator", "modes": "Modes",
          "cube": "Rubik's cube", "lamp": "Lamp connection"}
FALLBACK_LANGS = [("Hindi", "hi"), ("English", "en"), ("Urdu", "ur"), ("Bengali", "bn"), ("Marathi", "mr"), ("Gujarati", "gu"),
                  ("Tamil", "ta"), ("Telugu", "te"), ("Punjabi", "pa"), ("French", "fr"), ("German", "de"), ("Spanish", "es")]
NET = {"U": (3, 0), "L": (0, 3), "F": (3, 3), "R": (6, 3), "B": (9, 3), "D": (3, 6)}   # face -> (column, row) of its 3x3 block
FACE_NAME = {"U": "TOP", "L": "LEFT", "F": "FRONT", "R": "RIGHT", "B": "BACK", "D": "BOTTOM"}
GREY = (150, 150, 162)


class TftUi:
    SCREENS = {"home", "clock", "read", "translate", "modes", "lamp", "cube"}   # screens this class can draw itself

    def __init__(self, hooks=None):
        self.hooks = hooks or {}
        self.screen = "home"
        self.home_page = 0
        self.pressed = None            # id of the button the finger is on
        self._buttons = []             # (id, (x, y, w, h)) of the last drawn picture
        self._busy = {}                # id -> time until which a spinner shows
        self._toast = ("", 0.0)
        self.lang_i = 0
        self.tr_src = ""
        self.tr_out = ""
        self.tr_state = ""             # '' | 'working' | 'error'
        self.cube_face = "U"
        self._langs = None

    # ------------------------------------------------------------------ small helpers
    def hook(self, name, *args, default=None):
        fn = self.hooks.get(name)
        if fn is None:
            return default
        try:
            return fn(*args)
        except Exception as e:                                       # noqa: BLE001 - a broken hook must not freeze the TFT
            print(f"[tft-ui] {name}: {e}")
            return default

    def has(self, name):
        return name in self.hooks

    @property
    def mirror(self):
        """True = the desktop page is mirrored on the screen (old way); the app draws that picture itself."""
        return self.screen == "mirror"

    def say(self, msg, secs=3.0):
        self._toast = (str(msg)[:44], time.time() + secs)

    def busy(self, bid, secs=6.0):
        self._busy[bid] = time.time() + secs

    def done(self, bid):
        self._busy.pop(bid, None)

    def _is_busy(self, bid):
        if bid == "capture" and self.hook("ocr_busy", default=False):
            return True
        if bid == "connect" and self.hook("lamp_connecting", default=False):
            return True
        return self._busy.get(bid, 0) > time.time()

    def go(self, screen):
        self.screen = screen
        self.pressed = None
        if screen == "translate" and not self.tr_src:
            self.tr_src = self.hook("last_text", default="") or ""

    def sync_page(self, key):
        """The desktop opened page `key`: follow it."""
        scr = NATIVE_FOR_PAGE.get(key)
        self.screen = scr if scr in self.SCREENS else "mirror"
        self.pressed = None

    def langs(self):
        if self._langs is None:
            try:
                from ..core.translate import LANGUAGES
                self._langs = list(LANGUAGES.items())
            except Exception:                                        # noqa: BLE001
                self._langs = FALLBACK_LANGS
        return self._langs

    def _dark(self):
        return bool(self.hook("dark", default=True))

    def _now(self):
        return self.hook("now", default=None) or datetime.now()

    # ------------------------------------------------------------------ drawing: buttons and chips
    def _rect_pressed(self, bid):
        return self.pressed == bid

    def button(self, c, pal, bid, rect, label, style="glass", ic=None, size=13, enabled=True, sub=None):
        x, y, w, h = rect
        r = min(h / 2.0, 12) if h < 60 else 14
        pressed = enabled and self._rect_pressed(bid)
        if style == "primary":
            c1, c2 = (shade(PURPLE, -0.14), shade(BLUE, -0.14)) if pressed else (PURPLE, BLUE)
            c.gradient(rect, r, c1, c2, "h")
            fg, icol = (255, 255, 255), (255, 255, 255)
        elif style == "orange":
            c1, c2 = (shade(ORANGE, -0.12), shade(ORANGE2, -0.12)) if pressed else (ORANGE, ORANGE2)
            c.gradient(rect, r, c1, c2, "h")
            c.shine(rect, r, 0.28)
            fg = icol = (30, 18, 8)
        else:
            g1, g2 = pal["glass1"], pal["glass2"]
            if pressed:
                g1, g2 = shade(g1, -0.12), shade(g2, -0.12)
            c.gradient(rect, r, g1, g2, "v")
            c.rrect(rect, r, outline=pal["border"], width=0.8)
            fg = icol = pal["text"]
        if not enabled:
            c.rrect(rect, r, fill=mix(pal["bg"], pal["glass2"], 0.25))
            fg = icol = pal["sub"]
        busy = self._is_busy(bid)
        tw = c.text_width(label, size)
        isz = size * 0.62
        total = tw + ((isz * 2 + 6) if (ic or busy) else 0)
        x0 = x + (w - total) / 2
        cy = y + h / 2
        if ic or busy:
            icon(c, "spinner" if busy else ic, x0 + isz, cy, isz, icol, pal["glass2"],
                 t=(time.time() * 360) % 360)
            x0 += isz * 2 + 6
        if sub:
            c.text((x0, cy - size * 0.1), label, size, fg, "lm")
            c.text((x0, cy + size * 0.85), sub, max(7, size - 5), fg, "lm", bold=False)
        else:
            c.text((x0, cy + 0.5), label, size, fg, "lm")
        if enabled:
            self._buttons.append((bid, rect))

    def toggle(self, c, pal, rect):
        x, y, w, h = rect
        dark = self._dark()
        pressed = self._rect_pressed("theme")
        c.gradient(rect, h / 2, shade(pal["glass1"], -0.1 if pressed else 0), pal["glass2"], "v")
        c.rrect(rect, h / 2, outline=pal["border"], width=0.8)
        c.text((x + 10, y + h / 2 + 0.5), "Light" if dark else "Dark", 11, pal["text"], "lm")   # the mode a tap switches to
        kx, kr = x + w - h / 2, h / 2 - 2
        c.circle(kx, y + h / 2, kr, fill=pal["knob"], outline=pal["glass2"], width=0.6)
        icon(c, "moon" if dark else "sun", kx, y + h / 2, kr * 0.62, (60, 60, 80) if not dark else (60, 60, 90), bg=pal["knob"])
        self._buttons.append(("theme", rect))

    def chip(self, c, pal, rect, text, size=11):
        x, y, w, h = rect
        c.gradient(rect, h / 2, pal["glass1"], pal["glass2"], "v")
        c.rrect(rect, h / 2, outline=pal["border"], width=0.8)
        c.text((x + w / 2, y + h / 2 + 0.5), text, size, pal["text"], "mm")

    def card(self, c, pal, rect, r=10):
        c.rrect(rect, r, fill=pal["card"], outline=pal["card_line"], width=0.8)

    def stat_card(self, c, rect, label, value, unit=""):
        x, y, w, h = rect
        c.gradient(rect, 8, RED1, RED2, "d")
        c.text((x + 9, y + 11), label, 8, (255, 225, 228), "lm", mono=True)
        c.text((x + 9, y + h - 15), str(value), 26, (255, 255, 255), "lm", mono=True)
        if unit:
            c.text((x + 12 + c.text_width(str(value), 26, mono=True), y + h - 10), unit, 10, (255, 215, 220), "lm", mono=True)

    # ------------------------------------------------------------------ top bar
    def topbar(self, c, pal, title=None):
        now = self._now()
        if self.screen == "home":
            self.toggle(c, pal, (6, 4, 76, 24))
            pages = max(1, -(-len(FEATURES) // PER_PAGE))
            self.button(c, pal, "page", (92, 4, 56, 24), f"{self.home_page + 1}/{pages}", "glass", None, 11)
            h24 = self.hook("h24", default=False)
            t = now.strftime("%H:%M:%S") if h24 else now.strftime("%I:%M:%S %p").lstrip("0")
            self.chip(c, pal, (156, 4, 158, 24), "IST  " + t, 11)
        else:
            self.button(c, pal, "home", (6, 4, 60, 24), "Home", "glass", "home", 11)
            c.text((160, 16.5), title or TITLES.get(self.screen, ""), 13, pal["text"], "mm")
            self.toggle(c, pal, (244, 4, 70, 24))

    # ------------------------------------------------------------------ screens
    def _home(self, c, pal):
        self.topbar(c, pal)
        items = FEATURES[self.home_page * PER_PAGE:(self.home_page + 1) * PER_PAGE]
        tw, th, gx, gy = 72, 92, 6, 6
        for i, (label, ic, accent, native, key) in enumerate(items):
            col, row = i % 4, i // 4
            x, y = 8 + col * (tw + gx), 36 + row * (th + gy)
            rect = (x, y, tw, th)
            pressed = self._rect_pressed("tile%d" % (self.home_page * PER_PAGE + i))
            g1, g2 = pal["glass1"], pal["glass2"]
            if pressed:
                g1, g2 = shade(g1, -0.12), shade(g2, -0.12)
            c.gradient(rect, 12, g1, g2, "v")
            c.rrect(rect, 12, outline=pal["border"], width=0.8)
            c.circle(x + tw / 2, y + 36, 21, fill=mix(pal["glass2"], accent, 0.32 if pal is PALETTES["light"] else 0.45))
            icon(c, ic, x + tw / 2, y + 36, 13, accent if pal is PALETTES["dark"] else shade(accent, -0.25), pal["glass2"])
            size = c.fit(label, 11, tw - 6)
            c.text((x + tw / 2, y + 74), label, size, pal["text"], "mm")
            self._buttons.append(("tile%d" % (self.home_page * PER_PAGE + i), rect))

    def _clock(self, c, pal):
        self.topbar(c, pal)
        now = self._now()
        h24 = self.hook("h24", default=False)
        main = now.strftime("%H:%M:%S") if h24 else now.strftime("%I:%M:%S").lstrip("0")
        size = 52
        wmain = c.text_width(main, size, mono=True)
        ap = "" if h24 else now.strftime("%p")
        total = wmain + (c.text_width(ap, 18) + 8 if ap else 0)
        x0 = (W - total) / 2
        c.text((x0, 86), main, size, pal["text"], "lm", mono=True)
        if ap:
            c.text((x0 + wmain + 8, 100), ap, 18, ORANGE2, "lm")
        c.text((160, 130), now.strftime("%A, %d %B %Y"), 14, pal["sub"], "mm", bold=False)
        self.chip(c, pal, (122, 40, 76, 20), "IST  +05:30", 10)
        self.button(c, pal, "fmt", (6, 158, 150, 46), "Switch to 12-hour" if h24 else "Switch to 24-hour", "glass", "clock", 12)
        self.button(c, pal, "say", (164, 158, 150, 46), "Say the time", "glass", "speaker", 13)

    def _read(self, c, pal):
        self.topbar(c, pal)
        self.button(c, pal, "capture", (6, 34, 308, 48), "Capture and read", "primary", "camera", 15)
        self.button(c, pal, "open", (6, 88, 150, 40), "Open picture...", "glass", "folder", 12)
        self.button(c, pal, "to_translate", (164, 88, 150, 40), "Translate", "orange", "translate", 13)
        self.card(c, pal, (6, 134, 308, 100))
        text = (self.hook("last_text", default="") or "").strip()
        if self._is_busy("capture"):
            c.text((16, 150), "Reading... please wait", 12, pal["sub"], "lm")
        elif not text:
            c.text((16, 150), "No text yet.", 12, pal["text"], "lm")
            c.text((16, 168), "Put a page under the lamp and tap Capture and read.", 10, pal["sub"], "lm", bold=False)
            if not self.hook("lamp_connected", default=False):
                c.text((16, 184), "Lamp not connected - use Open picture...", 10, (240, 90, 100), "lm", bold=False)
        else:
            for i, line in enumerate(c.wrap(text, 11, 284, 6)):
                c.text((16, 148 + i * 15), line, 11, pal["text"], "lm", bold=False)

    def _translate(self, c, pal):
        self.topbar(c, pal)
        langs = self.langs()
        name = langs[self.lang_i % len(langs)][0]
        self.button(c, pal, "lang_prev", (6, 34, 44, 34), "", "glass", "back", 12)
        self.button(c, pal, "lang_pick", (56, 34, 208, 34), name, "glass", None, 14)
        self.button(c, pal, "lang_next", (270, 34, 44, 34), "", "glass", "next", 12)
        self.card(c, pal, (6, 74, 308, 50))
        src = self.tr_src or "Scan text first (Read text) or open the desktop Translator."
        for i, line in enumerate(c.wrap(src, 10, 288, 3)):
            c.text((14, 86 + i * 13), line, 10, pal["sub"] if not self.tr_src else pal["text"], "lm", bold=False)
        out_rect = (6, 130, 308, 64)
        c.rrect(out_rect, 10, fill=mix(pal["card"], ORANGE2, 0.12), outline=mix(pal["card_line"], ORANGE2, 0.5), width=0.8)
        if self._is_busy("go_tr") or self.tr_state == "working":
            c.text((16, 162), "Translating...", 12, pal["sub"], "lm")
        elif self.tr_state == "error":
            for i, line in enumerate(c.wrap(self.tr_out, 10, 288, 4)):
                c.text((14, 142 + i * 13), line, 10, (240, 90, 100), "lm", bold=False)
        else:
            for i, line in enumerate(c.wrap(self.tr_out or "Translation appears here.", 12, 288, 4)):
                c.text((14, 143 + i * 15), line, 12, pal["text"] if self.tr_out else pal["sub"], "lm")
        self.button(c, pal, "go_tr", (6, 198, 150, 38), "Translate", "orange", "translate", 13, enabled=bool(self.tr_src))
        self.button(c, pal, "say_tr", (164, 198, 150, 38), "Say it", "glass", "speaker", 13, enabled=bool(self.tr_out) and self.tr_state == "")

    def _modes(self, c, pal):
        self.topbar(c, pal)
        st = self.hook("stats", default=None) or {}
        self.stat_card(c, (6, 34, 112, 64), "FOCUS TODAY", int(st.get("focus_min", 0)), "min")
        self.stat_card(c, (6, 102, 112, 64), "OPEN TASKS", int(st.get("open_tasks", 0)))
        self.stat_card(c, (6, 170, 112, 64), "SESSIONS LOGGED", int(st.get("sessions", 0)))
        mode = self.hook("mode", default="normal") or "normal"
        label = "Mode: " + mode.title()
        el = self.hook("mode_elapsed", default=None)
        if mode != "normal" and el is not None:
            label += f"  {int(el)}m"
        self.button(c, pal, "mode_pill", (126, 34, 188, 34), label, "glass", "dot" if mode != "normal" else None, 12)
        studying, focusing = mode == "study", mode == "focus"
        self.button(c, pal, "study", (126, 74, 188, 76), "Stop Study mode" if studying else "Start Study mode", "primary", None, 14)
        self.button(c, pal, "focus", (126, 156, 188, 78), "Stop Focus mode" if focusing else "Start Focus mode", "orange", None, 14)

    def _lamp(self, c, pal):
        self.topbar(c, pal)
        ok = bool(self.hook("lamp_connected", default=False))
        status = self.hook("lamp_status", default="") or ("Lamp connected" if ok else "The lamp is not connected.")
        self.card(c, pal, (6, 34, 308, 58))
        c.circle(24, 63, 6, fill=(52, 211, 153) if ok else (240, 90, 100))
        lines = c.wrap(status, 12, 270, 3, bold=True)
        for i, line in enumerate(lines):
            c.text((38, 63 + (i - (len(lines) - 1) / 2) * 15), line, 12, pal["text"], "lm")
        self.button(c, pal, "connect", (6, 98, 308, 46), "Connect", "primary", "check", 15, enabled=not ok)
        self.button(c, pal, "disconnect", (6, 150, 150, 40), "Disconnect", "glass", "cross", 12, enabled=ok)
        self.button(c, pal, "refresh", (164, 150, 150, 40), "Refresh", "glass", "refresh", 12)
        self.button(c, pal, "calibrate", (6, 196, 308, 38), "Calibrate touch screen", "glass", "gear", 12, enabled=ok)

    def _cube(self, c, pal):
        self.topbar(c, pal)
        faces = self.hook("cube_faces", default=None) or {}
        cell, gap, ox, oy = 14, 2, 8, 36
        pitch = cell + gap
        for letter, (col0, row0) in NET.items():
            grid = faces.get(letter)
            for r in range(3):
                for k in range(3):
                    rect = (ox + (col0 + k) * pitch, oy + (row0 + r) * pitch, cell, cell)
                    fill = tuple(int(v) for v in grid[r][k]) if grid is not None else GREY
                    c.rrect(rect, 3, fill=fill if grid is not None else mix(pal["glass2"], GREY, 0.6))
            fx, fy = ox + col0 * pitch - 2, oy + row0 * pitch - 2
            rect = (fx, fy, 3 * pitch + 2, 3 * pitch + 2)
            if letter == self.cube_face:
                c.rrect(rect, 5, outline=(40, 210, 150), width=2)
            self._buttons.append(("face_" + letter, rect))
        c.text((ox, oy + 9 * pitch + 12), f"Face: {FACE_NAME[self.cube_face]} ({self.cube_face})", 12, pal["text"], "lm")
        done = sum(1 for v in faces.values() if v is not None)
        c.text((ox, oy + 9 * pitch + 28), f"{done} of 6 faces scanned", 10, pal["sub"], "lm", bold=False)
        self.button(c, pal, "cube_scan", (214, 36, 100, 56), "Scan", "primary", "camera", 13)
        self.button(c, pal, "cube_solve", (214, 98, 100, 56), "Solve", "orange", "check", 13)
        self.button(c, pal, "cube_open", (214, 160, 100, 40), "Open", "glass", "cube", 12)

    # ------------------------------------------------------------------ render
    def render(self):
        pal = PALETTES["dark" if self._dark() else "light"]
        c = Canvas(W, H, pal["bg"])
        self._buttons = []
        fn = {"home": self._home, "clock": self._clock, "read": self._read, "translate": self._translate,
              "modes": self._modes, "lamp": self._lamp, "cube": self._cube}.get(self.screen, self._home)
        fn(c, pal)
        text, until = self._toast
        if text and time.time() < until:
            tw = c.text_width(text, 11) + 22
            c.rrect(((W - tw) / 2, H - 30, tw, 22), 11, fill=(20, 20, 30), outline=(120, 124, 150), width=0.8)
            c.text((W / 2, H - 19), text, 11, (240, 240, 250), "mm")
        return c.finish()

    # ------------------------------------------------------------------ touch
    def _hit(self, x, y):
        for bid, (bx, by, bw, bh) in reversed(self._buttons):
            if bx - 2 <= x < bx + bw + 2 and by - 2 <= y < by + bh + 2:
                return bid
        return None

    def touch(self, kind, x, y):
        """Returns True when the picture should be redrawn now."""
        if kind == "down":
            self.pressed = self._hit(x, y)
            return self.pressed is not None
        if kind == "move":
            if self.pressed is not None and self._hit(x, y) != self.pressed:
                self.pressed = None
                return True
            return False
        if kind == "up":
            bid, self.pressed = self.pressed, None
            if bid is not None:
                self._activate(bid)
            return True
        return False

    # ------------------------------------------------------------------ what a button does
    def _need(self, name, msg="Not available"):
        if name not in self.hooks:
            self.say(msg)
            return False
        return True

    def _activate(self, bid):
        if bid.startswith("tile"):
            label, ic, accent, native, key = FEATURES[int(bid[4:])]
            if native and native in self.SCREENS:
                self.go(native)
            else:
                self.screen = "mirror"
                self.hook("open_page", key)
            return
        if bid.startswith("face_"):
            self.cube_face = bid[5:]
            return
        h = self.hook
        if bid == "home":
            self.go("home")
            h("open_page", "home")
        elif bid == "page":
            self.home_page = (self.home_page + 1) % max(1, -(-len(FEATURES) // PER_PAGE))
        elif bid == "theme":
            if self._need("set_dark"):
                h("set_dark", not self._dark())
        elif bid == "fmt":
            if self._need("toggle_h24"):
                h("toggle_h24")
        elif bid == "say":
            if self._need("say_time"):
                self.busy("say", 3)
                h("say_time")
        elif bid == "capture":
            if not h("lamp_connected", default=False):
                self.say("Lamp not connected")
            elif self._need("capture"):
                self.busy("capture", 40)
                h("capture")
        elif bid == "open":
            if self._need("open_picture"):
                self.say("Choose the picture on the laptop")
                h("open_picture")
        elif bid == "to_translate":
            self.tr_src = (h("last_text", default="") or "").strip()
            self.tr_out, self.tr_state = "", ""
            self.go("translate")
            if self.tr_src:
                self._do_translate()
        elif bid in ("lang_prev", "lang_next", "lang_pick"):
            n = len(self.langs())
            self.lang_i = (self.lang_i + (-1 if bid == "lang_prev" else 1)) % n
            self.tr_out, self.tr_state = "", ""
        elif bid == "go_tr":
            self._do_translate()
        elif bid == "say_tr":
            if self.tr_out and self._need("speak"):
                h("speak", self.tr_out)
        elif bid == "mode_pill":
            if (h("mode", default="normal") or "normal") != "normal":
                h("end_mode")
        elif bid in ("study", "focus"):
            cur = h("mode", default="normal") or "normal"
            if not self._need("start_mode"):
                return
            if cur == bid:
                h("end_mode")
            else:
                h("start_mode", bid)
        elif bid == "connect":
            if self._need("connect"):
                self.busy("connect", 15)
                h("connect")
        elif bid == "disconnect":
            if self._need("disconnect"):
                h("disconnect")
        elif bid == "refresh":
            if self._need("refresh"):
                self.busy("refresh", 3)
                h("refresh")
        elif bid == "calibrate":
            if self._need("calibrate"):
                self.say("Tap the 4 arrows on the screen", 5)
                h("calibrate")
        elif bid in ("cube_scan", "cube_solve", "cube_open"):
            self.screen = "mirror"
            h("open_page", "cube")

    def _do_translate(self):
        if not self.tr_src or self.tr_state == "working":
            return
        if not self._need("translate", "Translator not available"):
            return
        code = self.langs()[self.lang_i % len(self.langs())][1]
        self.tr_state, self.tr_out = "working", ""
        text = self.tr_src

        def cb(res, err):
            if err:
                self.tr_state, self.tr_out = "error", str(err)[:140]
            else:
                self.tr_state, self.tr_out = "", str(res)

        self.hook("translate", text, code, cb)
