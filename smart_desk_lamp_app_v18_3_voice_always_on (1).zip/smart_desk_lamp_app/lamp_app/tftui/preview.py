"""Writes a PNG of every screen: python -m lamp_app.tftui.preview [outfolder]"""
import os
import sys
from datetime import datetime

import cv2

from .engine import TftUi


def demo_hooks(dark=True):
    state = {"dark": dark, "h24": False, "mode": "normal"}
    faces = {f: [[(220, 60, 60)] * 3] * 3 for f in "UF"}
    return {
        "now": lambda: datetime(2026, 10, 20, 14, 16, 55), "h24": lambda: state["h24"], "dark": lambda: state["dark"],
        "lamp_connected": lambda: True, "lamp_status": lambda: "Lamp connected on COM5",
        "last_text": lambda: "Smart Desk Lamp reads printed text aloud and translates it into more than ten languages.",
        "stats": lambda: {"focus_min": 0, "open_tasks": 0, "sessions": 4}, "mode": lambda: state["mode"],
        "cube_faces": lambda: faces,
    }


def main(out="tft_preview"):
    os.makedirs(out, exist_ok=True)
    for dark in (True, False):
        ui = TftUi(demo_hooks(dark))
        ui.tr_src, ui.tr_out = "Hello, how are you?", "नमस्ते, आप कैसे हैं?"
        for screen in ("home", "clock", "read", "translate", "modes", "lamp", "cube"):
            ui.go(screen)
            ui.tr_src = "Hello, how are you?"
            cv2.imwrite(os.path.join(out, f"{'dark' if dark else 'light'}_{screen}.png"), cv2.resize(ui.render(), None, fx=2, fy=2, interpolation=cv2.INTER_NEAREST))
    print("written to", os.path.abspath(out))


if __name__ == "__main__":
    main(*sys.argv[1:2])
