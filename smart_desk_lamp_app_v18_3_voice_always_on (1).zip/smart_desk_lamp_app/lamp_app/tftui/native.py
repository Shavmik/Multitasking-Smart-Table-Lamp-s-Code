"""v15: the lamp's own button screens, drawn by the BOARD (no pictures).

The laptop only describes a screen - boxes, text labels and coloured buttons, a few hundred bytes - and the
firmware paints it with plain rectangles and text. The firmware also watches the finger by itself: a pressed
button changes colour at once, and the tap is passed to the laptop, which does the real work (say the time,
take a photo, start a mode...). When only a text changes (the ticking clock...) just that one text is sent.

    ui = NativeUi(hooks)             # same hooks as TftUi (see engine.py) + calc / spotify / timers hooks
    scene = ui.build()               # what the screen should look like now
    ui.tap("study")                  # a button was tapped
    NativeRunner(...)                # background thread: sends scenes / changes to the board, collects taps
"""
import threading
import time

from .. import config
from .engine import FEATURES, PALETTES, TftUi

W, H = 320, 240
FONT_PX = {1: 9, 2: 12, 3: 18, 4: 24, 5: 40}      # the five firmware fonts (DejaVu 9 / 12 / 18 / 24 / 40)
CHAR_W = 0.6                                        # average character width / font size
NPER = 8                                            # tiles per home page (3 x 3 minus the corner of the camera box)
MAX_WIDGETS = 96

PURPLE, BLUE = (139, 92, 246), (59, 130, 246)
ORANGE, ORANGE2 = (255, 160, 100), (255, 138, 61)
RED1, RED2 = (232, 44, 58), (186, 18, 36)
GREEN1, GREEN2 = (74, 222, 160), (46, 190, 134)
SALMON1, SALMON2 = (255, 120, 125), (232, 84, 96)

PAL = {
    "dark": dict(bg=(15, 15, 25), glass1=(70, 72, 92), glass2=(40, 42, 58), line=(104, 108, 132), text=(238, 238, 248),
                 sub=(150, 154, 178), card=(28, 30, 44), card_line=(58, 62, 86)),
    "light": dict(bg=(238, 236, 246), glass1=(250, 248, 250), glass2=(206, 206, 216), line=(186, 186, 204), text=(28, 28, 40),
                  sub=(108, 110, 130), card=(251, 251, 254), card_line=(214, 214, 228)),
}


def mix(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


def shade(c, k):
    return mix(c, (0, 0, 0), -k) if k < 0 else mix(c, (255, 255, 255), k)


def lum(c):
    return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]


def ascii_text(text):
    """The firmware fonts are ASCII only: other characters become '?'. Returns (text, lost_characters)."""
    out, lost = [], 0
    for ch in str(text):
        if ch in "\r\n\t":
            out.append(" ")
        elif 32 <= ord(ch) < 127:
            out.append(ch)
        elif ch in "\u2018\u2019":
            out.append("'")
        elif ch in "\u201c\u201d":
            out.append('"')
        elif ch in "\u2013\u2014":
            out.append("-")
        else:
            out.append("?")
            lost += 1
    return "".join(out), lost


def fit(text, font, maxw):
    """Shorten `text` (with '..') so it fits `maxw` pixels in `font`."""
    text = ascii_text(text)[0]
    n = max(1, int(maxw / (FONT_PX[font] * CHAR_W)))
    return text if len(text) <= n else text[:max(1, n - 2)] + ".."


def pick_font(text, maxw, fonts=(3, 2, 1)):
    for f in fonts:
        if len(text) * FONT_PX[f] * CHAR_W <= maxw:
            return f
    return fonts[-1]


def wrap(text, font, maxw, maxlines):
    """Word-wrap into at most `maxlines` lines (the last one gets '..' when the text is longer)."""
    text = ascii_text(text)[0]
    n = max(4, min(39, int(maxw / (FONT_PX[font] * CHAR_W))))
    words, lines, cur = text.split(), [], ""
    for w in words:
        while len(w) > n:                                  # a very long word
            if cur:
                lines.append(cur); cur = ""
            lines.append(w[:n]); w = w[n:]
        if len(cur) + (1 if cur else 0) + len(w) <= n:
            cur = (cur + " " + w) if cur else w
        else:
            lines.append(cur); cur = w
    if cur:
        lines.append(cur)
    if len(lines) > maxlines:
        lines = lines[:maxlines]
        lines[-1] = lines[-1][:max(1, n - 2)] + ".."
    return lines


# --------------------------------------------------------------------------------------------- scene
class Wid:
    """One widget. kind: 'box' | 'label' | 'button'. `static` never changes without a full redraw;
    `dyn` (text, flags) can be changed on the board one widget at a time."""
    __slots__ = ("kind", "x", "y", "w", "h", "bid", "f", "text", "flags")

    def __init__(self, kind, x, y, w, h, text="", flags=0, bid=None, **f):
        self.kind, self.x, self.y, self.w, self.h = kind, int(x), int(y), int(w), int(h)
        self.text, self.flags, self.bid, self.f = ascii_text(text)[0][:40], flags, bid, f

    def static(self):
        return (self.kind, self.x, self.y, self.w, self.h, self.flags & 4, tuple(sorted(self.f.items())))

    def dyn(self):
        return (self.text, self.flags)


class Scene:
    def __init__(self, bg):
        self.bg = bg
        self.w = []

    def box(self, x, y, w, h, c1, c2=None, grad=0, r=8, outline=None):
        self.w.append(Wid("box", x, y, w, h, r=r, c1=c1, c2=c2 or c1, grad=grad if c2 else 0, outline=outline))

    def label(self, x, y, w, h, text, color, bgc, font=2, align=0):
        self.w.append(Wid("label", x, y, w, h, text, color=color, bgc=bgc, font=font, align=align))
        return len(self.w) - 1

    def button(self, bid, x, y, w, h, text, c1, c2, grad, fg, line, font=2, enabled=True, busy=False, ghost=False, r=None):
        flags = (1 if enabled else 0) | (2 if busy else 0) | (4 if ghost else 0)
        if r is None:
            r = min(h // 2, 12) if h < 60 else 14
        self.w.append(Wid("button", x, y, w, h, text, flags, bid, r=r, c1=c1, c2=c2, grad=grad, fg=fg, line=line, font=font))

    def encode(self, gen, touch_flags=0):
        widgets = self.w[:MAX_WIDGETS]
        out = bytearray([gen & 255, touch_flags & 7]) + bytes(self.bg) + bytes([len(widgets)])
        for d in widgets:
            f = d.f
            out += bytes([{"box": 1, "label": 2, "button": 3}[d.kind]])
            out += int(d.x).to_bytes(2, "little", signed=True) + int(d.y).to_bytes(2, "little", signed=True)
            out += int(d.w).to_bytes(2, "little") + int(d.h).to_bytes(2, "little")
            if d.kind == "box":
                ol = f["outline"]
                out += bytes([f["r"]]) + bytes(f["c1"]) + bytes(f["c2"]) + bytes([f["grad"], 1 if ol else 0]) + bytes(ol or (0, 0, 0))
            elif d.kind == "label":
                t = d.text.encode("ascii", "replace")
                out += bytes(f["color"]) + bytes(f["bgc"]) + bytes([f["font"], f["align"], len(t)]) + t
            else:
                t = d.text.encode("ascii", "replace")
                out += bytes([f["r"]]) + bytes(f["c1"]) + bytes(f["c2"]) + bytes([f["grad"]]) + bytes(f["fg"])
                out += bytes([f["font"], d.flags]) + bytes(f["line"]) + bytes([len(t)]) + t
        return bytes(out)

    def bids(self):
        return {i: d.bid for i, d in enumerate(self.w[:MAX_WIDGETS]) if d.kind == "button" and d.bid}

    def same_layout(self, other):
        return (other is not None and len(other.w) == len(self.w) and other.bg == self.bg
                and all(a.static() == b.static() for a, b in zip(self.w, other.w)))


# --------------------------------------------------------------------------------------------- the screens
class NativeUi(TftUi):
    NATIVE_ONLY = {"calc", "spotify", "timers"}          # screens that need the board's own drawing (new firmware)

    @property
    def SCREENS(self):
        return TftUi.SCREENS | self.NATIVE_ONLY if self.hook("native_ok", default=False) else TftUi.SCREENS
    TITLES = {"clock": "India Standard Time", "read": "Read text", "translate": "Translator", "modes": "Modes",
              "cube": "Rubik's cube", "lamp": "Lamp connection", "calc": "Calculator", "spotify": "Spotify", "timers": "Timers"}

    # ---- button styles -> (colour 1, colour 2, gradient, text colour, outline)
    def n_style(self, name, pal, accent=None):
        if name == "primary":
            return PURPLE, BLUE, 2, (255, 255, 255), (150, 130, 250)
        if name == "orange":
            return ORANGE, ORANGE2, 2, (30, 18, 8), (255, 190, 140)
        if name == "red":
            return SALMON1, SALMON2, 1, (255, 255, 255), (255, 160, 165)
        if name == "green":
            return GREEN1, GREEN2, 2, (12, 40, 28), (150, 240, 200)
        if name == "key":
            return mix(pal["glass1"], pal["glass2"], 0.2), pal["glass2"], 1, pal["text"], pal["line"]
        if name == "tile":
            return accent, shade(accent, -0.28), 1, ((20, 20, 30) if lum(accent) > 150 else (255, 255, 255)), shade(accent, 0.35)
        return pal["glass1"], pal["glass2"], 1, pal["text"], pal["line"]                 # glass

    def n_btn(self, sc, pal, bid, rect, text, style="glass", font=2, enabled=True, accent=None):
        x, y, w, h = rect
        c1, c2, grad, fg, line = self.n_style(style, pal, accent)
        busy = self._is_busy(bid)
        room = w - 10 - (24 if busy else 0)
        while font > 1 and len(text) * FONT_PX[font] * CHAR_W > room:        # a smaller font before cutting the text
            font -= 1
        sc.button(bid, x, y, w, h, fit(text, font, room), c1, c2, grad, fg, line, font, enabled, busy)

    def n_card(self, sc, pal, rect, r=10, tint=None):
        c = pal["card"] if tint is None else mix(pal["card"], tint, 0.12)
        sc.box(*rect, c, r=r, outline=mix(pal["card_line"], tint, 0.5) if tint else pal["card_line"])

    def n_text_lines(self, sc, pal, x, y, w, n, lines, font, pitch, color, bgc):
        for i in range(n):
            sc.label(x, y + i * pitch, w, pitch, lines[i] if i < len(lines) else "", color, bgc, font, 0)

    # ---- top bar
    def n_topbar(self, sc, pal):
        now = self._now()
        if self.screen == "home":
            dark = self._dark()
            self.n_btn(sc, pal, "theme", (6, 4, 76, 24), "Light" if dark else "Dark", "glass", 2)   # the mode a tap switches to
            pages = max(1, -(-len(FEATURES) // NPER))
            self.n_btn(sc, pal, "page", (88, 4, 52, 24), f"{self.home_page + 1}/{pages}", "glass", 2)
            chip = mix(pal["glass1"], pal["glass2"], 0.5)
            sc.box(146, 4, 168, 24, chip, r=12, outline=pal["line"])
            sc.label(150, 6, 160, 20, "IST  " + self._clock_text(now, with_ampm=True), pal["text"], chip, 2, 1)
        else:
            self.n_btn(sc, pal, "home", (6, 4, 62, 24), "Home", "glass", 2)
            title = self.TITLES.get(self.screen, "")
            sc.label(72, 4, 168, 24, title, pal["text"], pal["bg"], pick_font(title, 168, (3, 2)), 1)
            dark = self._dark()
            self.n_btn(sc, pal, "theme", (246, 4, 68, 24), "Light" if dark else "Dark", "glass", 2)

    def _clock_text(self, now, with_ampm=False):
        h24 = bool(self.hook("h24", default=False))
        if h24:
            return now.strftime("%H:%M:%S")
        t = now.strftime("%I:%M:%S").lstrip("0")
        return t + (now.strftime(" %p") if with_ampm else "")

    # ---- screens (320 x 240; the bottom strip y 224..238 is the message line)
    def _n_home(self, sc, pal):
        self.n_topbar(sc, pal)
        items = FEATURES[self.home_page * NPER:(self.home_page + 1) * NPER]
        tw, th, gap = 100, 58, 4
        for i, (label, ic, accent, native, key) in enumerate(items):
            col, row = i % 3, i // 3
            self.n_btn(sc, pal, "tile%d" % (self.home_page * NPER + i), (6 + col * (tw + gap), 34 + row * (th + gap), tw, th),
                     label, "tile", 2, accent=accent)

    def _n_clock(self, sc, pal):
        self.n_topbar(sc, pal)
        now = self._now()
        h24 = bool(self.hook("h24", default=False))
        chip = mix(pal["glass1"], pal["glass2"], 0.5)
        sc.box(112, 36, 96, 20, chip, r=10, outline=pal["line"])
        sc.label(116, 38, 88, 16, "IST  +05:30", pal["text"], chip, 1, 1)
        main = now.strftime("%H:%M:%S") if h24 else now.strftime("%I:%M:%S").lstrip("0")
        sc.label(4, 62, 232 if not h24 else 312, 56, main, pal["text"], pal["bg"], 5, 1 if h24 else 2)
        if not h24:
            sc.label(240, 80, 76, 30, now.strftime("%p"), ORANGE2, pal["bg"], 4, 0)
        sc.label(6, 122, 308, 24, now.strftime("%A, %d %B %Y"), pal["sub"], pal["bg"], 3, 1)
        self.n_btn(sc, pal, "fmt", (6, 150, 150, 30), "Switch to 12-hour" if h24 else "Switch to 24-hour", "glass", 2)
        self.n_btn(sc, pal, "say", (164, 150, 150, 30), "Say the time", "glass", 2)

    def _n_read(self, sc, pal):
        self.n_topbar(sc, pal)
        self.n_btn(sc, pal, "capture", (6, 34, 308, 48), "Capture and read", "primary", 3)
        self.n_btn(sc, pal, "open", (6, 88, 150, 40), "Open picture...", "glass", 2)
        self.n_btn(sc, pal, "to_translate", (164, 88, 150, 40), "Translate", "orange", 3)
        self.n_card(sc, pal, (6, 134, 238, 86))
        text = (self.hook("last_text", default="") or "").strip()
        if self._is_busy("capture"):
            lines = ["Reading... please wait"]
        elif not text:
            lines = ["No text yet.", "Put a page under the", "lamp and tap Capture."]
            if not self.hook("lamp_connected", default=False):
                lines.append("No lamp: use Open picture")
        else:
            lines = wrap(text, 2, 222, 5)
        self.n_text_lines(sc, pal, 12, 138, 226, 5, lines, 2, 16, pal["text"], pal["card"])

    def _n_translate(self, sc, pal):
        self.n_topbar(sc, pal)
        langs = self.langs()
        name = langs[self.lang_i % len(langs)][0]
        self.n_btn(sc, pal, "lang_prev", (6, 34, 44, 32), "<", "glass", 3)
        self.n_btn(sc, pal, "lang_pick", (56, 34, 208, 32), name, "glass", 3)
        self.n_btn(sc, pal, "lang_next", (270, 34, 44, 32), ">", "glass", 3)
        self.n_card(sc, pal, (6, 70, 308, 46))
        src, lost = ascii_text(self.tr_src or "")
        self.n_text_lines(sc, pal, 12, 73, 296, 3, wrap(src, 1, 292, 3) if src else ["Scan text first (Read text)."], 1, 13,
                        pal["text"] if src else pal["sub"], pal["card"])
        self.n_card(sc, pal, (6, 120, 308, 58), tint=ORANGE2)
        tint_bg = mix(pal["card"], ORANGE2, 0.12)
        if self._is_busy("go_tr") or self.tr_state == "working":
            lines, col = ["Translating..."], pal["sub"]
        elif self.tr_state == "error":
            lines, col = wrap(self.tr_out, 1, 292, 4), (240, 90, 100)
        elif self.tr_out:
            out, lost = ascii_text(self.tr_out)
            if lost > len(out) * 0.3:
                lines, col = ["The translation uses letters the lamp", "screen cannot draw. Tap Say it, or look", "at the laptop."], pal["text"]
            else:
                lines, col = wrap(out, 2, 292, 3), pal["text"]
        else:
            lines, col = ["Translation appears here."], pal["sub"]
        small = len(lines) > 3 or (lines and lines[0].startswith("The translation uses")) or self.tr_state == "error"
        fnt, pitch = (1, 12) if small else (2, 16)
        self.n_text_lines(sc, pal, 12, 123, 296, 4 if fnt == 1 else 3, lines, fnt, pitch, col, tint_bg)
        self.n_btn(sc, pal, "go_tr", (6, 182, 118, 38), "Translate", "orange", 3, enabled=bool(self.tr_src))
        self.n_btn(sc, pal, "say_tr", (130, 182, 114, 38), "Say it", "glass", 3, enabled=bool(self.tr_out) and self.tr_state == "")

    def _n_stat(self, sc, rect, label, value, unit=""):
        x, y, w, h = rect
        flat = mix(RED1, RED2, 0.35)
        sc.box(x, y, w, h, flat, r=8)
        sc.label(x + 8, y + 3, w - 12, 14, label, (255, 225, 228), flat, 1, 0)
        sc.label(x + 8, y + 18, 56, 34, str(value), (255, 255, 255), flat, 4, 0)
        sc.label(x + 64, y + 30, w - 68, 18, unit, (255, 215, 220), flat, 2, 0)

    def _n_modes(self, sc, pal):
        self.n_topbar(sc, pal)
        st = self.hook("stats", default=None) or {}
        self._n_stat(sc, (6, 34, 112, 58), "FOCUS TODAY", int(st.get("focus_min", 0)), "min")
        self._n_stat(sc, (6, 96, 112, 58), "OPEN TASKS", int(st.get("open_tasks", 0)))
        self._n_stat(sc, (6, 158, 112, 58), "SESSIONS LOGGED", int(st.get("sessions", 0)))
        mode = self.hook("mode", default="normal") or "normal"
        label = "Mode: " + mode.title()
        el = self.hook("mode_elapsed", default=None)
        if mode != "normal" and el is not None:
            label += f"  {int(el)}m"
        self.n_btn(sc, pal, "mode_pill", (126, 34, 188, 30), label, "glass", 2)
        for i, (bid, name, style) in enumerate((("study", "Study", "primary"), ("focus", "Focus", "orange"), ("gaming", "Gaming", "green"))):
            running = mode == bid
            wd = 188 if i < 2 else 120                         # the last button stops short of the camera corner
            label = (f"Stop {name}" if i == 2 else f"Stop {name} mode") if running else (f"Start {name}" if i == 2 else f"Start {name} mode")
            self.n_btn(sc, pal, bid, (126, 68 + i * 50, wd, 46), label, "red" if running else style, 3 if not running else 2)

    def _n_lamp(self, sc, pal):
        self.n_topbar(sc, pal)
        ok = bool(self.hook("lamp_connected", default=False))
        status = self.hook("lamp_status", default="") or ("Lamp connected" if ok else "The lamp is not connected.")
        self.n_card(sc, pal, (6, 34, 308, 52))
        sc.box(16, 54, 12, 12, (52, 211, 153) if ok else (240, 90, 100), r=6)
        self.n_text_lines(sc, pal, 36, 40, 272, 3, wrap(status, 2, 268, 3), 2, 14, pal["text"], pal["card"])
        self.n_btn(sc, pal, "connect", (6, 90, 308, 44), "Connect", "primary", 3, enabled=not ok)
        self.n_btn(sc, pal, "disconnect", (6, 138, 150, 38), "Disconnect", "glass", 2, enabled=ok)
        self.n_btn(sc, pal, "refresh", (164, 138, 150, 38), "Refresh", "glass", 2)
        self.n_btn(sc, pal, "calibrate", (6, 180, 238, 38), "Calibrate touch screen", "glass", 2, enabled=ok)

    def _n_cube(self, sc, pal):
        from .engine import FACE_NAME, GREY, NET
        self.n_topbar(sc, pal)
        faces = self.hook("cube_faces", default=None) or {}
        cell, pitch, ox, oy = 14, 16, 8, 36
        for letter, (c0, r0) in NET.items():                    # a green frame behind the selected face
            if letter == self.cube_face:
                sc.box(ox + c0 * pitch - 2, oy + r0 * pitch - 2, 3 * pitch + 2, 3 * pitch + 2, (40, 210, 150), r=4)
        for letter, (c0, r0) in NET.items():
            grid = faces.get(letter)
            for r in range(3):
                for k in range(3):
                    col = tuple(int(v) for v in grid[r][k]) if grid is not None else mix(pal["glass2"], GREY, 0.6)
                    sc.box(ox + (c0 + k) * pitch, oy + (r0 + r) * pitch, cell, cell, col, r=3)
        for letter, (c0, r0) in NET.items():                    # invisible buttons: tap a face to select it
            sc.button("face_" + letter, ox + c0 * pitch - 2, oy + r0 * pitch - 2, 3 * pitch + 2, 3 * pitch + 2, "", pal["bg"],
                      pal["bg"], 0, pal["text"], pal["bg"], 1, True, False, True, 4)
        done = sum(1 for v in faces.values() if v is not None)
        sc.label(ox, oy + 9 * pitch + 6, 200, 18, f"Face: {FACE_NAME[self.cube_face]} ({self.cube_face})", pal["text"], pal["bg"], 2, 0)
        sc.label(ox, oy + 9 * pitch + 24, 200, 14, f"{done} of 6 faces scanned", pal["sub"], pal["bg"], 1, 0)
        self.n_btn(sc, pal, "cube_scan", (214, 36, 100, 56), "Scan", "primary", 3)
        self.n_btn(sc, pal, "cube_solve", (214, 98, 100, 56), "Solve", "orange", 3)
        self.n_btn(sc, pal, "cube_open", (214, 160, 100, 24), "Open", "glass", 2)

    def _n_calc(self, sc, pal):
        self.n_topbar(sc, pal)
        expr, note = self.hook("calc_text", default=("0", "")) or ("0", "")
        self.n_card(sc, pal, (6, 32, 308, 28), r=8)
        sc.label(12, 33, 296, 26, note or expr, (240, 90, 100) if note else pal["text"], pal["card"], 4 if not note else 2, 2)
        keys = [["C", "(", ")", "/"], ["7", "8", "9", "*"], ["4", "5", "6", "-"], ["1", "2", "3", "+"], ["0", ".", "<", "="]]
        shown = {"*": "x", "<": "<-"}
        for r, row in enumerate(keys):
            for c, k in enumerate(row):
                style = "key"
                if k in "/*-+":
                    style = "orange"
                elif k == "=":
                    style = "primary"
                elif k == "C":
                    style = "red"
                self.n_btn(sc, pal, "k:" + k, (6 + c * 78, 64 + r * 24, 74, 22), shown.get(k, k), style, 2)

    def _n_spotify(self, sc, pal):
        self.n_topbar(sc, pal)
        self.n_btn(sc, pal, "sp_prev", (6, 36, 100, 62), "|<  Prev", "glass", 2)
        self.n_btn(sc, pal, "sp_playpause", (110, 36, 100, 62), "Play / Pause", "primary", 2)
        self.n_btn(sc, pal, "sp_next", (214, 36, 100, 62), "Next  >|", "glass", 2)
        self.n_btn(sc, pal, "sp_voldown", (6, 104, 100, 52), "Vol -", "glass", 3)
        self.n_btn(sc, pal, "sp_mute", (110, 104, 100, 52), "Mute", "glass", 3)
        self.n_btn(sc, pal, "sp_volup", (214, 104, 100, 52), "Vol +", "glass", 3)
        self.n_btn(sc, pal, "sp_open", (6, 164, 238, 52), "Open Spotify", "green", 3)

    def _n_timers(self, sc, pal):
        self.n_topbar(sc, pal)
        st = self.hook("timer_state", default=None) or {"time": "25:00", "button": "Start"}
        sc.label(6, 40, 308, 56, st["time"], pal["text"], pal["bg"], 5, 1)
        for i, m in enumerate((5, 10, 25, 45, 60)):
            self.n_btn(sc, pal, f"tm_p{m}", (6 + i * 62, 102, 58, 40), f"{m}m", "glass", 3)
        self.n_btn(sc, pal, "tm_toggle", (6, 150, 150, 34), st["button"], "primary", 3)
        self.n_btn(sc, pal, "tm_reset", (164, 150, 150, 34), "Reset", "glass", 3)

    # ---- build
    def build(self):
        pal = PAL["dark" if self._dark() else "light"]
        sc = Scene(pal["bg"])
        fn = {"home": self._n_home, "clock": self._n_clock, "read": self._n_read, "translate": self._n_translate, "modes": self._n_modes,
              "lamp": self._n_lamp, "cube": self._n_cube, "calc": self._n_calc, "spotify": self._n_spotify,
              "timers": self._n_timers}.get(self.screen, self._n_home)
        fn(sc, pal)
        text, until = self._toast
        sc.label(6, 224, 240, 14, text if (text and time.time() < until) else "", pal["text"], pal["bg"], 1, 1)   # message line
        return sc

    # ---- taps (they come from the board, which already showed the pressed colour)
    def tap(self, bid):
        h = self.hook
        if bid == "page":
            self.home_page = (self.home_page + 1) % max(1, -(-len(FEATURES) // NPER))
        elif bid.startswith("k:"):
            h("calc_press", bid[2:])
        elif bid.startswith("sp_"):
            h("spotify_key", bid[3:])
        elif bid.startswith("tm_"):
            h("timer_do", bid[3:])
        elif bid in ("study", "focus", "gaming"):
            if (h("mode", default="normal") or "normal") == bid:
                h("end_mode")
            elif self._need("start_mode"):
                h("start_mode", bid)
        elif bid == "mode_pill":
            if (h("mode", default="normal") or "normal") != "normal":
                h("end_mode")
        else:
            self._activate(bid)


# --------------------------------------------------------------------------------------------- the sender thread
class NativeRunner:
    """Background thread: sends the newest scene to the board (a whole screen when the layout changed, single
    texts when only texts changed), and collects the taps the board has seen."""

    def __init__(self, get_board, is_active, on_tap, touch_flags=lambda: 0, idle_s=0.1):
        self.get_board, self.is_active, self.on_tap, self.touch_flags = get_board, is_active, on_tap, touch_flags
        self._latest = None
        self._sent = None
        self._board = None
        self._gen = 0
        self._bids = {}
        self._quit = False
        self.sent_full = 0                 # statistics (for tests / debugging)
        self.sent_updates = 0
        self._wake = threading.Event()
        threading.Thread(target=self._loop, daemon=True).start()

    def submit(self, scene):
        self._latest = scene
        self._wake.set()

    def forget(self):
        """The board's screen was changed by someone else: the next scene is sent in full."""
        self._sent = None

    def stop(self):
        self._quit = True
        self._wake.set()

    def _send(self, board, scene):
        old = self._sent
        if old is not None and scene.same_layout(old):
            for i, (a, b) in enumerate(zip(scene.w[:MAX_WIDGETS], old.w)):
                if a.dyn() != b.dyn():
                    board.scene_update(i, a.flags, a.text)
                    self.sent_updates += 1
        else:
            self._gen = self._gen % 250 + 1
            board.scene(scene.encode(self._gen, self.touch_flags()))
            self._bids = scene.bids()
            self.sent_full += 1
        self._sent = scene

    def _loop(self):
        while not self._quit:
            try:
                board = self.get_board()
                if board is None or not getattr(board, "native_ok", False) or not self.is_active():
                    self._sent = None
                    self._wake.wait(0.15)
                    self._wake.clear()
                    continue
                if board is not self._board:
                    self._board, self._sent = board, None
                scene = self._latest
                if scene is not None and scene is not self._sent:
                    self._send(board, scene)
                for gen, wid in board.poll_events():
                    bid = self._bids.get(wid)
                    if gen == self._gen and bid:
                        self.on_tap(bid)
                self._wake.wait(0.012)
                self._wake.clear()
            except Exception as e:                                     # noqa: BLE001 - a hiccup must not stop the screen
                self._sent = None
                print(f"[tft-native] {e}")
                time.sleep(0.3)


# --------------------------------------------------------------------------------------------- simulator (preview without the lamp)
def simulate(scene, pressed=None):
    """Draws a Scene the way the firmware does (same boxes, bands, fonts) so every screen can be checked on a PC.
    Returns a 320x240 RGB Pillow image."""
    from PIL import Image, ImageDraw

    from .fonts import font as pil_font

    img = Image.new("RGB", (W, H), scene.bg)
    d = ImageDraw.Draw(img)

    def grad_box(x, y, w, h, r, c1, c2, grad, outline=None):
        r = min(r, w // 2, h // 2)
        if grad == 0 or c1 == c2:
            d.rounded_rectangle([x, y, x + w - 1, y + h - 1], r, fill=tuple(c1))
        else:
            steps = (6 if h >= 40 else 4) if grad == 1 else (8 if w >= 120 else 5)
            layer = Image.new("RGB", (w, h), tuple(c1))
            ld = ImageDraw.Draw(layer)
            for i in range(steps):
                col = mix(c1, c2, i / max(1, steps - 1))
                if grad == 1:
                    ld.rectangle([0, h * i // steps, w, h * (i + 1) // steps], fill=col)
                else:
                    ld.rectangle([w * i // steps, 0, w * (i + 1) // steps, h], fill=col)
            mask = Image.new("L", (w, h), 0)
            ImageDraw.Draw(mask).rounded_rectangle([0, 0, w - 1, h - 1], r, fill=255)
            img.paste(layer, (x, y), mask)
        if outline:
            d.rounded_rectangle([x, y, x + w - 1, y + h - 1], r, outline=tuple(outline))

    def text(x, y, w, h, s, font, color, align):
        f = pil_font(FONT_PX[font], bold=False)
        tw = d.textlength(s, font=f)
        tx = x if align == 0 else (x + (w - tw) / 2 if align == 1 else x + w - tw)
        d.text((tx, y + h / 2), s, font=f, fill=tuple(color), anchor="lm")

    for i, wd in enumerate(scene.w[:MAX_WIDGETS]):
        f = wd.f
        if wd.kind == "box":
            grad_box(wd.x, wd.y, wd.w, wd.h, f["r"], f["c1"], f["c2"], f["grad"], f["outline"])
        elif wd.kind == "label":
            d.rectangle([wd.x, wd.y, wd.x + wd.w - 1, wd.y + wd.h - 1], fill=tuple(f["bgc"]))
            text(wd.x, wd.y, wd.w, wd.h, wd.text, f["font"], f["color"], f["align"])
        elif wd.flags & 4:
            continue
        else:
            c1, c2, fg = f["c1"], f["c2"], f["fg"]
            if not wd.flags & 1:
                c1, c2, fg = mix(c1, scene.bg, 0.65), mix(c2, scene.bg, 0.65), mix(fg, scene.bg, 0.45)
            elif pressed == wd.bid:
                c1, c2 = mix(c1, (0, 0, 0), 0.3), mix(c2, (0, 0, 0), 0.3)
            grad_box(wd.x, wd.y, wd.w, wd.h, f["r"], c1, c2, f["grad"], f["line"])
            f_ = pil_font(FONT_PX[f["font"]], bold=False)
            tw = d.textlength(wd.text, font=f_)
            if wd.flags & 2:                                   # busy: dots instead of the spinner
                d.text((wd.x + wd.w / 2 - tw / 2 - 12, wd.y + wd.h / 2), "...", font=f_, fill=tuple(fg), anchor="rm")
            d.text((wd.x + wd.w / 2, wd.y + wd.h / 2), wd.text, font=f_, fill=tuple(fg), anchor="mm")
    if config.TFT_CAM_ALWAYS:                                  # where the board draws the live camera picture
        x, y, w, h = config.TFT_CAM_BOX
        d.rectangle([x - 1, y - 1, x + w, y + h], outline=(255, 255, 255), fill=(34, 40, 56))
        d.text((x + w / 2, y + h / 2), "CAMERA", font=pil_font(9, bold=False), fill=(200, 205, 225), anchor="mm")
    return img
