"""Drawing helpers: everything is painted 3x bigger and shrunk at the end, so edges and text are smooth."""
import math

import numpy as np
from PIL import Image, ImageDraw

from .fonts import font, needs_wide, wide_font

SS = 3


def mix(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


def shade(c, k):
    """k > 0 lighter, k < 0 darker."""
    return mix(c, (255, 255, 255), k) if k >= 0 else mix(c, (0, 0, 0), -k)


class Canvas:
    def __init__(self, w, h, bg):
        self.w, self.h = w, h
        self.img = Image.new("RGB", (w * SS, h * SS), bg)
        self.d = ImageDraw.Draw(self.img)

    # ---- shapes
    def _box(self, rect):
        x, y, w, h = rect
        return [round(x * SS), round(y * SS), round((x + w) * SS) - 1, round((y + h) * SS) - 1]

    def rrect(self, rect, r, fill=None, outline=None, width=1):
        self.d.rounded_rectangle(self._box(rect), radius=r * SS, fill=fill, outline=outline, width=max(1, round(width * SS)))

    def gradient(self, rect, r, c1, c2, mode="h"):
        """Rounded rectangle filled with a gradient. mode: h (left->right), v (top->bottom), d (diagonal)."""
        x0, y0, x1, y1 = self._box(rect)
        w, h = x1 - x0 + 1, y1 - y0 + 1
        gx = np.linspace(0, 1, w)[None, :].repeat(h, 0)
        gy = np.linspace(0, 1, h)[:, None].repeat(w, 1)
        t = gx if mode == "h" else gy if mode == "v" else (gx * 0.7 + gy * 0.3)
        arr = (np.array(c1)[None, None, :] * (1 - t[..., None]) + np.array(c2)[None, None, :] * t[..., None]).astype(np.uint8)
        mask = Image.new("L", (w, h), 0)
        ImageDraw.Draw(mask).rounded_rectangle([0, 0, w - 1, h - 1], radius=r * SS, fill=255)
        self.img.paste(Image.fromarray(arr, "RGB"), (x0, y0), mask)

    def shine(self, rect, r, strength=0.35):
        """Soft diagonal light band across a button (like the 'Start Focus mode' picture)."""
        x0, y0, x1, y1 = self._box(rect)
        w, h = x1 - x0 + 1, y1 - y0 + 1
        xs = np.linspace(0, 1, w)[None, :].repeat(h, 0)
        band = np.exp(-((xs - 0.62) ** 2) / 0.012) * strength
        overlay = Image.new("RGB", (w, h), (255, 255, 255))
        mask = Image.fromarray((band * 255).astype(np.uint8), "L")
        clip = Image.new("L", (w, h), 0)
        ImageDraw.Draw(clip).rounded_rectangle([0, 0, w - 1, h - 1], radius=r * SS, fill=255)
        mask = Image.fromarray((np.array(mask) * (np.array(clip) / 255.0)).astype(np.uint8), "L")
        self.img.paste(overlay, (x0, y0), mask)

    def circle(self, cx, cy, r, fill=None, outline=None, width=1):
        self.d.ellipse([(cx - r) * SS, (cy - r) * SS, (cx + r) * SS, (cy + r) * SS], fill=fill, outline=outline,
                       width=max(1, round(width * SS)))

    def line(self, pts, fill, width=1):
        self.d.line([(x * SS, y * SS) for x, y in pts], fill=fill, width=max(1, round(width * SS)), joint="curve")

    def poly(self, pts, fill):
        self.d.polygon([(x * SS, y * SS) for x, y in pts], fill=fill)

    def arc(self, cx, cy, r, a0, a1, fill, width=2):
        self.d.arc([(cx - r) * SS, (cy - r) * SS, (cx + r) * SS, (cy + r) * SS], a0, a1, fill=fill,
                   width=max(1, round(width * SS)))

    # ---- text
    def text(self, xy, s, size, fill, anchor="la", bold=True, mono=False):
        f = wide_font(size * SS) if needs_wide(s) else font(size * SS, bold, mono)
        self.d.text((xy[0] * SS, xy[1] * SS), s, font=f, fill=fill, anchor=anchor)

    def text_width(self, s, size, bold=True, mono=False):
        f = wide_font(size * SS) if needs_wide(s) else font(size * SS, bold, mono)
        return self.d.textlength(s, font=f) / SS

    def fit(self, s, size, max_w, bold=True, mono=False, min_size=7):
        while size > min_size and self.text_width(s, size, bold, mono) > max_w:
            size -= 1
        return size

    def wrap(self, s, size, max_w, max_lines, bold=False):
        """Word-wrap text to the width; the last line gets '...' if there is more."""
        lines, cur = [], ""
        for para in str(s).replace("\r", "").split("\n"):
            for word in para.split(" "):
                trial = (cur + " " + word).strip()
                if self.text_width(trial, size, bold) <= max_w or not cur:
                    cur = trial
                else:
                    lines.append(cur)
                    cur = word
            lines.append(cur)
            cur = ""
        if len(lines) > max_lines:
            lines = lines[:max_lines]
            lines[-1] = lines[-1].rstrip()[:max(0, len(lines[-1]) - 3)] + "..."
        return lines

    def finish(self):
        """Shrink to the screen size -> BGR uint8 array (what OpenCV and the board code use)."""
        small = self.img.resize((self.w, self.h), Image.LANCZOS)
        return np.asarray(small)[:, :, ::-1].copy()


# ------------------------------------------------------------------ icons (centre cx, cy, half-size s)
def icon(c, name, cx, cy, s, col, bg=(0, 0, 0), t=0.0):
    w = max(1.4, s * 0.16)
    if name == "clock":
        c.circle(cx, cy, s, outline=col, width=w)
        c.line([(cx, cy), (cx, cy - s * 0.6)], col, w)
        c.line([(cx, cy), (cx + s * 0.45, cy + s * 0.2)], col, w)
    elif name == "speaker":
        c.poly([(cx - s, cy - s * 0.35), (cx - s * 0.45, cy - s * 0.35), (cx + s * 0.1, cy - s * 0.85),
                (cx + s * 0.1, cy + s * 0.85), (cx - s * 0.45, cy + s * 0.35), (cx - s, cy + s * 0.35)], col)
        c.arc(cx + s * 0.1, cy, s * 0.55, -50, 50, col, w)
        c.arc(cx + s * 0.1, cy, s * 0.95, -50, 50, col, w)
    elif name == "check":
        c.line([(cx - s * 0.7, cy), (cx - s * 0.2, cy + s * 0.55), (cx + s * 0.8, cy - s * 0.55)], col, w * 1.3)
    elif name == "cross":
        c.line([(cx - s * 0.6, cy - s * 0.6), (cx + s * 0.6, cy + s * 0.6)], col, w * 1.3)
        c.line([(cx - s * 0.6, cy + s * 0.6), (cx + s * 0.6, cy - s * 0.6)], col, w * 1.3)
    elif name == "refresh":
        c.arc(cx, cy, s * 0.8, 40, 340, col, w * 1.2)
        a = math.radians(40)
        px, py = cx + s * 0.8 * math.cos(a), cy + s * 0.8 * math.sin(a)
        c.poly([(px - s * 0.1, py - s * 0.55), (px + s * 0.45, py + s * 0.05), (px - s * 0.5, py + s * 0.15)], col)
    elif name == "camera":
        c.rrect((cx - s, cy - s * 0.6, s * 2, s * 1.5), s * 0.25, outline=col, width=w)
        c.rrect((cx - s * 0.35, cy - s * 0.95, s * 0.7, s * 0.4), s * 0.1, fill=col)
        c.circle(cx, cy + s * 0.15, s * 0.42, outline=col, width=w)
    elif name == "folder":
        c.poly([(cx - s, cy - s * 0.6), (cx - s * 0.25, cy - s * 0.6), (cx, cy - s * 0.3), (cx + s, cy - s * 0.3),
                (cx + s, cy + s * 0.7), (cx - s, cy + s * 0.7)], None if False else col)
        c.poly([(cx - s * 0.85, cy - s * 0.05), (cx + s * 0.85, cy - s * 0.05), (cx + s * 0.85, cy + s * 0.55),
                (cx - s * 0.85, cy + s * 0.55)], bg)
    elif name == "translate":
        c.rrect((cx - s, cy - s * 0.9, s * 1.25, s * 1.25), s * 0.25, outline=col, width=w)
        c.rrect((cx - s * 0.25, cy - s * 0.35, s * 1.25, s * 1.25), s * 0.25, outline=col, width=w)
    elif name == "sun":
        c.circle(cx, cy, s * 0.42, fill=col)
        for i in range(8):
            a = math.radians(i * 45)
            c.line([(cx + math.cos(a) * s * 0.7, cy + math.sin(a) * s * 0.7),
                    (cx + math.cos(a) * s * 1.0, cy + math.sin(a) * s * 1.0)], col, w)
    elif name == "moon":
        c.circle(cx, cy, s * 0.8, fill=col)
        c.circle(cx + s * 0.45, cy - s * 0.3, s * 0.7, fill=bg)
    elif name == "home":
        c.poly([(cx - s, cy), (cx, cy - s * 0.9), (cx + s, cy)], col)
        c.rrect((cx - s * 0.7, cy - s * 0.05, s * 1.4, s * 0.9), 1, fill=col)
    elif name == "back":
        c.line([(cx + s * 0.4, cy - s * 0.8), (cx - s * 0.4, cy), (cx + s * 0.4, cy + s * 0.8)], col, w * 1.3)
    elif name == "next":
        c.line([(cx - s * 0.4, cy - s * 0.8), (cx + s * 0.4, cy), (cx - s * 0.4, cy + s * 0.8)], col, w * 1.3)
    elif name == "calc":
        c.rrect((cx - s * 0.75, cy - s, s * 1.5, s * 2), s * 0.2, outline=col, width=w)
        c.rrect((cx - s * 0.5, cy - s * 0.75, s, s * 0.45), 1, fill=col)
        for i in range(3):
            for j in range(2):
                c.circle(cx - s * 0.35 + i * s * 0.35, cy + s * 0.1 + j * s * 0.5, s * 0.1, fill=col)
    elif name == "gear":
        c.circle(cx, cy, s * 0.55, outline=col, width=w * 1.4)
        for i in range(8):
            a = math.radians(i * 45)
            c.line([(cx + math.cos(a) * s * 0.7, cy + math.sin(a) * s * 0.7),
                    (cx + math.cos(a) * s * 1.0, cy + math.sin(a) * s * 1.0)], col, w * 1.6)
    elif name == "cube":
        pts = [(cx, cy - s), (cx + s * 0.9, cy - s * 0.5), (cx + s * 0.9, cy + s * 0.5), (cx, cy + s), (cx - s * 0.9, cy + s * 0.5),
               (cx - s * 0.9, cy - s * 0.5), (cx, cy - s)]
        c.line(pts, col, w)
        c.line([(cx, cy), (cx, cy + s), (cx, cy)], col, w)
        c.line([(cx - s * 0.9, cy - s * 0.5), (cx, cy), (cx + s * 0.9, cy - s * 0.5)], col, w)
    elif name == "wifi":
        for k in (0.4, 0.75, 1.1):
            c.arc(cx, cy + s * 0.55, s * k, 225, 315, col, w * 1.2)
        c.circle(cx, cy + s * 0.55, s * 0.1, fill=col)
    elif name == "book":
        c.rrect((cx - s * 0.9, cy - s * 0.7, s * 0.9, s * 1.4), 2, outline=col, width=w)
        c.rrect((cx, cy - s * 0.7, s * 0.9, s * 1.4), 2, outline=col, width=w)
    elif name == "music":
        c.line([(cx + s * 0.4, cy - s * 0.8), (cx + s * 0.4, cy + s * 0.5)], col, w * 1.2)
        c.line([(cx + s * 0.4, cy - s * 0.8), (cx - s * 0.5, cy - s * 0.5)], col, w * 1.4)
        c.circle(cx + s * 0.1, cy + s * 0.5, s * 0.35, fill=col)
    elif name == "globe":
        c.circle(cx, cy, s * 0.9, outline=col, width=w)
        c.d.ellipse([(cx - s * 0.4) * SS, (cy - s * 0.9) * SS, (cx + s * 0.4) * SS, (cy + s * 0.9) * SS], outline=col, width=round(w * SS))
        c.line([(cx - s * 0.9, cy), (cx + s * 0.9, cy)], col, w)
    elif name == "chess":
        c.circle(cx, cy - s * 0.5, s * 0.35, fill=col)
        c.poly([(cx - s * 0.3, cy - s * 0.2), (cx + s * 0.3, cy - s * 0.2), (cx + s * 0.6, cy + s * 0.7), (cx - s * 0.6, cy + s * 0.7)], col)
        c.rrect((cx - s * 0.8, cy + s * 0.7, s * 1.6, s * 0.25), 1, fill=col)
    elif name == "grid":
        for i in range(3):
            for j in range(3):
                c.rrect((cx - s + i * s * 0.72, cy - s + j * s * 0.72, s * 0.56, s * 0.56), 1.5, fill=col)
    elif name == "spinner":
        c.arc(cx, cy, s * 0.8, t, t + 270, col, w * 1.5)
    elif name == "dot":
        c.circle(cx, cy, s * 0.5, fill=col)
