"""Fonts: the bundled DejaVu files first, then whatever the PC has (Hindi etc. need a system font)."""
import os
from functools import lru_cache

from PIL import ImageFont

_HERE = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets", "fonts")
_SYSTEM_WIDE = [os.path.join(_HERE, "FreeSans.ttf"), r"C:\Windows\Fonts\Nirmala.ttf", r"C:\Windows\Fonts\segoeui.ttf", r"C:\Windows\Fonts\arial.ttf",
                "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf", "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"]


def _first(paths):
    for p in paths:
        if os.path.exists(p):
            return p
    return None


@lru_cache(maxsize=64)
def font(size, bold=True, mono=False):
    name = "DejaVuSansMono-Bold.ttf" if mono else ("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf")
    p = _first([os.path.join(_HERE, name)])
    try:
        return ImageFont.truetype(p, int(size)) if p else ImageFont.load_default()
    except OSError:
        return ImageFont.load_default()


@lru_cache(maxsize=16)
def wide_font(size):
    """For scripts DejaVu does not have (Devanagari, Arabic, CJK)."""
    p = _first(_SYSTEM_WIDE)
    try:
        return ImageFont.truetype(p, int(size)) if p else font(size, False)
    except OSError:
        return font(size, False)


def needs_wide(text):
    return any(ord(c) > 0x024F and not (0x2000 <= ord(c) <= 0x2BFF) for c in text)
