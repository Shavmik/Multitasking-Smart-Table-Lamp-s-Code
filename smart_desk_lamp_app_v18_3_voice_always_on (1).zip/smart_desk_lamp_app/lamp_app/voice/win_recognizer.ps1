# Windows speech recogniser (built into the operating system, works offline).
# Listens to the default microphone for the phrases in $PhrasesFile and prints one line per phrase it understood:
#   READY|en-US          the recogniser is listening
#   HEARD|0.87|turn on the smart desk lamp
#   ERROR|message
param([Parameter(Mandatory = $true)][string]$PhrasesFile, [switch]$Debug)
try {
    Add-Type -AssemblyName System.Speech
    $installed = [System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers()
    if ($installed.Count -eq 0) {
        [Console]::WriteLine("ERROR|Windows has no speech recogniser installed (Settings > Time & language > Speech).")
        exit 2
    }
    $info = $installed | Where-Object { $_.Culture.Name -like 'en*' } | Select-Object -First 1
    if (-not $info) { $info = $installed[0] }
    $engine = New-Object System.Speech.Recognition.SpeechRecognitionEngine($info)
    $choices = New-Object System.Speech.Recognition.Choices
    foreach ($line in (Get-Content -LiteralPath $PhrasesFile)) {
        if ($line.Trim().Length -gt 0) { $choices.Add($line.Trim()) }
    }
    $builder = New-Object System.Speech.Recognition.GrammarBuilder
    $builder.Culture = $info.Culture
    $builder.Append($choices)
    $engine.LoadGrammar((New-Object System.Speech.Recognition.Grammar($builder)))
    $engine.SetInputToDefaultAudioDevice()
    [Console]::WriteLine("READY|" + $info.Culture.Name)
    [Console]::Out.Flush()
    if ($Debug) {
        # test mode: live feedback about the microphone and about everything the recogniser thinks it hears
        $global:lvl = 0
        Register-ObjectEvent -InputObject $engine -EventName AudioLevelUpdated -Action {
            $global:lvl++
            if ($global:lvl % 4 -eq 0) { [Console]::WriteLine("LEVEL|" + $Event.SourceEventArgs.AudioLevel); [Console]::Out.Flush() }
        } | Out-Null
        Register-ObjectEvent -InputObject $engine -EventName SpeechDetected -Action { [Console]::WriteLine("DETECTED|"); [Console]::Out.Flush() } | Out-Null
        Register-ObjectEvent -InputObject $engine -EventName SpeechHypothesized -Action {
            [Console]::WriteLine("HYP|" + $Event.SourceEventArgs.Result.Text); [Console]::Out.Flush() } | Out-Null
        Register-ObjectEvent -InputObject $engine -EventName SpeechRecognitionRejected -Action {
            [Console]::WriteLine([string]::Format([Globalization.CultureInfo]::InvariantCulture, "REJECTED|{0:0.00}|{1}", $Event.SourceEventArgs.Result.Confidence, $Event.SourceEventArgs.Result.Text)); [Console]::Out.Flush() } | Out-Null
        Register-ObjectEvent -InputObject $engine -EventName SpeechRecognized -Action {
            [Console]::WriteLine([string]::Format([Globalization.CultureInfo]::InvariantCulture, "HEARD|{0:0.00}|{1}", $Event.SourceEventArgs.Result.Confidence, $Event.SourceEventArgs.Result.Text)); [Console]::Out.Flush() } | Out-Null
        $engine.RecognizeAsync([System.Speech.Recognition.RecognizeMode]::Multiple)
        while ($true) { Start-Sleep -Milliseconds 200 }
    }
    while ($true) {
        $result = $engine.Recognize()
        if ($result -ne $null -and $result.Text) {
            [Console]::WriteLine([string]::Format([Globalization.CultureInfo]::InvariantCulture, "HEARD|{0:0.00}|{1}", $result.Confidence, $result.Text))
            [Console]::Out.Flush()
        }
    }
}
catch {
    [Console]::WriteLine("ERROR|" + $_.Exception.Message)
    exit 1
}
