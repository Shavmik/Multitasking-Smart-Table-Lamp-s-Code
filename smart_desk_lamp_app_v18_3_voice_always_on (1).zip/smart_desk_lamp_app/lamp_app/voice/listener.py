"""The always-running voice listener (small, no Qt): hears a command, starts the app if needed, tells it what to do."""
import os
import shutil
import subprocess
import sys
import tempfile
import time

from .. import config
from . import client
from .phrases import COMMANDS, lookup

HERE = os.path.dirname(os.path.abspath(__file__))


def _find_project():
    """The folder that contains lamp_app/ (when packed as an .exe, walk up from the .exe until it is found)."""
    if getattr(sys, "frozen", False):
        d = os.path.dirname(os.path.abspath(sys.executable))
        for _ in range(5):
            if os.path.isdir(os.path.join(d, "lamp_app")):
                return d
            d = os.path.dirname(d)
    return os.path.dirname(os.path.dirname(HERE))


PROJECT = _find_project()
LOG_DIR = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "SmartDeskLamp")
LOG_FILE = os.path.join(LOG_DIR, "voice.log")                    # "Voice status.bat" shows the end of this file
NO_WINDOW = 0x08000000                                           # CREATE_NO_WINDOW (Windows)
NEW_CONSOLE = 0x00000010                                         # CREATE_NEW_CONSOLE (the app hides it itself)
NEW_GROUP = 0x00000200


def log(msg):
    line = time.strftime("%Y-%m-%d %H:%M:%S ") + msg
    print(line, flush=True)
    try:                                                         # the hidden listener has no window: keep a log file
        os.makedirs(LOG_DIR, exist_ok=True)
        if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > 300_000:
            os.replace(LOG_FILE, LOG_FILE + ".old")
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def python_exe():
    if getattr(sys, "frozen", False):                            # we are SmartDeskLampVoice.exe: use the installed Python for the app
        return shutil.which("python") or shutil.which("py") or "python"
    exe = sys.executable
    return exe[:-len("pythonw.exe")] + "python.exe" if exe.lower().endswith("pythonw.exe") else exe


def launch_app():
    """Starts the Smart Desk Lamp app the way 'Smart Desk Lamp.bat' does (its own console, hidden by the app)."""
    flags = (NEW_CONSOLE | NEW_GROUP) if os.name == "nt" else 0
    subprocess.Popen([python_exe(), "-m", "lamp_app"], cwd=PROJECT, creationflags=flags, close_fds=True)


def speak(text):
    if os.name != "nt":
        return
    ps = f"Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{text}')"
    subprocess.Popen(["powershell", "-NoProfile", "-Command", ps], creationflags=NO_WINDOW)


# ---------------------------------------------------------------- Windows helpers (always-on, clean exit)
_job = None


def _kernel32():
    import ctypes
    from ctypes import wintypes
    k = ctypes.WinDLL("kernel32", use_last_error=True)
    k.CreateJobObjectW.restype = wintypes.HANDLE
    k.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
    k.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
    k.OpenProcess.restype = wintypes.HANDLE
    k.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    k.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
    k.CloseHandle.argtypes = [wintypes.HANDLE]
    k.CreateMutexW.restype = wintypes.HANDLE
    k.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
    return k


def already_running():
    """True when another voice listener is already running (so a second one would fight for the microphone)."""
    if os.name != "nt":
        return False
    k = _kernel32()
    import ctypes
    global _mutex
    _mutex = k.CreateMutexW(None, False, "Local\\SmartDeskLampVoiceListener")
    return ctypes.get_last_error() == 183                        # ERROR_ALREADY_EXISTS


def bind_to_my_life(proc):
    """Makes Windows kill the microphone process (powershell) when THIS program ends - also when it is
    ended from the Task Manager. Without this the recogniser would keep listening after End task."""
    global _job
    if os.name != "nt":
        return
    try:
        import ctypes
        from ctypes import wintypes
        k = _kernel32()
        if _job is None:
            class BASIC(ctypes.Structure):
                _fields_ = [("PerProcessUserTimeLimit", ctypes.c_int64), ("PerJobUserTimeLimit", ctypes.c_int64),
                            ("LimitFlags", wintypes.DWORD), ("MinimumWorkingSetSize", ctypes.c_size_t),
                            ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", wintypes.DWORD),
                            ("Affinity", ctypes.c_size_t), ("PriorityClass", wintypes.DWORD), ("SchedulingClass", wintypes.DWORD)]

            class IOC(ctypes.Structure):
                _fields_ = [(n, ctypes.c_uint64) for n in ("a", "b", "c", "d", "e", "f")]

            class EXT(ctypes.Structure):
                _fields_ = [("Basic", BASIC), ("Io", IOC), ("ProcessMemoryLimit", ctypes.c_size_t),
                            ("JobMemoryLimit", ctypes.c_size_t), ("PeakProcessMemoryUsed", ctypes.c_size_t),
                            ("PeakJobMemoryUsed", ctypes.c_size_t)]
            _job = k.CreateJobObjectW(None, None)
            info = EXT()
            info.Basic.LimitFlags = 0x2000                       # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            k.SetInformationJobObject(_job, 9, ctypes.byref(info), ctypes.sizeof(info))
        h = k.OpenProcess(0x0001 | 0x0100, False, proc.pid)      # TERMINATE | SET_QUOTA
        if h:
            k.AssignProcessToJobObject(_job, h)
            k.CloseHandle(h)
    except Exception as e:                                       # noqa: BLE001 - only a safety net
        log(f"could not tie the microphone process to this program: {e}")


class Listener:
    def __init__(self, port=None, confidence=None, say=None, launch=None, send=None, running=None, clock=time.time):
        self.port = port or config.VOICE_PORT
        self.confidence = config.VOICE_CONFIDENCE if confidence is None else confidence
        self.say = say if say is not None else (speak if config.VOICE_SPEAK else (lambda t: None))
        self.launch = launch or launch_app
        self.send = send or client.send
        self.running = running or client.is_running
        self.clock = clock
        self.mute_until = 0.0

    def handle(self, text, conf):
        """One phrase Windows understood. Returns what was done (for logs / tests)."""
        now = self.clock()
        if now < self.mute_until:
            return "ignored (just spoke)"
        cmd = lookup(text)
        if cmd is None:
            return "not a command"
        if conf < self.confidence:
            log(f"heard '{text}' but only {conf:.2f} sure (need {self.confidence:.2f}) - ignored")
            return "too unsure"
        log(f"heard '{text}' ({conf:.2f}) -> {cmd}")
        if cmd == "WAKE":
            if not self.running(self.port):
                log("the app is not running: starting it ...")
                self._speak("Okay, starting")
                self.launch()
                end = self.clock() + 120
                while self.clock() < end and not self.running(self.port):
                    time.sleep(0.5)
                if not self.running(self.port):
                    log("the app did not come up in time")
                    return "app did not start"
                self.send("WAKE", self.port)
                return "started app"
            self.send("WAKE", self.port)
            self._speak("Okay")
            return "woke app"
        if not self.running(self.port):
            log("the app is not running - say 'turn on the smart desk lamp' first")
            return "app not running"
        answer = self.send(cmd, self.port)
        if cmd != "SLEEP":
            self._speak("Okay")
        return f"sent {cmd}: {answer}"

    def _speak(self, text):
        self.say(text)
        self.mute_until = self.clock() + 2.5            # do not hear our own voice


def format_test_line(line, confidence=None):
    """One recogniser line -> a readable line for the microphone test (None = nothing to show)."""
    confidence = config.VOICE_CONFIDENCE if confidence is None else confidence
    kind, _, rest = line.strip().partition("|")
    if kind == "LEVEL":
        try:
            n = max(0, min(100, int(rest)))
        except ValueError:
            return None
        return "   microphone level  [" + "#" * (n // 5) + "." * (20 - n // 5) + f"] {n:3d}"
    if kind == "DETECTED":
        return " > it hears speech ..."
    if kind == "HYP":
        return f" > thinking you said: {rest}"
    if kind == "REJECTED":
        return " x heard something but it did not match any command phrase"
    if kind == "HEARD":
        conf, _, text = rest.partition("|")
        cmd = lookup(text)
        try:
            ok = float(conf) >= confidence
        except ValueError:
            ok = False
        verdict = ("WOULD RUN: " + cmd) if (cmd and ok) else ("too unsure (needs " + f"{confidence:.2f}" + ")" if cmd else "not a command")
        return f" OK UNDERSTOOD '{text}' (sure {conf}) -> {verdict}"
    if kind in ("READY", "ERROR"):
        return f" {kind}: {rest}"
    return None


def test_mode():
    """Microphone test: shows live what Windows hears. Nothing is started or sent to the app."""
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as f:
        f.write("\n".join(sorted(COMMANDS)))
        phrases_file = f.name
    print("MICROPHONE TEST - speak now. Try:  turn on the smart desk lamp")
    print("The bar moves with your voice. Press Ctrl+C to stop.\n")
    proc = recognizer_process(phrases_file, debug=True)
    try:
        for line in proc.stdout:
            text = format_test_line(line)
            if text:
                print(text, flush=True)
    except KeyboardInterrupt:
        pass
    finally:
        proc.terminate()
    return 0


def recognizer_process(phrases_file, debug=False):
    script = os.path.join(HERE, "win_recognizer.ps1")
    flags = NO_WINDOW if os.name == "nt" else 0
    extra = ["-Debug"] if debug else []
    proc = subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script, "-PhrasesFile", phrases_file] + extra,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1, creationflags=flags)
    bind_to_my_life(proc)
    return proc


def main(argv=None):
    if os.name != "nt":
        print("The voice listener uses the Windows speech recogniser, so it only runs on Windows.")
        return 1
    if "--test" in (sys.argv[1:] if argv is None else argv):
        return test_mode()
    if already_running():
        log("another voice listener is already running - this one will close (end it in the Task Manager to stop voice control)")
        return 0
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as f:
        f.write("\n".join(sorted(COMMANDS)))
        phrases_file = f.name
    listener = Listener()
    log(f"Smart Desk Lamp voice listener started (process id {os.getpid()}). Say:  \"turn on the smart desk lamp\"")
    failures = 0
    while True:
        started = time.time()
        proc = recognizer_process(phrases_file)
        for line in proc.stdout:
            line = line.strip()
            if line.startswith("READY|"):
                failures = 0
                log(f"listening (recogniser language {line.split('|', 1)[1]}) - say \"turn on the smart desk lamp\"")
            elif line.startswith("HEARD|"):
                try:
                    _, conf, text = line.split("|", 2)
                    listener.handle(text, float(conf))
                except Exception as e:                                  # noqa: BLE001 - never stop listening
                    log(f"error: {e}")
            elif line.startswith("ERROR|"):
                log("recogniser: " + line.split("|", 1)[1])
        proc.wait()
        failures += 1 if time.time() - started < 20 else 0
        wait = min(60, 5 * max(1, failures))
        log(f"the recogniser stopped - restarting in {wait} s (is a microphone connected and allowed for desktop apps?)")
        time.sleep(wait)
