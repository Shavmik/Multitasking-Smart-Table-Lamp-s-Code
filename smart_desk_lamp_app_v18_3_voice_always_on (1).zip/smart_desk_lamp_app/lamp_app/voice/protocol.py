"""The few words the listener and the app say to each other (one text line per command, answered by one line)."""

ALLOWED_TAPS = {"capture", "say", "fmt", "theme", "to_translate"}      # buttons a voice command may press on the lamp screen
MODES = {"study", "focus", "gaming", "normal"}
SCREENS = {"home", "clock", "read", "translate", "modes", "lamp", "cube", "calc", "spotify", "timers", "reader", "erp", "planner"}


def parse(line):
    """'GO clock' -> ('GO', 'clock'); returns (None, '') for anything that is not a known command."""
    parts = str(line).strip().split(None, 1)
    if not parts:
        return None, ""
    verb, arg = parts[0].upper(), (parts[1].strip().lower() if len(parts) > 1 else "")
    if verb in ("PING", "WAKE", "SLEEP", "QUIT"):
        return verb, ""
    if verb == "GO" and arg in SCREENS:
        return verb, arg
    if verb == "MODE" and arg in MODES:
        return verb, arg
    if verb == "TAP" and arg in ALLOWED_TAPS:
        return verb, arg
    return None, ""
