"""Talks to the running app (Qt free, so the small listener process stays light)."""
import socket


def send(cmd, port, timeout=2.0):
    """Sends one command line, returns the app's one-line answer, or None when the app is not running."""
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=timeout) as s:
            s.settimeout(timeout)
            s.sendall((cmd.strip() + "\n").encode("utf-8"))
            data = b""
            while not data.endswith(b"\n"):
                chunk = s.recv(256)
                if not chunk:
                    break
                data += chunk
            return data.decode("utf-8", "replace").strip()
    except OSError:
        return None


def is_running(port):
    return send("PING", port, timeout=1.0) == "PONG"
