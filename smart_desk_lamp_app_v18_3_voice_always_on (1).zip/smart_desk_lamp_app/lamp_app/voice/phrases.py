"""What can be said. Windows only has to tell these phrases apart (a small fixed list is far more reliable than free dictation)."""

NAME = "smart desk lamp"

WAKE = [f"turn on the {NAME}", f"turn on {NAME}", f"switch on the {NAME}", f"start the {NAME}", f"open the {NAME}",
        f"open {NAME}", f"wake up the {NAME}", f"{NAME} on", f"hey {NAME}", f"hello {NAME}"]
SLEEP = [f"turn off the {NAME}", f"switch off the {NAME}", f"{NAME} off", f"put the {NAME} to sleep", f"good night {NAME}"]
QUIT = [f"close the {NAME} app", f"quit the {NAME} app", f"exit the {NAME} app"]

# phrase -> command (see protocol.py)
COMMANDS = {}
for _p in WAKE:
    COMMANDS[_p] = "WAKE"
for _p in SLEEP:
    COMMANDS[_p] = "SLEEP"
for _p in QUIT:
    COMMANDS[_p] = "QUIT"

for _word, _screen in (("clock", "clock"), ("calculator", "calc"), ("spotify", "spotify"), ("timers", "timers"),
                       ("translator", "translate"), ("read text", "read"), ("modes", "modes"), ("cube solver", "cube"),
                       ("lamp settings", "lamp"), ("planner", "planner"), ("read aloud", "reader"), ("college e r p", "erp")):
    COMMANDS[f"open the {_word}"] = f"GO {_screen}"
    COMMANDS[f"show the {_word}"] = f"GO {_screen}"
COMMANDS["go home"] = "GO home"
COMMANDS["go to the home screen"] = "GO home"
for _m in ("study", "focus", "gaming"):
    COMMANDS[f"start {_m} mode"] = f"MODE {_m}"
    COMMANDS[f"start the {_m} mode"] = f"MODE {_m}"
COMMANDS["stop the mode"] = "MODE normal"
COMMANDS["stop mode"] = "MODE normal"
COMMANDS["say the time"] = "TAP say"
COMMANDS["capture and read"] = "TAP capture"
COMMANDS["switch to dark mode"] = "TAP theme"
COMMANDS["switch to light mode"] = "TAP theme"


def lookup(text):
    """Text Windows understood -> command, or None."""
    return COMMANDS.get(" ".join(str(text).lower().replace(".", " ").replace(",", " ").split()))
