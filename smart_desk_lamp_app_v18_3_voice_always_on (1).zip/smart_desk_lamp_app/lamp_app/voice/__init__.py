"""Voice control: "turn on the smart desk lamp".

voice_listener.py (always running, started by Windows at login) listens with the Windows speech recogniser
(offline, built into the operating system). When it understands a command it starts the app (if it is not
running) and tells it what to do through a tiny local socket (127.0.0.1 only) - see protocol.py.
"""
