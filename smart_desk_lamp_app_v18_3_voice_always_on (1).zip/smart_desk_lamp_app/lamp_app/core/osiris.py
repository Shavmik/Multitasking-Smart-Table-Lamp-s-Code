"""Osiris AI connector. Two ways to use it, both configurable in the Osiris page:
  * Assistant  - chat through any OpenAI-compatible endpoint (Ollama / LM Studio / an Osiris server): POST {api}/chat/completions
  * Dashboard  - the Osiris web console (default http://localhost:3000) shown inside the app
Standard library only."""
import json
import urllib.error
import urllib.request

DEFAULTS = {"osiris_api": "http://localhost:11434/v1", "osiris_model": "llama3.2", "osiris_key": "",
            "osiris_url": "http://localhost:3000"}
SYSTEM = ("You are Osiris, the built-in assistant of a smart desk lamp app. The app has Study, Focus and Gaming modes, "
          "stopwatch/timer/tracker, an AI planner, OCR text reading, a translator, and puzzle solvers. "
          "Answer briefly and clearly; help the user plan study time and stay focused.")


class OsirisClient:
    def __init__(self, store):
        self.store = store
        self.history = []

    def cfg(self, key):
        return str(self.store.get(key, DEFAULTS[key])) or DEFAULTS[key]

    def ping(self):
        """Returns (ok, message)."""
        try:
            req = urllib.request.Request(self.cfg("osiris_api").rstrip("/") + "/models", headers=self._headers())
            with urllib.request.urlopen(req, timeout=3):
                return True, "Osiris is online."
        except Exception as e:                                   # noqa: BLE001
            return False, (f"Osiris is not reachable at {self.cfg('osiris_api')} ({e.__class__.__name__}). "
                            "The Assistant tab talks to a *local* AI server (Ollama / LM Studio / your own "
                            "Osiris backend) - it needs one running on this PC. No local server? Use the "
                            "Dashboard tab instead: it loads any AI web app right inside the app, the same "
                            "way the College ERP page does.")

    def _headers(self):
        h = {"Content-Type": "application/json"}
        if self.cfg("osiris_key").strip() and self.cfg("osiris_key") != DEFAULTS["osiris_key"]:
            h["Authorization"] = "Bearer " + self.cfg("osiris_key").strip()
        return h

    def ask(self, text, context=""):
        """Blocking - call through run_async. Keeps the conversation in self.history."""
        self.history.append({"role": "user", "content": (f"[App context]\n{context}\n\n" if context else "") + text})
        body = {"model": self.cfg("osiris_model"), "stream": False,
                "messages": [{"role": "system", "content": SYSTEM}] + self.history[-12:]}
        req = urllib.request.Request(self.cfg("osiris_api").rstrip("/") + "/chat/completions",
                                     data=json.dumps(body).encode(), headers=self._headers())
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                reply = json.load(r)["choices"][0]["message"]["content"].strip()
        except urllib.error.HTTPError as e:
            self.history.pop()
            raise RuntimeError(f"Osiris answered HTTP {e.code}. Check the model name '{self.cfg('osiris_model')}'.") from e
        except Exception as e:                                   # noqa: BLE001
            self.history.pop()
            raise RuntimeError(f"Could not reach Osiris at {self.cfg('osiris_api')}: {e}") from e
        self.history.append({"role": "assistant", "content": reply})
        return reply

    def reset(self):
        self.history.clear()
