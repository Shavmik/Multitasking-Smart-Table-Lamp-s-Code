"""Open the Spotify desktop app (or the web player) and press the system media keys."""
import os
import subprocess
import sys
import webbrowser
from urllib.parse import quote

# virtual-key codes understood by Windows (Spotify listens to them even when it is in the background)
MEDIA_KEYS = {"playpause": 0xB3, "next": 0xB0, "prev": 0xB1,
              "mute": 0xAD, "voldown": 0xAE, "volup": 0xAF}


def open_spotify(query=None):
    """Returns 'app' when the desktop app was started, 'web' when the browser player was used."""
    uri = "spotify:search:" + quote(query) if query else "spotify:"
    web = ("https://open.spotify.com/search/" + quote(query)) if query else "https://open.spotify.com/"
    try:
        if sys.platform == "win32":
            os.startfile(uri)                           # raises OSError if the app is not installed
            return "app"
        if sys.platform == "darwin":
            subprocess.run(["open", uri], check=True)
            return "app"
        subprocess.run(["xdg-open", uri], check=True)
        return "app"
    except Exception:
        webbrowser.open(web)
        return "web"


def media_keys_supported():
    return sys.platform == "win32"


def press_media_key(name):
    if not media_keys_supported() or name not in MEDIA_KEYS:
        return False
    import ctypes
    vk = MEDIA_KEYS[name]
    user32 = ctypes.windll.user32
    user32.keybd_event(vk, 0, 0, 0)
    user32.keybd_event(vk, 0, 2, 0)                     # KEYEVENTF_KEYUP
    return True
