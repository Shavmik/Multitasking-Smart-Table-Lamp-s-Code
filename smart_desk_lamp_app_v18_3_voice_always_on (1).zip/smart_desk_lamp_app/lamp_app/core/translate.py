"""Translation with deep-translator (Google Translate web endpoint, no API key, needs internet).

Google's free endpoint occasionally answers "TooManyRequests" when it's been called a lot in a short
time (it's a shared, unofficial endpoint - not a real outage). We retry a couple of times with a short
backoff, and if it still won't answer we fall back to MyMemory (a different free translation service),
so a single rate-limited call no longer shows up to the user as "Check the internet connection"."""
import time

LANGUAGES = {
    "Hindi": "hi", "English": "en", "Urdu": "ur", "Bengali": "bn", "Marathi": "mr", "Gujarati": "gu",
    "Tamil": "ta", "Telugu": "te", "Kannada": "kn", "Malayalam": "ml", "Punjabi": "pa", "Nepali": "ne",
    "Arabic": "ar", "French": "fr", "German": "de", "Spanish": "es", "Portuguese": "pt", "Italian": "it",
    "Russian": "ru", "Japanese": "ja", "Korean": "ko", "Chinese (Simplified)": "zh-CN",
}
CHUNK = 4500          # the free endpoint accepts about 5000 characters per request


class TranslateError(RuntimeError):
    pass


def _chunks(text):
    out, cur = [], ""
    for line in text.splitlines(keepends=True):
        while len(line) > CHUNK:                       # one huge line: cut it
            if cur:
                out.append(cur)
                cur = ""
            out.append(line[:CHUNK])
            line = line[CHUNK:]
        if len(cur) + len(line) > CHUNK:
            out.append(cur)
            cur = ""
        cur += line
    if cur:
        out.append(cur)
    return out


def _is_rate_limit(e):
    name = type(e).__name__.lower()
    msg = str(e).lower()
    return "toomanyrequests" in name or "429" in msg or "too many requests" in msg


def _translate_chunk(tr, chunk, retries=3, backoff=1.0):
    """Translate one chunk, retrying a few times on a rate-limit response before giving up."""
    last = None
    for attempt in range(retries):
        try:
            return tr.translate(chunk) or ""
        except Exception as e:                           # noqa: BLE001
            last = e
            if not _is_rate_limit(e) or attempt == retries - 1:
                raise
            time.sleep(backoff * (attempt + 1))
    raise last


def translate(text, target="hi", source="auto"):
    text = (text or "").strip()
    if not text:
        return ""
    try:
        from deep_translator import GoogleTranslator
    except ImportError as e:
        raise TranslateError("The translator library is missing. Run:  pip install deep-translator") from e

    chunks = _chunks(text)

    def run_with(tr):
        parts = []
        for chunk in chunks:
            parts.append(_translate_chunk(tr, chunk) if chunk.strip() else chunk)
        return "".join(parts).strip()

    try:
        return run_with(GoogleTranslator(source=source, target=target))
    except Exception as e1:                              # Google rate-limited/unreachable: try a fallback service
        try:
            from deep_translator import MyMemoryTranslator
            mm_source = "auto" if source == "auto" else source
            return run_with(MyMemoryTranslator(source=mm_source, target=target))
        except Exception:
            if _is_rate_limit(e1):
                raise TranslateError(
                    "Translation failed (TooManyRequests). The free Google endpoint is temporarily "
                    "rate-limited and the backup service couldn't be reached either - wait a few "
                    "seconds and try again.") from e1
            raise TranslateError(f"Translation failed ({type(e1).__name__}). Check the internet connection.") from e1
