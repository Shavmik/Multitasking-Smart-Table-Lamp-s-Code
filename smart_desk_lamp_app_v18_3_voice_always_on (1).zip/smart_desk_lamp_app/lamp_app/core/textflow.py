"""Shared 'here is some text - search it, edit it, save it' screen (OCR, QR, handwriting)."""
import os
import time
import webbrowser
from datetime import datetime
from urllib.parse import quote_plus

from .. import config
from .ui import blank, button, put, wrap, ascii_only, in_rect, W, H


def google_url(text):
    return "https://www.google.com/search?q=" + quote_plus(text[:config.MAX_QUERY_LEN])


def save_note(text, source):
    if not text.strip():
        return
    os.makedirs(config.SAVE_DIR, exist_ok=True)
    with open(os.path.join(config.SAVE_DIR, "notes.txt"), "a", encoding="utf-8") as f:
        f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {source}: {text}\n")


def result_screen(ctx, title, text, url=None):
    """Show text on the laptop and the TFT with SEARCH/OPEN, EDIT and DONE buttons.
    Returns the final (possibly edited) text."""
    ui = ctx.ui
    go_label = "OPEN" if url else "SEARCH"
    btns = {"go": (6, 206, 96, 28), "edit": (112, 206, 96, 28), "done": (218, 206, 96, 28)}
    print(f"\n----- {title} -----\n{text}\n{'-' * (len(title) + 12)}")

    def render():
        img = blank()
        put(img, ascii_only(title), (8, 18), 0.55, (255, 255, 0), 1)
        lines = wrap(text, 36)
        for i, line in enumerate(lines[:10]):
            put(img, line, (8, 42 + i * 16), 0.45, (255, 255, 255))
        if len(lines) > 10:
            put(img, "...", (8, 42 + 10 * 16), 0.45, (200, 200, 200))
        button(img, btns["go"], go_label, (140, 90, 20))
        button(img, btns["edit"], "EDIT", (60, 60, 60))
        button(img, btns["done"], "DONE", (40, 110, 40))
        return img

    def do_go():
        target = url or google_url(text)
        print(f"Opening: {target}")
        webbrowser.open(target)

    def do_edit():
        nonlocal text
        note = blank()
        put(note, "Type the corrected text in the", (8, 100), 0.5, (0, 255, 255))
        put(note, "terminal window, then press ENTER", (8, 124), 0.5, (0, 255, 255))
        ui.show(note, force=True)
        new = ui.ask("Type the corrected text (ENTER keeps the current text):\n> ").strip()
        if new:
            text = new
            print(f"Text is now: {text}")

    try:
        while not ui.closed():
            ui.show(render())
            for ev in ui.events():
                action = None
                if ev.type == "key":
                    action = {"s": "go", "o": "go", "enter": "go", "e": "edit",
                              "d": "done", "esc": "done", "q": "done"}.get(ev.key)
                elif ev.type == "down":
                    for name, r in btns.items():
                        if in_rect(ev.x, ev.y, r):
                            action = name
                if action == "go":
                    do_go()
                elif action == "edit":
                    do_edit()
                elif action == "done":
                    return text
                if action:
                    break
            time.sleep(0.01)
    finally:
        save_note(text, title)
    return text
