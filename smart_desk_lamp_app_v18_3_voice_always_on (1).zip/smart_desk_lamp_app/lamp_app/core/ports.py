"""Find the lamp's serial port without asking questions in a terminal."""


def list_ports():
    try:
        import serial.tools.list_ports
    except ImportError:
        return []
    return [(p.device, p.description or p.device, p.vid) for p in serial.tools.list_ports.comports()]


def detect_port():
    ports = list_ports()
    for device, _, vid in ports:
        if vid == 0x303A:                               # Espressif native USB
            return device
    if len(ports) == 1:
        return ports[0][0]
    return None
