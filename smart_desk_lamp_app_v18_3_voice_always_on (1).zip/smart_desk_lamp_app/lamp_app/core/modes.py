"""Study / Focus / Gaming modes: closes distracting desktop apps and website tabs, silences notifications.
No Qt in here, so it can be tested on its own. `store` needs get(key, default) and set(key, value) (the app's Prefs)."""
import json
import sys
import time

PROFILES = {
    "normal": {"title": "Normal", "apps": [], "sites": [], "dnd": False, "games": True, "minutes": 0},
    "study": {"title": "Study", "apps": ["discord", "steam", "epic games", "instagram", "youtube", "whatsapp", "telegram"],
              "sites": ["youtube", "instagram", "facebook", "twitter", "reddit", "netflix", "twitch", "tiktok", "chess.com"],
              "dnd": True, "games": False, "minutes": 50},
    "focus": {"title": "Focus", "apps": ["discord", "steam", "instagram", "youtube", "whatsapp", "telegram"],
              "sites": ["youtube", "instagram", "facebook", "twitter", "reddit", "twitch", "tiktok"],
              "dnd": True, "games": False, "minutes": 25},
    "gaming": {"title": "Gaming", "apps": [], "sites": [], "dnd": False, "games": True, "minutes": 0},
}
# friendly name -> process names (lower case, without .exe)
PROCESSES = {"discord": ["discord"], "steam": ["steam", "steamwebhelper", "steamservice"],
             "epic games": ["epicgameslauncher"], "instagram": ["instagram"], "youtube": ["youtube", "youtubemusic"],
             "whatsapp": ["whatsapp", "whatsapp.root"], "telegram": ["telegram"], "spotify": ["spotify"]}
BROWSERS = ("chrome", "edge", "firefox", "brave", "opera", "vivaldi")
TOAST_KEY = r"Software\Microsoft\Windows\CurrentVersion\PushNotifications"


class ModeController:
    def __init__(self, store):
        self.store = store
        self.current = "normal"
        self.started = None
        self.planned_min = 0
        self.log = []                                   # (time, text) of things closed
        self._prev_toast = None
        self._warned = set()
        self.blocked = 0                                # things closed during this session

    # ---- settings per mode (editable lists) ----
    def profile(self, mode):
        p = dict(PROFILES[mode])
        raw = self.store.get("mode_" + mode, "")
        if raw:
            try:
                p.update(json.loads(raw))
            except ValueError:
                pass
        return p

    def save_profile(self, mode, apps, sites, dnd, minutes):
        self.store.set("mode_" + mode, json.dumps({"apps": apps, "sites": sites, "dnd": dnd, "minutes": minutes}))

    # ---- switching ----
    def start(self, mode, minutes=None):
        self.stop(silent=True)
        p = self.profile(mode)
        self.current, self.started = mode, time.time()
        self.planned_min = p["minutes"] if minutes is None else minutes
        self._warned.clear()
        self.blocked = 0
        if p["dnd"]:
            self.set_toasts(False)
        if mode == "gaming":
            for a in self.store.get("gaming_open", "").split(","):
                if a.strip():
                    self.open_app(a.strip())
        self.notify(f"{p['title']} mode on", "Distractions are blocked." if p["apps"] else "Have fun!")
        return p

    def stop(self, silent=False):
        """Ends the mode. Returns (mode, minutes_spent)."""
        mode, started = self.current, self.started
        self.set_toasts(True)
        self.current, self.started = "normal", None
        if mode != "normal" and not silent:
            self.notify(f"{PROFILES[mode]['title']} mode off", "Notifications are back.")
        return mode, ((time.time() - started) / 60.0 if started else 0.0)

    def elapsed(self):
        return time.time() - self.started if self.started else 0.0

    def allows_games(self):
        return self.profile(self.current)["games"]

    # ---- enforcement (call every few seconds) ----
    def enforce(self):
        """Closes blocked apps / browser tabs for the current mode. Returns a list of what was closed."""
        p = self.profile(self.current)
        done = []
        for name in p["apps"]:
            if self.close_app(name):
                done.append(f"closed {name}")
        if p["sites"]:
            for title in self.close_blocked_tabs(p["sites"]):
                done.append(f"closed tab: {title[:50]}")
        self.blocked += len(done)
        for d in done:
            self.log.append((time.strftime("%H:%M:%S"), d))
        del self.log[:-100]
        if done:
            self.notify("Blocked", "; ".join(done[:2]))
        return done

    def close_app(self, name):
        """Force-closes a desktop app. AppOpener finds the program by name; psutil is the safety net."""
        key = name.lower().strip()
        closed = False
        procs = PROCESSES.get(key, [key.replace(" ", "")])
        try:
            import psutil
            for pr in psutil.process_iter(["name"]):
                n = (pr.info["name"] or "").lower().rsplit(".exe", 1)[0]
                if n in procs:
                    try:
                        pr.terminate()
                        closed = True
                    except psutil.Error:
                        pass
            if closed:
                time.sleep(0.4)
                for pr in psutil.process_iter(["name"]):
                    if (pr.info["name"] or "").lower().rsplit(".exe", 1)[0] in procs:
                        try:
                            pr.kill()
                        except psutil.Error:
                            pass
        except ImportError:
            pass
        if not closed and self.running(procs, key):
            try:
                from AppOpener import close
                close(key, match_closest=True, output=False)
                closed = True
            except Exception:                                    # noqa: BLE001 - AppOpener is Windows only
                pass
        return closed

    def running(self, procs, key=""):
        try:
            import psutil
            return any((p.info["name"] or "").lower().rsplit(".exe", 1)[0] in procs for p in psutil.process_iter(["name"]))
        except ImportError:
            return False

    def open_app(self, name):
        try:
            from AppOpener import open as app_open
            app_open(name, match_closest=True, output=False)
            return True
        except Exception:                                        # noqa: BLE001
            return False

    # ---- website blocking: close the browser TAB (Ctrl+W) whose title contains a blocked name ----
    def close_blocked_tabs(self, sites):
        if sys.platform != "win32":
            return []
        import ctypes
        from ctypes import wintypes
        u = ctypes.windll.user32
        titles, hits = [], []

        @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def cb(hwnd, _):
            if u.IsWindowVisible(hwnd):
                n = u.GetWindowTextLengthW(hwnd)
                if n:
                    buf = ctypes.create_unicode_buffer(n + 1)
                    u.GetWindowTextW(hwnd, buf, n + 1)
                    titles.append((hwnd, buf.value))
            return True
        u.EnumWindows(cb, 0)
        keys = [s.lower() for s in sites]
        for hwnd, title in titles:
            low = title.lower()
            if any(b in low for b in BROWSERS) and any(k in low for k in keys):
                u.ShowWindow(hwnd, 9)
                u.SetForegroundWindow(hwnd)
                time.sleep(0.15)
                for down in (0, 2):                              # Ctrl+W
                    u.keybd_event(0x11, 0, down, 0)
                    if down == 0:
                        u.keybd_event(0x57, 0, 0, 0); u.keybd_event(0x57, 0, 2, 0)
                hits.append(title)
        return hits

    # ---- notifications ----
    def notify(self, title, msg):
        try:
            if sys.platform == "win32":
                from winotify import Notification
                Notification(app_id="Smart Desk Lamp", title=title, msg=msg, duration="short").show()
                return True
        except Exception:                                        # noqa: BLE001
            pass
        try:
            from plyer import notification
            notification.notify(title=title, message=msg, app_name="Smart Desk Lamp", timeout=4)
            return True
        except Exception:                                        # noqa: BLE001
            print(f"[{title}] {msg}")
            return False

    def set_toasts(self, enabled):
        """Windows: switch pop-up notifications from other apps off while a mode runs, and restore them afterwards."""
        if sys.platform != "win32":
            return False
        try:
            import winreg
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, TOAST_KEY) as k:
                if not enabled and self._prev_toast is None:
                    try:
                        self._prev_toast = winreg.QueryValueEx(k, "ToastEnabled")[0]
                    except OSError:
                        self._prev_toast = 1
                if enabled:
                    if self._prev_toast is None:
                        return True
                    winreg.SetValueEx(k, "ToastEnabled", 0, winreg.REG_DWORD, int(self._prev_toast))
                    self._prev_toast = None
                else:
                    winreg.SetValueEx(k, "ToastEnabled", 0, winreg.REG_DWORD, 0)
            return True
        except OSError:
            return False
