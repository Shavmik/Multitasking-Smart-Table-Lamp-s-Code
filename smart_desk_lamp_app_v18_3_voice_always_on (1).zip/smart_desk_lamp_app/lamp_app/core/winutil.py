"""Windows-only helpers with no effect (and no error) on other platforms."""
import sys


def hide_console():
    """Hide the PowerShell/Command Prompt window the app was launched from, once the GUI is up.
    The console process keeps running (so 'Smart Desk Lamp.bat' can still show 'press any key to
    close' when the app exits) - it is just not shown on screen any more."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            SW_HIDE = 0
            ctypes.windll.user32.ShowWindow(hwnd, SW_HIDE)
    except Exception:                                 # noqa: BLE001 - never let this stop the app from starting
        pass


def show_console():
    """Undo hide_console() - used if the app needs to print something the user must see (e.g. a crash)."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            SW_SHOW = 5
            ctypes.windll.user32.ShowWindow(hwnd, SW_SHOW)
    except Exception:                                 # noqa: BLE001
        pass


_taskbar_hidden = False


def set_topmost(hwnd, on):
    """Keep a window above other programs (or stop doing so) WITHOUT re-creating it, so there is no flicker."""
    if sys.platform != "win32" or not hwnd:
        return
    try:
        import ctypes
        HWND_TOPMOST, HWND_NOTOPMOST = -1, -2
        SWP_NOSIZE, SWP_NOMOVE, SWP_NOACTIVATE = 0x0001, 0x0002, 0x0010
        from ctypes import c_int, c_uint, c_void_p
        f = ctypes.windll.user32.SetWindowPos
        f.argtypes = [c_void_p, c_void_p, c_int, c_int, c_int, c_int, c_uint]
        f(int(hwnd), HWND_TOPMOST if on else HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE)
    except Exception:                                 # noqa: BLE001 - cosmetic only
        pass


def set_taskbar_visible(visible):
    """Show / hide the Windows taskbar (every monitor).  Always call set_taskbar_visible(True) when the app ends -
    main.py does that on quit and on start-up, so a crash can never leave it hidden for long."""
    global _taskbar_hidden
    if sys.platform != "win32":
        return
    if not visible and _taskbar_hidden:
        return
    try:
        import ctypes
        from ctypes import c_int, c_void_p, c_wchar_p
        u = ctypes.windll.user32
        u.FindWindowExW.restype = c_void_p             # 64-bit handles must not be cut to 32 bits
        u.FindWindowExW.argtypes = [c_void_p, c_void_p, c_wchar_p, c_wchar_p]
        u.ShowWindow.argtypes = [c_void_p, c_int]
        cmd = 5 if visible else 0                      # SW_SHOW / SW_HIDE
        for cls in ("Shell_TrayWnd", "Shell_SecondaryTrayWnd"):
            h = None
            while True:
                h = u.FindWindowExW(None, h, cls, None)
                if not h:
                    break
                u.ShowWindow(h, cmd)
        _taskbar_hidden = not visible
    except Exception:                                 # noqa: BLE001
        pass
