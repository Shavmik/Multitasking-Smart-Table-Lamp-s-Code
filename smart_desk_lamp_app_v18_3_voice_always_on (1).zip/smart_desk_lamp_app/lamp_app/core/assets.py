"""Where the pictures live (works from source and from a PyInstaller build)."""
import sys
from pathlib import Path


def asset_path(name):
    if getattr(sys, "_MEIPASS", None):
        return str(Path(sys._MEIPASS) / "lamp_app" / "assets" / name)
    return str(Path(__file__).resolve().parent.parent / "assets" / name)
