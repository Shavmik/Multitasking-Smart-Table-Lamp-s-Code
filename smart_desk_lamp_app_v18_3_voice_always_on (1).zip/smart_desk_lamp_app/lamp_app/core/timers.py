"""Helpers for the stopwatch / timer / tracker, and for turning OCR text into a duration."""
import re


def fmt_hms(sec, tenths=False):
    sec = max(0.0, float(sec))
    h, r = divmod(int(sec), 3600)
    m, s = divmod(r, 60)
    t = f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"
    return t + f".{int((sec % 1) * 10)}" if tenths else t


def parse_duration(text):
    """'25 min', '1h 30m', '1:30:00', '45:00', 'timer 90 seconds' -> seconds (int) or None."""
    t = (text or "").lower().replace(",", " ")
    m = re.search(r"\b(\d{1,2}):(\d{2}):(\d{2})\b", t)
    if m:
        return int(m[1]) * 3600 + int(m[2]) * 60 + int(m[3])
    m = re.search(r"\b(\d{1,3}):(\d{2})\b", t)
    if m:
        return int(m[1]) * 60 + int(m[2])
    total, found = 0, False
    for num, unit in re.findall(r"(\d+(?:\.\d+)?)\s*(hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s)\b", t):
        v = float(num)
        found = True
        total += v * (3600 if unit.startswith("h") else 60 if unit.startswith("m") else 1)
    return int(total) if found and total > 0 else None
