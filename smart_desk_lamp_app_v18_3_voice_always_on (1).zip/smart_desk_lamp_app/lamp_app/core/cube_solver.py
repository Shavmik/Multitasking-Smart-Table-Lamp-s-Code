"""Pure-Python Rubik's cube solver (two-phase algorithm, same idea as 'kociemba').
No extra library needed. The first solve builds lookup tables (a few seconds)."""
import math
import time
from operator import itemgetter

import numpy as np

SOLVE_SECONDS = 6.0      # after the first solution, keep looking for a shorter one this long
SOLVE_MAX_MOVES = 30

_MOVE_NAMES = ["", "2", "'"]

# Basic clockwise face turns in the order U R F D L B:  (cp, co, ep, eo)
# corners: 0 URF 1 UFL 2 ULB 3 UBR 4 DFR 5 DLF 6 DBL 7 DRB
# edges:   0 UR 1 UF 2 UL 3 UB 4 DR 5 DF 6 DL 7 DB 8 FR 9 FL 10 BL 11 BR
_BASIC = [
    ([3, 0, 1, 2, 4, 5, 6, 7], [0] * 8, [3, 0, 1, 2, 4, 5, 6, 7, 8, 9, 10, 11], [0] * 12),            # U
    ([4, 1, 2, 0, 7, 5, 6, 3], [2, 0, 0, 1, 1, 0, 0, 2], [8, 1, 2, 3, 11, 5, 6, 7, 4, 9, 10, 0], [0] * 12),  # R
    ([1, 5, 2, 3, 0, 4, 6, 7], [1, 2, 0, 0, 2, 1, 0, 0], [0, 9, 2, 3, 4, 8, 6, 7, 1, 5, 10, 11],
     [0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0]),                                                          # F
    ([0, 1, 2, 3, 5, 6, 7, 4], [0] * 8, [0, 1, 2, 3, 5, 6, 7, 4, 8, 9, 10, 11], [0] * 12),            # D
    ([0, 2, 6, 3, 4, 1, 5, 7], [0, 1, 2, 0, 0, 2, 1, 0], [0, 1, 10, 3, 4, 5, 9, 7, 8, 2, 6, 11], [0] * 12),  # L
    ([0, 1, 3, 7, 4, 5, 2, 6], [0, 0, 1, 2, 0, 0, 2, 1], [0, 1, 2, 11, 4, 5, 6, 10, 8, 9, 3, 7],
     [0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1]),                                                          # B
]
_CORNER_FACELET = [[8, 9, 20], [6, 18, 38], [0, 36, 47], [2, 45, 11],
                   [29, 26, 15], [27, 44, 24], [33, 53, 42], [35, 17, 51]]
_EDGE_FACELET = [[5, 10], [7, 19], [3, 37], [1, 46], [32, 16], [28, 25],
                 [30, 43], [34, 52], [23, 12], [21, 41], [50, 39], [48, 14]]
_CORNER_COLOR = ["URF", "UFL", "ULB", "UBR", "DFR", "DLF", "DBL", "DRB"]
_EDGE_COLOR = ["UR", "UF", "UL", "UB", "DR", "DF", "DL", "DB", "FR", "FL", "BL", "BR"]


def _cmul(a, b):
    """Cube a followed by move b."""
    acp, aco, aep, aeo = a
    bcp, bco, bep, beo = b
    return ([acp[bcp[i]] for i in range(8)],
            [(aco[bcp[i]] + bco[i]) % 3 for i in range(8)],
            [aep[bep[i]] for i in range(12)],
            [(aeo[bep[i]] + beo[i]) % 2 for i in range(12)])


_IDENT = (list(range(8)), [0] * 8, list(range(12)), [0] * 12)
_MOVES = []                       # 18 moves: index = 3*face + power
for _b in _BASIC:
    _m1 = _b
    _m2 = _cmul(_m1, _b)
    _m3 = _cmul(_m2, _b)
    _MOVES += [_m1, _m2, _m3]
_P2_MOVES = [m for m in range(18) if (m // 3) in (0, 3) or m % 3 == 1]   # U D any, R L F B half turns


def _facelets_to_cubie(f):
    if len(f) != 54:
        raise ValueError("The cube description must have 54 stickers.")
    cp, co, ep, eo = [0] * 8, [0] * 8, [0] * 12, [0] * 12
    for i in range(8):
        fl = _CORNER_FACELET[i]
        ori = 0
        while ori < 3 and f[fl[ori]] not in "UD":
            ori += 1
        if ori == 3:
            raise ValueError("A corner has no top/bottom colour - a colour was misread.")
        c1, c2 = f[fl[(ori + 1) % 3]], f[fl[(ori + 2) % 3]]
        for j in range(8):
            if c1 == _CORNER_COLOR[j][1] and c2 == _CORNER_COLOR[j][2]:
                cp[i], co[i] = j, ori
                break
        else:
            raise ValueError("A corner piece has an impossible colour combination - a colour was misread.")
    for i in range(12):
        a, b = f[_EDGE_FACELET[i][0]], f[_EDGE_FACELET[i][1]]
        for j in range(12):
            if a == _EDGE_COLOR[j][0] and b == _EDGE_COLOR[j][1]:
                ep[i], eo[i] = j, 0
                break
            if a == _EDGE_COLOR[j][1] and b == _EDGE_COLOR[j][0]:
                ep[i], eo[i] = j, 1
                break
        else:
            raise ValueError("An edge piece has an impossible colour combination - a colour was misread.")
    return cp, co, ep, eo


def _parity(p):
    n = len(p)
    return sum(1 for i in range(n) for j in range(i + 1, n) if p[i] > p[j]) % 2


def _check_cubie(c):
    cp, co, ep, eo = c
    if sorted(cp) != list(range(8)):
        raise ValueError("The same corner piece was seen twice - a colour was misread.")
    if sorted(ep) != list(range(12)):
        raise ValueError("The same edge piece was seen twice - a colour was misread.")
    if sum(co) % 3:
        raise ValueError("One corner looks twisted - a colour was misread.")
    if sum(eo) % 2:
        raise ValueError("One edge looks flipped - a colour was misread.")
    if _parity(cp) != _parity(ep):
        raise ValueError("Two pieces look swapped - a colour was misread or a face was scanned wrongly.")


def _twist(c):
    t = 0
    for i in range(7):
        t = 3 * t + c[1][i]
    return t


def _flip(c):
    t = 0
    for i in range(11):
        t = 2 * t + c[3][i]
    return t


def _slice(c):
    a, x = 0, 0
    ep = c[2]
    for j in range(11, -1, -1):
        if ep[j] >= 8:
            a += math.comb(11 - j, x + 1)
            x += 1
    return a


def _coord_table(coord, n, moves):
    """Move table for one coordinate: table[value][move_number]."""
    tab = [[0] * len(moves) for _ in range(n)]
    rep = {0: _IDENT}
    todo = [0]
    while todo:
        v = todo.pop()
        cube = rep[v]
        for k, m in enumerate(moves):
            nc = _cmul(cube, _MOVES[m])
            nv = coord(nc)
            tab[v][k] = nv
            if nv not in rep:
                rep[nv] = nc
                todo.append(nv)
    return tab


def _perm_table(extract, apply_move, moves):
    """Move table for a permutation coordinate (phase 2). Returns (table, perm -> index)."""
    start = extract(_IDENT)
    index = {start: 0}
    states = [start]
    tab = []
    i = 0
    while i < len(states):
        s = states[i]
        row = []
        for m in moves:
            ns = apply_move(s, _MOVES[m])
            if ns not in index:
                index[ns] = len(states)
                states.append(ns)
            row.append(index[ns])
        tab.append(row)
        i += 1
    return tab, index


def _prune_table(tab_a, tab_b, n_a, n_b, n_moves):
    ta = np.array(tab_a, dtype=np.int64)
    tb = np.array(tab_b, dtype=np.int64)
    dist = np.full(n_a * n_b, -1, np.int16)
    dist[0] = 0
    frontier = np.array([0], np.int64)
    d = 0
    while frontier.size:
        d += 1
        a, b = frontier // n_b, frontier % n_b
        nxt = np.concatenate([ta[a, m] * n_b + tb[b, m] for m in range(n_moves)])
        nxt = nxt[dist[nxt] < 0]
        dist[nxt] = d
        frontier = np.flatnonzero(dist == d)
    return dist.tolist()


class _Timeout(Exception):
    pass


class _TwoPhase:
    def __init__(self):
        all18 = list(range(18))
        self.t_twist = _coord_table(_twist, 2187, all18)
        self.t_flip = _coord_table(_flip, 2048, all18)
        self.t_slice = _coord_table(_slice, 495, all18)
        self.p1a = _prune_table(self.t_twist, self.t_slice, 2187, 495, 18)
        self.p1b = _prune_table(self.t_flip, self.t_slice, 2048, 495, 18)
        p2 = _P2_MOVES
        get_cp = {id(m): itemgetter(*m[0]) for m in _MOVES}
        get_ep = {id(m): itemgetter(*m[2][:8]) for m in _MOVES if max(m[2][:8]) < 8}
        get_sl = {id(m): itemgetter(*[x - 8 for x in m[2][8:]]) for m in _MOVES if min(m[2][8:]) >= 8}
        self.t_cp, self.cp_index = _perm_table(lambda c: tuple(c[0]),
                                               lambda s, m: get_cp[id(m)](s), p2)
        self.t_ep, self.ep_index = _perm_table(lambda c: tuple(c[2][:8]),
                                               lambda s, m: get_ep[id(m)](s), p2)
        self.t_sl, self.sl_index = _perm_table(lambda c: tuple(x - 8 for x in c[2][8:]),
                                               lambda s, m: get_sl[id(m)](s), p2)
        self.p2a = _prune_table(self.t_cp, self.t_sl, 40320, 24, 10)
        self.p2b = _prune_table(self.t_ep, self.t_sl, 40320, 24, 10)

    def solve(self, cube, time_limit, max_total):
        self.best = None
        self.max_total = max_total
        self.cube = cube
        self.nodes = 0
        tw, fl, sl = _twist(cube), _flip(cube), _slice(cube)
        self.t0 = time.time()
        self.time_limit = time_limit
        try:
            for d1 in range(0, 13):
                if self.best is not None and d1 >= len(self.best) - 1:
                    break
                self._p1(tw, fl, sl, d1, -1, [])
        except _Timeout:
            pass
        return self.best

    def _tick(self):
        self.nodes += 1
        if self.nodes & 2047 == 0 and self.best is not None:
            if time.time() - self.t0 > self.time_limit:
                raise _Timeout()

    def _p1(self, tw, fl, sl, left, last, path):
        self._tick()
        if left == 0:
            if tw == 0 and fl == 0 and sl == 0 and path:
                lm = path[-1]
                if (lm // 3) in (0, 3) or lm % 3 == 1:
                    return                     # a shorter phase 1 exists
                self._start_phase2(path)
            elif tw == 0 and fl == 0 and sl == 0 and not path:
                self._start_phase2(path)
            return
        t_twist, t_flip, t_slice = self.t_twist, self.t_flip, self.t_slice
        p1a, p1b = self.p1a, self.p1b
        lastface = last // 3 if last >= 0 else -1
        for m in range(18):
            face = m // 3
            if face == lastface or (lastface >= 0 and face + 3 == lastface):
                continue
            ntw, nfl, nsl = t_twist[tw][m], t_flip[fl][m], t_slice[sl][m]
            if p1a[ntw * 495 + nsl] >= left or p1b[nfl * 495 + nsl] >= left:
                continue
            path.append(m)
            self._p1(ntw, nfl, nsl, left - 1, m, path)
            path.pop()

    def _start_phase2(self, path):
        cube = self.cube
        for m in path:
            cube = _cmul(cube, _MOVES[m])
        c = self.cp_index[tuple(cube[0])]
        e = self.ep_index[tuple(cube[2][:8])]
        s = self.sl_index[tuple(x - 8 for x in cube[2][8:])]
        limit = self.max_total if self.best is None else len(self.best) - 1
        limit -= len(path)
        if limit < 0:
            return
        lower = max(self.p2a[c * 24 + s], self.p2b[e * 24 + s])
        for d2 in range(lower, limit + 1):
            p2path = []
            if self._p2(c, e, s, d2, -1, p2path):
                self.best = list(path) + [_P2_MOVES[k] for k in p2path]
                return

    def _p2(self, c, e, s, left, last, path):
        self._tick()
        if left == 0:
            return c == 0 and e == 0 and s == 0
        t_cp, t_ep, t_sl = self.t_cp, self.t_ep, self.t_sl
        p2a, p2b = self.p2a, self.p2b
        lastface = _P2_MOVES[last] // 3 if last >= 0 else -1
        for k in range(10):
            face = _P2_MOVES[k] // 3
            if face == lastface or (lastface >= 0 and face + 3 == lastface):
                continue
            nc, ne, ns = t_cp[c][k], t_ep[e][k], t_sl[s][k]
            if p2a[nc * 24 + ns] >= left or p2b[ne * 24 + ns] >= left:
                continue
            path.append(k)
            if self._p2(nc, ne, ns, left - 1, k, path):
                return True
            path.pop()
        return False


_solver_cache = {}


def solve_cube(facelets, time_limit=None):
    """facelets: 54 letters in the order U R F D L B (kociemba order). Returns a list of moves.
    Raises ValueError with a friendly message when the cube is impossible."""
    cube = _facelets_to_cubie(facelets)
    _check_cubie(cube)
    if facelets == "".join(f * 9 for f in "URFDLB"):
        return []
    if "solver" not in _solver_cache:
        print("Building the solver tables (only the first time, a few seconds)...")
        t = time.time()
        _solver_cache["solver"] = _TwoPhase()
        print(f"Tables ready in {time.time() - t:.1f} s.")
    t = time.time()
    best = _solver_cache["solver"].solve(cube, SOLVE_SECONDS if time_limit is None else time_limit,
                                         SOLVE_MAX_MOVES)
    if best is None:
        raise ValueError("No solution found - a colour was probably misread.")
    print(f"Solution found in {time.time() - t:.1f} s.")
    return ["URFDLB"[m // 3] + _MOVE_NAMES[m % 3] for m in best]
