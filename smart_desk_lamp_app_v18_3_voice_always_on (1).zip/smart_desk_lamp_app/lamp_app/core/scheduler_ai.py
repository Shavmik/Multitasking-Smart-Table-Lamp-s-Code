"""Smart scheduling: a weekly timetable, a time-estimate manager and a day planner.
scikit-learn learns from the sessions you log (tracker, modes, finished tasks):
  * duration model  -> how long a task of this kind REALLY takes you (not how long you hoped)
  * focus model     -> in which hours you work best, per kind of task
Until there is enough history it falls back to simple, explainable rules and says so."""
import json
import os
from datetime import datetime, timedelta

DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
DAY_START, DAY_END = 8 * 60, 22 * 60            # planning window (minutes from midnight)
MIN_FOR_ML = 12                                  # sessions before the models are trusted


def hm(minutes):
    return f"{int(minutes) // 60:02d}:{int(minutes) % 60:02d}"


def parse_hm(text):
    h, _, m = text.strip().partition(":")
    return int(h) * 60 + int(m or 0)


class SmartScheduler:
    def __init__(self, path):
        self.path = path
        self.data = {"timetable": [], "tasks": [], "history": []}
        self._models = None
        self._models_n = -1
        self.load()

    # ------------------------------------------------------------ storage
    def load(self):
        try:
            with open(self.path, encoding="utf-8") as f:
                self.data.update(json.load(f))
        except (OSError, ValueError):
            pass

    def save(self):
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=1)
        os.replace(tmp, self.path)

    @property
    def history(self):
        return self.data["history"]

    @property
    def categories(self):
        base = ["Study", "Revision", "Assignment", "Reading", "Project", "Coding", "Gaming", "Other"]
        return base + sorted({h["category"] for h in self.history if h["category"] not in base})

    # ------------------------------------------------------------ timetable
    def add_block(self, day, start, end, title):
        self.data["timetable"].append({"day": day, "start": start, "end": end, "title": title})
        self.save()

    def remove_block(self, index):
        if 0 <= index < len(self.data["timetable"]):
            del self.data["timetable"][index]
            self.save()

    def busy(self, day_index):
        return sorted((b["start"], b["end"]) for b in self.data["timetable"] if b["day"] == day_index)

    # ------------------------------------------------------------ tasks
    def add_task(self, title, category, estimate, priority=2, deadline=""):
        self.data["tasks"].append({"title": title, "category": category, "estimate": int(estimate),
                                   "priority": int(priority), "deadline": deadline, "done": False})
        self.save()

    def remove_task(self, index):
        if 0 <= index < len(self.data["tasks"]):
            del self.data["tasks"][index]
            self.save()

    # ------------------------------------------------------------ history
    def log_session(self, category, title, estimated, actual, start=None, focus=1.0, mode="normal"):
        """actual / estimated in minutes; focus = share of the session spent undistracted (0..1)."""
        if actual < 1:
            return
        start = start or datetime.now() - timedelta(minutes=actual)
        self.history.append({"category": category, "title": title, "estimated": float(estimated or actual),
                             "actual": float(actual), "hour": start.hour, "weekday": start.weekday(),
                             "focus": float(max(0.0, min(1.0, focus))), "mode": mode, "when": start.isoformat(timespec="minutes")})
        del self.history[:-2000]
        self.save()

    # ------------------------------------------------------------ models
    def _features(self, rows):
        feats = []
        for r in rows:
            f = {"cat=" + r["category"]: 1, "estimated": r["estimated"], "hour": r["hour"], "weekday": r["weekday"]}
            feats.append(f)
        return feats

    def _train(self):
        n = len(self.history)
        if self._models_n == n:
            return self._models
        self._models_n, self._models = n, None
        if n < MIN_FOR_ML:
            return None
        from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
        from sklearn.feature_extraction import DictVectorizer
        vec = DictVectorizer(sparse=False)
        X = vec.fit_transform(self._features(self.history))
        # predict the RATIO actual/estimated so one model works for short and long tasks
        ratio = [min(4.0, max(0.2, h["actual"] / max(1.0, h["estimated"]))) for h in self.history]
        dur = GradientBoostingRegressor(n_estimators=80, max_depth=2, learning_rate=0.1, random_state=0).fit(X, ratio)
        focus = RandomForestRegressor(n_estimators=60, min_samples_leaf=2, random_state=0).fit(
            X, [h["focus"] for h in self.history])
        self._models = (vec, dur, focus)
        return self._models

    def _category_ratio(self, category):
        rs = sorted(h["actual"] / max(1.0, h["estimated"]) for h in self.history if h["category"] == category)
        return (rs[len(rs) // 2], len(rs)) if rs else (None, 0)

    def predict_minutes(self, category, estimate, when=None):
        """Returns (minutes, explanation)."""
        when = when or datetime.now()
        models = self._train()
        if models:
            vec, dur, _ = models
            x = vec.transform([{"cat=" + category: 1, "estimated": estimate, "hour": when.hour, "weekday": when.weekday()}])
            ratio = float(dur.predict(x)[0])
            how = f"learned from {len(self.history)} sessions"
        else:
            ratio, n = self._category_ratio(category)
            if ratio is not None and n >= 3:
                how = f"your median for {category} ({n} sessions)"
            else:
                ratio, how = 1.25, "default +25% (people underestimate); log more sessions to personalise"
        minutes = max(5, int(round(estimate * ratio / 5.0)) * 5)
        return minutes, f"{minutes} min  ({how})"

    def hour_scores(self, category):
        """Expected focus (0..1) for every hour of the day, used to pick the best slots."""
        models = self._train()
        scores = {}
        for h in range(DAY_START // 60, DAY_END // 60):
            if models:
                vec, _, focus = models
                x = vec.transform([{"cat=" + category: 1, "estimated": 45, "hour": h, "weekday": datetime.now().weekday()}])
                scores[h] = float(focus.predict(x)[0])
            else:                                                   # sensible default: late morning and early evening
                scores[h] = {9: .8, 10: .9, 11: .9, 12: .6, 13: .5, 14: .6, 15: .7, 16: .75, 17: .7, 18: .65, 19: .7, 20: .65}.get(h, .5)
        return scores

    def best_hours(self, category, top=3):
        sc = self.hour_scores(category)
        return sorted(sc, key=sc.get, reverse=True)[:top]

    def accuracy(self):
        """Mean absolute error of your own estimates over the last 20 sessions, in minutes (None if no data)."""
        last = self.history[-20:]
        return round(sum(abs(h["actual"] - h["estimated"]) for h in last) / len(last), 1) if last else None

    def status(self):
        n = len(self.history)
        if n >= MIN_FOR_ML:
            return f"AI active: trained on {n} sessions."
        return f"Learning: {n}/{MIN_FOR_ML} sessions logged before the AI takes over (rules are used until then)."

    # ------------------------------------------------------------ planner
    def plan(self, day=None, now_minutes=None, tasks=None, break_min=10):
        """Greedy plan: most urgent tasks first, each placed in the best free hours. Returns a list of blocks."""
        day = day or datetime.now()
        busy = list(self.busy(day.weekday()))
        floor = DAY_START if now_minutes is None else max(DAY_START, (now_minutes + 4) // 5 * 5)
        todo = [t for t in (tasks if tasks is not None else self.data["tasks"]) if not t.get("done")]
        todo.sort(key=lambda t: (t.get("deadline") or "9999", -t.get("priority", 2)))
        blocks = []
        for t in todo:
            need, _ = self.predict_minutes(t["category"], t["estimate"], day)
            scores = self.hour_scores(t["category"])
            best = None
            for start in range(floor, DAY_END - need + 1, 5):
                end = start + need
                if any(start < be + break_min and end > bs - break_min for bs, be in busy):
                    continue
                score = sum(scores.get(m // 60, .4) for m in range(start, end, 15)) / max(1, len(range(start, end, 15)))
                if best is None or score > best[0] + 1e-9:
                    best = (score, start, end)
            if best:
                _, s, e = best
                busy.append((s, e))
                blocks.append({"title": t["title"], "category": t["category"], "start": s, "end": e,
                               "minutes": need, "focus": round(best[0], 2)})
        blocks.sort(key=lambda b: b["start"])
        return blocks

    def summary_for_ai(self):
        """Short plain-text overview that is sent to the Osiris assistant when the user shares their day."""
        today = datetime.now().weekday()
        lines = [f"Timetable today: " + (", ".join(f"{hm(s)}-{hm(e)}" for s, e in self.busy(today)) or "free")]
        lines += [f"Task: {t['title']} ({t['category']}, ~{t['estimate']} min)" for t in self.data["tasks"] if not t["done"]][:10]
        lines.append(self.status())
        return "\n".join(lines)
