"""Serial link to the lamp board: camera, TFT screen and touch."""
import struct
import threading
import time

import cv2
import numpy as np
import serial

from .. import config


class BoardError(RuntimeError):
    pass


def decode_jpeg(jpeg):
    return cv2.imdecode(np.frombuffer(jpeg, np.uint8), cv2.IMREAD_COLOR)


class Board:
    def __init__(self, port, baud=config.BAUD):
        self.ser = serial.Serial(port, baud, timeout=0.05)
        self.lock = threading.RLock()
        self.sd = False
        self._hold = None
        self.display_ok = False          # True = the firmware understands screen on / off (ping says DP=1)
        self.cam_ok = False              # True = the firmware can draw the always-on camera box (ping says CB=1)
        self.native_ok = False           # True = the firmware can draw button screens itself (ping says UI=1)

    # ------------------------------ low level ------------------------------
    def _request(self, data, markers, timeout):
        """Send `data`, wait for one of the marker byte strings. Returns (marker, bytes after it)."""
        self.ser.reset_input_buffer()
        self.ser.write(data)
        buf = bytearray()
        deadline = time.time() + timeout
        while True:
            buf += self.ser.read(max(1, self.ser.in_waiting))
            for m in markers:
                i = buf.find(m)
                if i >= 0:
                    return m, bytearray(buf[i + len(m):])
            if len(buf) > 4096:                  # junk before the marker: keep only the tail
                del buf[:-8]
            if time.time() > deadline:
                raise TimeoutError("The board did not answer.")

    def _take(self, buf, n, deadline):
        while len(buf) < n:
            if time.time() > deadline:
                raise TimeoutError("Timed out while receiving data.")
            buf += self.ser.read(max(1, self.ser.in_waiting))
        out = bytes(buf[:n])
        del buf[:n]
        return out

    def _jpeg(self, cmd, timeout):
        with self.lock:
            marker, rest = self._request(cmd, [b"IMG!", b"ERR!"], timeout)
            if marker == b"ERR!":
                raise BoardError("The camera failed to take a picture.")
            deadline = time.time() + timeout
            length = struct.unpack("<I", self._take(rest, 4, deadline))[0]
            if length == 0 or length > config.MAX_IMAGE_BYTES:
                raise BoardError(f"Bad image size received: {length}")
            return self._take(rest, length, deadline)

    def _write(self, data):
        with self.lock:
            self.ser.write(data)
            self.ser.flush()

    # ------------------------------ commands ------------------------------
    def ping(self):
        with self.lock:
            try:
                _, rest = self._request(b"P", [b"PONG"], 4)
            except TimeoutError:
                return None
            end = time.time() + 1
            while b"\n" not in rest and time.time() < end:
                rest += self.ser.read(16)
            line = bytes(rest).split(b"\n")[0].decode(errors="ignore").strip()
            self.sd = "SD=1" in line
            self.native_ok = "UI=1" in line
            self.cam_ok = "CB=1" in line
            self.display_ok = "DP=1" in line
            return line

    def set_hold(self, hold):
        """hold=True: the laptop owns the TFT. hold=False: live preview is drawn on it."""
        if hold != self._hold:
            self._write(b"M" + bytes([1 if hold else 0]))
            self._hold = hold

    def frame(self):
        """One live preview frame (320x240, BGR). The board also draws it on the TFT."""
        self.set_hold(True)              # the laptop composes the TFT picture (page + small camera box)
        img = decode_jpeg(self._jpeg(b"V", 5))
        if img is None:
            raise BoardError("bad frame")
        return img

    def photo(self):
        """Full-size photo. Returns (BGR image, jpeg bytes)."""
        self.set_hold(True)
        jpeg = self._jpeg(b"C", 25)
        img = decode_jpeg(jpeg)
        if img is None:
            raise BoardError(f"The photo was damaged in transfer ({len(jpeg)} bytes). Try again.")
        return img, jpeg

    def touch(self):
        """Returns (pressed, x, y) in screen pixels (320x240)."""
        with self.lock:
            _, rest = self._request(b"X", [b"TCH!"], 1)
            d = self._take(rest, 5, time.time() + 1)
        x, y = struct.unpack("<hh", d[1:5])
        return d[0] == 1, x, y

    def show_image(self, img):
        """Draw a 320x240 BGR picture on the TFT."""
        self.set_hold(True)
        if img.shape[1] != config.TFT_W or img.shape[0] != config.TFT_H:
            img = cv2.resize(img, (config.TFT_W, config.TFT_H))
        limit = min(config.MAX_UI_JPEG, config.TFT_TARGET_BYTES)
        for q in (80, 65, 50, 40, 30, 22):
            ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, q])
            if ok and len(buf) <= limit:
                break
        data = buf.tobytes()
        self._write(b"J" + struct.pack("<I", len(data)) + data)

    def display(self, on):
        """Lamp screen on / off (black). Only sent when the firmware says it understands it."""
        if self.display_ok:
            self._write(b"D" + bytes([1 if on else 0]))

    def cam_box(self, x, y, w, h, ms=200):
        """Always-on camera box: the board draws a small live camera picture there by itself. w = 0 switches it off."""
        self._write(b"B" + struct.pack("<hhHHH", x, y, w, h, ms))

    # ---- native button screens (v15): the board draws boxes / text / buttons itself ----
    def scene(self, payload):
        """Send a whole screen (bytes made by tftui.native.Scene.encode)."""
        self.set_hold(True)
        self._write(b"S" + struct.pack("<H", len(payload)) + payload)

    def scene_update(self, wid, flags, text):
        """Change the text (and button flags) of ONE widget; the board repaints only that widget."""
        t = str(text).encode("ascii", "replace")[:40]
        self._write(b"U" + bytes([wid, flags, len(t)]) + t)

    def poll_events(self):
        """Taps the board has seen since the last call: [(scene generation, widget id), ...]."""
        with self.lock:
            _, rest = self._request(b"E", [b"EVT!"], 1)
            n = self._take(rest, 1, time.time() + 1)[0]
            d = self._take(rest, 2 * n, time.time() + 1) if n else b""
        return [(d[i], d[i + 1]) for i in range(0, 2 * n, 2)]

    def clock(self, text):
        """Live clock: big white digits on black. Call this once a second - the board repaints
        ONLY the digit box (never the whole screen), so this is the fastest possible TFT update."""
        self.set_hold(True)
        t = str(text).encode("ascii", "replace")[:15]
        self._write(b"H" + bytes([len(t)]) + t)

    def show_menu(self, title, buttons, bg=(10, 10, 20), title_color=(0, 230, 255),
                  title_font=2, title_animated=False):
        """Draw a title + coloured button boxes DIRECTLY on the TFT - no JPEG round trip, so this
        is near-instant and flicker-free even over slow jumper wires (unlike show_image()).

        buttons: up to 10 dicts, each with:
            x, y, w, h   - pixel rect on the 320x240 screen
            label        - short text (ASCII, <=24 chars)
            fill         - (r, g, b) box colour, 0-255 each
            fg           - (r, g, b) text colour
            font         - 1 (small) .. 4 (large)
            animated     - True = the board makes this button's text pulse on its own, with
                            zero extra traffic (handy for one "alive" highlight, a notice, ...)
        Colours are (R, G, B), same order as clear()/line().
        """
        self.set_hold(True)
        out = bytearray(b"N")
        out += bytes(bg)
        t = str(title).encode("ascii", "replace")[:48]
        out += bytes([len(t)]) + t
        out += bytes(title_color)
        out += bytes([title_font, 1 if title_animated else 0])
        btns = list(buttons)[:10]
        out += bytes([len(btns)])
        for b in btns:
            x, y, w, h = int(b["x"]), int(b["y"]), int(b["w"]), int(b["h"])
            out += struct.pack("<HHHH", x, y, w, h)
            out += bytes(b.get("fill", (60, 60, 60)))
            out += bytes(b.get("fg", (255, 255, 255)))
            out += bytes([int(b.get("font", 2)), 1 if b.get("animated") else 0])
            label = str(b.get("label", "")).encode("ascii", "replace")[:24]
            out += bytes([len(label)]) + label
        self._write(bytes(out))

    def text(self, title, body=""):
        """Plain text page (ASCII only) - handy for short status messages."""
        self.set_hold(True)
        msg = (title + "\n" + body).encode("ascii", "replace")[:config.MAX_TFT_CHARS]
        self._write(b"T" + struct.pack("<H", len(msg)) + msg)

    def clear(self, rgb=(0, 0, 0)):
        self.set_hold(True)
        self._write(b"K" + bytes(rgb))

    def line(self, x0, y0, x1, y1, rgb=(0, 0, 0), width=5):
        self._write(b"L" + struct.pack("<hhhh", x0, y0, x1, y1) + bytes(rgb) + bytes([width]))

    def calibrate(self):
        """Touch calibration on the TFT (tap the 4 arrows). Blocks until done."""
        self.set_hold(True)
        with self.lock:
            self._request(b"Z", [b"CAL!"], 120)

    def close(self):
        try:
            self.ser.close()
        except Exception:
            pass
