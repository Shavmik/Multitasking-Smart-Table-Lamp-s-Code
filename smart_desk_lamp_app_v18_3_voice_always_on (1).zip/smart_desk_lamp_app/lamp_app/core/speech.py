"""Read-aloud with pyttsx3 (offline Windows voices).

Each reading runs in its own small Python process, so STOP is instant and reliable and a crash in the
speech engine can never take the app down.  (A frozen .exe falls back to a thread.)
"""
import subprocess
import sys
import threading

_WORKER = r'''
import sys
try:
    import pyttsx3
except Exception as e:
    sys.stderr.write("NO_PYTTSX3: %s" % e)
    sys.exit(3)
rate, vol = int(sys.argv[1]), float(sys.argv[2])
text = sys.stdin.buffer.read().decode("utf-8", "replace")
eng = pyttsx3.init()
eng.setProperty("rate", rate)
eng.setProperty("volume", vol)
eng.say(text)
eng.runAndWait()
'''


class Speaker:
    def __init__(self):
        self.rate = 170
        self.volume = 1.0
        self.last_error = ""
        self._proc = None
        self._thread = None

    @property
    def speaking(self):
        if self._proc is not None and self._proc.poll() is None:
            return True
        return self._thread is not None and self._thread.is_alive()

    def speak(self, text):
        text = (text or "").strip()
        if not text:
            return False
        self.stop()
        self.last_error = ""
        if getattr(sys, "frozen", False):
            return self._speak_thread(text)
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform == "win32" else 0
        try:
            self._proc = subprocess.Popen(
                [sys.executable, "-c", _WORKER, str(int(self.rate)), str(float(self.volume))],
                stdin=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=flags)
            self._proc.stdin.write(text.encode("utf-8"))
            self._proc.stdin.close()
        except Exception as e:
            self.last_error = f"Could not start the voice: {e}"
            self._proc = None
            return False
        threading.Thread(target=self._watch, args=(self._proc,), daemon=True).start()
        return True

    def _watch(self, proc):
        err = proc.stderr.read().decode("utf-8", "replace").strip() if proc.stderr else ""
        code = proc.wait()
        if getattr(proc, "_lamp_stopped", False):        # we stopped it ourselves: not an error
            return
        if code != 0:
            self.last_error = ("Read-aloud needs pyttsx3.  Run:  pip install pyttsx3"
                               if "NO_PYTTSX3" in err else (err.splitlines() or ["The voice stopped."])[-1])

    def _speak_thread(self, text):
        def work():
            try:
                try:
                    import comtypes
                    comtypes.CoInitialize()
                except Exception:
                    pass
                import pyttsx3
                eng = pyttsx3.init()
                eng.setProperty("rate", int(self.rate))
                eng.setProperty("volume", float(self.volume))
                eng.say(text)
                eng.runAndWait()
            except Exception as e:
                self.last_error = f"Read-aloud failed: {e}"
        self._thread = threading.Thread(target=work, daemon=True)
        self._thread.start()
        return True

    def stop(self):
        p = self._proc
        if p is not None and p.poll() is None:
            try:
                p._lamp_stopped = True
                p.terminate()
            except Exception:
                pass
        self._proc = None
