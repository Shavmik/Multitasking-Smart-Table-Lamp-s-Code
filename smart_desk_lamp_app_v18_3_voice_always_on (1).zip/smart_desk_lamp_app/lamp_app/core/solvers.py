"""Sudoku solver (bit-mask backtracking, fewest-candidates-first) and a picture reader for printed grids."""
import numpy as np

FULL = 0x3FE            # bits 1..9


def _parse(grid):
    g = [int(v) for v in grid]
    if len(g) != 81 or any(not 0 <= v <= 9 for v in g):
        raise ValueError("A sudoku needs 81 cells with digits 0-9.")
    return g


def conflicts(grid):
    """Indexes of cells that repeat a digit in their row, column or box."""
    g = _parse(grid)
    bad = set()
    groups = [[r * 9 + c for c in range(9)] for r in range(9)] + [[r * 9 + c for r in range(9)] for c in range(9)]
    groups += [[(br + r) * 9 + bc + c for r in range(3) for c in range(3)] for br in (0, 3, 6) for bc in (0, 3, 6)]
    for grp in groups:
        seen = {}
        for i in grp:
            if g[i]:
                seen.setdefault(g[i], []).append(i)
        for idx in seen.values():
            if len(idx) > 1:
                bad.update(idx)
    return sorted(bad)


def solve_sudoku(grid):
    """Returns the solved list of 81 ints, or None if there is no solution."""
    g = _parse(grid)
    if conflicts(g):
        return None
    rows, cols, boxes = [0] * 9, [0] * 9, [0] * 9
    for i, v in enumerate(g):
        if v:
            b = 1 << v
            rows[i // 9] |= b; cols[i % 9] |= b; boxes[(i // 27) * 3 + (i % 9) // 3] |= b

    def rec():
        best, cand = -1, 0
        best_n = 10
        for i in range(81):
            if g[i] == 0:
                used = rows[i // 9] | cols[i % 9] | boxes[(i // 27) * 3 + (i % 9) // 3]
                c = FULL & ~used
                n = bin(c).count("1")
                if n < best_n:
                    best, cand, best_n = i, c, n
                    if n <= 1:
                        break
        if best < 0:
            return True
        if best_n == 0:
            return False
        r, c_, bx = best // 9, best % 9, (best // 27) * 3 + (best % 9) // 3
        for d in range(1, 10):
            b = 1 << d
            if cand & b:
                g[best] = d
                rows[r] |= b; cols[c_] |= b; boxes[bx] |= b
                if rec():
                    return True
                g[best] = 0
                rows[r] &= ~b; cols[c_] &= ~b; boxes[bx] &= ~b
        return False

    return g if rec() else None


# ---------------------------------------------------------------- picture -> grid
def _order(pts):
    pts = pts.reshape(4, 2).astype("float32")
    s, d = pts.sum(1), np.diff(pts, axis=1).ravel()
    return np.array([pts[np.argmin(s)], pts[np.argmin(d)], pts[np.argmax(s)], pts[np.argmax(d)]], dtype="float32")


def find_grid(img_bgr, size=450):
    """Finds the biggest square outline and returns it flattened (grayscale, size x size), or None."""
    import cv2
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    th = cv2.adaptiveThreshold(cv2.GaussianBlur(gray, (7, 7), 0), 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                               cv2.THRESH_BINARY_INV, 11, 2)
    cnts, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for c in sorted(cnts, key=cv2.contourArea, reverse=True)[:5]:
        if cv2.contourArea(c) < 0.15 * gray.shape[0] * gray.shape[1]:
            break
        approx = cv2.approxPolyDP(c, 0.02 * cv2.arcLength(c, True), True)
        if len(approx) == 4:
            dst = np.array([[0, 0], [size - 1, 0], [size - 1, size - 1], [0, size - 1]], dtype="float32")
            m = cv2.getPerspectiveTransform(_order(approx), dst)
            return cv2.warpPerspective(gray, m, (size, size))
    return None


def read_grid(img_bgr, engine="easyocr", tess_cmd=""):
    """Reads a printed sudoku from a picture. Returns (81 ints, number of cells that looked filled)."""
    import cv2
    flat = find_grid(img_bgr)
    if flat is None:
        raise ValueError("I could not find the sudoku square. Fill the picture with the grid and keep it flat.")
    cell = flat.shape[0] // 9
    out, filled, crops = [0] * 81, 0, {}
    for i in range(81):
        r, c = divmod(i, 9)
        piece = flat[r * cell:(r + 1) * cell, c * cell:(c + 1) * cell]
        m = int(cell * 0.14)
        piece = piece[m:-m, m:-m]
        _, bw = cv2.threshold(piece, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        if cv2.countNonZero(bw[bw.shape[0] // 5:-bw.shape[0] // 5, bw.shape[1] // 5:-bw.shape[1] // 5]) < 0.04 * bw.size:
            continue
        crops[i] = cv2.copyMakeBorder(255 - bw, 12, 12, 12, 12, cv2.BORDER_CONSTANT, value=255)
    filled = len(crops)
    if engine == "tesseract":
        import pytesseract
        from .ocr_engine import tesseract_ready
        tesseract_ready(tess_cmd)
        for i, im in crops.items():
            t = pytesseract.image_to_string(im, config="--psm 10 -c tessedit_char_whitelist=123456789").strip()
            out[i] = int(t[0]) if t[:1].isdigit() else 0
    else:
        from .ocr_engine import get_reader
        reader = get_reader()
        for i, im in crops.items():
            res = reader.readtext(im, detail=0, allowlist="123456789")
            out[i] = int(res[0][0]) if res and res[0][:1].isdigit() else 0
    return out, filled
