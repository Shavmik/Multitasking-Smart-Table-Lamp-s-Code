"""Fast native TFT menu: title + big colour button boxes, drawn directly on the lamp screen by
the firmware (board.show_menu) instead of being screenshotted and squeezed into a JPEG. This is
what makes the touchscreen feel instant - no picture to encode, send or decode, just a few dozen
bytes describing rectangles and text.

Layout (320x240): a title bar, a 2x2 grid of big colour tiles, and PREV/NEXT if there is more
than one page of features.
"""

TFT_W, TFT_H = 320, 240

GRID = [(6, 34, 150, 86), (164, 34, 150, 86), (6, 128, 150, 86), (164, 128, 150, 86)]
PREV_RECT = (6, 216, 150, 20)
NEXT_RECT = (164, 216, 150, 20)
PER_PAGE = len(GRID)

# key (matches the app's page keys / ctx.go(key)), label shown on the lamp, colour (R, G, B)
# - the colours match the desktop app's own accent palette, so the lamp screen still "feels" like
#   the rest of the app even though it is drawn natively instead of mirrored.
QUICK_FEATURES = [
    ("clock",     "Clock",       (139, 92, 246)),   # purple
    ("ocr",       "Read Text",   (255, 138, 61)),    # orange
    ("reader",    "Read Aloud",  (255, 200, 61)),    # yellow
    ("translate", "Translate",   (59, 155, 255)),    # blue
    ("spotify",   "Spotify",     (52, 211, 153)),    # green
    ("erp",       "College ERP", (52, 211, 153)),    # green
    ("calc",      "Calculator",  (139, 92, 246)),    # purple
    ("settings",  "Settings",    (138, 143, 168)),   # grey
]


def pages():
    return max(1, -(-len(QUICK_FEATURES) // PER_PAGE))


def build(page):
    """(title, buttons) for `page`. Each button has x/y/w/h/label/fill/fg/font/animated, plus
    either 'key' (a feature to open) or 'nav' ('prev'/'next') so the caller knows what a tap does."""
    n = pages()
    page %= n
    items = QUICK_FEATURES[page * PER_PAGE:(page + 1) * PER_PAGE]
    buttons = []
    for (x, y, w, h), (key, label, color) in zip(GRID, items):
        buttons.append({
            "x": x, "y": y, "w": w, "h": h, "label": label.upper(),
            "fill": color, "fg": (255, 255, 255), "font": 2,
            "animated": key == "clock",      # one gentle pulse - shows the screen is alive, not stale
            "key": key,
        })
    if n > 1:
        x, y, w, h = PREV_RECT
        buttons.append({"x": x, "y": y, "w": w, "h": h, "label": "< PREV",
                         "fill": (40, 44, 58), "fg": (0, 230, 255), "font": 1, "nav": "prev"})
        x, y, w, h = NEXT_RECT
        buttons.append({"x": x, "y": y, "w": w, "h": h, "label": "NEXT >",
                         "fill": (35, 35, 40), "fg": (0, 230, 255), "font": 1, "nav": "next"})
    title = f"SMART DESK LAMP  {page + 1}/{n}"
    return title, buttons


def hit(x, y, buttons):
    """The button at (x, y), or None. x/y are 320x240 screen pixels."""
    for b in buttons:
        if b["x"] <= x < b["x"] + b["w"] and b["y"] <= y < b["y"] + b["h"]:
            return b
    return None
