"""Chess helper built on python-chess. Uses Stockfish when its path is set, otherwise a small built-in alpha-beta engine."""
import chess
import chess.engine

VALUE = {chess.PAWN: 100, chess.KNIGHT: 320, chess.BISHOP: 330, chess.ROOK: 500, chess.QUEEN: 900, chess.KING: 0}
CENTER = {chess.D4, chess.E4, chess.D5, chess.E5}
WIDE_CENTER = {chess.C3, chess.D3, chess.E3, chess.F3, chess.C4, chess.F4, chess.C5, chess.F5, chess.C6, chess.D6, chess.E6, chess.F6}


def evaluate(b):
    """Score from White's point of view in centipawns."""
    if b.is_checkmate():
        return -99999 if b.turn == chess.WHITE else 99999
    if b.is_stalemate() or b.is_insufficient_material():
        return 0
    s = 0
    for sq, p in b.piece_map().items():
        v = VALUE[p.piece_type]
        if p.piece_type in (chess.KNIGHT, chess.BISHOP, chess.PAWN, chess.QUEEN):
            v += 25 if sq in CENTER else 10 if sq in WIDE_CENTER else 0
        if p.piece_type == chess.PAWN:
            rank = chess.square_rank(sq) if p.color == chess.WHITE else 7 - chess.square_rank(sq)
            v += rank * 6
        s += v if p.color == chess.WHITE else -v
    s += 4 * (b.legal_moves.count() if b.turn == chess.WHITE else -b.legal_moves.count())
    return s


def _ordered(b):
    def key(m):
        k = 0
        if b.is_capture(m):
            v = b.piece_at(m.to_square)
            k += 10 * (VALUE[v.piece_type] if v else 100) - VALUE[b.piece_type_at(m.from_square)]
        if m.promotion:
            k += 800
        if b.gives_check(m):
            k += 50
        return -k
    return sorted(b.legal_moves, key=key)


def _search(b, depth, alpha, beta):
    if depth == 0 or b.is_game_over():
        return evaluate(b)
    if b.turn == chess.WHITE:
        best = -10 ** 6
        for m in _ordered(b):
            b.push(m); best = max(best, _search(b, depth - 1, alpha, beta)); b.pop()
            alpha = max(alpha, best)
            if alpha >= beta:
                break
        return best
    best = 10 ** 6
    for m in _ordered(b):
        b.push(m); best = min(best, _search(b, depth - 1, alpha, beta)); b.pop()
        beta = min(beta, best)
        if alpha >= beta:
            break
    return best


def best_move(board, depth=3, stockfish=""):
    """Returns (move, score_for_side_to_move_in_pawns, engine_name)."""
    if stockfish:
        try:
            with chess.engine.SimpleEngine.popen_uci(stockfish) as eng:
                r = eng.play(board, chess.engine.Limit(time=0.4 + 0.2 * depth),
                             info=chess.engine.INFO_SCORE)
                sc = r.info.get("score")
                cp = sc.pov(board.turn).score(mate_score=10000) if sc else 0
                return r.move, cp / 100.0, "Stockfish"
        except Exception as e:                                # noqa: BLE001
            print("Stockfish failed, using the built-in engine:", e)
    best, best_s = None, None
    for m in _ordered(board):
        board.push(m)
        s = _search(board, depth - 1, -10 ** 6, 10 ** 6)
        board.pop()
        s = s if board.turn == chess.WHITE else -s
        if best_s is None or s > best_s:
            best, best_s = m, s
    return best, (best_s or 0) / 100.0, "built-in engine"


def load_position(text):
    """Accepts a FEN or a PGN (e.g. copied from chess.com) and returns a chess.Board."""
    t = (text or "").strip()
    if not t:
        return chess.Board()
    if t.count("/") == 7 and " " in t:
        return chess.Board(t)
    import io
    import chess.pgn
    game = chess.pgn.read_game(io.StringIO(t))
    if game is None:
        raise ValueError("That is not a FEN or a PGN.")
    b = game.board()
    for m in game.mainline_moves():
        b.push(m)
    return b
