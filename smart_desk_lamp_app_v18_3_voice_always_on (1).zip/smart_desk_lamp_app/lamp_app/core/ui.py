"""Window + touchscreen handling and a few drawing helpers.

Everything the user sees is a 320x240 picture. The laptop window shows it 2x bigger,
and the same picture is sent to the lamp's TFT. Clicks in the window and touches on the
TFT both arrive as the same events, so every feature works with mouse, keyboard and touch.
"""
import textwrap
import threading
import time
import zlib
from dataclasses import dataclass

import cv2
import numpy as np

from .. import config
from .board import BoardError

W, H = config.TFT_W, config.TFT_H
BACK_RECT = (0, 0, 58, 22)          # top-left corner = "back" on every screen
FONT = cv2.FONT_HERSHEY_SIMPLEX


@dataclass
class Event:
    type: str            # "key", "down", "move", "up"
    key: str = ""        # for "key": 'a', '5', 'space', 'enter', 'esc', 'backspace' ...
    x: int = 0           # for touch/mouse events, in 320x240 pixels
    y: int = 0


# ------------------------------ drawing helpers ------------------------------
def in_rect(x, y, r):
    return r[0] <= x < r[0] + r[2] and r[1] <= y < r[1] + r[3]


def ascii_only(s):
    return s.encode("ascii", "replace").decode()


def put(img, text, org, scale=0.5, color=(255, 255, 255), thick=1, outline=False):
    if outline:
        cv2.putText(img, text, org, FONT, scale, (0, 0, 0), thick + 2, cv2.LINE_AA)
    cv2.putText(img, text, org, FONT, scale, color, thick, cv2.LINE_AA)


def put_center(img, text, rect, scale=0.5, color=(255, 255, 255), thick=1):
    (tw, th), _ = cv2.getTextSize(text, FONT, scale, thick)
    x = rect[0] + (rect[2] - tw) // 2
    y = rect[1] + (rect[3] + th) // 2
    put(img, text, (x, y), scale, color, thick)


def button(img, rect, label, fill=(70, 70, 70), fg=(255, 255, 255), scale=0.5, thick=1):
    x, y, w, h = rect
    cv2.rectangle(img, (x, y), (x + w - 1, y + h - 1), fill, -1)
    cv2.rectangle(img, (x, y), (x + w - 1, y + h - 1), (200, 200, 200), 1)
    put_center(img, label, rect, scale, fg, thick)


def draw_back(img):
    button(img, BACK_RECT, "< BACK", fill=(0, 0, 0), fg=(0, 255, 255), scale=0.45)
    cv2.rectangle(img, (0, 0), (BACK_RECT[2] - 1, BACK_RECT[3] - 1), (0, 255, 255), 1)


def wrap(text, width=36):
    out = []
    for para in ascii_only(text).splitlines() or [""]:
        out += textwrap.wrap(para, width) or [""]
    return out


def overlay(img, lines, color=(0, 255, 0), top=True):
    """Outlined text lines on the top (or bottom) of a picture."""
    out = img.copy()
    h = out.shape[0]
    y = 24 if top else h - 24 * len(lines) + 12
    for line in lines:
        put(out, line, (10, y), 0.6, color, 1, outline=True)
        y += 24
    return out


def is_back(ev):
    if ev.type == "key":
        return ev.key in ("esc", "q")
    return ev.type == "down" and in_rect(ev.x, ev.y, BACK_RECT)


# ------------------------------ the window ------------------------------
class UI:
    def __init__(self, board):
        self.board = board
        self._mouse = []
        self._mdown = False
        self._tp = False             # touch state: finger is down
        self._tlast = 0.0
        self._tft_hash = None
        self._tft_time = 0.0
        cv2.namedWindow(config.WINDOW, cv2.WINDOW_AUTOSIZE)   # raises cv2.error on headless OpenCV
        cv2.setMouseCallback(config.WINDOW, self._on_mouse)

    # ---- showing pictures ----
    def show(self, img, tft=True, force=False):
        """Show a 320x240 picture on the laptop (2x) and on the TFT."""
        s = config.SCALE
        cv2.imshow(config.WINDOW, cv2.resize(img, None, fx=s, fy=s, interpolation=cv2.INTER_LINEAR))
        if tft:
            self._send_tft(img, force)

    def show_big(self, img):
        """Laptop window only (used for the live camera: the board draws that on the TFT itself)."""
        cv2.imshow(config.WINDOW, img)

    def _send_tft(self, img, force):
        h = zlib.adler32(img.tobytes())
        if not force and h == self._tft_hash:
            return
        if not force and time.time() - self._tft_time < 0.05:
            return                                   # the next call will send it
        try:
            self.board.show_image(img)
        except (TimeoutError, BoardError):
            return
        self._tft_hash = h
        self._tft_time = time.time()

    def invalidate(self):
        """Forget what the TFT shows (call after the live camera used the screen)."""
        self._tft_hash = None

    def closed(self):
        try:
            return cv2.getWindowProperty(config.WINDOW, cv2.WND_PROP_VISIBLE) < 1
        except cv2.error:
            return True

    def pump(self, ms=50):
        cv2.waitKey(ms)

    # ---- input ----
    def _on_mouse(self, event, x, y, flags, param):
        s = config.SCALE
        x, y = x // s, y // s
        if event == cv2.EVENT_LBUTTONDOWN:
            self._mdown = True
            self._mouse.append(Event("down", x=x, y=y))
        elif event == cv2.EVENT_MOUSEMOVE and self._mdown:
            self._mouse.append(Event("move", x=x, y=y))
        elif event == cv2.EVENT_LBUTTONUP:
            self._mdown = False
            self._mouse.append(Event("up", x=x, y=y))

    def events(self):
        """Everything that happened since the last call: keys, mouse and touchscreen."""
        evs = []
        k = cv2.waitKey(1)
        if k != -1:
            k &= 0xFF
            names = {27: "esc", 13: "enter", 32: "space", 8: "backspace"}
            key = names.get(k, chr(k) if 32 < k < 127 else "")
            if key:
                evs.append(Event("key", key=key))
        evs += self._mouse
        self._mouse = []

        now = time.time()
        if now - self._tlast >= 0.015:
            self._tlast = now
            try:
                pressed, x, y = self.board.touch()
            except (TimeoutError, BoardError):
                pressed, x, y = False, 0, 0
            if pressed and not self._tp:
                evs.append(Event("down", x=x, y=y))
            elif pressed:
                evs.append(Event("move", x=x, y=y))
            elif self._tp:
                evs.append(Event("up", x=x, y=y))
            self._tp = pressed
        return evs

    # ---- keep the window alive while something slow happens ----
    def run_bg(self, fn):
        """Run fn() in a thread, keep the window responsive. Returns (result, error)."""
        box = {}

        def w():
            try:
                box["result"] = fn()
            except Exception as e:          # noqa: BLE001 - shown to the user
                box["error"] = e

        t = threading.Thread(target=w, daemon=True)
        t.start()
        while t.is_alive():
            self.pump(50)
        return box.get("result"), box.get("error")

    def ask(self, prompt):
        """input() in the terminal while the window stays alive."""
        res, err = self.run_bg(lambda: input(prompt))
        return "" if err else (res or "")


def blank(color=(30, 22, 18)):
    img = np.zeros((H, W, 3), np.uint8)
    img[:] = color
    return img
