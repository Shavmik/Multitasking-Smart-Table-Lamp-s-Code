class Context:
    """What every feature receives: the board, the window, and shared tools."""

    def __init__(self, board, ui):
        self.board = board
        self.ui = ui

    def ocr(self):
        from .ocr_engine import get_reader
        return get_reader(lambda msg: self.board.text("Please wait", msg))
