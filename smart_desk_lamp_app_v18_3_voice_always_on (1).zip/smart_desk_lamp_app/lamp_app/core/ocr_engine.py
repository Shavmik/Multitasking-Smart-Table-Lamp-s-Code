"""OCR back-ends: EasyOCR (loaded once, it is big) and Tesseract (pytesseract). 'both' keeps the more confident result."""
import os
import sys

from .. import config

_reader = None
TESS_WIN = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
ENGINES = ("easyocr", "tesseract", "both")


def get_reader(announce=None):
    global _reader
    if _reader is None:
        if announce:
            announce("Loading the text reader (first time only)...")
        print("\nLoading EasyOCR (the first run downloads the model)...")
        import warnings
        warnings.filterwarnings("ignore")
        import easyocr
        _reader = easyocr.Reader(config.LANGUAGES, gpu=config.USE_GPU)
    return _reader


def _tess_lang():
    m = {"en": "eng", "hi": "hin"}
    return "+".join(m.get(c, c) for c in config.LANGUAGES)


def tesseract_ready(cmd=""):
    """Returns (ok, message)."""
    try:
        import pytesseract
    except ImportError:
        return False, "pytesseract is not installed (pip install pytesseract)."
    path = cmd or (TESS_WIN if sys.platform == "win32" and os.path.exists(TESS_WIN) else "")
    if path:
        pytesseract.pytesseract.tesseract_cmd = path
    try:
        pytesseract.get_tesseract_version()
        return True, "Tesseract is ready."
    except Exception:                                       # noqa: BLE001
        return False, "Tesseract program not found. Install it (UB-Mannheim build) and set its path in Settings."


def _easy(img, paragraph, lock=None):
    reader = get_reader()
    res = reader.readtext(img, detail=1, paragraph=False)
    text = " ".join(r[1] for r in res).strip()
    conf = (sum(r[2] for r in res) / len(res) * 100) if res else 0.0
    if paragraph and res:
        text = " ".join(reader.readtext(img, detail=0, paragraph=True)).strip() or text
    return text, conf


def _tess(img, cmd=""):
    import pytesseract
    ok, msg = tesseract_ready(cmd)
    if not ok:
        raise RuntimeError(msg)
    d = pytesseract.image_to_data(img, lang=_tess_lang(), output_type=pytesseract.Output.DICT)
    words = [(w, float(c)) for w, c in zip(d["text"], d["conf"]) if w.strip() and float(c) >= 0]
    text = " ".join(w for w, _ in words)
    conf = sum(c for _, c in words) / len(words) if words else 0.0
    return text.strip(), conf


def read(img, engine="easyocr", paragraph=True, tess_cmd=""):
    """Returns the recognised text. engine = easyocr | tesseract | both."""
    if engine == "tesseract":
        return _tess(img, tess_cmd)[0]
    if engine == "both":
        results = []
        try:
            results.append(_easy(img, paragraph))
        except Exception as e:                              # noqa: BLE001
            print("EasyOCR failed:", e)
        try:
            results.append(_tess(img, tess_cmd))
        except Exception as e:                              # noqa: BLE001
            print("Tesseract failed:", e)
        if not results:
            raise RuntimeError("Neither EasyOCR nor Tesseract could read the picture.")
        return max(results, key=lambda r: (r[1], len(r[0])))[0]
    return _easy(img, paragraph)[0]
