"""Indian Standard Time (New Delhi). India has no daylight saving, so a fixed +05:30 offset is exact
and works on any PC without extra packages, whatever time zone the laptop itself is set to."""
from datetime import datetime, timedelta, timezone

IST = timezone(timedelta(hours=5, minutes=30), "IST")


def ist_now():
    return datetime.now(IST)


def time_text(dt, h24=False, seconds=True):
    if h24:
        return dt.strftime("%H:%M:%S" if seconds else "%H:%M")
    s = dt.strftime("%I:%M:%S" if seconds else "%I:%M").lstrip("0")
    return s


def ampm(dt):
    return dt.strftime("%p")


def date_text(dt):
    return dt.strftime("%A, %d %B %Y")
