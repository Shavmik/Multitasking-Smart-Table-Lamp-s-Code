"""Google inside the app. Text read by OCR (Tesseract / EasyOCR) is searched here, and chess.com opens here too.
While Study or Focus mode runs, blocked websites (YouTube, Instagram...) are refused by a request interceptor."""
import os
from urllib.parse import quote_plus, urlparse

from PySide6.QtCore import QStandardPaths, QUrl
from PySide6.QtWidgets import QHBoxLayout, QLineEdit, QProgressBar, QVBoxLayout

from ..theme import px
from ..widgets import GlassCard, IconButton, label, make_button
from .base import Page

try:
    from PySide6.QtWebEngineCore import (QWebEnginePage, QWebEngineProfile, QWebEngineUrlRequestInfo,
                                         QWebEngineUrlRequestInterceptor)
    from PySide6.QtWebEngineWidgets import QWebEngineView
    HAVE_WEB = True
except Exception:                                            # noqa: BLE001
    HAVE_WEB = False

GOOGLE = "https://www.google.com/"


def to_url(text):
    t = text.strip()
    if " " not in t and ("." in t or "://" in t) and not t.endswith("."):
        return t if "://" in t else "https://" + t
    return GOOGLE + "search?q=" + quote_plus(t)


if HAVE_WEB:
    class _Blocker(QWebEngineUrlRequestInterceptor):
        def __init__(self, ctx):
            super().__init__()
            self.ctx = ctx
            self.hit = None

        def interceptRequest(self, info):
            m = self.ctx.modes
            if m.current == "normal":
                return
            host = info.requestUrl().host().lower()
            if info.resourceType() == QWebEngineUrlRequestInfo.ResourceType.ResourceTypeMainFrame and any(
                    k.lower().replace(" ", "") in host for k in m.profile(m.current)["sites"]):
                self.hit = host
                info.block(True)

    class _Page(QWebEnginePage):
        def createWindow(self, kind):
            tmp = QWebEnginePage(self.profile(), self)
            tmp.urlChanged.connect(lambda u: (self.setUrl(u), tmp.deleteLater()) if not u.isEmpty() else None)
            return tmp


class WebSearchPage(Page):
    key, title = "web", "Google Search"

    def __init__(self, ctx):
        super().__init__(ctx)
        self.view = None
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(px(10))
        bar = GlassCard(radius=18)
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(px(12), px(8), px(12), px(8))
        self.b_back, self.b_fwd = IconButton("back", "Back", 42), IconButton("forward", "Forward", 42)
        self.b_reload, self.b_home = IconButton("reload", "Reload", 42), IconButton("home", "Google home", 42)
        for b in (self.b_back, self.b_fwd, self.b_reload, self.b_home):
            bl.addWidget(b)
        self.url = QLineEdit()
        self.url.setPlaceholderText("Search Google or type an address")
        bl.addWidget(self.url, 1)
        b_go = make_button("Search", "primary", "search")
        bl.addWidget(b_go)
        root.addWidget(bar)
        self.progress = QProgressBar(); self.progress.setTextVisible(False); self.progress.setRange(0, 100); self.progress.setFixedHeight(px(4))
        root.addWidget(self.progress)
        self.holder = QVBoxLayout()
        root.addLayout(self.holder, 1)
        self.msg = label("", "dim", wrap=True)
        root.addWidget(self.msg)
        b_go.clicked.connect(self._go)
        self.url.returnPressed.connect(self._go)
        if not HAVE_WEB:
            self.msg.setText("The built-in web view is missing:  pip install PySide6   (it includes Qt WebEngine). Searches open in your normal browser meanwhile.")

    def _build(self):
        base = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppDataLocation)
        self.profile = QWebEngineProfile("smartdesklamp_web", self)
        self.profile.setPersistentStoragePath(os.path.join(base, "web_profile"))
        self.profile.setCachePath(os.path.join(base, "web_cache"))
        self.blocker = _Blocker(self.ctx)
        self.profile.setUrlRequestInterceptor(self.blocker)
        self.view = QWebEngineView(self)
        self.view.setPage(_Page(self.profile, self))
        self.holder.addWidget(self.view, 1)
        self.view.urlChanged.connect(lambda u: self.url.setText(u.toString()))
        self.view.loadProgress.connect(self.progress.setValue)
        self.view.loadFinished.connect(self._finished)
        self.b_back.clicked.connect(self.view.back); self.b_fwd.clicked.connect(self.view.forward)
        self.b_reload.clicked.connect(self.view.reload); self.b_home.clicked.connect(lambda: self.open_url(GOOGLE))

    def on_enter(self):
        if HAVE_WEB and self.view is None:
            self._build()
        url, self.ctx.pending_url = self.ctx.pending_url, ""
        if url:
            self.open_url(url)
        elif HAVE_WEB and self.view.url().isEmpty():
            self.open_url(GOOGLE)

    def open_url(self, url):
        if self.view is not None:
            self.msg.setText("")
            self.view.setUrl(QUrl(url))
        else:
            import webbrowser
            webbrowser.open(url)

    def _go(self):
        if self.url.text().strip():
            self.open_url(to_url(self.url.text()))

    def _finished(self, ok):
        self.progress.setValue(100 if ok else 0)
        hit = self.blocker.hit
        self.blocker.hit = None
        if hit:
            self.msg.setText(f"{hit} is blocked while {self.ctx.modes.current.title()} mode is on.")
        elif not ok:
            self.msg.setText("The page could not be loaded. Check the internet connection and press Reload.")
        else:
            self.msg.setText("")
