"""Modes: Study / Focus / Gaming. Study and Focus close distracting apps and browser tabs and silence notifications."""
import time

from PySide6.QtCore import QTimer, Qt
from PySide6.QtWidgets import (QCheckBox, QComboBox, QHBoxLayout, QListWidget, QPlainTextEdit, QSpinBox, QVBoxLayout)

from ...core.timers import fmt_hms
from ..services import run_async
from ..theme import px
from ..widgets import GlassCard, label, make_button
from ._ui import restyle, vcard
from ..fx import Banner
from .base import Page

CARDS = [("study", "Study", "Blocks games, chat and video apps, closes YouTube / Instagram tabs, mutes notifications.", "primary"),
         ("focus", "Focus", "A lighter pomodoro-style block for deep work. Same blocking, shorter default.", "orange"),
         ("gaming", "Gaming", "Unlocks the Gaming hub: Rubik's cube, chess and sudoku solvers.", "green")]


def _banner(key):
    if key == "study":
        return Banner("fx/chibi/001.jpg", "cover", 110, title="Study")
    if key == "focus":
        return Banner("fx/focus_banner.jpg", "cover", 110, title="Focus")
    return Banner("fx/icon_discord.jpg", "icon", 110, "#FF5A3D")


class ModesPage(Page):
    key, title = "modes", "Modes"
    tft_names = ('lb_mode', 'lb_time', ('lb_sess', 'sp_min'), 'b_stop', ('b_study', 'b_focus', 'b_gaming'))

    def __init__(self, ctx):
        super().__init__(ctx)
        self._busy = False
        self._ticks = 0
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(self.gap())
        left = QVBoxLayout()
        left.setSpacing(self.gap())

        # ---- status ----
        c, l = vcard("Current mode")
        self.lb_mode = label("Normal", "h1")
        self.lb_time = label("", "dim")
        self.lb_time.setStyleSheet(f"font-size: {px(34)}px; font-weight: 700;")
        l.addWidget(self.lb_mode)
        l.addWidget(self.lb_time)
        row = QHBoxLayout()
        self.lb_sess = label("Session length (minutes, 0 = no limit):", "dim")
        row.addWidget(self.lb_sess)
        self.sp_min = QSpinBox()
        self.sp_min.setRange(0, 600)
        self.sp_min.setValue(50)
        row.addWidget(self.sp_min)
        row.addStretch(1)
        self.b_stop = make_button("Stop mode", "danger", "stop")
        self.b_stop.clicked.connect(lambda: ctx.set_mode("normal"))
        row.addWidget(self.b_stop)
        l.addLayout(row)
        left.addWidget(c)

        # ---- the three mode cards ----
        cards = QHBoxLayout()
        cards.setSpacing(self.gap())
        self.start_btns = {}
        for key, name, desc, var in CARDS:
            c, l = vcard(name, desc)
            l.insertWidget(0, _banner(key))
            b = make_button(f"Start {name} mode", var)
            b.clicked.connect(lambda _=False, k=key: self._start(k))
            l.addStretch(1)
            l.addWidget(b)
            cards.addWidget(c, 1)
            self.start_btns[key] = b
            setattr(self, f"b_{key}", b)                     # b_study / b_focus / b_gaming (also shown on the TFT)
        left.addLayout(cards)

        # ---- editable block lists ----
        c, l = vcard("What gets blocked", "One name per line. Apps are force-closed; website names are matched against browser tab titles.")
        top = QHBoxLayout()
        self.cb_mode = QComboBox()
        for k in ("study", "focus", "gaming"):
            self.cb_mode.addItem(k.title(), k)
        self.cb_mode.currentIndexChanged.connect(self._load_profile)
        top.addWidget(self.cb_mode)
        self.ck_dnd = QCheckBox("Silence notifications from other apps")
        top.addWidget(self.ck_dnd)
        top.addStretch(1)
        l.addLayout(top)
        boxes = QHBoxLayout()
        v1, v2 = QVBoxLayout(), QVBoxLayout()
        self.ed_apps, self.ed_sites = QPlainTextEdit(), QPlainTextEdit()
        v1.addWidget(label("Desktop apps (Discord, Steam...)", "h3")); v1.addWidget(self.ed_apps)
        v2.addWidget(label("Websites (youtube, instagram...)", "h3")); v2.addWidget(self.ed_sites)
        boxes.addLayout(v1); boxes.addLayout(v2)
        l.addLayout(boxes, 1)
        row = QHBoxLayout()
        b_save = make_button("Save lists", "primary", "save")
        b_save.clicked.connect(self._save_profile)
        b_test = make_button("Test now", None, "check")
        b_test.setToolTip("Runs the blocker once for the selected mode")
        b_test.clicked.connect(self._test)
        self.lb_note = label("", "dim", wrap=True)
        row.addWidget(b_save); row.addWidget(b_test); row.addWidget(self.lb_note, 1)
        l.addLayout(row)
        left.addWidget(c, 1)
        root.addLayout(left, 3)

        # ---- activity log ----
        c, l = vcard("Blocked so far")
        self.log = QListWidget()
        l.addWidget(self.log, 1)
        l.addWidget(label("Notifications use Winotify / Plyer. Blocking needs the app to stay open.", "dim", wrap=True))
        c.setMaximumWidth(px(340))
        root.addWidget(c, 1)

        self._t = QTimer(self)
        self._t.setInterval(1000)
        self._t.timeout.connect(self._tick)
        self._t.start()
        ctx.mode_changed.connect(lambda m: self._refresh())
        self._load_profile()
        self._refresh()

    # ---- profile editor ----
    def _load_profile(self):
        p = self.ctx.modes.profile(self.cb_mode.currentData())
        self.ed_apps.setPlainText("\n".join(p["apps"]))
        self.ed_sites.setPlainText("\n".join(p["sites"]))
        self.ck_dnd.setChecked(p["dnd"])

    def _lines(self, ed):
        return [x.strip() for x in ed.toPlainText().replace(",", "\n").splitlines() if x.strip()]

    def _save_profile(self):
        mode = self.cb_mode.currentData()
        self.ctx.modes.save_profile(mode, self._lines(self.ed_apps), self._lines(self.ed_sites), self.ck_dnd.isChecked(),
                                    self.ctx.modes.profile(mode)["minutes"])
        self.lb_note.setText(f"Saved the {mode} lists.")

    def _test(self):
        self._save_profile()
        saved = self.ctx.modes.current
        self.ctx.modes.current = self.cb_mode.currentData()
        run_async(self.ctx.modes.enforce, lambda res, err: (setattr(self.ctx.modes, "current", saved),
                                                             self.lb_note.setText(", ".join(res) if res else (str(err) if err else "Nothing to close right now."))))

    # ---- start / stop ----
    def _start(self, mode):
        self.ctx.set_mode(mode, self.sp_min.value() if mode != "gaming" else 0)
        if mode == "gaming":
            self.ctx.go("gaming")

    def _refresh(self):
        mode = self.ctx.modes.current
        on = mode != "normal"
        self.lb_mode.setText(("%s mode" % mode.title()) if on else "Normal")
        self.b_stop.setEnabled(on)
        for k, b in self.start_btns.items():
            b.setEnabled(k != mode)
        self.log.clear()
        for when, text in reversed(self.ctx.modes.log[-40:]):
            self.log.addItem(f"{when}  {text}")
        self._tick()

    def on_enter(self):
        p = self.ctx.modes.profile("study")
        self._refresh()

    def _tick(self):
        m = self.ctx.modes
        if m.current == "normal":
            self.lb_time.setText("No mode running")
            return
        el = m.elapsed()
        if m.planned_min:
            left = m.planned_min * 60 - el
            self.lb_time.setText(f"{fmt_hms(left)} left")
            if left <= 0:
                spent = self.ctx.end_mode()[1]
                m.notify("Session finished", f"Well done - {int(spent)} minutes logged. Take a short break.")
                self.ctx.speak("Session finished. Take a short break.")
                return
        else:
            self.lb_time.setText(f"{fmt_hms(el)} elapsed")
        self._ticks += 1
        if self._ticks % 3 == 0 and not self._busy and m.profile(m.current)["apps"] + m.profile(m.current)["sites"]:
            self._busy = True
            run_async(m.enforce, self._enforced)

    def _enforced(self, res, err):
        self._busy = False
        if res:
            self._refresh()
