"""Real-time clock in Indian Standard Time (New Delhi): digital + analog, 12/24 hour switch."""
import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPen, QRadialGradient
from PySide6.QtWidgets import QHBoxLayout, QVBoxLayout, QWidget, QSizePolicy

from ...core.clock import ampm, date_text, ist_now, time_text
from ..icons import art_pixmap
from ..theme import px
from ..widgets import AA, SMOOTH, GlassCard, label, make_button, rounded
from .base import Page


class AnalogClock(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.now = ist_now()
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMinimumSize(px(220), px(220))

    def set_time(self, dt):
        self.now = dt
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        side = min(self.width(), self.height()) - px(8)
        c = QPointF(self.width() / 2, self.height() / 2)
        rad = side / 2
        face = QRadialGradient(c, rad)
        face.setColorAt(0, QColor(255, 255, 255, 36)); face.setColorAt(1, QColor(255, 255, 255, 14))
        p.setBrush(face); p.setPen(QPen(QColor(255, 255, 255, 90), 2))
        p.drawEllipse(c, rad, rad)
        for i in range(60):
            a = math.radians(i * 6 - 90)
            major = i % 5 == 0
            r1 = rad * (0.86 if major else 0.92)
            p.setPen(QPen(QColor(255, 255, 255, 220 if major else 90), 3 if major else 1.4, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            p.drawLine(QPointF(c.x() + r1 * math.cos(a), c.y() + r1 * math.sin(a)),
                       QPointF(c.x() + rad * 0.97 * math.cos(a), c.y() + rad * 0.97 * math.sin(a)))
        f = QFont(self.font()); f.setPixelSize(int(rad * 0.16)); f.setBold(True); p.setFont(f)
        p.setPen(QColor(255, 255, 255, 235))
        for n in (12, 3, 6, 9):
            a = math.radians(n * 30 - 90)
            p.drawText(QRectF(c.x() + rad * 0.68 * math.cos(a) - rad * .12, c.y() + rad * 0.68 * math.sin(a) - rad * .12, rad * .24, rad * .24),
                       int(Qt.AlignmentFlag.AlignCenter), str(n))
        t = self.now
        sec = t.second
        minute = t.minute + sec / 60
        hour = (t.hour % 12) + minute / 60

        def hand(angle_deg, length, width, color):
            a = math.radians(angle_deg - 90)
            p.setPen(QPen(QColor(color), width, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            p.drawLine(c, QPointF(c.x() + rad * length * math.cos(a), c.y() + rad * length * math.sin(a)))

        hand(hour * 30, 0.5, rad * 0.055, "#FFFFFF")
        hand(minute * 6, 0.75, rad * 0.04, "#C9B8FF")
        hand(sec * 6, 0.84, rad * 0.018, "#FF8A3D")
        p.setBrush(QColor("#FF8A3D")); p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(c, rad * 0.04, rad * 0.04)


class ArtCard(GlassCard):
    """Glass card showing one picture, large and crisp."""

    def __init__(self, art, parent=None):
        super().__init__(parent)
        self.art = art
        self._cache = (None, None)

    def paintEvent(self, e):
        super().paintEvent(e)
        p = QPainter(self)
        p.setRenderHint(AA); p.setRenderHint(SMOOTH)
        r = QRectF(self.rect()).adjusted(px(10), px(10), -px(10), -px(10))
        src = art_pixmap(self.art)
        dpr = self.devicePixelRatioF()
        key = (int(r.width()), int(r.height()), dpr)
        if self._cache[0] != key:
            pm = src.scaled(int(r.width() * dpr), int(r.height() * dpr), Qt.AspectRatioMode.KeepAspectRatio,
                            Qt.TransformationMode.SmoothTransformation)
            pm.setDevicePixelRatio(dpr)
            self._cache = (key, pm)
        pm = self._cache[1]
        sz = pm.size() / dpr
        p.setClipPath(rounded(r, px(18)))
        from ..theme import is_dark
        bg = QColor(14, 12, 26) if is_dark() else QColor(255, 255, 255)
        p.fillRect(r, bg)
        img_top = r.bottom() - sz.height()
        p.drawPixmap(QPointF(r.center().x() - sz.width() / 2, img_top), pm)
        # soft fade where the picture meets the card, so the hard image edge never shows as a visible seam
        from PySide6.QtGui import QLinearGradient
        fade_h = min(px(46), sz.height() * 0.3)
        g = QLinearGradient(0, img_top, 0, img_top + fade_h)
        g.setColorAt(0.0, QColor(bg.red(), bg.green(), bg.blue(), 235))
        g.setColorAt(1.0, QColor(bg.red(), bg.green(), bg.blue(), 0))
        p.fillRect(QRectF(r.left(), img_top, r.width(), fade_h), g)


class ClockPage(Page):
    key, title = "clock", "Clock"
    tft_names = (('lb_time', 'lb_ampm'), 'lb_date', 'analog', ('b_fmt', 'b_say'))

    def tft_clock(self):
        """The lamp screen becomes a plain black-background, white-digit clock, redrawn in
        place every second - the fastest update the TFT can do."""
        n = self.ctx.clock.now()
        return time_text(n, self.ctx.clock.h24)

    def __init__(self, ctx):
        super().__init__(ctx)
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(self.gap())

        self.hero = GlassCard()
        hl = QVBoxLayout(self.hero)
        m = px(26)
        hl.setContentsMargins(m, m, m, m)
        hl.setSpacing(px(8))
        hl.addWidget(label("India Standard Time", "h2"))
        hl.addWidget(label("New Delhi  \u2022  IST (UTC+05:30)", "dim"))
        row = QHBoxLayout()
        self.lb_time = label("--:--:--", align=Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.lb_ampm = label("", align=Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignBottom)
        row.addWidget(self.lb_time)
        row.addWidget(self.lb_ampm)
        row.addStretch(1)
        hl.addLayout(row)
        self.lb_date = label("", "h2")
        hl.addWidget(self.lb_date)
        hl.addStretch(1)
        self.analog = AnalogClock()
        hl.addWidget(self.analog, 4)
        btns = QHBoxLayout()
        self.b_fmt = make_button("", None, "clock")
        btns.addWidget(self.b_fmt)
        self.b_say = make_button("Say the time", None, "speaker")
        btns.addWidget(self.b_say)
        btns.addStretch(1)
        hl.addLayout(btns)
        root.addWidget(self.hero, 3)
        root.addWidget(ArtCard("art_clock.png"), 2)

        self.b_fmt.clicked.connect(self._toggle)
        self.b_say.clicked.connect(self._say)
        ctx.clock.tick.connect(self._tick)
        self._tick(ctx.clock.now())

    def _toggle(self):
        self.ctx.clock.h24 = not self.ctx.clock.h24

    def _say(self):
        n = self.ctx.clock.now()
        self.ctx.speak(f"The time in India is {n.strftime('%I').lstrip('0')} {n.strftime('%M')} {n.strftime('%p')}. {date_text(n)}")

    def resizeEvent(self, e):
        size = max(px(40), min(int(self.hero.width() * 0.16), int(self.hero.height() * 0.22)))
        self.lb_time.setStyleSheet(f"font-size: {size}px; font-weight: 700;")
        self.lb_ampm.setStyleSheet(f"font-size: {int(size * .32)}px; font-weight: 700; color: #FF8A3D; padding-bottom: {int(size * .12)}px;")
        super().resizeEvent(e)

    def _tick(self, now):
        h24 = self.ctx.clock.h24
        self.lb_time.setText(time_text(now, h24))
        self.lb_ampm.setText("" if h24 else ampm(now))
        self.lb_date.setText(date_text(now))
        self.b_fmt.setText("Switch to 12-hour" if h24 else "Switch to 24-hour")
        self.analog.set_time(now)
