"""Calculator: big glass keypad, keyboard input, history, and it can speak the result."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QListWidget, QVBoxLayout

from ...features.calculator import fmt, safe_eval
from ..theme import px
from ..widgets import GlassCard, label, make_button
from ..fx import TechKey
from .base import Page

KEYS = [["C", "(", ")", "/"],
        ["7", "8", "9", "*"],
        ["4", "5", "6", "-"],
        ["1", "2", "3", "+"],
        ["0", ".", "<", "="]]


class CalculatorPage(Page):
    key, title = "calc", "Calculator"

    def tft_units(self):
        from PySide6.QtCore import QPoint, QRect
        r = QRect()
        for b in self.keys:
            if b.isVisible():
                r = r.united(QRect(b.mapTo(self, QPoint(0, 0)), b.size()))
        if r.isNull():
            return None
        return [self.tft_visible(self.lb_expr), [(self, r)]]

    def __init__(self, ctx):
        super().__init__(ctx)
        self.expr, self.result = "", ""
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(self.gap())

        left = GlassCard()
        ll = QVBoxLayout(left)
        m = px(20)
        ll.setContentsMargins(m, m, m, m)
        ll.setSpacing(px(12))
        self.keys = []
        self.lb_res = label("", "dim", align=Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.lb_res.setStyleSheet(f"font-size: {px(20)}px; color: #7DE3FF;")
        self.lb_expr = label("0", align=Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.lb_expr.setStyleSheet(f"font-size: {px(46)}px; font-weight: 700;")
        self.lb_expr.setMinimumHeight(px(70))
        ll.addWidget(self.lb_res)
        ll.addWidget(self.lb_expr)
        grid = QGridLayout()
        grid.setSpacing(px(10))
        for r, row in enumerate(KEYS):
            for c, k in enumerate(row):
                b = TechKey({"<": "\u232B", "*": "\u00D7", "/": "\u00F7"}.get(k, k),
                            "op" if k in "/*-+=" else ("fn" if k in "C()" else "key"),
                            {"C": "Esc", "<": "Bksp", "=": "Enter"}.get(k, ""))
                b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
                b.setMinimumHeight(px(64))
                b.setSizePolicy(b.sizePolicy().horizontalPolicy(), b.sizePolicy().verticalPolicy())
                b.clicked.connect(lambda _=False, key=k: self.press(key))
                grid.addWidget(b, r, c)
                self.keys.append(b)
                grid.setRowStretch(r, 1)
        ll.addLayout(grid, 1)
        self.b_say = make_button("Read the result aloud", None, "speaker")
        self.b_say.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.b_say.clicked.connect(self.speak)
        ll.addWidget(self.b_say)
        root.addWidget(left, 3)

        right = GlassCard()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(m, m, m, m)
        rl.addWidget(label("History", "h2"))
        rl.addWidget(label("Click an entry to use its result again.", "dim", wrap=True))
        self.hist = QListWidget()
        self.hist.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.hist.itemClicked.connect(self._reuse)
        rl.addWidget(self.hist, 1)
        b_clear = make_button("Clear history", None, "trash")
        b_clear.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b_clear.clicked.connect(self.hist.clear)
        rl.addWidget(b_clear)
        root.addWidget(right, 2)

    def on_enter(self):
        self.setFocus()

    # ---- logic (same rules as the lamp calculator) ----
    def press(self, k):
        if k == "C":
            self.expr, self.result = "", ""
        elif k == "<":
            self.expr = self.expr[:-1]
        elif k == "=":
            if self.expr:
                try:
                    res = fmt(safe_eval(self.expr))
                    self.hist.insertItem(0, f"{self.expr} = {res}")
                    self.result, self.expr = res, res
                    self.lb_res.setText("")
                except ZeroDivisionError:
                    self.lb_res.setText("Cannot divide by 0")
                except Exception:
                    self.lb_res.setText("Not a valid sum")
                self._show()
                return
        else:
            if self.result and k in "0123456789.(":          # typing a number starts a new sum
                self.expr, self.result = "", ""
            self.expr += k
            self.result = ""
        self.lb_res.setText("")
        self._show()

    def _show(self):
        self.lb_expr.setText(self.expr[-18:] if self.expr else "0")

    def _reuse(self, item):
        res = item.text().split("=")[-1].strip()
        self.expr, self.result = res, ""
        self._show()

    def speak(self):
        text = self.result or self.expr
        if text:
            self.ctx.speak(text.replace("-", "minus ").replace(".", " point "))

    def keyPressEvent(self, e):
        k, t = e.key(), e.text()
        if k in (Qt.Key.Key_Return, Qt.Key.Key_Enter) or t == "=":
            self.press("=")
        elif k == Qt.Key.Key_Backspace:
            self.press("<")
        elif k in (Qt.Key.Key_Escape, Qt.Key.Key_Delete) or t in ("c", "C"):
            self.press("C")
        elif t and t in "0123456789.+-*/()":
            self.press(t)
        elif t in ("x", "X"):
            self.press("*")
        elif t == "^":
            self.press("^")
        else:
            super().keyPressEvent(e)
