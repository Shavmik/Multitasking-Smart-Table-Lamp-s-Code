"""Stopwatch, countdown timer and activity tracker. The timer can be set from a picture (Tesseract / EasyOCR),
and every tracked activity is logged so the Smart Planner learns how long your tasks really take."""
import time
from datetime import datetime

import cv2
from PySide6.QtCore import QTimer, Qt
from PySide6.QtWidgets import (QComboBox, QFileDialog, QHBoxLayout, QLineEdit, QListWidget, QSpinBox, QVBoxLayout)

from ...core.timers import fmt_hms, parse_duration
from ..services import run_async
from ..theme import px
from ..widgets import label, make_button
from ._ui import vcard
from ..fx import ProgressRing
from .base import Page


def big(text="00:00"):
    lb = label(text, align=Qt.AlignmentFlag.AlignCenter)
    lb.setStyleSheet(f"font-size: {px(54)}px; font-weight: 700;")
    return lb


class TimersPage(Page):
    key, title = "timers", "Timers & Tracker"
    tft_names = ('ring_tm', 'lb_tm', ('b_p5', 'b_p10', 'b_p25', 'b_p45', 'b_p60'), ('b_tm', 'b_tmr'))

    def __init__(self, ctx):
        super().__init__(ctx)
        self.sw_base, self.sw_start, self.laps = 0.0, None, []
        self.tm_total, self.tm_left, self.tm_end = 0.0, 0.0, None
        self.tr_start, self.tr_info = None, None
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(self.gap())

        # ---------------- stopwatch ----------------
        c, l = vcard("Stopwatch")
        self.lb_sw = big("00:00.0")
        l.addWidget(self.lb_sw)
        r = QHBoxLayout()
        self.b_sw = make_button("Start", "green"); self.b_lap = make_button("Lap"); self.b_swr = make_button("Reset")
        for b in (self.b_sw, self.b_lap, self.b_swr):
            r.addWidget(b)
        l.addLayout(r)
        self.lap_list = QListWidget()
        l.addWidget(self.lap_list, 1)
        self.b_sw.clicked.connect(self._sw_toggle); self.b_lap.clicked.connect(self._sw_lap); self.b_swr.clicked.connect(self._sw_reset)
        root.addWidget(c, 1)

        # ---------------- timer ----------------
        c, l = vcard("Timer")
        self.ring_tm = ProgressRing(150, "fire", text="")
        l.addWidget(self.ring_tm, 0, Qt.AlignmentFlag.AlignHCenter)
        self.lb_tm = big("25:00")
        l.addWidget(self.lb_tm)
        r = QHBoxLayout()
        for m in (5, 10, 25, 45, 60):
            b = make_button(f"{m}m")
            b.clicked.connect(lambda _=False, v=m: self._tm_set(v * 60))
            setattr(self, f"b_p{m}", b)                      # preset buttons (also shown on the TFT)
            r.addWidget(b)
        l.addLayout(r)
        r = QHBoxLayout()
        self.sp_tm = QSpinBox(); self.sp_tm.setRange(1, 600); self.sp_tm.setValue(25); self.sp_tm.setSuffix(" min")
        b_set = make_button("Set"); b_set.clicked.connect(lambda: self._tm_set(self.sp_tm.value() * 60))
        r.addWidget(self.sp_tm); r.addWidget(b_set); r.addStretch(1)
        l.addLayout(r)
        r = QHBoxLayout()
        self.b_tm = make_button("Start", "green"); self.b_tmr = make_button("Reset")
        r.addWidget(self.b_tm); r.addWidget(self.b_tmr)
        l.addLayout(r)
        self.b_pic = make_button("Set from a picture (OCR)", None, "ocr")
        self.b_pic.setToolTip("Read '25 min' or '1:30:00' from a photo of a note, a whiteboard or a timer, using Tesseract / EasyOCR")
        self.b_lampshot = make_button("Set from the lamp camera", None, "camera")
        l.addWidget(self.b_pic); l.addWidget(self.b_lampshot)
        self.lb_tm_note = label("", "dim", wrap=True)
        l.addWidget(self.lb_tm_note)
        l.addStretch(1)
        self.b_tm.clicked.connect(self._tm_toggle); self.b_tmr.clicked.connect(self._tm_reset)
        self.b_pic.clicked.connect(self._pic_file); self.b_lampshot.clicked.connect(self._pic_lamp)
        self._tm_set(25 * 60)
        root.addWidget(c, 1)

        # ---------------- tracker ----------------
        c, l = vcard("Activity tracker", "Track what you do. The planner learns from it.")
        self.cb_cat = QComboBox(); self.cb_cat.setEditable(True)
        self.ed_title = QLineEdit(); self.ed_title.setPlaceholderText("What are you working on?")
        r = QHBoxLayout()
        self.sp_est = QSpinBox(); self.sp_est.setRange(0, 600); self.sp_est.setValue(30); self.sp_est.setSuffix(" min planned")
        r.addWidget(self.sp_est); r.addStretch(1)
        self.lb_ai = label("", "dim", wrap=True)
        self.lb_tr = big("00:00")
        self.b_tr = make_button("Start tracking", "primary", "check")
        for w in (self.cb_cat, self.ed_title):
            l.addWidget(w)
        l.addLayout(r); l.addWidget(self.lb_ai); l.addWidget(self.lb_tr); l.addWidget(self.b_tr)
        l.addWidget(label("Today", "h3"))
        self.today = QListWidget()
        l.addWidget(self.today, 1)
        self.b_tr.clicked.connect(self._tr_toggle)
        self.cb_cat.currentTextChanged.connect(self._ai_hint)
        self.sp_est.valueChanged.connect(self._ai_hint)
        root.addWidget(c, 1)

        self._t = QTimer(self); self._t.setInterval(100); self._t.timeout.connect(self._tick); self._t.start()

    def on_enter(self):
        cur = self.cb_cat.currentText()
        self.cb_cat.clear(); self.cb_cat.addItems(self.ctx.sched.categories)
        if cur:
            self.cb_cat.setCurrentText(cur)
        self._ai_hint(); self._today()

    # ---- stopwatch ----
    def _sw_elapsed(self):
        return self.sw_base + (time.monotonic() - self.sw_start if self.sw_start else 0)

    def _sw_toggle(self):
        if self.sw_start:
            self.sw_base = self._sw_elapsed(); self.sw_start = None; self.b_sw.setText("Resume")
        else:
            self.sw_start = time.monotonic(); self.b_sw.setText("Pause")

    def _sw_lap(self):
        e = self._sw_elapsed()
        if e > 0:
            prev = self.laps[-1] if self.laps else 0
            self.laps.append(e)
            self.lap_list.insertItem(0, f"Lap {len(self.laps)}   {fmt_hms(e, True)}   (+{fmt_hms(e - prev, True)})")

    def _sw_reset(self):
        self.sw_base, self.sw_start, self.laps = 0.0, None, []
        self.lap_list.clear(); self.b_sw.setText("Start")

    # ---- timer ----
    def _tm_set(self, sec):
        self.tm_total = self.tm_left = float(sec); self.tm_end = None
        self.b_tm.setText("Start"); self.lb_tm.setText(fmt_hms(sec)); self.ring_tm.set_value(1.0 if sec else 0.0)

    def _tm_toggle(self):
        if self.tm_end:
            self.tm_left = max(0, self.tm_end - time.monotonic()); self.tm_end = None; self.b_tm.setText("Resume")
        elif self.tm_left > 0:
            self.tm_end = time.monotonic() + self.tm_left; self.b_tm.setText("Pause")

    def _tm_reset(self):
        self._tm_set(self.tm_total)

    def _tm_done(self):
        self.tm_end = None; self.tm_left = 0; self.b_tm.setText("Start"); self.lb_tm.setText("00:00"); self.ring_tm.set_value(0.0)
        self.ctx.modes.notify("Timer finished", "Time is up!")
        self.ctx.speak("Time is up")
        self.ctx.lamp.tft_text("Timer", "Time is up!")

    # ---- timer from picture ----
    def _pic_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Choose a picture", "", "Pictures (*.png *.jpg *.jpeg *.bmp *.webp)")
        if path:
            img = cv2.imread(path)
            if img is None:
                self.lb_tm_note.setText("I could not open that picture.")
            else:
                self._read_pic(img)

    def _pic_lamp(self):
        self.lb_tm_note.setText("Taking a photo with the lamp...")
        run_async(self.ctx.lamp.photo, lambda res, err: self._read_pic(res[0]) if res else self.lb_tm_note.setText(str(err)))

    def _read_pic(self, img):
        self.lb_tm_note.setText("Reading the picture...")

        def done(text, err):
            if err:
                self.lb_tm_note.setText(f"Could not read it: {err}")
                return
            sec = parse_duration(text)
            if sec:
                self._tm_set(sec)
                self.lb_tm_note.setText(f'Read "{text[:60]}"  ->  timer set to {fmt_hms(sec)}.')
            else:
                self.lb_tm_note.setText(f'I read "{text[:80]}" but found no duration (try "25 min" or "1:30:00").')
        self.ctx.read_text_async(img, done, paragraph=False)

    # ---- tracker ----
    def _ai_hint(self, *_):
        cat, est = self.cb_cat.currentText().strip() or "Other", self.sp_est.value()
        if est:
            self.lb_ai.setText("AI estimate: " + self.ctx.sched.predict_minutes(cat, est)[1])
        else:
            self.lb_ai.setText("")

    def _tr_toggle(self):
        if self.tr_start is None:
            self.tr_start = time.monotonic()
            self.tr_info = (self.cb_cat.currentText().strip() or "Other", self.ed_title.text().strip() or "Untitled",
                            self.sp_est.value(), datetime.now())
            self.b_tr.setText("Stop and log"); self.b_tr.setProperty("variant", "danger")
        else:
            mins = (time.monotonic() - self.tr_start) / 60.0
            cat, title, est, started = self.tr_info
            self.ctx.sched.log_session(cat, title, est or mins, mins, start=started)
            self.tr_start = None
            self.b_tr.setText("Start tracking"); self.b_tr.setProperty("variant", "primary")
            self.lb_tr.setText("00:00"); self._today()
        st = self.b_tr.style(); st.unpolish(self.b_tr); st.polish(self.b_tr)

    def _today(self):
        self.today.clear()
        day = datetime.now().date().isoformat()
        tot = {}
        for h in self.ctx.sched.history:
            if h["when"].startswith(day):
                tot[h["category"]] = tot.get(h["category"], 0) + h["actual"]
        for cat, m in sorted(tot.items(), key=lambda kv: -kv[1]):
            self.today.addItem(f"{cat}:  {int(m // 60)}h {int(m % 60):02d}m" if m >= 60 else f"{cat}:  {int(m)} min")
        if not tot:
            self.today.addItem("Nothing logged yet today.")

    def _tick(self):
        if self.sw_start:
            self.lb_sw.setText(fmt_hms(self._sw_elapsed(), True))
        if self.tm_end:
            left = self.tm_end - time.monotonic()
            if left <= 0:
                self._tm_done()
            else:
                self.lb_tm.setText(fmt_hms(left + 0.99))
                self.ring_tm._value = left / max(1.0, self.tm_total); self.ring_tm.update()
        if self.tr_start is not None:
            self.lb_tr.setText(fmt_hms(time.monotonic() - self.tr_start))
