"""Smart Planner: weekly timetable + time-estimate manager + AI day plan (scikit-learn learns from your history)."""
from datetime import datetime

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QComboBox, QHBoxLayout, QHeaderView, QInputDialog, QLineEdit, QListWidget, QSpinBox,
                               QTableWidget, QTableWidgetItem, QVBoxLayout, QMessageBox)

from ...core.scheduler_ai import DAYS, hm, parse_hm
from ..theme import px
from ..widgets import label, make_button
from ..fx import InsightCard
from ._ui import vcard
from .base import Page


class PlannerPage(Page):
    key, title = "planner", "Smart Planner"

    def tft_units(self):
        from PySide6.QtCore import QRect
        ins = self.insight
        if not ins.isVisible():
            return None
        left = px(196)                                       # the graph starts right of the red boxes
        units = [self.tft_visible(*ins.stats), self.tft_visible((ins, QRect(left, 0, max(10, ins.width() - left), ins.height())))]
        return [u for u in units if u] or None

    def __init__(self, ctx):
        super().__init__(ctx)
        self.sch = ctx.sched
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(self.gap())
        self.insight = InsightCard()                       # the red graph picture, fed with your real minutes
        outer.addWidget(self.insight, 2)
        root = QHBoxLayout()
        root.setSpacing(self.gap())
        outer.addLayout(root, 5)

        # ---------------- timetable ----------------
        c, l = vcard("Weekly timetable", "Classes and fixed commitments. The planner never schedules over them.")
        self.grid = QTableWidget(14, 7)
        self.grid.setHorizontalHeaderLabels(DAYS)
        self.grid.setVerticalHeaderLabels([f"{h:02d}:00" for h in range(8, 22)])
        self.grid.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.grid.verticalHeader().setDefaultSectionSize(px(30))
        self.grid.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.grid.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        l.addWidget(self.grid, 1)
        r = QHBoxLayout()
        self.cb_day = QComboBox(); self.cb_day.addItems(DAYS); self.cb_day.setCurrentIndex(datetime.now().weekday())
        self.ed_s, self.ed_e, self.ed_t = QLineEdit("09:00"), QLineEdit("10:00"), QLineEdit()
        self.ed_s.setFixedWidth(px(80)); self.ed_e.setFixedWidth(px(80)); self.ed_t.setPlaceholderText("Class / activity")
        b_add = make_button("Add", "primary", "plus"); b_add.clicked.connect(self._add_block)
        for w in (self.cb_day, self.ed_s, self.ed_e, self.ed_t, b_add):
            r.addWidget(w)
        r.setStretch(3, 1)
        l.addLayout(r)
        self.blocks = QListWidget(); self.blocks.setMaximumHeight(px(120))
        l.addWidget(self.blocks)
        b_rm = make_button("Remove selected block", None, "trash"); b_rm.clicked.connect(self._rm_block)
        l.addWidget(b_rm)
        root.addWidget(c, 3)

        # ---------------- tasks + plan ----------------
        col = QVBoxLayout(); col.setSpacing(self.gap())
        c, l = vcard("Tasks & time estimates")
        self.ed_task = QLineEdit(); self.ed_task.setPlaceholderText("Task, e.g. Maths chapter 4")
        r = QHBoxLayout()
        self.cb_cat = QComboBox(); self.cb_cat.setEditable(True); self.cb_cat.setMinimumWidth(px(110))
        self.sp_est = QSpinBox(); self.sp_est.setRange(5, 600); self.sp_est.setValue(45); self.sp_est.setSuffix(" min")
        self.sp_est.setFixedWidth(px(92))
        self.sp_pri = QSpinBox(); self.sp_pri.setRange(1, 3); self.sp_pri.setValue(2); self.sp_pri.setPrefix("priority ")
        self.sp_pri.setFixedWidth(px(108))
        r.addWidget(self.cb_cat, 1)
        r.addWidget(self.sp_est, 0)
        r.addWidget(self.sp_pri, 0)
        self.lb_ai = label("", wrap=True); self.lb_ai.setStyleSheet("color:#7DE3FF; font-weight:600;")
        b_task = make_button("Add task", "primary", "plus"); b_task.clicked.connect(self._add_task)
        l.addWidget(self.ed_task); l.addLayout(r); l.addWidget(self.lb_ai); l.addWidget(b_task)
        self.tasks = QListWidget(); l.addWidget(self.tasks, 1)
        r = QHBoxLayout()
        b_done = make_button("Done - log real time", "green", "check"); b_done.clicked.connect(self._done)
        b_del = make_button("Delete", None, "trash"); b_del.clicked.connect(self._del_task)
        r.addWidget(b_done); r.addWidget(b_del)
        l.addLayout(r)
        col.addWidget(c, 3)
        self.cb_cat.currentTextChanged.connect(self._hint); self.sp_est.valueChanged.connect(self._hint)

        c, l = vcard("AI plan for today")
        self.lb_status = label("", "dim", wrap=True)
        b_plan = make_button("Build today's plan", "primary", "clock"); b_plan.clicked.connect(self._plan)
        self.plan = QListWidget()
        self.lb_best = label("", wrap=True)
        b_go = make_button("Start the selected block in Study mode", None, "play"); b_go.clicked.connect(self._start_block)
        for w in (self.lb_status, b_plan, self.plan, self.lb_best, b_go):
            l.addWidget(w)
        col.addWidget(c, 3)
        root.addLayout(col, 2)
        self._plan_blocks = []
        self._base_refresh = self._refresh
        self._refresh = lambda: (self._base_refresh(), self._refresh_insight())

    def _refresh_insight(self):
        from datetime import date, timedelta
        today = date.today()
        days = [today - timedelta(days=i) for i in range(6, -1, -1)]
        totals = {d: 0.0 for d in days}
        for h in self.sch.history:
            try:
                d = datetime.fromisoformat(h.get("when", "")).date()
            except ValueError:
                continue
            if d in totals:
                totals[d] += float(h.get("actual", 0))
        self.insight.set_data([totals[d] for d in days], [d.strftime("%a") for d in days], 6,
                              [int(totals[today]), len(self.sch.data.get("tasks", [])), len(self.sch.history)])

    def on_enter(self):
        cur = self.cb_cat.currentText()
        self.cb_cat.clear(); self.cb_cat.addItems(self.sch.categories)
        if cur:
            self.cb_cat.setCurrentText(cur)
        self._refresh()

    # ---- timetable ----
    def _add_block(self):
        try:
            s, e = parse_hm(self.ed_s.text()), parse_hm(self.ed_e.text())
        except ValueError:
            return QMessageBox.information(self, "Time", "Write times like 09:30.")
        if e <= s or not self.ed_t.text().strip():
            return QMessageBox.information(self, "Timetable", "Give a title and an end time after the start time.")
        self.sch.add_block(self.cb_day.currentIndex(), s, e, self.ed_t.text().strip())
        self.ed_t.clear(); self._refresh()

    def _rm_block(self):
        i = self.blocks.currentRow()
        if i >= 0:
            self.sch.remove_block(i); self._refresh()

    # ---- tasks ----
    def _hint(self, *_):
        cat = self.cb_cat.currentText().strip() or "Other"
        self.lb_ai.setText("AI: expect " + self.sch.predict_minutes(cat, self.sp_est.value())[1])

    def _add_task(self):
        if self.ed_task.text().strip():
            self.sch.add_task(self.ed_task.text().strip(), self.cb_cat.currentText().strip() or "Other",
                              self.sp_est.value(), self.sp_pri.value())
            self.ed_task.clear(); self._refresh()

    def _del_task(self):
        i = self.tasks.currentRow()
        if i >= 0:
            self.sch.remove_task(i); self._refresh()

    def _done(self):
        i = self.tasks.currentRow()
        if i < 0:
            return
        t = self.sch.data["tasks"][i]
        mins, ok = QInputDialog.getInt(self, "How long did it really take?", f'"{t["title"]}" took (minutes):',
                                       t["estimate"], 1, 900)
        if ok:
            focus, ok2 = QInputDialog.getInt(self, "Focus", "How focused were you? (0-100%)", 80, 0, 100)
            self.sch.log_session(t["category"], t["title"], t["estimate"], mins, focus=(focus if ok2 else 80) / 100.0)
            self.sch.remove_task(i); self._refresh()

    # ---- plan ----
    def _plan(self):
        now = datetime.now()
        self._plan_blocks = self.sch.plan(now, now.hour * 60 + now.minute)
        self.plan.clear()
        for b in self._plan_blocks:
            self.plan.addItem(f"{hm(b['start'])} - {hm(b['end'])}   {b['title']}   ({b['category']}, {b['minutes']} min, focus {int(b['focus'] * 100)}%)")
        if not self._plan_blocks:
            self.plan.addItem("Nothing to plan (no tasks, or no free time left today).")
        cat = self.cb_cat.currentText().strip() or "Study"
        self.lb_best.setText(f"Your best hours for {cat}: " + ", ".join(f"{h:02d}:00" for h in sorted(self.sch.best_hours(cat))))

    def _start_block(self):
        i = self.plan.currentRow()
        if 0 <= i < len(self._plan_blocks):
            self.ctx.set_mode("study", self._plan_blocks[i]["minutes"])
            self.ctx.go("modes")

    def _refresh(self):
        self.blocks.clear()
        for j, b in enumerate(self.sch.data["timetable"]):
            self.blocks.addItem(f"{DAYS[b['day']]}  {hm(b['start'])}-{hm(b['end'])}  {b['title']}")
        self.grid.clearContents()
        for b in self.sch.data["timetable"]:
            for h in range(max(8, b["start"] // 60), min(22, (b["end"] + 59) // 60)):
                it = QTableWidgetItem(b["title"])
                it.setBackground(Qt.GlobalColor.darkMagenta); it.setForeground(Qt.GlobalColor.white)
                self.grid.setItem(h - 8, b["day"], it)
        self.tasks.clear()
        for t in self.sch.data["tasks"]:
            m, _ = self.sch.predict_minutes(t["category"], t["estimate"])
            self.tasks.addItem(f"{t['title']}   [{t['category']}]   you said {t['estimate']} min  ->  AI {m} min")
        acc = self.sch.accuracy()
        self.lb_status.setText(self.sch.status() + (f"  Your estimates are off by {acc} min on average." if acc is not None else ""))
        self._hint()
