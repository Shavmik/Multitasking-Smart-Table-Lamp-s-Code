"""Osiris AI: chat assistant (OpenAI-compatible endpoint) and the Osiris dashboard inside the app."""
from PySide6.QtCore import QUrl
from PySide6.QtWidgets import (QCheckBox, QHBoxLayout, QLineEdit, QTabWidget, QTextEdit, QVBoxLayout, QWidget)

from ...core.osiris import DEFAULTS
from ..services import run_async
from ..theme import px
from ..widgets import label, make_button
from ._ui import vcard
from ..fx import FrameSprite
from .base import Page

try:
    from PySide6.QtWebEngineWidgets import QWebEngineView
    HAVE_WEB = True
except Exception:                                            # noqa: BLE001
    HAVE_WEB = False


class OsirisPage(Page):
    key, title = "osiris", "Osiris AI"

    def tft_units(self):
        return [self.tft_visible(self.eye), self.tft_visible(self.tft_top(self.log, px(170))),
                self.tft_visible(self.b_send, self.b_scan)]

    def __init__(self, ctx):
        super().__init__(ctx)
        self.o = ctx.osiris
        self.web = None
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        tabs = QTabWidget()
        self.tabs = tabs
        root.addWidget(tabs)

        # ---------------- assistant ----------------
        chat = QWidget(); cl = QHBoxLayout(chat); cl.setContentsMargins(0, px(8), 0, 0); cl.setSpacing(self.gap())
        c, l = vcard()
        self.log = QTextEdit(); self.log.setReadOnly(True)
        self.log.setPlaceholderText("Ask Osiris anything: how to plan your week, explain a topic, summarise scanned text...")
        l.addWidget(self.log, 1)
        row = QHBoxLayout()
        self.ed = QLineEdit(); self.ed.setPlaceholderText("Type a message and press Enter")
        self.b_send = make_button("Send", "primary", "play")
        row.addWidget(self.ed, 1); row.addWidget(self.b_send)
        l.addLayout(row)
        opts = QHBoxLayout()
        self.ck_day = QCheckBox("Share my timetable and tasks"); self.ck_say = QCheckBox("Read answers aloud")
        self.b_scan = make_button("Use last scanned text", None, "ocr")
        b_new = make_button("New chat", None, "reload")
        for w in (self.ck_day, self.ck_say, self.b_scan, b_new):
            opts.addWidget(w)
        opts.addStretch(1)
        l.addLayout(opts)
        cl.addWidget(c, 3)
        self.b_send.clicked.connect(self.send); self.ed.returnPressed.connect(self.send)
        self.b_scan.clicked.connect(lambda: self.ed.setText(("Explain this text: " + (ctx.last_text or ctx.pending_text))[:1500]))
        b_new.clicked.connect(lambda: (self.o.reset(), self.log.clear()))

        c, l = vcard("Connection", "Any OpenAI-compatible server works: Ollama, LM Studio or an Osiris backend.")
        eye = self.eye = FrameSprite("eye", fps=10, radius=20, pingpong=True, scan=True); eye.setMinimumHeight(px(200))
        l.insertWidget(0, eye)
        self.f = {}
        for key, name in [("osiris_api", "API address"), ("osiris_model", "Model name"), ("osiris_key", "API key (optional)"),
                          ("osiris_url", "Dashboard address")]:
            l.addWidget(label(name, "h3"))
            e = QLineEdit(str(ctx.prefs.get(key, DEFAULTS[key])))
            if key == "osiris_key":
                e.setEchoMode(QLineEdit.EchoMode.Password)
            l.addWidget(e); self.f[key] = e
        b_save = make_button("Save and test", "primary", "check"); b_save.clicked.connect(self.save)
        b_to_dash = make_button("No local AI? Open the Dashboard tab", None, "globe")
        b_to_dash.clicked.connect(lambda: tabs.setCurrentIndex(1))
        self.lb = label("", "dim", wrap=True)
        l.addWidget(b_save); l.addWidget(self.lb); l.addWidget(b_to_dash); l.addStretch(1)
        c.setMaximumWidth(px(360))
        cl.addWidget(c, 1)
        tabs.addTab(chat, "Assistant")

        # ---------------- dashboard ----------------
        self.dash = QWidget(); self.dl = QVBoxLayout(self.dash); self.dl.setContentsMargins(0, px(8), 0, 0)
        self.dl.addWidget(label("Open any AI web app right here - just like the College ERP page.", "h3"))
        self.dl.addWidget(label("Works with a locally-running Osiris web app (e.g. `npm run dev`, default "
                                "http://localhost:3000), or with any AI website you have access to - set the "
                                "Dashboard address below, under Connection, and load it.", "dim", wrap=True))
        row_d = QHBoxLayout()
        self.b_dash = make_button("Load in app", "primary", "globe"); self.b_dash.clicked.connect(self.load_dash)
        self.b_dash_ext = make_button("Open in browser instead", None, "globe"); self.b_dash_ext.clicked.connect(self.open_dash_browser)
        row_d.addWidget(self.b_dash); row_d.addWidget(self.b_dash_ext); row_d.addStretch(1)
        self.dl.addLayout(row_d)
        self.lb_dash_err = label("", "dim", wrap=True)
        self.dl.addWidget(self.lb_dash_err)
        self.dl.addStretch(1)
        tabs.addTab(self.dash, "Dashboard")

    def on_enter(self):
        run_async(self.o.ping, lambda res, err: self.lb.setText(res[1] if res else str(err)))

    def save(self):
        for k, e in self.f.items():
            self.ctx.prefs.set(k, e.text().strip())
        self.on_enter()

    def send(self):
        text = self.ed.text().strip()
        if not text:
            return
        self.ed.clear(); self.b_send.setEnabled(False)
        self.log.append(f"<p><b>You:</b> {text}</p>")
        ctxt = self.ctx.sched.summary_for_ai() if self.ck_day.isChecked() else ""
        run_async(lambda: self.o.ask(text, ctxt), self._reply)

    def _reply(self, res, err):
        self.b_send.setEnabled(True)
        if err:
            self.log.append(f"<p style='color:#FF7A7F'>{err}</p>")
            return
        self.log.append(f"<p><b>Osiris:</b> {res}</p>")
        if self.ck_say.isChecked():
            self.ctx.speak(res)

    def load_dash(self):
        url = self.o.cfg("osiris_url")
        if not HAVE_WEB:
            self.lb_dash_err.setText("This build has no embedded browser - opening in your default browser instead.")
            return self.open_dash_browser()
        if self.web is None:
            self.web = QWebEngineView()
            self.web.loadFinished.connect(self._dash_loaded)
            self.dl.insertWidget(2, self.web, 1)
        self.lb_dash_err.setText(f"Loading {url} ...")
        self.web.setUrl(QUrl(url))

    def _dash_loaded(self, ok):
        if ok:
            self.lb_dash_err.setText("")
        else:
            self.lb_dash_err.setText(f"Could not load {self.o.cfg('osiris_url')} here (the site may block "
                                     "being embedded, or it isn't running). Try 'Open in browser instead'.")

    def open_dash_browser(self):
        import webbrowser
        webbrowser.open(self.o.cfg("osiris_url"))
