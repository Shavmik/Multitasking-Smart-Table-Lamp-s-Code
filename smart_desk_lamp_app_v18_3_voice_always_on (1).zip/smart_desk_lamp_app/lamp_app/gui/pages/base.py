from PySide6.QtWidgets import QWidget

from ..theme import px


class Page(QWidget):
    key = "page"
    title = "Page"
    uses_camera = False
    tft_ink = None            # the drawing widget of the page (gets instant pen lines on the TFT)

    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self._cam = None
        self._frame_cb = None
        self.last_frame = None

    # ---- camera plumbing shared by every camera page ----
    def bind_camera(self, view, on_frame=None):
        self._cam, self._frame_cb = view, on_frame
        lamp = self.ctx.lamp
        lamp.frame.connect(self._frame_in)
        lamp.camera_state.connect(self._cam_problem)
        lamp.status.connect(lambda *_: self._cam_idle())
        self._cam_idle()

    def _frame_in(self, img):
        if not self.isVisible() or self._cam is None:
            return
        self.last_frame = img
        self._cam.set_frame(img)
        if self._frame_cb:
            self._frame_cb(img)

    def _cam_idle(self):
        if self._cam is None or self._cam._frame is not None:
            return
        if not self.ctx.lamp.connected and not self.ctx.lamp.has_camera:
            self._cam.set_message("The lamp is not connected.\nPlug it in and press Connect in Settings.")
        elif not self.ctx.lamp.connected:
            self._cam.set_message("The lamp is not connected.\nStarting the laptop camera...")
        else:
            self._cam.set_message("Waiting for the camera...")

    def _cam_problem(self, msg):
        if self._cam is not None and msg:
            self._cam.clear(msg)

    def on_enter(self):
        if self.uses_camera:
            self.ctx.lamp.acquire(self)
            self._cam_idle()

    def on_leave(self):
        if self.uses_camera:
            self.ctx.lamp.release(self)

    # ---- lamp touchscreen (every page is drawn on the lamp's TFT) ----
    # tft_names lists the main controls of the page, in reading order. Each entry is
    #     "attr"              one control (it may be moved to any row), or
    #     ("a", "b", "c")     controls that must stay side by side in one row.
    # The controls are cut out one by one and re-flowed into rows that fill the 320x240 screen
    # (see tftlayout.py), so a wide strip of buttons is no longer shrunk into a thin unreadable line.
    tft_names = ()

    def tft_units(self):
        """List of units; a unit = list of (widget, QRect-in-that-widget or None) shown side by side.
        None = no TFT view defined: the whole page is drawn."""
        units = []
        for entry in self.tft_names:
            names = entry if isinstance(entry, (tuple, list)) else (entry,)
            unit = []
            for n in names:
                w = self.tft_widget(n)
                if w is not None and w.isVisible() and w.width() > 4 and w.height() > 4:
                    unit.append((w, None))
            if unit:
                units.append(unit)
        return units or None

    def tft_widget(self, name):
        """Widget for an attribute name; dots reach inside other widgets ("panel.edit")."""
        w = self
        for part in name.split("."):
            w = getattr(w, part, None)
            if w is None:
                return None
        return w

    def tft_rect(self):
        """Fallback when a page has no tft_names: the whole page."""
        return self.rect()

    def tft_top(self, widget, height_px):
        """(widget, rect) showing only the top part of a tall text box (the TFT is small)."""
        from PySide6.QtCore import QRect
        return (widget, QRect(0, 0, widget.width(), min(widget.height(), height_px)))

    @staticmethod
    def tft_visible(*items):
        """A unit from widgets / (widget, rect) pairs, keeping only the ones that are on screen."""
        unit = []
        for it in items:
            w, r = it if isinstance(it, tuple) else (it, None)
            if w is not None and w.isVisible() and w.width() > 4 and w.height() > 4:
                unit.append((w, r))
        return unit

    def tft_theme_toggle(self):
        """The light/dark switch of the top bar (can be shown on the TFT next to a page's controls)."""
        return getattr(self.window(), "t_theme", None)

    def tft_touch_began(self):
        """A finger just touched the TFT. Return True if the page used the touch itself."""
        return False

    def tft_clock(self):
        """Optional fastest-of-all path: return the current time as a short string (e.g.
        '14:32:07') to have the lamp show it as big white digits on black, repainted IN PLACE
        every tick - no screenshot, no JPEG, not even a full-screen redraw, just the digit box.
        Return None (the default) outside of a clock page."""
        return None

    def tft_native(self):
        """Optional fast path. Return (title, buttons) to have the lamp draw a native, instantly
        updating menu of colour button boxes (see core/nativemenu.py) instead of screenshotting
        and shrinking the page's pixels into a JPEG. Each button needs x, y, w, h, label, fill,
        fg and an on_tap() callable. Return None (the default) to use the normal pixel mirror."""
        return None

    @staticmethod
    def gap():
        return px(16)
