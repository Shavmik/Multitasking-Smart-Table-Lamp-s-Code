"""ERP: the whole https://erp.psit.ac.in/ site, loaded inside the app with Chromium (Qt WebEngine).
Logins are kept between sessions, downloads go to your Downloads folder, links stay inside the app."""
import os

from PySide6.QtCore import QRect, QStandardPaths, QTimer, QUrl
from PySide6.QtWidgets import QHBoxLayout, QLineEdit, QProgressBar, QVBoxLayout

from ... import config
from ..theme import px
from ..widgets import GlassCard, IconButton, label, make_button
from .base import Page

try:
    from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile, QWebEngineSettings
    from PySide6.QtWebEngineWidgets import QWebEngineView
    HAVE_WEB = True
except Exception:                                        # noqa: BLE001
    HAVE_WEB = False


if HAVE_WEB:
    class _Page(QWebEnginePage):
        def createWindow(self, kind):
            """target=_blank links / pop-ups open in the same view instead of a stray window."""
            tmp = QWebEnginePage(self.profile(), self)

            def redirect(url):
                if not url.isEmpty():
                    self.setUrl(url)
                    tmp.deleteLater()
            tmp.urlChanged.connect(redirect)
            return tmp


# finds the login form (logo + user id + password + Sign in) so the lamp screen can show just that part
_FORM_JS = """(function(){var p=document.querySelector('input[type=password]'); if(!p) return null;
var f=p.closest('form')||p.parentElement.parentElement||p; var r=f.getBoundingClientRect();
var top=Math.max(0, r.top-110); return [Math.max(0,r.left-16), top, r.width+32, r.bottom-top+12];})()"""


class ErpPage(Page):
    key, title = "erp", "ERP"
    tft_crop = None                      # QRect (in view pixels) of the login form, found by _FORM_JS

    def tft_units(self):
        """Back / reload / home + the part of the site worth seeing on the small screen (the login form when there is one)."""
        if self.view is None or not self.view.isVisible():
            return None
        vw, vh = self.view.width(), self.view.height()
        r = self.tft_crop
        if r is None or r.width() < 40 or r.height() < 40:
            r = QRect(0, 0, min(vw, 700), min(vh, 520))      # no form on this page: top-left of the page
        return [self.tft_visible(self.b_back, self.b_reload, self.b_home), self.tft_visible((self.view, r.intersected(self.view.rect())))]

    def _find_form(self):
        if self.view is None or not self.view.isVisible():
            return

        def got(res):
            if res and len(res) == 4:
                z = self.view.zoomFactor()
                self.tft_crop = QRect(int(res[0] * z), int(res[1] * z), int(res[2] * z), int(res[3] * z))
            else:
                self.tft_crop = None
        self.view.page().runJavaScript(_FORM_JS, got)

    def __init__(self, ctx):
        super().__init__(ctx)
        self.view = None
        self._loaded = False
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(px(10))

        bar = GlassCard(radius=18)
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(px(12), px(8), px(12), px(8))
        bl.setSpacing(px(8))
        self.b_back = IconButton("back", "Back", 42)
        self.b_fwd = IconButton("forward", "Forward", 42)
        self.b_reload = IconButton("reload", "Reload", 42)
        self.b_home = IconButton("home", "ERP home page", 42)
        for b in (self.b_back, self.b_fwd, self.b_reload, self.b_home):
            bl.addWidget(b)
        self.url = QLineEdit()
        self.url.setPlaceholderText("Address")
        bl.addWidget(self.url, 1)
        self.b_zm = IconButton("minus", "Zoom out", 42)
        self.b_zp = IconButton("plus", "Zoom in", 42)
        self.b_ext = IconButton("open", "Open this page in your normal browser", 42)
        for b in (self.b_zm, self.b_zp, self.b_ext):
            bl.addWidget(b)
        root.addWidget(bar)
        self.progress = QProgressBar()
        self.progress.setTextVisible(False)
        self.progress.setRange(0, 100)
        self.progress.setFixedHeight(px(4))
        root.addWidget(self.progress)
        self.holder = QVBoxLayout()
        root.addLayout(self.holder, 1)
        self.msg = label("", "dim", wrap=True)
        root.addWidget(self.msg)

        if not HAVE_WEB:
            self.msg.setText("The built-in web view is not installed.  Run:  pip install PySide6   (it includes Qt WebEngine)\n"
                             "Until then the ERP opens in your normal browser.")
            for b in (self.b_back, self.b_fwd, self.b_reload, self.b_zm, self.b_zp):
                b.setEnabled(False)
            fallback = make_button("Open the ERP in my browser", "primary", "globe")
            fallback.clicked.connect(self._external_home)
            self.holder.addStretch(1)
            self.holder.addWidget(fallback)
            self.holder.addStretch(1)
        self.b_home.clicked.connect(self.home)
        self.b_ext.clicked.connect(self._external)
        self.url.returnPressed.connect(self._go)

    # ---- lazy start: the browser engine is only created when the page is first opened ----
    def _build_view(self):
        base = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppDataLocation)
        self.profile = QWebEngineProfile("smartdesklamp_erp", self)
        self.profile.setPersistentStoragePath(os.path.join(base, "erp_profile"))
        self.profile.setCachePath(os.path.join(base, "erp_cache"))
        self.profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies)
        self.profile.downloadRequested.connect(self._download)
        page = _Page(self.profile, self)
        self.view = QWebEngineView(self)
        self.view.setPage(page)
        self.view.setStyleSheet("background: #ffffff; border-radius: 12px;")
        self.view.page().settings().setAttribute(QWebEngineSettings.WebAttribute.FullScreenSupportEnabled, True)
        self.view.page().fullScreenRequested.connect(lambda req: req.accept())
        self.holder.addWidget(self.view, 1)
        self.view.urlChanged.connect(lambda u: self.url.setText(u.toString()))
        self.view.loadProgress.connect(self.progress.setValue)
        self.view.loadFinished.connect(self._finished)
        self._form_timer = QTimer(self)
        self._form_timer.setInterval(1500)
        self._form_timer.timeout.connect(self._find_form)
        self._form_timer.start()
        self.b_back.clicked.connect(self.view.back)
        self.b_fwd.clicked.connect(self.view.forward)
        self.b_reload.clicked.connect(self.view.reload)
        self.b_zp.clicked.connect(lambda: self.view.setZoomFactor(min(3.0, self.view.zoomFactor() + 0.1)))
        self.b_zm.clicked.connect(lambda: self.view.setZoomFactor(max(0.4, self.view.zoomFactor() - 0.1)))

    def on_enter(self):
        if HAVE_WEB and self.view is None:
            self._build_view()
        if HAVE_WEB and not self._loaded:
            self._loaded = True
            self.home()

    def home(self):
        if self.view is not None:
            self.msg.setText("")
            self.view.setUrl(QUrl(config.ERP_URL))
        else:
            self._external_home()

    def _go(self):
        t = self.url.text().strip()
        if not t or self.view is None:
            return
        if "://" not in t:
            t = "https://" + t
        self.view.setUrl(QUrl(t))

    def _finished(self, ok):
        self.progress.setValue(100 if ok else 0)
        if not ok:
            self.msg.setText("The page could not be loaded. Check the internet connection (or the college server) and press Reload.")
        else:
            self.msg.setText("")

    def _download(self, item):
        folder = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DownloadLocation)
        item.setDownloadDirectory(folder)
        item.accept()
        name = item.downloadFileName()
        self.msg.setText(f"Downloading {name} to your Downloads folder...")
        item.isFinishedChanged.connect(lambda: self.msg.setText(f"Saved {name} in Downloads"))

    def _external(self):
        import webbrowser
        webbrowser.open(self.url.text().strip() or config.ERP_URL)

    def _external_home(self):
        import webbrowser
        webbrowser.open(config.ERP_URL)
