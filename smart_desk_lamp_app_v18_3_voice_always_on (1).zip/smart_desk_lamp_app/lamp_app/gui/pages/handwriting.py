"""Handwriting: write with the mouse, a pen or a finger; EasyOCR reads it (sums are solved)."""
import re
import time

from PySide6.QtCore import Qt, QPointF, QRectF, Signal
from PySide6.QtGui import QColor, QImage, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QHBoxLayout, QSizePolicy, QVBoxLayout, QWidget

import cv2

from ...features.calculator import fmt, safe_eval
from ..imgutil import qimage_to_bgr
from ..theme import px
from ..widgets import AA, GlassCard, label, make_button, rounded
from .base import Page
from .textpanel import TextPanel


class InkCanvas(QWidget):
    changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.strokes = []                     # each stroke = list of (x/width, y/height)
        self._cur = None
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMinimumSize(px(360), px(240))
        self.setCursor(Qt.CursorShape.CrossCursor)

    # ---- drawing ----
    def _pt(self, e):
        pos = e.position()
        return (min(max(pos.x() / max(1, self.width()), 0.0), 1.0), min(max(pos.y() / max(1, self.height()), 0.0), 1.0))

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._cur = [self._pt(e)]
            self.strokes.append(self._cur)
            self.update()

    def mouseMoveEvent(self, e):
        if self._cur is not None:
            self._cur.append(self._pt(e))
            self.update()

    def mouseReleaseEvent(self, e):
        if self._cur is not None:
            self._cur = None
            self.changed.emit()

    def undo(self):
        if self.strokes:
            self.strokes.pop()
            self.update()
            self.changed.emit()

    def clear(self):
        self.strokes.clear()
        self.update()
        self.changed.emit()

    def _draw_strokes(self, p, w, h, pen_w):
        pen = QPen(QColor(15, 15, 25), pen_w, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        for s in self.strokes:
            pts = [QPointF(x * w, y * h) for x, y in s]
            if len(pts) == 1:
                p.drawPoint(pts[0])
                continue
            path = QPainterPath(pts[0])
            for a, b in zip(pts, pts[1:]):
                path.quadTo(a, (a + b) / 2)
            path.lineTo(pts[-1])
            p.drawPath(path)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(.5, .5, -.5, -.5)
        card = rounded(r, px(20))
        p.fillPath(card, QColor(250, 250, 252))
        p.save()
        p.setClipPath(card)
        p.setPen(QPen(QColor(190, 200, 225), 1))
        step = px(54)
        y = step
        while y < self.height():
            p.drawLine(0, y, self.width(), y)
            y += step
        p.restore()
        if not self.strokes:
            p.setPen(QColor(150, 150, 170))
            p.drawText(r, int(Qt.AlignmentFlag.AlignCenter), "Write here with the mouse, a pen or your finger")
        self._draw_strokes(p, self.width(), self.height(), px(6))

    def render_image(self, width=1600):
        w = width
        h = max(1, int(width * self.height() / max(1, self.width())))
        img = QImage(w, h, QImage.Format.Format_RGB32)
        img.fill(QColor(255, 255, 255))
        p = QPainter(img)
        p.setRenderHint(AA)
        self._draw_strokes(p, w, h, w * px(6) / max(1, self.width()))
        p.end()
        return img


class HandwritingPage(Page):
    key, title = "hand", "Handwriting"

    def __init__(self, ctx):
        super().__init__(ctx)
        self._result_until = 0.0
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(self.gap())
        left = QVBoxLayout()
        left.setSpacing(px(12))
        self.canvas = InkCanvas()
        self.tft_ink = self.canvas
        left.addWidget(self.canvas, 1)
        row = QHBoxLayout()
        self.b_read = make_button("Read my writing", "primary", "ocr")
        self.b_read.setMinimumHeight(px(54))
        self.b_undo = make_button("Undo", None, "back")
        self.b_clear = make_button("Clear", None, "trash")
        for b in (self.b_undo, self.b_clear):
            b.setMinimumHeight(px(54))
        row.addWidget(self.b_read, 2)
        row.addWidget(self.b_undo, 1)
        row.addWidget(self.b_clear, 1)
        left.addLayout(row)
        left.addWidget(label("Write big, with thick clear letters. A sum such as 12+7*3 is solved for you.", "dim", wrap=True))
        root.addLayout(left, 5)
        self.panel = TextPanel(ctx, "What you wrote", "Handwriting")
        root.addWidget(self.panel, 4)

        self.b_read.clicked.connect(self.read)
        self.b_undo.clicked.connect(self.canvas.undo)
        self.b_clear.clicked.connect(self.canvas.clear)
        ctx.ocr_state_changed.connect(lambda s, m: self.panel.say(m, s == "error") if s in ("loading", "error") else None)

    def on_enter(self):
        self.ctx.warm_ocr()

    # ---- lamp touchscreen: show the writing area + buttons; after reading, show the result for a few seconds ----
    def tft_units(self):
        if time.time() < self._result_until:
            return self.tft_visible(self.panel) and [self.tft_visible(self.panel)]
        return [self.tft_visible(self.canvas), self.tft_visible(self.b_read, self.b_undo, self.b_clear)]

    def tft_touch_began(self):
        if time.time() < self._result_until:      # a tap on the result goes back to the writing area
            self._result_until = 0.0
            return True
        return False

    def read(self):
        if not self.canvas.strokes:
            self.panel.say("Write something first.", True)
            return
        gray = cv2.cvtColor(qimage_to_bgr(self.canvas.render_image()), cv2.COLOR_BGR2GRAY)
        gray = cv2.copyMakeBorder(gray, 40, 40, 40, 40, cv2.BORDER_CONSTANT, value=255)
        img = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
        self.b_read.setEnabled(False)
        self.panel.say("Reading your handwriting...")
        self.ctx.read_text_async(img, self._done, paragraph=False)

    def _done(self, text, err):
        self.b_read.setEnabled(True)
        if err or not text:
            self.panel.say("Nothing read. Write bigger, with thick clear letters, then try again." if not err else str(err), True)
            return
        if re.fullmatch(r"[0-9\s+\-*/().^xX=]+", text):               # looks like a sum? solve it
            try:
                expr = text.rstrip("= ")
                text = f"{expr} = {fmt(safe_eval(expr))}"
            except Exception:
                pass
        print(f"\n----- Handwriting -----\n{text}\n{'-' * 22}")
        self.panel.set_text(text)
        self.panel.say("Done")
        self._result_until = time.time() + 8      # the lamp screen shows the result for 8 s (tap = back)
