"""Spotify: opens the desktop app (or the web player) and controls it with the media keys."""
from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import QHBoxLayout, QLineEdit, QVBoxLayout, QWidget

from ...core.spotify import media_keys_supported, open_spotify, press_media_key
from ..icons import art_pixmap
from ..theme import px
from ..widgets import AA, SMOOTH, GlassCard, IconButton, label, make_button
from .base import Page


class _Backdrop(QWidget):
    """The wall of music players, dimmed, behind the page."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._cache = (None, None)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA); p.setRenderHint(SMOOTH)
        src = art_pixmap("art_musicwall.jpg")
        dpr = self.devicePixelRatioF()
        key = (self.width(), self.height(), dpr)
        if self._cache[0] != key:
            pm = src.scaled(int(self.width() * dpr), int(self.height() * dpr), Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                            Qt.TransformationMode.SmoothTransformation)
            pm.setDevicePixelRatio(dpr)
            self._cache = (key, pm)
        pm = self._cache[1]
        sz = pm.size() / dpr
        p.setOpacity(0.38)
        p.drawPixmap(QPointF((self.width() - sz.width()) / 2, (self.height() - sz.height()) / 2), pm)
        p.setOpacity(1.0)
        p.fillRect(self.rect(), QColor(10, 8, 24, 110))


class SpotifyPage(Page):
    key, title = "spotify", "Spotify"
    tft_names = (('b_prev', 'b_play', 'b_next'), ('b_vd', 'b_mute', 'b_vu'))

    def __init__(self, ctx):
        super().__init__(ctx)
        self.back = _Backdrop(self)
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(self.gap())

        # ---- open ----
        left = GlassCard(strength=1.6)
        ll = QVBoxLayout(left)
        m = px(26)
        ll.setContentsMargins(m, m, m, m)
        ll.setSpacing(px(12))
        self.logo = label("", align=Qt.AlignmentFlag.AlignCenter)
        ll.addWidget(self.logo, 3)
        ll.addWidget(label("Spotify", "h1", align=Qt.AlignmentFlag.AlignCenter))
        self.b_app = make_button("Open the Spotify app", "green", "music")
        self.b_app.setMinimumHeight(px(60))
        self.b_web = make_button("Open the web player", None, "globe")
        ll.addWidget(self.b_app)
        ll.addWidget(self.b_web)
        sr = QHBoxLayout()
        self.q = QLineEdit()
        self.q.setPlaceholderText("Search a song, artist or podcast...")
        self.b_search = make_button("Search", None, "search")
        sr.addWidget(self.q, 1)
        sr.addWidget(self.b_search)
        ll.addLayout(sr)
        self.status = label("", "dim", wrap=True)
        ll.addWidget(self.status)
        root.addWidget(left, 2)

        # ---- remote ----
        right = GlassCard(strength=1.6)
        rl = QVBoxLayout(right)
        rl.setContentsMargins(m, m, m, m)
        rl.setSpacing(px(16))
        rl.addWidget(label("Remote control", "h2"))
        rl.addWidget(label("Controls whatever Spotify is playing on this PC, even when this app is in front.", "dim", wrap=True))
        rl.addStretch(1)
        tr = QHBoxLayout()
        tr.addStretch(1)
        self.b_prev = IconButton("prev", "Previous song", 72)
        self.b_play = IconButton("playpause", "Play / pause", 104, filled=True)
        self.b_next = IconButton("next", "Next song", 72)
        for b in (self.b_prev, self.b_play, self.b_next):
            tr.addWidget(b)
            tr.addSpacing(px(14))
        tr.addStretch(1)
        rl.addLayout(tr)
        vr = QHBoxLayout()
        vr.addStretch(1)
        self.b_vd = IconButton("voldown", "Volume down", 56)
        self.b_mute = IconButton("mute", "Mute", 56)
        self.b_vu = IconButton("volup", "Volume up", 56)
        for b in (self.b_vd, self.b_mute, self.b_vu):
            vr.addWidget(b)
            vr.addSpacing(px(10))
        vr.addStretch(1)
        rl.addLayout(vr)
        rl.addStretch(1)
        self.note = label("" if media_keys_supported() else "The remote buttons work on Windows only.", "dim", wrap=True)
        rl.addWidget(self.note)
        root.addWidget(right, 2)

        self.b_app.clicked.connect(lambda: self._open())
        self.b_web.clicked.connect(self._web)
        self.b_search.clicked.connect(lambda: self._open(self.q.text().strip() or None))
        self.q.returnPressed.connect(lambda: self._open(self.q.text().strip() or None))
        for b, k in ((self.b_prev, "prev"), (self.b_play, "playpause"), (self.b_next, "next"),
                     (self.b_vd, "voldown"), (self.b_mute, "mute"), (self.b_vu, "volup")):
            b.clicked.connect(lambda _=False, key=k: self._key(key))
            b.setEnabled(media_keys_supported())

    def resizeEvent(self, e):
        self.back.setGeometry(self.rect())
        self.back.lower()
        side = max(px(120), min(int(self.height() * 0.38), int(self.width() * 0.2)))
        dpr = self.devicePixelRatioF()
        pm = art_pixmap("art_spotify.png").scaled(int(side * dpr), int(side * dpr), Qt.AspectRatioMode.KeepAspectRatio,
                                                  Qt.TransformationMode.SmoothTransformation)
        pm.setDevicePixelRatio(dpr)
        self.logo.setPixmap(pm)
        super().resizeEvent(e)

    def _open(self, query=None):
        how = open_spotify(query)
        if how == "app":
            self.status.setText("Opened the Spotify app" + (f" and searched for \"{query}\"." if query else "."))
        else:
            self.status.setText("The Spotify app was not found, so the web player was opened in your browser.")

    def _web(self):
        import webbrowser
        webbrowser.open("https://open.spotify.com/")
        self.status.setText("Opened the web player in your browser.")

    def _key(self, name):
        if not press_media_key(name):
            self.status.setText("Media keys are not available on this system.")
