"""Panel used by Read text, Handwriting and QR: edit the text, read it aloud, translate it, search, save."""
import webbrowser

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QHBoxLayout, QLabel, QTextEdit,
                               QVBoxLayout)

from ...core.textflow import google_url, save_note
from ...core.translate import LANGUAGES, TranslateError, translate
from .. import theme
from ..services import run_async
from ..theme import px
from ..widgets import GlassCard, label, make_button


class TextPanel(GlassCard):
    def __init__(self, ctx, title="Recognised text", source="Text", placeholder="", parent=None):
        super().__init__(parent)
        self.ctx, self.source = ctx, source
        self._seq = 0
        lay = QVBoxLayout(self)
        m = px(18)
        lay.setContentsMargins(m, m, m, m)
        lay.setSpacing(px(10))

        head = QHBoxLayout()
        head.addWidget(label(title, "h2"))
        head.addStretch(1)
        self.status = label("", "dim")
        head.addWidget(self.status)
        lay.addLayout(head)

        self.edit = QTextEdit()
        self.edit.setAcceptRichText(False)
        self.edit.setPlaceholderText(placeholder or "The text will appear here. You can correct it before reading or translating.")
        self.edit.setMinimumHeight(px(120))
        self._set_edit_px(ctx.prefs.get("text_px", 22))
        lay.addWidget(self.edit, 3)

        row = QHBoxLayout()
        self.b_speak = make_button("Read aloud", "primary", "speaker")
        self.b_stop = make_button("Stop", None, "stop")
        self.b_stop.setEnabled(False)
        b_minus = make_button("A-", tooltip="Smaller text")
        b_plus = make_button("A+", tooltip="Bigger text")
        for b in (b_minus, b_plus):
            b.setFixedWidth(px(56))
        row.addWidget(self.b_speak); row.addWidget(self.b_stop); row.addStretch(1)
        row.addWidget(b_minus); row.addWidget(b_plus)
        lay.addLayout(row)

        row2 = QHBoxLayout()
        self.b_search = make_button("Search", None, "search")
        self.b_copy = make_button("Copy", None, "copy")
        self.b_save = make_button("Save note", None, "save")
        for b in (self.b_search, self.b_copy, self.b_save):
            row2.addWidget(b)
        row2.addStretch(1)
        self.extra_row = QHBoxLayout()
        row2.addLayout(self.extra_row)
        lay.addLayout(row2)

        tr = QHBoxLayout()
        tr.addWidget(label("Translate to", "h3"))
        self.lang = QComboBox()
        for name, code in LANGUAGES.items():
            self.lang.addItem(name, code)
        saved = ctx.prefs.get("target_lang", "hi")
        i = self.lang.findData(saved)
        self.lang.setCurrentIndex(max(0, i))
        tr.addWidget(self.lang, 1)
        self.b_tr = make_button("Translate", "orange", "translate")
        tr.addWidget(self.b_tr)
        lay.addLayout(tr)

        self.out = QTextEdit()
        self.out.setReadOnly(True)
        self.out.setPlaceholderText("The translation appears here (and in the terminal).")
        self.out.setMinimumHeight(px(90))
        self._set_out_px(ctx.prefs.get("text_px", 22))
        lay.addWidget(self.out, 2)

        row3 = QHBoxLayout()
        self.b_speak_tr = make_button("Read translation", None, "speaker")
        self.b_speak_tr.setToolTip("Needs a Windows voice for that language\n(Settings > Time & language > Speech)")
        self.b_copy_tr = make_button("Copy translation", None, "copy")
        row3.addWidget(self.b_speak_tr); row3.addWidget(self.b_copy_tr); row3.addStretch(1)
        lay.addLayout(row3)

        opts = QHBoxLayout()
        self.chk_read = QCheckBox("Read aloud automatically")
        self.chk_read.setToolTip("Low-vision mode: new text is spoken as soon as it is found")
        self.chk_tr = QCheckBox("Translate automatically")
        self.chk_read.setChecked(ctx.prefs.get("auto_read", False))
        self.chk_tr.setChecked(ctx.prefs.get("auto_translate", False))
        opts.addWidget(self.chk_read); opts.addWidget(self.chk_tr); opts.addStretch(1)
        lay.addLayout(opts)

        self.b_speak.clicked.connect(self.speak)
        self.b_stop.clicked.connect(ctx.stop_speaking)
        b_minus.clicked.connect(lambda: self._bump(-2))
        b_plus.clicked.connect(lambda: self._bump(2))
        self.b_search.clicked.connect(self.search)
        self.b_copy.clicked.connect(lambda: self._copy(self.edit.toPlainText()))
        self.b_save.clicked.connect(self.save)
        self.b_tr.clicked.connect(self.translate)
        self.b_speak_tr.clicked.connect(lambda: self._speak_text(self.out.toPlainText()))
        self.b_copy_tr.clicked.connect(lambda: self._copy(self.out.toPlainText()))
        self.lang.currentIndexChanged.connect(lambda _: ctx.prefs.set("target_lang", self.lang.currentData()))
        self.chk_read.toggled.connect(lambda v: ctx.prefs.set("auto_read", bool(v)))
        self.chk_tr.toggled.connect(lambda v: ctx.prefs.set("auto_translate", bool(v)))
        ctx.speech_state.connect(self._speech_changed)

    # ---- text size ----
    def _set_edit_px(self, n):
        self.edit.setStyleSheet(f"font-size: {px(n)}px;")

    def _set_out_px(self, n):
        self.out.setStyleSheet(f"font-size: {px(n)}px;")

    def _bump(self, d):
        n = max(12, min(64, self.ctx.prefs.get("text_px", 22) + d))
        self.ctx.prefs.set("text_px", n)
        self._set_edit_px(n)
        self._set_out_px(n)

    # ---- API for pages ----
    def text(self):
        return self.edit.toPlainText().strip()

    def set_text(self, text, auto=True):
        self.edit.setPlainText(text)
        self.out.clear()
        self.ctx.last_text = text
        if text.strip() and auto:
            if self.chk_tr.isChecked():
                self.translate()
            if self.chk_read.isChecked():
                self.speak()

    def say(self, msg, bad=False):
        self.status.setObjectName("status_bad" if bad else "dim")
        st = self.status.style()
        st.unpolish(self.status)
        st.polish(self.status)
        self.status.setText(msg)

    # ---- actions ----
    def _speak_text(self, text):
        if not text.strip():
            self.say("Nothing to read yet.", True)
            return
        self.ctx.speak(text)
        self.say("Reading aloud...")

    def speak(self):
        sel = self.edit.textCursor().selectedText().replace("\u2029", "\n").strip()
        self._speak_text(sel or self.edit.toPlainText())

    def _speech_changed(self, speaking, err):
        self.b_stop.setEnabled(speaking)
        if err:
            self.say(err, True)
        elif not speaking and self.status.text().startswith("Reading"):
            self.say("")

    def search(self):
        t = self.text()
        if t:
            from .websearch import HAVE_WEB
            if HAVE_WEB:                                    # Google results open inside the app
                self.ctx.pending_url = google_url(t)
                self.ctx.go("web")
            else:
                webbrowser.open(google_url(t))

    def _copy(self, text):
        if text.strip():
            QApplication.clipboard().setText(text)
            self.say("Copied")

    def save(self):
        t = self.text()
        if not t:
            return
        save_note(t, self.source)
        self.say("Saved in captures/notes.txt")

    def translate(self):
        text = self.text()
        if not text:
            self.say("Nothing to translate yet.", True)
            return
        code, name = self.lang.currentData(), self.lang.currentText()
        self._seq += 1
        seq = self._seq
        self.say("Translating...")
        self.b_tr.setEnabled(False)

        def done(res, err):
            self.b_tr.setEnabled(True)
            if seq != self._seq:
                return
            if err:
                self.say(str(err), True)
                print(f"[translate] {err}")
                return
            self.out.setPlainText(res)
            self.say(f"Translated to {name}")
            print(f"\n----- Translation ({name}) -----\n{res}\n{'-' * 30}")

        run_async(lambda: translate(text, code), done)
