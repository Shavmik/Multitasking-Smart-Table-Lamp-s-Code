"""Sudoku solver: type the puzzle, or scan it from a picture / the lamp camera (Tesseract or EasyOCR reads the digits)."""
import cv2
from PySide6.QtCore import Qt
from PySide6.QtGui import QRegularExpressionValidator
from PySide6.QtCore import QRegularExpression
from PySide6.QtWidgets import QFileDialog, QGridLayout, QHBoxLayout, QLineEdit, QVBoxLayout, QWidget

from ...core.solvers import conflicts, read_grid, solve_sudoku
from ..services import run_async
from ..theme import px, is_dark
from ..widgets import GlassCard, label, make_button
from ._ui import vcard
from .base import Page

EXAMPLE = "530070000600195000098000060800060003400803001700020006060000280000419005000080079"


class SudokuPage(Page):
    key, title = "sudoku", "Sudoku solver"

    def __init__(self, ctx):
        super().__init__(ctx)
        self.cells, self.given = [], set()
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(self.gap())
        c, l = vcard()
        boxes = QGridLayout(); boxes.setSpacing(px(8))
        val = QRegularExpressionValidator(QRegularExpression("[1-9]?"))
        self.cells = [None] * 81
        for br in range(3):
            for bc in range(3):
                box = QWidget(); g = QGridLayout(box); g.setSpacing(px(2)); g.setContentsMargins(0, 0, 0, 0)
                for r in range(3):
                    for cc in range(3):
                        e = QLineEdit(); e.setValidator(val); e.setMaxLength(1); e.setAlignment(Qt.AlignmentFlag.AlignCenter)
                        e.setMinimumSize(px(46), px(46))
                        e.textEdited.connect(self._edited)
                        g.addWidget(e, r, cc)
                        self.cells[(br * 3 + r) * 9 + bc * 3 + cc] = e
                boxes.addWidget(box, br, bc)
        l.addLayout(boxes, 1)
        root.addWidget(c, 3)

        c, l = vcard("Solver")
        self.status = label("Type the numbers you know, then press Solve.", "dim", wrap=True)
        l.addWidget(self.status)
        for text, var, ic, fn in [("Solve", "primary", "check", self.solve), ("Hint (one cell)", None, "search", self.hint),
                                  ("Check for mistakes", None, "check", self.check), ("Scan from a picture", None, "ocr", self.scan_file),
                                  ("Scan with the lamp camera", None, "camera", self.scan_lamp), ("Load an example", None, "open", self.example),
                                  ("Clear", None, "trash", self.clear)]:
            b = make_button(text, var, ic); b.clicked.connect(fn); l.addWidget(b)
        l.addStretch(1)
        l.addWidget(label("Scanning: fill the picture with the printed grid, keep it flat and well lit. Always check the digits before solving.", "dim", wrap=True))
        c.setMaximumWidth(px(380))
        root.addWidget(c, 1)
        self._paint()

    # ---- grid helpers ----
    def values(self):
        return [int(e.text()) if e.text() else 0 for e in self.cells]

    def _set(self, vals, given=None):
        for e, v in zip(self.cells, vals):
            e.setText(str(v) if v else "")
        self.given = set(i for i, v in enumerate(vals) if v) if given is None else given
        self._paint()

    def _edited(self, _):
        self.given = set(i for i, v in enumerate(self.values()) if v)
        self._paint()

    def _paint(self, bad=(), solved=()):
        ink = "#FFFFFF" if is_dark() else "#16161C"
        for i, e in enumerate(self.cells):
            bg = "rgba(255,90,95,170)" if i in bad else "rgba(52,211,153,70)" if i in solved else \
                ("rgba(255,255,255,26)" if is_dark() else "rgba(20,20,30,14)") if i in self.given else \
                ("rgba(0,0,0,70)" if is_dark() else "rgba(255,255,255,210)")
            e.setStyleSheet(f"QLineEdit {{ background:{bg}; color:{ink}; font-size:{px(22)}px; font-weight:700; border-radius:{px(8)}px; padding:0; }}")

    # ---- actions ----
    def solve(self):
        g = self.values()
        bad = conflicts(g)
        if bad:
            self._paint(bad=bad); return self.status.setText("Some numbers repeat in a row, column or box (red). Fix them first.")
        s = solve_sudoku(g)
        if s is None:
            return self.status.setText("This sudoku has no solution. Check the digits (a scan may have misread one).")
        self.given = set(i for i, v in enumerate(g) if v)
        for e, v in zip(self.cells, s):
            e.setText(str(v))
        self._paint(solved=[i for i in range(81) if i not in self.given])
        self.status.setText("Solved. The new numbers are green.")

    def hint(self):
        g = self.values()
        s = solve_sudoku(g)
        if s is None:
            return self.status.setText("No solution yet - use 'Check for mistakes'.")
        empty = [i for i, v in enumerate(g) if not v]
        if not empty:
            return self.status.setText("The grid is already full.")
        i = empty[0]
        self.cells[i].setText(str(s[i])); self.given.add(i)
        self._paint(solved=[i])
        self.status.setText(f"Row {i // 9 + 1}, column {i % 9 + 1} is {s[i]}.")

    def check(self):
        bad = conflicts(self.values())
        self._paint(bad=bad)
        if bad:
            self.status.setText("Repeated numbers are red.")
        else:
            self.status.setText("No repeats so far." if solve_sudoku(self.values()) else "No repeats, but there is no way to finish it - a number is wrong.")

    def example(self):
        self._set([int(c) for c in EXAMPLE]); self.status.setText("Example loaded.")

    def clear(self):
        self._set([0] * 81); self.status.setText("Cleared.")

    def scan_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Choose a sudoku picture", "", "Pictures (*.png *.jpg *.jpeg *.bmp *.webp)")
        img = cv2.imread(path) if path else None
        if img is not None:
            self._scan(img)

    def scan_lamp(self):
        self.status.setText("Taking a photo with the lamp...")
        run_async(self.ctx.lamp.photo, lambda res, err: self._scan(res[0]) if res else self.status.setText(str(err)))

    def _scan(self, img):
        self.status.setText("Reading the grid (the first time loads the text reader)...")
        eng = self.ctx.prefs.get("ocr_engine", "easyocr")
        eng = "easyocr" if eng == "both" else eng
        run_async(lambda: read_grid(img, eng, self.ctx.prefs.get("tesseract_cmd", "")), self._scanned)

    def _scanned(self, res, err):
        if err:
            return self.status.setText(str(err))
        vals, filled = res
        self._set(vals)
        got = sum(1 for v in vals if v)
        self.status.setText(f"Found {got} digits ({filled} filled cells). Correct any wrong digit, then press Solve.")
