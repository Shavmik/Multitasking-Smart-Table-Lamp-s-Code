"""Read text: capture a photo with the lamp (or open a picture) -> OCR -> read aloud / translate."""
import os
from datetime import datetime

from PySide6.QtWidgets import QFileDialog, QHBoxLayout, QVBoxLayout

from ... import config
from ..imgutil import read_image_file
from ..services import run_async
from ..theme import px
from ..widgets import CameraView, label, make_button
from .base import Page
from .textpanel import TextPanel


class OcrPage(Page):
    key, title, uses_camera = "ocr", "Read text", True

    def tft_units(self):
        from PySide6.QtCore import QRect
        p = self.panel
        head = QRect(0, 0, p.width(), max(10, p.edit.y()))     # "Recognised text" + status line
        return [self.tft_visible((p, head)), self.tft_visible((p.edit, QRect(0, 0, p.edit.width(), min(p.edit.height(), px(120))))),
                self.tft_visible(self.b_cap, self.b_open), self.tft_visible(p.b_speak, p.b_stop)]

    def __init__(self, ctx):
        super().__init__(ctx)
        self._busy = False
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(self.gap())
        left = QVBoxLayout()
        left.setSpacing(px(12))
        self.cam = CameraView()
        left.addWidget(self.cam, 1)
        row = QHBoxLayout()
        self.b_cap = make_button("Capture and read", "primary", "camera")
        self.b_cap.setMinimumHeight(px(54))
        self.b_open = make_button("Open picture...", None, "folder")
        self.b_open.setMinimumHeight(px(54))
        row.addWidget(self.b_cap, 2)
        row.addWidget(self.b_open, 1)
        left.addLayout(row)
        self.hint = label("Place the page under the lamp, keep it in focus, then press Capture. (Space also captures)", "dim", wrap=True)
        left.addWidget(self.hint)
        root.addLayout(left, 5)
        self.panel = TextPanel(ctx, "Recognised text", "Read text")
        root.addWidget(self.panel, 4)

        self.bind_camera(self.cam)
        self.b_cap.clicked.connect(self.capture)
        self.b_open.clicked.connect(self.open_picture)
        ctx.ocr_state_changed.connect(self._ocr_state)

    def on_enter(self):
        super().on_enter()
        self.ctx.warm_ocr()
        self.b_cap.setFocus()

    def _ocr_state(self, state, msg):
        if state in ("loading", "error"):
            self.panel.say(msg, state == "error")
        elif state == "ready" and not self._busy:
            self.panel.say("Text reader ready")

    def _set_busy(self, busy):
        self._busy = busy
        self.b_cap.setEnabled(not busy)
        self.b_open.setEnabled(not busy)

    # ---- capture from the lamp ----
    def capture(self):
        if self._busy:
            return
        if not self.ctx.lamp.has_camera:
            self.panel.say("The lamp is not connected. Use 'Open picture...' or connect it in Settings.", True)
            return
        self._set_busy(True)
        self.panel.say("Taking a photo...")
        print("\nTaking photo...")
        run_async(self.ctx.lamp.photo, self._photo_done)

    def _photo_done(self, res, err):
        if err:
            self._set_busy(False)
            self.panel.say(f"The photo failed: {err}", True)
            print(f"Error: {err}")
            return
        img, jpeg = res
        os.makedirs(config.SAVE_DIR, exist_ok=True)
        path = os.path.join(config.SAVE_DIR, datetime.now().strftime("capture_%Y%m%d_%H%M%S.jpg"))
        with open(path, "wb") as f:
            f.write(jpeg)
        print(f"Saved on laptop: {path}")
        self._read(img)

    # ---- or read a picture from disk ----
    def open_picture(self):
        path, _ = QFileDialog.getOpenFileName(self, "Choose a picture with text", "",
                                              "Pictures (*.png *.jpg *.jpeg *.bmp *.webp *.tif *.tiff)")
        if not path:
            return
        img = read_image_file(path)
        if img is None:
            self.panel.say("That file could not be opened as a picture.", True)
            return
        self._set_busy(True)
        self._read(img)

    def _read(self, img):
        self.panel.say("Reading text...")
        self.ctx.read_text_async(img, self._ocr_done)

    def _ocr_done(self, text, err):
        self._set_busy(False)
        if err:
            self.panel.say(f"Could not read the picture: {err}", True)
            print(f"OCR error: {err}")
            return
        if not text:
            self.panel.say("No text found. Try better light, less glare, and keep the text in focus.", True)
            print("No text found.")
            return
        print(f"\n----- Text found -----\n{text}\n{'-' * 22}")
        self.panel.set_text(text)
        self.panel.say("Text found")

    def keyPressEvent(self, e):
        from PySide6.QtCore import Qt
        if e.key() in (Qt.Key.Key_Space,) and self.cam.hasFocus():
            self.capture()
        else:
            super().keyPressEvent(e)
