"""Read aloud: any text (typed, pasted, scanned earlier or saved notes) spoken by the PC voice."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication, QHBoxLayout, QSlider, QTextEdit, QVBoxLayout

from ..theme import px
from ..widgets import GlassCard, label, make_button
from .base import Page


class ReaderPage(Page):
    key, title = "reader", "Read aloud"

    def tft_units(self):
        return [self.tft_visible(self.tft_top(self.edit, px(130))), self.tft_visible(self.b_speak, self.b_stop),
                self.tft_visible(self.b_paste, self.b_last, self.b_clear), self.tft_visible(self.speed)]

    def __init__(self, ctx):
        super().__init__(ctx)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        card = GlassCard()
        root.addWidget(card)
        lay = QVBoxLayout(card)
        m = px(22)
        lay.setContentsMargins(m, m, m, m)
        lay.setSpacing(px(12))
        head = QHBoxLayout()
        head.addWidget(label("Read aloud", "h1"))
        head.addStretch(1)
        self.status = label("", "dim")
        head.addWidget(self.status)
        lay.addLayout(head)
        lay.addWidget(label("Made for low vision: big text, one big button, and the PC speaks it for you.", "dim", wrap=True))

        self.edit = QTextEdit()
        self.edit.setAcceptRichText(False)
        self.edit.setPlaceholderText("Type or paste text here, or press 'Last scanned text'...")
        self._px = ctx.prefs.get("reader_px", 30)
        self._apply_px()
        lay.addWidget(self.edit, 1)

        row = QHBoxLayout()
        self.b_speak = make_button("Read aloud", "primary", "speaker")
        self.b_speak.setMinimumHeight(px(58))
        self.b_speak.setMinimumWidth(px(200))
        self.b_stop = make_button("Stop", "danger", "stop")
        self.b_stop.setMinimumHeight(px(58))
        self.b_stop.setEnabled(False)
        row.addWidget(self.b_speak)
        row.addWidget(self.b_stop)
        row.addSpacing(px(20))
        row.addWidget(label("Speed", "h3"))
        self.speed = QSlider(Qt.Orientation.Horizontal)
        self.speed.setRange(90, 280)
        self.speed.setValue(int(ctx.speaker.rate))
        self.speed.setMinimumWidth(px(180))
        row.addWidget(self.speed)
        self.speed_lb = label(f"{int(ctx.speaker.rate)}", "dim")
        row.addWidget(self.speed_lb)
        row.addStretch(1)
        b_m, b_p = make_button("A-"), make_button("A+")
        b_m.setFixedWidth(px(58)); b_p.setFixedWidth(px(58))
        row.addWidget(b_m); row.addWidget(b_p)
        lay.addLayout(row)

        row2 = QHBoxLayout()
        self.b_paste = make_button("Paste", None, "copy")
        self.b_last = make_button("Last scanned text", None, "ocr")
        self.b_clear = make_button("Clear", None, "trash")
        self.b_tr = make_button("Translate this...", "orange", "translate")
        self.b_scan = make_button("Scan with the lamp", None, "camera")
        for b in (self.b_paste, self.b_last, self.b_clear, self.b_tr, self.b_scan):
            row2.addWidget(b)
        row2.addStretch(1)
        lay.addLayout(row2)

        self.b_speak.clicked.connect(self.speak)
        self.b_stop.clicked.connect(ctx.stop_speaking)
        self.speed.valueChanged.connect(self._speed)
        b_m.clicked.connect(lambda: self._bump(-3))
        b_p.clicked.connect(lambda: self._bump(3))
        self.b_paste.clicked.connect(lambda: self.edit.insertPlainText(QApplication.clipboard().text()))
        self.b_last.clicked.connect(self._last)
        self.b_clear.clicked.connect(self.edit.clear)
        self.b_tr.clicked.connect(self._to_translator)
        self.b_scan.clicked.connect(lambda: ctx.go("ocr"))
        ctx.speech_state.connect(self._speech)

    def on_enter(self):
        if self.ctx.pending_text:
            self.edit.setPlainText(self.ctx.pending_text)
            self.ctx.pending_text = ""
        self.edit.setFocus()

    def _apply_px(self):
        self.edit.setStyleSheet(f"font-size: {px(self._px)}px;")

    def _bump(self, d):
        self._px = max(14, min(90, self._px + d))
        self.ctx.prefs.set("reader_px", self._px)
        self._apply_px()

    def _speed(self, v):
        self.ctx.speaker.rate = v
        self.ctx.prefs.set("tts_rate", v)
        self.speed_lb.setText(str(v))

    def _last(self):
        if self.ctx.last_text:
            self.edit.setPlainText(self.ctx.last_text)
        else:
            self.status.setText("Nothing scanned yet.")

    def _to_translator(self):
        self.ctx.pending_translate_text = self.edit.toPlainText()
        self.ctx.go("translate")

    def speak(self):
        sel = self.edit.textCursor().selectedText().replace("\u2029", "\n").strip()
        text = sel or self.edit.toPlainText().strip()
        if not text:
            self.status.setText("Nothing to read yet.")
            return
        self.ctx.speak(text)
        self.status.setText("Reading aloud...")

    def _speech(self, speaking, err):
        self.b_stop.setEnabled(speaking)
        if err:
            self.status.setText(err)
        elif not speaking:
            self.status.setText("")
