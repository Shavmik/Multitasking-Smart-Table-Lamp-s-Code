"""Profile: level, XP ring, badges and study stats, styled after the Steam profile picture (purple nebula, big eyes banner)."""
import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap, QRadialGradient
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLineEdit, QVBoxLayout, QWidget

from .. import theme
from ..fx import (AA, SMOOTH, AnimWidget, DotRing, FrameSprite, ProgressRing, RollingNumber, cover_rect, fx_asset, paint_rainbow_ring)
from ..icons import draw_icon
from ..theme import px
from ..widgets import GlassCard, label, make_button
from .base import Page

TITLES = ["Newcomer", "Apprentice", "Scholar", "Focused", "Expert", "Master", "Legend"]
# name, icon, description
BADGES = [("First step", "check", "Log your first study session"), ("Getting warm", "clock", "Log 10 sessions"),
          ("Hour power", "clock", "Study for 60 minutes in total"), ("Marathon", "clock", "Study for 10 hours in total"),
          ("Laser focus", "check", "Average focus of 80% or more over 3+ sessions"), ("Planner", "folder", "Have 5 tasks in the planner"),
          ("Night owl", "pen", "Study after 22:00"), ("Early bird", "pen", "Study before 07:00")]


class NebulaCard(QFrame):
    """Purple galaxy backdrop with stars (the profile background of the picture)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._stars = [((i * 53) % 97 / 97.0, (i * 31) % 89 / 89.0, 0.6 + (i % 4) * 0.5) for i in range(70)]

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        path = QPainterPath(); path.addRoundedRect(r, px(24), px(24))
        p.setClipPath(path)
        g = QLinearGradient(r.topLeft(), r.bottomRight())
        g.setColorAt(0, QColor(30, 12, 64)); g.setColorAt(1, QColor(12, 8, 34))
        p.fillRect(r, g)
        for cx, cy, rad, col in ((0.15, 0.2, 0.55, (140, 70, 255, 110)), (0.85, 0.8, 0.5, (200, 60, 255, 80)), (0.6, 0.1, 0.4, (70, 90, 255, 70))):
            rg = QRadialGradient(QPointF(r.left() + cx * r.width(), r.top() + cy * r.height()), rad * max(r.width(), r.height()))
            rg.setColorAt(0, QColor(*col)); rg.setColorAt(1, QColor(col[0], col[1], col[2], 0))
            p.fillRect(r, rg)
        p.setPen(Qt.PenStyle.NoPen)
        for sx, sy, sz in self._stars:
            p.setBrush(QColor(255, 255, 255, int(70 + 80 * (sz / 2))))
            p.drawEllipse(QPointF(r.left() + sx * r.width(), r.top() + sy * r.height()), sz, sz)
        p.setClipping(False)
        p.setBrush(Qt.BrushStyle.NoBrush); p.setPen(QPen(QColor(190, 160, 255, 70), 1.2))
        p.drawPath(path)


class BadgeRow(AnimWidget):
    """Round badges; earned ones get the rainbow rim, locked ones stay dim.  Hover a badge to read how to earn it."""
    FPS = 24

    def __init__(self, parent=None):
        super().__init__(parent)
        self.earned = [False] * len(BADGES)
        self._hover = -1
        self.setMouseTracking(True)
        self.setMinimumHeight(px(150))

    def set_earned(self, flags):
        self.earned = list(flags)
        self.update()

    def _centers(self):
        n = len(BADGES)
        slot = self.width() / n
        return [QPointF(slot * (i + 0.5), px(46)) for i in range(n)], slot

    def mouseMoveEvent(self, e):
        cs, slot = self._centers()
        self._hover = next((i for i, c in enumerate(cs) if abs(e.position().x() - c.x()) < slot / 2 and abs(e.position().y() - c.y()) < px(50)), -1)

    def leaveEvent(self, e):
        self._hover = -1

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        cs, slot = self._centers()
        R = min(px(34), slot * 0.36)
        ink = QColor("#FFFFFF") if theme.is_dark() else QColor("#16161C")
        for i, (c, (name, icon, desc)) in enumerate(zip(cs, BADGES)):
            on = self.earned[i]
            scale = 1.1 if i == self._hover else 1.0
            rr = R * scale
            p.setPen(QPen(QColor(255, 255, 255, 60) if theme.is_dark() else QColor(20, 20, 30, 50), 1.2))
            p.setBrush(QColor(20, 16, 44, 235) if theme.is_dark() else QColor(255, 255, 255, 245))
            p.drawEllipse(c, rr, rr)
            if on:
                paint_rainbow_ring(p, c, rr, px(2.6), (self.t() * 70 + i * 40) % 360, 1.0)
            col = QColor(ink); col.setAlpha(255 if on else 70)
            draw_icon(p, icon, QRectF(c.x() - rr * .5, c.y() - rr * .5, rr, rr), col, 0.1)
            f = QFont(self.font()); f.setPixelSize(px(12)); f.setBold(on)
            p.setFont(f)
            tc = QColor(ink); tc.setAlpha(230 if on else 110)
            p.setPen(tc)
            p.drawText(QRectF(c.x() - slot / 2, c.y() + R + px(8), slot, px(18)), int(Qt.AlignmentFlag.AlignCenter), name)
        if self._hover >= 0:
            f = QFont(self.font()); f.setPixelSize(px(13)); p.setFont(f)
            p.setPen(QColor(ink.red(), ink.green(), ink.blue(), 200))
            p.drawText(QRectF(0, self.height() - px(26), self.width(), px(22)), int(Qt.AlignmentFlag.AlignCenter),
                       ("Earned: " if self.earned[self._hover] else "Locked: ") + BADGES[self._hover][2])


class _Avatar(QWidget):
    """First frame of the mascot inside a soft violet rim."""

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA); p.setRenderHint(SMOOTH)
        r = QRectF(self.rect()).adjusted(5, 5, -5, -5)
        pm = QPixmap(fx_asset("chibi/001.jpg"))
        path = QPainterPath(); path.addRoundedRect(r, px(22), px(22))
        p.setClipPath(path)
        if not pm.isNull():
            p.drawPixmap(r, pm, cover_rect(r, pm.width(), pm.height()))
        p.setClipping(False)
        p.setBrush(Qt.BrushStyle.NoBrush); p.setPen(QPen(QColor(190, 160, 255, 200), 2.4))
        p.drawPath(path)


class ProfilePage(Page):
    key, title = "profile", "Profile"
    tft_names = ('head', 'eye')

    def __init__(self, ctx):
        super().__init__(ctx)
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(self.gap())
        left = QVBoxLayout(); left.setSpacing(self.gap())

        # ---- header (avatar, name, level, XP ring) ----
        head = self.head = NebulaCard()
        hl = QHBoxLayout(head)
        hl.setContentsMargins(px(22), px(18), px(22), px(18))
        hl.setSpacing(px(18))
        self.avatar = _Avatar(); self.avatar.setFixedSize(px(92), px(92))
        hl.addWidget(self.avatar)
        info = QVBoxLayout(); info.setSpacing(px(4))
        self.lb_name = label("", "h1")
        self.ed_name = QLineEdit(); self.ed_name.hide(); self.ed_name.setMaximumWidth(px(280))
        self.lb_title = label("", "dim")
        self.lb_level = label("", "h3")
        self.b_edit = make_button("Edit profile", None, "pen")
        self.b_edit.clicked.connect(self._edit)
        self.ed_name.editingFinished.connect(self._save_name)
        for w in (self.lb_name, self.ed_name, self.lb_title, self.lb_level):
            info.addWidget(w)
        row = QHBoxLayout(); row.addWidget(self.b_edit); row.addStretch(1)
        info.addLayout(row)
        hl.addLayout(info, 1)
        self.ring = ProgressRing(118, "purple", text="")
        hl.addWidget(self.ring)
        left.addWidget(head)

        # ---- eyes banner (the animated red eye) ----
        self.eye = FrameSprite("eye", fps=10, radius=24, pingpong=True, scan=True)
        self.eye.setMinimumHeight(px(210))
        left.addWidget(self.eye, 1)

        # ---- badges ----
        c = GlassCard()
        cl = QVBoxLayout(c); cl.setContentsMargins(px(20), px(14), px(20), px(10))
        cl.addWidget(label("Badges", "h2"))
        self.badges = BadgeRow()
        cl.addWidget(self.badges)
        left.addWidget(c)
        root.addLayout(left, 3)

        # ---- stats column ----
        right = GlassCard()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(px(20), px(16), px(20), px(16))
        rl.setSpacing(px(6))
        rl.addWidget(label("Study stats", "h2"))
        self.stat = {}
        for key, cap, suffix in (("sessions", "Sessions logged", ""), ("minutes", "Minutes studied", ""), ("tasks", "Tasks in planner", ""),
                                 ("badges", "Badges earned", ""), ("xp", "Experience", " XP")):
            rl.addWidget(label(cap, "dim"))
            rn = RollingNumber(0, size=30, color="#FFFFFF" if theme.is_dark() else "#16161C", suffix=suffix)
            rl.addWidget(rn)
            self.stat[key] = rn
        self.dots = DotRing(150, "#FF5A2E", "focus")
        rl.addWidget(self.dots, 0, Qt.AlignmentFlag.AlignHCenter)
        rl.addStretch(1)
        right.setFixedWidth(px(300))
        root.addWidget(right)

    def _edit(self):
        if self.ed_name.isVisible():
            self._save_name()
        else:
            self.ed_name.setText(self.ctx.prefs.get("user_name", "Student"))
            self.ed_name.show(); self.lb_name.hide(); self.ed_name.setFocus()
            self.b_edit.setText("Save")

    def _save_name(self):
        if not self.ed_name.isVisible():
            return
        name = self.ed_name.text().strip() or "Student"
        self.ctx.prefs.set("user_name", name)
        self.ed_name.hide(); self.lb_name.show(); self.lb_name.setText(name)
        self.b_edit.setText("Edit profile")

    def on_enter(self):
        sch = self.ctx.sched
        hist = sch.history
        sessions = len(hist)
        minutes = int(sum(h.get("actual", 0) for h in hist))
        tasks = len(sch.data.get("tasks", []))
        focus = (sum(h.get("focus", 1.0) for h in hist) / sessions) if sessions else 0.0
        hours = [h.get("hour", 12) for h in hist]
        flags = [sessions >= 1, sessions >= 10, minutes >= 60, minutes >= 600, sessions >= 3 and focus >= 0.8, tasks >= 5,
                 any(x >= 22 or x < 4 for x in hours), any(4 <= x < 7 for x in hours)]
        xp = minutes * 2 + sessions * 10
        level = int(math.sqrt(xp / 30.0)) + 1
        base, nxt = 30 * (level - 1) ** 2, 30 * level ** 2
        prog = (xp - base) / max(1, nxt - base)
        name = self.ctx.prefs.get("user_name", "Student")
        self.lb_name.setText(name)
        self.lb_title.setText(f"{TITLES[min(level // 3, len(TITLES) - 1)]}  \u2022  {xp - base} / {nxt - base} XP to level {level + 1}")
        self.lb_level.setText(f"Level {level}")
        self.ring.set_value(prog, text=f"Lv {level}")
        self.badges.set_earned(flags)
        for k, v in (("sessions", sessions), ("minutes", minutes), ("tasks", tasks), ("badges", sum(flags)), ("xp", xp)):
            self.stat[k].set_value(v)
        self.dots.set_value(focus, f"{int(focus * 100)}%")
