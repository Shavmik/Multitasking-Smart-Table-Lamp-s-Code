"""QR scanner: finds QR codes in the live picture by itself; a button scans a sharper full photo."""
import time
import webbrowser

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QHBoxLayout, QVBoxLayout

from ...features.qr_scanner import as_url, decode_qr
from ..services import run_async
from ..theme import px
from ..widgets import CameraView, label, make_button
from .base import Page
from .textpanel import TextPanel


class QrPage(Page):
    key, title, uses_camera = "qr", "QR scanner", True

    def tft_units(self):
        from PySide6.QtCore import QRect
        p = self.panel
        head = QRect(0, 0, p.width(), max(10, p.edit.y()))     # "QR code" + status line
        return [self.tft_visible((p, head)), self.tft_visible((p.edit, QRect(0, 0, p.edit.width(), min(p.edit.height(), px(150))))),
                self.tft_visible(self.b_deep, self.b_open)]

    def __init__(self, ctx):
        super().__init__(ctx)
        self._n = 0
        self._last = ("", 0.0)
        self._url = None
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(self.gap())
        left = QVBoxLayout()
        left.setSpacing(px(12))
        self.cam = CameraView()
        left.addWidget(self.cam, 1)
        row = QHBoxLayout()
        self.b_deep = make_button("Sharp photo scan", "primary", "camera")
        self.b_deep.setMinimumHeight(px(54))
        row.addWidget(self.b_deep)
        row.addStretch(1)
        left.addLayout(row)
        left.addWidget(label("Hold the code steady in view. It is found automatically; use the photo scan for small or blurry codes.", "dim", wrap=True))
        root.addLayout(left, 5)

        self.panel = TextPanel(ctx, "QR code", "QR code", "The scanned code shows here.")
        self.b_open = make_button("Open link", "green", "open")
        self.b_open.setVisible(False)
        self.panel.extra_row.addWidget(self.b_open)
        root.addWidget(self.panel, 4)

        self._fade = QTimer(self)
        self._fade.setSingleShot(True)
        self._fade.setInterval(1500)
        self._fade.timeout.connect(self._clear_overlay)
        self.bind_camera(self.cam, self._frame)
        self.b_deep.clicked.connect(self.deep)
        self.b_open.clicked.connect(lambda: self._url and webbrowser.open(self._url))

    def _clear_overlay(self):
        self.cam.set_polygon(None)
        self.cam.set_badge("")

    def _frame(self, img):
        self._n += 1
        if self._n % 2:
            return
        text, pts = decode_qr(img, deep=False)
        if text:
            self._found(text, pts)

    def _found(self, text, pts=None):
        if pts is not None:
            self.cam.set_polygon([(float(x), float(y)) for x, y in pts])
        self.cam.set_badge("QR code found")
        self._fade.start()
        if text == self._last[0] and time.time() - self._last[1] < 4:
            return
        self._last = (text, time.time())
        print(f"\n----- QR code found -----\n{text}")
        self._url = as_url(text)
        self.b_open.setVisible(bool(self._url))
        self.panel.set_text(text)
        self.panel.say("Link found" if self._url else "Text found")

    def deep(self):
        if not self.ctx.lamp.has_camera:
            self.panel.say("The lamp is not connected.", True)
            return
        self.b_deep.setEnabled(False)
        self.panel.say("Taking a sharp photo...")

        def work():
            img, _ = self.ctx.lamp.photo()
            return decode_qr(img, deep=True)[0]

        def done(text, err):
            self.b_deep.setEnabled(True)
            if err:
                self.panel.say(str(err), True)
            elif not text:
                self.panel.say("No QR code found - get closer and hold it still.", True)
            else:
                self._found(text)

        run_async(work, done)
