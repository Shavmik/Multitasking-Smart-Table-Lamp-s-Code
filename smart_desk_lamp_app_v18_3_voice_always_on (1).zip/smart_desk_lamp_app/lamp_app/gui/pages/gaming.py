"""Gaming hub: Rubik's cube, chess and sudoku solvers. Locked while Study or Focus mode is running."""
from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QVBoxLayout

from ..theme import px
from ..widgets import ArtTile, label, make_button
from ._ui import restyle, vcard
from .base import Page


class GamingPage(Page):
    key, title = "gaming", "Gaming hub"

    def __init__(self, ctx):
        super().__init__(ctx)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(self.gap())
        c, l = vcard()
        row = QHBoxLayout()
        self.lb = label("", "h2")
        self.b = make_button("Start Gaming mode", "green", "play")
        self.b.clicked.connect(self._toggle)
        row.addWidget(self.lb, 1); row.addWidget(self.b)
        l.addLayout(row)
        self.lb_sub = label("", "dim", wrap=True)
        l.addWidget(self.lb_sub)
        root.addWidget(c)
        grid = QGridLayout(); grid.setSpacing(px(14))
        tiles = [("cube", "Rubik's cube", "Scan six faces, get the steps", "red", "art_cube.png", None),
                 ("chess", "Chess", "Play the engine, analyse, open chess.com", "blue", None, "globe"),
                 ("sudoku", "Sudoku", "Type or scan a puzzle and solve it", "purple", None, "calc")]
        for i, (k, t, s, a, art, ic) in enumerate(tiles):
            tile = ArtTile(t, s, a, art, ic)
            tile.clicked.connect(lambda _=False, key=k: ctx.go(key))
            grid.addWidget(tile, 0, i)
            grid.setColumnStretch(i, 1)
        grid.setRowStretch(0, 1)
        root.addLayout(grid, 1)
        ctx.mode_changed.connect(lambda m: self._refresh())

    def _toggle(self):
        self.ctx.set_mode("normal" if self.ctx.modes.current == "gaming" else "gaming")

    def on_enter(self):
        self._refresh()

    def _refresh(self):
        m = self.ctx.modes.current
        self.b.setVisible(m in ("normal", "gaming"))
        if m == "gaming":
            self.lb.setText("Gaming mode is ON"); self.b.setText("Stop Gaming mode"); self.b.setProperty("variant", "danger")
            self.lb_sub.setText("Have fun. Your session time is saved for the planner.")
        else:
            self.lb.setText("Gaming hub"); self.b.setText("Start Gaming mode"); self.b.setProperty("variant", "green")
            self.lb_sub.setText("Study and Focus modes lock the games." if m != "normal" else "Start Gaming mode to track your play time (the games also work in Normal mode).")
        restyle(self.b)
