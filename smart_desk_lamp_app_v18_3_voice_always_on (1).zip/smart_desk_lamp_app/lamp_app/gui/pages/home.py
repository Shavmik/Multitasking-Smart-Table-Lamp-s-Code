"""Home = a desktop, like the anime desktop picture: blurred city wallpaper, frosted glass window, round app rail on the left,
big clock + calendar, the animated mascot in the middle, picture cards + music player on the right and a magnifying dock at
the bottom.  The old tile grid is still here as the 'All apps' drawer (start button of the dock)."""
import os

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, QVariantAnimation, QEasingCurve
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap, QRadialGradient
from PySide6.QtWidgets import (QAbstractButton, QGridLayout, QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QStackedWidget,
                               QVBoxLayout, QWidget)

from ... import config
from ...core import nativemenu
from ...core.clock import ampm, time_text
from .. import theme
from ..fx import (AA, SMOOTH, CalendarCard, Dock, FrameSprite, PhotoCard, RailButton, cover_rect, fx_pixmap, paint_rainbow_ring)
from ..cutout import CutoutDesktop
from ..icons import draw_icon
from ..theme import px
from ..widgets import ArtTile, GlassCard, IconButton, label, make_button
from .base import Page

# ---- the 'All apps' drawer (the old bento grid, now with the new pictures) ----
# key, title, subtitle, accent, art, icon, (row, col, rowspan, colspan)
TILES = [
    ("clock", "India Standard Time", "", "purple", "art_clock.png", None, (0, 0, 1, 2)),
    ("modes", "Modes", "Study \u2022 Focus \u2022 Gaming", "orange", "fx/icon_discord.jpg", None, (0, 2, 1, 1)),
    ("timers", "Timers & Tracker", "Stopwatch, timer, tracker", "teal", None, "clock", (0, 3, 1, 1)),
    ("planner", "Smart Planner", "AI timetable & estimates", "red", "fx/graph_photo.jpg", None, (1, 0, 1, 1)),
    ("gaming", "Gaming hub", "Cube \u2022 Chess \u2022 Sudoku", "red", "art_cube.png", None, (1, 1, 1, 1)),
    ("osiris", "Osiris AI", "Ask the assistant", "purple", None, "translate", (1, 2, 1, 1)),
    ("web", "Google Search", "Search inside the app", "yellow", "art_google_g.jpg", None, (1, 3, 1, 1)),
    ("ocr", "Read text", "Tesseract / EasyOCR", "orange", "art_ocr_notebook.jpg", None, (2, 0, 1, 1)),
    ("reader", "Read aloud", "For low vision", "yellow", "art_reader_book.jpg", None, (2, 1, 1, 1)),
    ("translate", "Translator", "Instant translation", "blue", "fx/icon_translate.png", None, (2, 2, 1, 1)),
    ("qr", "QR scanner", "Scan and open links", "pink", "art_qr.png", None, (2, 3, 1, 1)),
    ("hand", "Handwriting", "Write, then read", "teal", "art_notebook.png", None, (3, 0, 1, 1)),
    ("calc", "Calculator", "Sums and history", "purple", "art_calc_toga.jpg", None, (3, 1, 1, 1)),
    ("spotify", "Spotify", "Open and control music", "green", "art_spotify.png", None, (3, 2, 1, 1)),
    ("erp", "College ERP", "erp.psit.ac.in", "green", "art_erp_psit.jpg", None, (3, 3, 1, 1)),
    ("profile", "Profile", "Level \u2022 badges \u2022 stats", "purple", None, "check", (4, 0, 1, 2)),
    ("settings", "Smart lamp", "Connect \u2022 voice \u2022 OCR", "grey", "fx/lamp_sketch.jpg", None, (4, 2, 1, 2)),
]

# key, icon, art, label, accent
DOCK_ITEMS = [
    ("__start__", None, None, "All apps", "#3B82F6"),
    ("modes", None, "fx/icon_discord.jpg", "Modes", "#FF8A3D"),
    ("timers", "clock", None, "Timers", "#2DD4BF"),
    ("planner", "folder", None, "Smart Planner", "#E5283C"),
    ("gaming", None, "art_cube.png", "Gaming hub", "#FF5A5F"),
    ("osiris", "translate", None, "Osiris AI", "#8B5CF6"),
    ("ocr", None, "art_ocr_notebook.jpg", "Read text", "#FF8A3D"),
    ("web", None, "art_google_g.jpg", "Google Search", "#FFC83D"),
    ("calc", None, "art_calc_toga.jpg", "Calculator", "#7C5CFF"),
    ("spotify", None, "art_spotify.png", "Spotify", "#34D399"),
    ("erp", None, "art_erp_psit.jpg", "College ERP", "#34D399"),
    ("settings", "gear", None, "Settings", "#8A8FA8"),
]

# left rail: key (or 'search'), icon, art, tooltip, accent
RAIL = [("search", "search", None, "Search (Ctrl+K)", "#2B2B3A"),
        ("web", None, "art_google_g.jpg", "Google Search", "#3B82F6"),
        ("erp", None, "art_erp_psit.jpg", "College ERP", "#1D7A4C"),
        ("spotify", None, "art_spotify.png", "Spotify", "#1DB954"),
        ("modes", None, "fx/icon_discord.jpg", "Modes", "#FF8A3D"),
        ("translate", None, "fx/icon_translate.png", "Translator", "#4F8CFF"),
        ("reader", None, "art_reader_book.jpg", "Read aloud", "#FFC83D"),
        ("osiris", "translate", None, "Osiris AI", "#8B5CF6")]


class DesktopView(QWidget):
    """Wallpaper + frosted glass window, baked once per size / theme (cheap to repaint under the animated children)."""

    def __init__(self, ctx=None, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self._pm, self._key = None, None
        self.win_margins = (px(16), px(14), px(16), px(104))        # left, top, right, bottom of the glass window

    def _bake(self):
        dpr = self.devicePixelRatioF()
        w, h = self.width(), self.height()
        pm = QPixmap(int(w * dpr), int(h * dpr))
        pm.setDevicePixelRatio(dpr)
        pm.fill(Qt.GlobalColor.transparent)
        p = QPainter(pm)
        p.setRenderHint(AA); p.setRenderHint(SMOOTH)
        r = QRectF(0, 0, w, h)
        path = QPainterPath(); path.addRoundedRect(r, px(30), px(30))
        p.setClipPath(path)
        wall_key = self.ctx.prefs.get("desktop_wallpaper", "city") if self.ctx else "city"
        wall_file, _ = WALLPAPER_OPTIONS.get(wall_key, WALLPAPER_OPTIONS["city"])
        wp = fx_pixmap(wall_file)
        if wp.isNull():
            p.fillRect(r, QColor(40, 60, 120))
        else:
            p.drawPixmap(r, wp, cover_rect(r, wp.width(), wp.height()))
        p.fillRect(r, QColor(10, 8, 30, 165) if theme.is_dark() else QColor(255, 255, 255, 18))
        l, t, rr, b = self.win_margins
        win = QRectF(l, t, w - l - rr, h - t - b)
        gl = QLinearGradient(win.topLeft(), win.bottomRight())
        if theme.is_dark():
            gl.setColorAt(0, QColor(255, 255, 255, 46)); gl.setColorAt(1, QColor(255, 255, 255, 18)); edge = QColor(255, 255, 255, 70)
        else:
            gl.setColorAt(0, QColor(255, 255, 255, 150)); gl.setColorAt(1, QColor(255, 255, 255, 88)); edge = QColor(255, 255, 255, 230)
        for i in range(5):                                         # soft shadow under the window
            p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor(0, 0, 0, 12))
            p.drawRoundedRect(win.adjusted(-i * 2, i * 2 + 4, i * 2, i * 2 + 4), px(36), px(36))
        p.setPen(QPen(edge, 1.4)); p.setBrush(gl)
        p.drawRoundedRect(win, px(34), px(34))
        p.end()
        self._pm = pm

    def paintEvent(self, e):
        wall_key = self.ctx.prefs.get("desktop_wallpaper", "city") if self.ctx else "city"
        key = (self.width(), self.height(), theme.MODE, self.devicePixelRatioF(), wall_key)
        if key != self._key:
            self._bake()
            self._key = key
        p = QPainter(self)
        p.drawPixmap(0, 0, self._pm)


class HiLabel(QLabel):
    """'Hi name!!' greeting; its colour follows the light / dark cardboard."""

    def __init__(self, parent=None):
        super().__init__("", parent)
        self.setFixedHeight(px(30))

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        f = QFont(self.font()); f.setPixelSize(px(22)); f.setBold(True)
        p.setFont(f)
        p.setPen(QColor("#FFE9B8") if theme.is_dark() else QColor("#3A2412"))
        p.drawText(QRectF(self.rect()), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), self.text())


class RailBar(QWidget):
    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setPen(QPen(QColor(255, 255, 255, 70) if theme.is_dark() else QColor(255, 255, 255, 230), 1.2))
        p.setBrush(QColor(255, 255, 255, 26) if theme.is_dark() else QColor(255, 255, 255, 150))
        p.drawRoundedRect(r, r.width() / 2, r.width() / 2)


class ClockBlock(QWidget):
    """Big HH:MM and the date, top left of the desktop picture."""

    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.setFixedHeight(px(112))
        ctx.clock.tick.connect(lambda _: self.update())

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        now = self.ctx.clock.now()
        ink = QColor("#FFFFFF") if theme.is_dark() else QColor("#111827")
        f = QFont("Consolas"); f.setBold(True); f.setPixelSize(px(58))
        p.setFont(f); p.setPen(ink)
        txt = time_text(now, self.ctx.clock.h24, False)
        p.drawText(QPointF(px(4), px(58)), txt)
        w = p.fontMetrics().horizontalAdvance(txt)
        f2 = QFont(self.font()); f2.setPixelSize(px(17)); f2.setBold(True)
        p.setFont(f2); p.setPen(QColor("#FF8A3D"))
        if not self.ctx.clock.h24:
            p.drawText(QPointF(px(10) + w, px(58)), ampm(now))
        f2.setBold(False); f2.setPixelSize(px(15)); p.setFont(f2)
        p.setPen(QColor(ink.red(), ink.green(), ink.blue(), 190))
        p.drawText(QPointF(px(6), px(88)), now.strftime("%A   %d/%m"))


class LogoBadge(QWidget):
    """Round lamp logo with a slowly turning rainbow rim (top right, where the picture has the Figma logo)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(px(48), px(48))
        self._t = QTimer(self); self._t.setInterval(40); self._t.timeout.connect(self.update)

    def showEvent(self, e):
        self._t.start(); super().showEvent(e)

    def hideEvent(self, e):
        self._t.stop(); super().hideEvent(e)

    def paintEvent(self, e):
        import time
        p = QPainter(self)
        p.setRenderHint(AA)
        c = QPointF(self.width() / 2, self.height() / 2)
        R = self.width() / 2 - px(4)
        p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor(14, 14, 24, 235) if theme.is_dark() else QColor(255, 255, 255, 245))
        p.drawEllipse(c, R, R)
        paint_rainbow_ring(p, c, R, px(2.2), (time.monotonic() * 70) % 360, 0.9)
        col = QColor("#FFFFFF" if theme.is_dark() else "#16161C")
        p.setPen(QPen(col, px(1.8), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)); p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(QPointF(c.x(), c.y() - R * .12), R * .36, R * .36)
        p.drawLine(QPointF(c.x() - R * .17, c.y() + R * .42), QPointF(c.x() + R * .17, c.y() + R * .42))
        p.drawLine(QPointF(c.x() - R * .11, c.y() + R * .58), QPointF(c.x() + R * .11, c.y() + R * .58))


class UserPill(QAbstractButton):
    """Name pill with an avatar (click = profile)."""
    fx_ripple = True

    def __init__(self, name, parent=None):
        super().__init__(parent)
        self.name = name
        self.setFixedSize(px(176), px(44))
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setPen(QPen(QColor(255, 255, 255, 70) if theme.is_dark() else QColor(20, 20, 30, 40), 1))
        p.setBrush(QColor(255, 255, 255, 30) if theme.is_dark() else QColor(255, 255, 255, 215))
        p.drawRoundedRect(r, r.height() / 2, r.height() / 2)
        av = QRectF(r.right() - r.height() + px(4), r.top() + px(4), r.height() - px(8), r.height() - px(8))
        g = QLinearGradient(av.topLeft(), av.bottomRight())
        g.setColorAt(0, QColor("#B58BFF")); g.setColorAt(1, QColor("#5B7CFF"))
        p.setPen(Qt.PenStyle.NoPen); p.setBrush(g)
        p.drawEllipse(av)
        f = QFont(self.font()); f.setBold(True); f.setPixelSize(px(17))
        p.setFont(f); p.setPen(QColor("#FFFFFF"))
        p.drawText(av, int(Qt.AlignmentFlag.AlignCenter), (self.name or "S")[0].upper())
        f.setPixelSize(px(15)); p.setFont(f)
        p.setPen(QColor("#FFFFFF") if theme.is_dark() else QColor("#16161C"))
        p.drawText(QRectF(r.left() + px(16), r.top(), r.width() - av.width() - px(26), r.height()),
                   int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), self.name)


class MiniPlayer(QWidget):
    """Dark music card with media keys (bottom right of the desktop picture)."""

    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.setFixedHeight(px(88))
        lay = QHBoxLayout(self)
        lay.setContentsMargins(px(88), px(10), px(14), px(10))
        col = QVBoxLayout(); col.setSpacing(px(2))
        t = QLabel("Spotify"); t.setStyleSheet(f"color:white; font-weight:700; font-size:{px(16)}px;")
        self.sub = QLabel("Tap play to control your music"); self.sub.setStyleSheet(f"color:rgba(255,255,255,150); font-size:{px(11)}px;")
        col.addStretch(1); col.addWidget(t); col.addWidget(self.sub)
        row = QHBoxLayout(); row.setSpacing(px(6))
        for kind, key in (("prev", "prev"), ("playpause", "playpause"), ("next", "next")):
            b = IconButton(kind, "", 34, filled=(kind == "playpause"))
            b.clicked.connect(lambda _=False, k=key: self._key(k))
            row.addWidget(b)
        row.addStretch(1)
        col.addLayout(row); col.addStretch(1)
        lay.addLayout(col, 1)

    def _key(self, k):
        page = self.ctx.window.pages.get("spotify") if self.ctx.window else None
        if page:
            page._key(k)
            self.sub.setText({"prev": "Previous track", "next": "Next track", "playpause": "Play / pause"}[k])

    def paintEvent(self, e):
        from ..icons import art_pixmap
        p = QPainter(self)
        p.setRenderHint(AA); p.setRenderHint(SMOOTH)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setPen(QPen(QColor(255, 255, 255, 50), 1)); p.setBrush(QColor(20, 18, 34, 240))
        p.drawRoundedRect(r, px(22), px(22))
        s = r.height() - px(20)
        thumb = QRectF(r.left() + px(12), r.top() + px(10), s, s)
        pm = art_pixmap("art_spotify.png")
        clip = QPainterPath(); clip.addRoundedRect(thumb, px(14), px(14))
        p.save(); p.setClipPath(clip)
        p.fillRect(thumb, QColor("#1DB954"))
        if not pm.isNull():
            p.drawPixmap(thumb, pm, QRectF(pm.rect()))
        p.restore()


# centrepiece choices for the middle of the desktop (Settings > Appearance > Desktop centrepiece)
# value -> (frame folder, fps, pingpong)
CENTRE_OPTIONS = {
    "gothic_rain": ("gothic_rain", 12, False),   # silent rain / gothic city loop (default)
    "chibi": ("chibi", 10, True),                # the original dancing character
}

# desktop wallpaper choices (Settings > Appearance > Desktop wallpaper) -> fx/<file>
WALLPAPER_OPTIONS = {
    "city": ("wallpaper_city.jpg", "Blurred city (default)"),
    "gothic_rain": ("wallpaper_gothic_rain.jpg", "Silent rain / gothic city"),
}


class HomePage(Page):
    key, title = "home", "Home"
    _tft_page = 0

    def tft_units(self):
        """The dock as a grid of big icons (touch one = open that page). Fallback only -
        tft_native() below is used instead whenever it is available."""
        if not self.dock.isVisible():
            return None
        return [[(self.dock, r)] for r in self.dock.tft_parts()]

    def tft_native(self):
        """The lamp's home screen: big colour tiles drawn natively, instant to update."""
        title, raw = nativemenu.build(self._tft_page)
        buttons = []
        for b in raw:
            bb = dict(b)
            if "key" in b:
                k = b["key"]
                bb["on_tap"] = lambda k=k: self.ctx.go(k)
            elif b.get("nav") == "prev":
                bb["on_tap"] = self._tft_prev
            elif b.get("nav") == "next":
                bb["on_tap"] = self._tft_next
            buttons.append(bb)
        return title, buttons

    def _tft_next(self):
        self._tft_page = (self._tft_page + 1) % nativemenu.pages()
        self.ctx.tft.refresh()

    def _tft_prev(self):
        self._tft_page = (self._tft_page - 1) % nativemenu.pages()
        self.ctx.tft.refresh()

    def __init__(self, ctx):
        super().__init__(ctx)
        self.stack = QStackedWidget()
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(self.stack)
        self.stack.addWidget(self._build_desktop())
        self.stack.addWidget(self._build_drawer())
        self.stack.addWidget(self._build_cutout())            # index 2: the cardboard cut-out desktop
        ctx.lamp.status.connect(lambda ok, msg: self._lamp(ok, msg))
        self._lamp(ctx.lamp.connected, "Connecting..." if ctx.lamp.connecting else "The lamp is not connected.")

    # ------------------------------------------------------------------ the desktop
    def _build_desktop(self):
        ctx = self.ctx
        d = DesktopView(ctx)
        self.desk = d
        l, t, r, b = d.win_margins
        outer = QVBoxLayout(d)
        outer.setContentsMargins(l + px(20), t + px(20), r + px(20), px(4))
        outer.setSpacing(0)
        win = QHBoxLayout()
        win.setSpacing(px(20))
        outer.addLayout(win, 1)

        # rail
        rail = RailBar(); rail.setFixedWidth(px(72))
        rl = QVBoxLayout(rail); rl.setContentsMargins(px(9), px(14), px(9), px(14)); rl.setSpacing(px(10))
        rl.addStretch(1)
        for key, icon, art, tip, accent in RAIL:
            b_ = RailButton(icon, tip, accent, art)
            b_.clicked.connect(lambda _=False, k=key: self._rail(k))
            rl.addWidget(b_, 0, Qt.AlignmentFlag.AlignHCenter)
        rl.addStretch(1)
        win.addWidget(rail)

        # left: clock + calendar
        left = QVBoxLayout(); left.setSpacing(px(14))
        self.clock_block = ClockBlock(ctx)
        left.addWidget(self.clock_block)
        self.cal = CalendarCard()
        self.cal.setFixedWidth(px(226))
        left.addWidget(self.cal, 1)
        left.addStretch(0)
        win.addLayout(left)
        ctx.clock.tick.connect(lambda now: self.cal.set_date(now.date()))

        # centre: the mascot (frames cut from a character video) OR an ambient video wallpaper loop,
        # whichever the user picked in Settings > Appearance > Desktop centrepiece.
        self.mascot = FrameSprite(*self._centre_sprite_args())
        self.mascot.setMinimumWidth(px(260))
        win.addWidget(self.mascot, 1)

        # right: user, greeting, picture cards, music
        right = QVBoxLayout(); right.setSpacing(px(12))
        top = QHBoxLayout(); top.setSpacing(px(10))
        top.addStretch(1)
        top.addWidget(LogoBadge())
        self.user = UserPill(ctx.prefs.get("user_name", "Student"))
        self.user.clicked.connect(lambda: ctx.go("profile"))
        top.addWidget(self.user)
        right.addLayout(top)
        self.hi = QLabel("")
        self.hi.setStyleSheet(f"color:#7C8CFF; font-size:{px(24)}px; font-weight:800;")
        right.addWidget(self.hi)
        grid = QGridLayout(); grid.setSpacing(px(10))
        cards = [("art_cube.png", "Cube solver", "Scan & solve", "cube", (0, 0, 2, 1)),
                 ("fx/graph_photo.jpg", "Smart Planner", "Your week", "planner", (0, 1, 1, 1)),
                 ("fx/focus_banner.jpg", "Focus mode", "Block distractions", "modes", (1, 1, 1, 1))]
        for art, ttl, sub, key, (rr, cc, rs, cs) in cards:
            pc = PhotoCard(art, ttl, sub)
            pc.clicked.connect(lambda _=False, k=key: ctx.go(k))
            grid.addWidget(pc, rr, cc, rs, cs)
        grid.setRowStretch(0, 1); grid.setRowStretch(1, 1); grid.setColumnStretch(0, 1); grid.setColumnStretch(1, 1)
        right.addLayout(grid, 1)
        right.addWidget(MiniPlayer(ctx))
        rw = QWidget(); rw.setLayout(right); rw.setFixedWidth(px(330))
        win.addWidget(rw)

        # dock
        dl = QHBoxLayout(); dl.addStretch(1)
        self.dock = Dock(DOCK_ITEMS)
        self.dock.launched.connect(self._dock)
        dl.addWidget(self.dock); dl.addStretch(1)
        outer.addLayout(dl)
        return d

    # ------------------------------------------------------------------ the cardboard cut-out desktop
    def _build_cutout(self):
        """Cardboard pieces lying on the REAL Windows desktop (no wallpaper of our own is drawn - see gui/cutout.py)."""
        ctx = self.ctx
        d = CutoutDesktop(ctx)
        self.cut = d
        pl = d.panel.content
        top = QHBoxLayout(); top.setSpacing(px(10))
        top.addWidget(LogoBadge())
        top.addStretch(1)
        self.cuser = UserPill(ctx.prefs.get("user_name", "Student"))
        self.cuser.clicked.connect(lambda: ctx.go("profile"))
        top.addWidget(self.cuser)
        pl.addLayout(top)
        self.chi = HiLabel()
        pl.addWidget(self.chi)
        pl.addWidget(ClockBlock(ctx))
        self.ccal = CalendarCard()
        pl.addWidget(self.ccal, 1)
        ctx.clock.tick.connect(lambda now: self.ccal.set_date(now.date()))
        cards = QHBoxLayout(); cards.setSpacing(px(10))
        for art, ttl, sub, key in (("art_cube.png", "Cube solver", "Scan & solve", "cube"),
                                   ("fx/focus_banner.jpg", "Focus mode", "Block distractions", "modes")):
            pc = PhotoCard(art, ttl, sub)
            pc.setFixedHeight(px(104))
            pc.clicked.connect(lambda _=False, k=key: ctx.go(k))
            cards.addWidget(pc)
        pl.addLayout(cards)
        pl.addWidget(MiniPlayer(ctx))
        self.cdock = Dock(DOCK_ITEMS)
        self.cdock.launched.connect(self._dock)
        d.dockp.content.addWidget(self.cdock)
        return d

    def _cut_wanted(self):
        return self.ctx.prefs.get("desktop_style", "cutout") == "cutout"

    def show_desktop(self):
        """The desktop of Home: cardboard cut-out (default) or the old wallpaper look, as chosen in Settings."""
        win = self.ctx.window
        if self._cut_wanted():
            self.stack.setCurrentIndex(2)
            win.set_cutout(True)
            self.cut.activate()
        else:
            self.cut.deactivate()
            win.set_cutout(False)
            self.stack.setCurrentIndex(0)

    def show_drawer(self):
        self.cut.deactivate()
        self.ctx.window.set_cutout(False)             # the 'All apps' grid needs the whole opaque window
        self.stack.setCurrentIndex(1)

    def leave_cutout_temp(self):
        """Opaque window for a moment (search bar); the next visit to Home brings the cardboard back."""
        self.cut.deactivate()
        self.ctx.window.set_cutout(False)
        self.stack.setCurrentIndex(0)

    def set_desktop_style(self, value):
        self.ctx.prefs.set("desktop_style", value)
        if self.ctx.window.current == "home":
            self.show_desktop()

    def _centre_sprite_args(self):
        folder, fps, pingpong = CENTRE_OPTIONS.get(self.ctx.prefs.get("desktop_centre", "gothic_rain"),
                                                    CENTRE_OPTIONS["gothic_rain"])
        return (folder, fps, 34, pingpong)

    def set_centrepiece(self, value):
        """Called by Settings when the user changes the desktop centrepiece. Swaps the live widget."""
        self.ctx.prefs.set("desktop_centre", value)
        win = self.mascot.parent().layout()
        idx = win.indexOf(self.mascot)
        old = self.mascot
        self.mascot = FrameSprite(*self._centre_sprite_args())
        self.mascot.setMinimumWidth(px(260))
        win.insertWidget(idx, self.mascot, 1)
        win.removeWidget(old)
        old.deleteLater()

    def set_wallpaper(self, value):
        self.ctx.prefs.set("desktop_wallpaper", value)
        self.desk._key = None            # force DesktopView to re-bake with the new wallpaper
        self.desk.update()

    def _rail(self, key):
        if key == "search":
            self.ctx.window.searchbar.open()
        else:
            self.ctx.go(key)

    def _dock(self, key):
        if key == "__start__":
            if self.stack.currentIndex() == 1:
                self.show_desktop()
            else:
                self.show_drawer()
        else:
            self.ctx.go(key)

    # ------------------------------------------------------------------ the 'All apps' drawer
    def _build_drawer(self):
        ctx = self.ctx
        w = QWidget()
        root = QVBoxLayout(w)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(px(12))
        bar = QHBoxLayout()
        b_back = make_button("Back to desktop", "primary", "back")
        b_back.clicked.connect(self.show_desktop)
        bar.addWidget(b_back)
        bar.addStretch(1)
        root.addLayout(bar)
        body = QHBoxLayout(); body.setSpacing(self.gap())
        grid = QGridLayout(); grid.setSpacing(px(14))
        self.tiles = {}
        for key, title, sub, accent, art, icon, (r, c, rs, cs) in TILES:
            t = ArtTile(title, sub, accent, art, icon)
            t.clicked.connect(lambda _=False, k=key: ctx.go(k))
            grid.addWidget(t, r, c, rs, cs)
            self.tiles[key] = t
        for i in range(5):
            grid.setRowStretch(i, 1)
        for i in range(4):
            grid.setColumnStretch(i, 1)
        body.addLayout(grid, 1)
        self.clock_tile = self.tiles["clock"]
        self.clock_tile.extra = self._paint_clock
        ctx.clock.tick.connect(self._tick)
        self._tick(ctx.clock.now())

        self.side = QWidget()
        sl = QVBoxLayout(self.side)
        sl.setContentsMargins(0, 0, 0, 0)
        sl.setSpacing(px(14))
        lamp = GlassCard()
        ll = QVBoxLayout(lamp)
        ll.setContentsMargins(px(18), px(16), px(18), px(16))
        ll.addWidget(label("Smart lamp", "h2"))
        self.lb_lamp = label("", wrap=True)
        ll.addWidget(self.lb_lamp)
        b = make_button("Lamp settings", None, "gear")
        b.clicked.connect(lambda: ctx.go("settings"))
        ll.addWidget(b)
        sl.addWidget(lamp)
        notes = GlassCard()
        nl = QVBoxLayout(notes)
        nl.setContentsMargins(px(18), px(16), px(18), px(16))
        nl.addWidget(label("Recent notes", "h2"))
        nl.addWidget(label("Click one to read it aloud.", "dim"))
        self.notes = QListWidget()
        self.notes.setWordWrap(True)
        self.notes.itemClicked.connect(self._note)
        nl.addWidget(self.notes, 1)
        sl.addWidget(notes, 1)
        self.side.setFixedWidth(px(300))
        body.addWidget(self.side)
        root.addLayout(body, 1)
        return w

    def _lamp(self, ok, msg):
        self.lb_lamp.setObjectName("status_ok" if ok else "status_bad")
        st = self.lb_lamp.style()
        st.unpolish(self.lb_lamp); st.polish(self.lb_lamp)
        self.lb_lamp.setText(msg)

    def resizeEvent(self, e):
        self.side.setVisible(self.width() >= px(1400))
        super().resizeEvent(e)

    def on_enter(self):
        super().on_enter()
        self.show_desktop()
        name = self.ctx.prefs.get("user_name", "Student")
        self.user.name = self.cuser.name = name
        self.user.update(); self.cuser.update()
        self.hi.setText(f"Hi {name}!!")
        self.chi.setText(f"Hi {name}!!")
        self.dock.set_active("home")
        self.cdock.set_active("home")
        self.notes.clear()
        path = os.path.join(config.SAVE_DIR, "notes.txt")
        lines = []
        if os.path.exists(path):
            with open(path, encoding="utf-8", errors="replace") as f:
                lines = [ln.strip() for ln in f if ln.strip()][-14:]
        for ln in reversed(lines):
            when, _, rest = ln[1:].partition("] ")
            src, _, text = rest.partition(": ")
            it = QListWidgetItem(f"{src}  \u2022  {when[5:16]}\n{text[:90]}")
            it.setData(Qt.ItemDataRole.UserRole, text)
            self.notes.addItem(it)
        if not lines:
            self.notes.addItem("No notes yet. Saved text appears here.")

    def on_leave(self):
        super().on_leave()
        self.cut.deactivate()
        self.ctx.window.set_cutout(False)             # every other page is a normal opaque window

    def _note(self, item):
        text = item.data(Qt.ItemDataRole.UserRole)
        if text:
            self.ctx.pending_text = text
            self.ctx.go("reader")

    # ---- live clock inside the hero tile of the drawer ----
    def _tick(self, now):
        from ...core.clock import date_text
        self.clock_tile.subtitle = date_text(now) + "  \u2022  New Delhi"
        self.clock_tile.update()

    def _paint_clock(self, p, r):
        now = self.ctx.clock.now()
        h24 = self.ctx.clock.h24
        f = QFont(self.clock_tile.font())
        f.setPixelSize(int(max(px(28), min(r.height() * 0.30, r.width() * 0.13))))
        f.setBold(True)
        p.setFont(f)
        p.setPen(QColor("#FFFFFF"))
        txt = time_text(now, h24)
        x, y = r.left() + r.width() * 0.07, r.top() + r.height() * 0.42
        p.drawText(QPointF(x, y), txt)
        if not h24:
            w = p.fontMetrics().horizontalAdvance(txt)
            f2 = QFont(f); f2.setPixelSize(int(f.pixelSize() * 0.38))
            p.setFont(f2); p.setPen(QColor("#FF8A3D"))
            p.drawText(QPointF(x + w + px(8), y), ampm(now))
