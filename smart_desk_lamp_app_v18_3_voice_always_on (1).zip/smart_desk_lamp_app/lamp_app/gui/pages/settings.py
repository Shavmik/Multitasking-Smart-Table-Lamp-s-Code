"""Settings: lamp connection, touch calibration, voice, text-reader language, window."""
import os

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QCheckBox, QComboBox, QHBoxLayout, QLineEdit, QScrollArea, QSlider, QVBoxLayout, QWidget)

from ... import __version__, config
from ...core.ports import list_ports
from ..services import run_async
from ..theme import px
from ..fx import Banner
from ..widgets import GlassCard, label, make_button
from .base import Page


class SettingsPage(Page):
    key, title = "settings", "Settings"
    tft_names = ('lb_lamp', 'ports', 'b_refresh', 'b_connect', 'b_disc', 'b_cal')

    def tft_units(self):
        units = super().tft_units() or []
        toggle = self.tft_theme_toggle()                    # the Dark / Light switch of the top bar
        if toggle is not None and toggle.isVisible():
            units.append([(toggle, None)])
        return units or None

    def __init__(self, ctx):
        super().__init__(ctx)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        outer.addWidget(scroll)
        body = QWidget()
        scroll.setWidget(body)
        col = QVBoxLayout(body)
        col.setContentsMargins(0, 0, px(8), 0)
        col.setSpacing(self.gap())

        # ---- lamp ----
        c, l = self._card("Smart lamp")
        l.addWidget(Banner("fx/lamp_sketch.jpg", "cover", 200))
        self.lb_lamp = label("", wrap=True)
        l.addWidget(self.lb_lamp)
        row = QHBoxLayout()
        self.ports = QComboBox()
        self.ports.setMinimumWidth(px(320))
        self.b_refresh = make_button("Refresh", None, "reload")
        self.b_connect = make_button("Connect", "primary", "check")
        self.b_disc = make_button("Disconnect", None, "close")
        for w in (self.ports, self.b_refresh, self.b_connect, self.b_disc):
            row.addWidget(w)
        row.addStretch(1)
        l.addLayout(row)
        row2 = QHBoxLayout()
        self.b_cal = make_button("Calibrate the lamp's touch screen", None, "gear")
        row2.addWidget(self.b_cal)
        row2.addStretch(1)
        l.addLayout(row2)
        self.lb_cal = label("The lamp screen now shows the live camera and status; this app is the main control.", "dim", wrap=True)
        l.addWidget(self.lb_cal)
        col.addWidget(c)

        # ---- voice ----
        c, l = self._card("Voice (read aloud)")
        r = QHBoxLayout()
        r.addWidget(label("Speed", "h3"))
        self.s_rate = QSlider(Qt.Orientation.Horizontal); self.s_rate.setRange(90, 280)
        self.s_rate.setValue(int(ctx.speaker.rate))
        self.lb_rate = label(str(int(ctx.speaker.rate)), "dim")
        r.addWidget(self.s_rate, 1); r.addWidget(self.lb_rate)
        l.addLayout(r)
        r = QHBoxLayout()
        r.addWidget(label("Volume", "h3"))
        self.s_vol = QSlider(Qt.Orientation.Horizontal); self.s_vol.setRange(10, 100)
        self.s_vol.setValue(int(ctx.speaker.volume * 100))
        self.lb_vol = label(str(int(ctx.speaker.volume * 100)), "dim")
        r.addWidget(self.s_vol, 1); r.addWidget(self.lb_vol)
        l.addLayout(r)
        self.b_test = make_button("Test the voice", None, "speaker")
        l.addWidget(self.b_test, 0, Qt.AlignmentFlag.AlignLeft)
        l.addWidget(label("Voices come from Windows (Settings > Time & language > Speech). Install a Hindi voice there to hear Hindi text.", "dim", wrap=True))
        col.addWidget(c)

        # ---- OCR ----
        c, l = self._card("Text reader (OCR)")
        r = QHBoxLayout()
        r.addWidget(label("Languages", "h3"))
        self.ocr_lang = QComboBox()
        self.ocr_lang.addItem("English", "en")
        self.ocr_lang.addItem("Hindi + English", "hi,en")
        self.ocr_lang.setCurrentIndex(max(0, self.ocr_lang.findData(ctx.prefs.get("ocr_langs", "en"))))
        self.b_ocr = make_button("Apply and reload", None, "reload")
        r.addWidget(self.ocr_lang); r.addWidget(self.b_ocr); r.addStretch(1)
        l.addLayout(r)
        self.lb_ocr = label("", "dim", wrap=True)
        l.addWidget(self.lb_ocr)
        col.addWidget(c)

        # ---- window / files ----
        c, l = self._card("Window and files")
        r = QHBoxLayout()
        self.b_full = make_button("Full screen on / off  (F11)", None, "fullscreen")
        self.b_dir = make_button("Open the captures folder", None, "folder")
        r.addWidget(self.b_full); r.addWidget(self.b_dir); r.addStretch(1)
        l.addLayout(r)
        l.addWidget(label(f"Smart Desk Lamp {__version__}   \u2022   College ERP: {config.ERP_URL}", "dim", wrap=True))
        col.addWidget(c)

        # ---- appearance + text-reading engine + tools (new) ----
        c, l = self._card("Appearance")
        r = QHBoxLayout()
        self.b_dark = make_button("Dark mode", None, None)
        self.b_light = make_button("Light mode", None, None)
        self.b_dark.clicked.connect(lambda: ctx.window.set_theme("dark"))
        self.b_light.clicked.connect(lambda: ctx.window.set_theme("light"))
        r.addWidget(self.b_dark); r.addWidget(self.b_light); r.addStretch(1)
        l.addLayout(r)
        l.addWidget(label("Desktop style", "h3"))
        self.cb_style = QComboBox()
        self.cb_style.addItem("Cardboard cut-out - see your real Windows desktop through the holes", "cutout")
        self.cb_style.addItem("Classic - wallpaper drawn inside the app", "classic")
        self.cb_style.setCurrentIndex(max(0, self.cb_style.findData(ctx.prefs.get("desktop_style", "cutout"))))
        self.cb_style.currentIndexChanged.connect(self._style)
        l.addWidget(self.cb_style)
        self.ck_taskbar = QCheckBox("Hide the Windows taskbar while the cardboard desktop is showing")
        self.ck_taskbar.setChecked(bool(ctx.prefs.get("hide_taskbar", True)))
        self.ck_taskbar.toggled.connect(self._taskbar)
        l.addWidget(self.ck_taskbar)
        l.addWidget(label("Desktop wallpaper (classic style only)", "h3"))
        self.cb_wall = QComboBox()
        from .home import WALLPAPER_OPTIONS
        for v, (_, name) in WALLPAPER_OPTIONS.items():
            self.cb_wall.addItem(name, v)
        self.cb_wall.setCurrentIndex(max(0, self.cb_wall.findData(ctx.prefs.get("desktop_wallpaper", "city"))))
        self.cb_wall.currentIndexChanged.connect(self._wallpaper)
        l.addWidget(self.cb_wall)
        l.addWidget(label("Desktop centrepiece", "h3"))
        self.cb_centre = QComboBox()
        for v, name in {"gothic_rain": "Silent rain / gothic city (video loop)", "chibi": "Dancing character"}.items():
            self.cb_centre.addItem(name, v)
        self.cb_centre.setCurrentIndex(max(0, self.cb_centre.findData(ctx.prefs.get("desktop_centre", "gothic_rain"))))
        self.cb_centre.currentIndexChanged.connect(self._centre)
        l.addWidget(self.cb_centre)
        col.addWidget(c)

        c, l = self._card("Text reading engine (OCR)")
        self.cb_engine = QComboBox()
        for v, t in [("easyocr", "EasyOCR (best for photos, Hindi + English)"), ("tesseract", "Tesseract (fast, best for clean print)"),
                     ("both", "Both - keep the more confident result")]:
            self.cb_engine.addItem(t, v)
        self.cb_engine.setCurrentIndex(max(0, self.cb_engine.findData(ctx.prefs.get("ocr_engine", "easyocr"))))
        self.cb_engine.currentIndexChanged.connect(lambda: ctx.prefs.set("ocr_engine", self.cb_engine.currentData()))
        l.addWidget(self.cb_engine)
        self.ed_tess = QLineEdit(ctx.prefs.get("tesseract_cmd", ""))
        self.ed_tess.setPlaceholderText(r"Path to tesseract.exe (leave empty to use C:\Program Files\Tesseract-OCR)")
        self.ed_tess.editingFinished.connect(lambda: ctx.prefs.set("tesseract_cmd", self.ed_tess.text().strip()))
        self.b_tess = make_button("Test Tesseract", None, "check")
        self.lb_tess = label("", "dim", wrap=True)
        self.b_tess.clicked.connect(self._test_tess)
        for w in (self.ed_tess, self.b_tess, self.lb_tess):
            l.addWidget(w)
        col.addWidget(c)

        c, l = self._card("Chess engine and gaming mode")
        self.ed_sf = QLineEdit(ctx.prefs.get("stockfish_path", ""))
        self.ed_sf.setPlaceholderText("Path to stockfish.exe (optional - the built-in engine is used when empty)")
        self.ed_sf.editingFinished.connect(lambda: ctx.prefs.set("stockfish_path", self.ed_sf.text().strip()))
        self.ed_open = QLineEdit(ctx.prefs.get("gaming_open", ""))
        self.ed_open.setPlaceholderText("Apps to open when Gaming mode starts, e.g. steam, discord")
        self.ed_open.editingFinished.connect(lambda: ctx.prefs.set("gaming_open", self.ed_open.text().strip()))
        l.addWidget(self.ed_sf); l.addWidget(self.ed_open)
        col.addWidget(c)
        col.addStretch(1)

        self.b_refresh.clicked.connect(self.refresh_ports)
        self.b_connect.clicked.connect(self.connect_lamp)
        self.b_disc.clicked.connect(ctx.lamp.disconnect_lamp)
        self.b_cal.clicked.connect(self.calibrate)
        self.s_rate.valueChanged.connect(self._rate)
        self.s_vol.valueChanged.connect(self._vol)
        self.b_test.clicked.connect(lambda: ctx.speak("Hello. This is the Smart Desk Lamp voice."))
        self.b_ocr.clicked.connect(self.apply_ocr)
        self.b_full.clicked.connect(lambda: ctx.window.toggle_fullscreen())
        self.b_dir.clicked.connect(self.open_dir)
        ctx.lamp.status.connect(lambda ok, msg: self._status(ok, msg))
        ctx.ocr_state_changed.connect(lambda s, m: self.lb_ocr.setText(m))
        self.refresh_ports()
        self._status(ctx.lamp.connected, "Lamp connected" if ctx.lamp.connected else ("The lamp is not connected - the laptop camera is used." if ctx.lamp.has_camera else "The lamp is not connected."))

    def _card(self, title):
        card = GlassCard()
        lay = QVBoxLayout(card)
        m = px(20)
        lay.setContentsMargins(m, m, m, m)
        lay.setSpacing(px(10))
        lay.addWidget(label(title, "h2"))
        return card, lay

    def on_enter(self):
        self.refresh_ports()

    def refresh_ports(self):
        cur = self.ctx.prefs.get("lamp_port", "") or self.ctx.lamp.port
        self.ports.clear()
        self.ports.addItem("Automatic (find the lamp)", "")
        for dev, desc, _ in list_ports():
            self.ports.addItem(f"{dev}  -  {desc}", dev)
        self.ports.setCurrentIndex(max(0, self.ports.findData(cur or "")))

    def _status(self, ok, msg):
        self.lb_lamp.setObjectName("status_ok" if ok else "status_bad")
        st = self.lb_lamp.style()
        st.unpolish(self.lb_lamp); st.polish(self.lb_lamp)
        self.lb_lamp.setText(msg)
        self.b_disc.setEnabled(ok)
        self.b_cal.setEnabled(ok)

    def connect_lamp(self):
        port = self.ports.currentData() or None
        self.ctx.prefs.set("lamp_port", port or "")
        self.ctx.lamp.connect_lamp(port)

    def calibrate(self):
        board = self.ctx.lamp.board
        if board is None:
            return
        self.lb_cal.setText("Tap the tip of each arrow on the lamp screen with a finger or stylus...")
        self.b_cal.setEnabled(False)

        def done(_, err):
            self.b_cal.setEnabled(True)
            self.lb_cal.setText(f"Calibration failed: {err}" if err else "Calibration finished.")
        run_async(board.calibrate, done)

    def _rate(self, v):
        self.ctx.speaker.rate = v
        self.ctx.prefs.set("tts_rate", v)
        self.lb_rate.setText(str(v))

    def _vol(self, v):
        self.ctx.speaker.volume = v / 100.0
        self.ctx.prefs.set("tts_volume", v)
        self.lb_vol.setText(str(v))

    def _test_tess(self):
        from ...core.ocr_engine import tesseract_ready
        self.ctx.prefs.set("tesseract_cmd", self.ed_tess.text().strip())
        self.lb_tess.setText(tesseract_ready(self.ed_tess.text().strip())[1])

    def apply_ocr(self):
        v = self.ocr_lang.currentData()
        self.ctx.prefs.set("ocr_langs", v)
        config.LANGUAGES = v.split(",")
        self.ctx.reset_ocr()

    def _wallpaper(self):
        home = self.ctx.window.pages.get("home") if self.ctx.window else None
        if home:
            home.set_wallpaper(self.cb_wall.currentData())
        else:
            self.ctx.prefs.set("desktop_wallpaper", self.cb_wall.currentData())

    def _taskbar(self, on):
        self.ctx.prefs.set("hide_taskbar", bool(on))

    def _style(self):
        home = self.ctx.window.pages.get("home") if self.ctx.window else None
        if home:
            home.set_desktop_style(self.cb_style.currentData())
        else:
            self.ctx.prefs.set("desktop_style", self.cb_style.currentData())

    def _centre(self):
        home = self.ctx.window.pages.get("home") if self.ctx.window else None
        if home:
            home.set_centrepiece(self.cb_centre.currentData())
        else:
            self.ctx.prefs.set("desktop_centre", self.cb_centre.currentData())

    def open_dir(self):
        os.makedirs(config.SAVE_DIR, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.abspath(config.SAVE_DIR)))
