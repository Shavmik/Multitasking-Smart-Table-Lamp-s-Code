"""Instant translator: type, paste or load scanned text and the translation follows as you type."""
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import (QApplication, QComboBox, QHBoxLayout, QTextEdit, QVBoxLayout)

from ...core.textflow import save_note
from ...core.translate import LANGUAGES, translate
from ..services import run_async
from ..theme import px
from ..widgets import GlassCard, label, make_button
from .base import Page


class TranslatePage(Page):
    key, title = "translate", "Translator"

    def tft_units(self):
        return [self.tft_visible(self.src), self.tft_visible(self.tft_top(self.inp, px(100))),
                self.tft_visible(self.b_paste, self.b_last), self.tft_visible(self.b_clear, self.b_speak_in),
                self.tft_visible(self.dst), self.tft_visible(self.tft_top(self.out, px(100))),
                self.tft_visible(self.b_speak_out, self.b_stop)]

    def __init__(self, ctx):
        super().__init__(ctx)
        self._seq = 0
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(self.gap())

        # ---- input ----
        left = GlassCard()
        ll = QVBoxLayout(left)
        m = px(20)
        ll.setContentsMargins(m, m, m, m)
        ll.setSpacing(px(10))
        top = QHBoxLayout()
        top.addWidget(label("From", "h3"))
        self.src = QComboBox()
        self.src.addItem("Detect language", "auto")
        for n, c in LANGUAGES.items():
            self.src.addItem(n, c)
        top.addWidget(self.src, 1)
        ll.addLayout(top)
        self.inp = QTextEdit()
        self.inp.setAcceptRichText(False)
        self.inp.setPlaceholderText("Type or paste text - it is translated instantly...")
        ll.addWidget(self.inp, 1)
        row = QHBoxLayout()
        self.b_paste = make_button("Paste", None, "copy")
        self.b_last = make_button("Last scanned text", None, "ocr")
        self.b_clear = make_button("Clear", None, "trash")
        self.b_speak_in = make_button("Read", None, "speaker")
        for b in (self.b_paste, self.b_last, self.b_clear, self.b_speak_in):
            row.addWidget(b)
        row.addStretch(1)
        ll.addLayout(row)
        root.addWidget(left, 1)

        # ---- output ----
        right = GlassCard()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(m, m, m, m)
        rl.setSpacing(px(10))
        top2 = QHBoxLayout()
        top2.addWidget(label("To", "h3"))
        self.dst = QComboBox()
        for n, c in LANGUAGES.items():
            self.dst.addItem(n, c)
        self.dst.setCurrentIndex(max(0, self.dst.findData(ctx.prefs.get("target_lang", "hi"))))
        top2.addWidget(self.dst, 1)
        self.b_swap = make_button("Swap", None)
        top2.addWidget(self.b_swap)
        rl.addLayout(top2)
        self.out = QTextEdit()
        self.out.setReadOnly(True)
        self.out.setPlaceholderText("The translation appears here (and in the terminal).")
        rl.addWidget(self.out, 1)
        row2 = QHBoxLayout()
        self.b_speak_out = make_button("Read translation", "primary", "speaker")
        self.b_stop = make_button("Stop", None, "stop")
        self.b_copy = make_button("Copy", None, "copy")
        self.b_save = make_button("Save note", None, "save")
        for b in (self.b_speak_out, self.b_stop, self.b_copy, self.b_save):
            row2.addWidget(b)
        row2.addStretch(1)
        self.status = label("", "dim")
        row2.addWidget(self.status)
        rl.addLayout(row2)
        root.addWidget(right, 1)

        self._font()
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(650)
        self._timer.timeout.connect(self.run)
        self.inp.textChanged.connect(self._timer.start)
        self.dst.currentIndexChanged.connect(self._lang_changed)
        self.src.currentIndexChanged.connect(lambda _: self._timer.start())
        self.b_paste.clicked.connect(lambda: self.inp.insertPlainText(QApplication.clipboard().text()))
        self.b_last.clicked.connect(self._last)
        self.b_clear.clicked.connect(self.inp.clear)
        self.b_speak_in.clicked.connect(lambda: self._say(self.inp.toPlainText()))
        self.b_speak_out.clicked.connect(lambda: self._say(self.out.toPlainText()))
        self.b_stop.clicked.connect(ctx.stop_speaking)
        self.b_copy.clicked.connect(lambda: QApplication.clipboard().setText(self.out.toPlainText()))
        self.b_save.clicked.connect(self._save)
        self.b_swap.clicked.connect(self._swap)

    def _font(self):
        n = px(self.ctx.prefs.get("text_px", 22))
        self.inp.setStyleSheet(f"font-size: {n}px;")
        self.out.setStyleSheet(f"font-size: {n}px;")

    def on_enter(self):
        self._font()
        if self.ctx.pending_translate_text:
            self.inp.setPlainText(self.ctx.pending_translate_text)
            self.ctx.pending_translate_text = ""
        self.inp.setFocus()

    def _lang_changed(self):
        self.ctx.prefs.set("target_lang", self.dst.currentData())
        self._timer.start()

    def _last(self):
        if self.ctx.last_text:
            self.inp.setPlainText(self.ctx.last_text)
        else:
            self.status.setText("Nothing scanned yet.")

    def _say(self, text):
        if text.strip():
            self.ctx.speak(text)

    def _save(self):
        t = self.out.toPlainText().strip()
        if t:
            save_note(t, "Translation")
            self.status.setText("Saved in captures/notes.txt")

    def _swap(self):
        out, inp = self.out.toPlainText(), self.inp.toPlainText()
        d = self.dst.currentData()
        s = self.src.currentData()
        if s == "auto":
            self.status.setText("Choose a 'From' language first to swap.")
            return
        self.src.setCurrentIndex(self.src.findData(d))
        self.dst.setCurrentIndex(self.dst.findData(s))
        self.inp.setPlainText(out or inp)

    def run(self):
        text = self.inp.toPlainText().strip()
        if not text:
            self.out.clear()
            self.status.setText("")
            return
        self._seq += 1
        seq = self._seq
        code, name, src = self.dst.currentData(), self.dst.currentText(), self.src.currentData()
        self.status.setText("Translating...")

        def done(res, err):
            if seq != self._seq:
                return
            if err:
                self.status.setText(str(err))
                print(f"[translate] {err}")
                return
            self.out.setPlainText(res)
            self.ctx.last_text = text
            self.status.setText(f"Translated to {name}")
            print(f"\n----- Translation ({name}) -----\n{res}\n{'-' * 30}")

        run_async(lambda: translate(text, code, src), done)
