"""Chess: play the engine, analyse any FEN/PGN (e.g. copied from chess.com), open chess.com inside the app."""
from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPen
from PySide6.QtWidgets import (QCheckBox, QHBoxLayout, QLineEdit, QListWidget, QPlainTextEdit, QSlider, QVBoxLayout, QWidget,
                               QApplication)

from ..services import run_async
from ..theme import px, is_dark
from ..widgets import label, make_button
from ._ui import vcard
from .base import Page

try:
    import chess
    from ...core import chess_ai
    HAVE_CHESS = True
except ImportError:                                           # pragma: no cover
    HAVE_CHESS = False

GLYPH = {"k": "\u265A", "q": "\u265B", "r": "\u265C", "b": "\u265D", "n": "\u265E", "p": "\u265F"}


class BoardView(QWidget):
    moved = Signal(object)                                    # chess.Move

    def __init__(self, board):
        super().__init__()
        self.board, self.flip, self.sel, self.hint, self.last = board, False, None, None, None
        self.setMinimumSize(px(420), px(420))
        self.setSizePolicy(self.sizePolicy().horizontalPolicy(), self.sizePolicy().verticalPolicy())

    def _geom(self):
        s = min(self.width(), self.height())
        return (self.width() - s) / 2, (self.height() - s) / 2, s / 8

    def _sq(self, f, r):
        return chess.square(7 - f if self.flip else f, r if self.flip else 7 - r)

    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        x0, y0, c = self._geom()
        font = QFont("Segoe UI Symbol"); font.setPixelSize(int(c * 0.78)); p.setFont(font)
        legal_to = {m.to_square for m in self.board.legal_moves if self.sel is not None and m.from_square == self.sel}
        for r in range(8):
            for f in range(8):
                sq = self._sq(f, r)
                rect = QRectF(x0 + f * c, y0 + r * c, c, c)
                light = (f + r) % 2 == 0
                col = QColor("#EEEED2") if light else QColor("#769656")
                if self.last and sq in (self.last.from_square, self.last.to_square):
                    col = QColor("#F6F669") if light else QColor("#BACA2B")
                if self.hint and sq in (self.hint.from_square, self.hint.to_square):
                    col = QColor("#7DE3FF") if light else QColor("#3B9BFF")
                if sq == self.sel:
                    col = QColor("#F7C948")
                p.fillRect(rect, col)
                if sq in legal_to:
                    p.setBrush(QColor(20, 20, 30, 70)); p.setPen(Qt.PenStyle.NoPen)
                    p.drawEllipse(rect.center(), c * 0.13, c * 0.13)
                pc = self.board.piece_at(sq)
                if pc:
                    ch = GLYPH[pc.symbol().lower()]            # the solid glyph for both colours
                    if pc.color:                                # white piece: dark outline, white fill
                        p.setPen(QColor("#1b1b1b"))
                        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (1, 1), (-1, 1), (1, -1)):
                            p.drawText(rect.translated(dx * c * 0.012, dy * c * 0.012), Qt.AlignmentFlag.AlignCenter, ch)
                        p.setPen(QColor("#FFFFFF"))
                    else:
                        p.setPen(QColor("#111111"))
                    p.drawText(rect, Qt.AlignmentFlag.AlignCenter, ch)
        p.end()

    def mousePressEvent(self, e):
        x0, y0, c = self._geom()
        f, r = int((e.position().x() - x0) // c), int((e.position().y() - y0) // c)
        if not (0 <= f < 8 and 0 <= r < 8):
            return
        sq = self._sq(f, r)
        if self.sel is None:
            pc = self.board.piece_at(sq)
            if pc and pc.color == self.board.turn:
                self.sel = sq
        else:
            mv = chess.Move(self.sel, sq)
            pc = self.board.piece_at(self.sel)
            if pc and pc.piece_type == chess.PAWN and chess.square_rank(sq) in (0, 7):
                mv.promotion = chess.QUEEN
            if mv in self.board.legal_moves:
                self.sel = None
                self.moved.emit(mv)
            else:
                p2 = self.board.piece_at(sq)
                self.sel = sq if p2 and p2.color == self.board.turn else None
        self.hint = None
        self.update()


class ChessPage(Page):
    key, title = "chess", "Chess"
    tft_names = ('status', 'ck_ai', 'lv', 'view', ('b_new', 'b_undo', 'b_flip', 'b_hint'))

    def __init__(self, ctx):
        super().__init__(ctx)
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(self.gap())
        if not HAVE_CHESS:
            c, l = vcard("Chess needs one more library", "Run:  pip install chess")
            root.addWidget(c)
            return
        self.board = chess.Board()
        self.view = BoardView(self.board)
        self.view.moved.connect(self._player_move)
        c, l = vcard()
        l.addWidget(self.view, 1)
        root.addWidget(c, 3)

        c, l = vcard("Chess")
        self.status = label("", wrap=True)
        l.addWidget(self.status)
        self.ck_ai = QCheckBox("Play against the engine (you are White)"); self.ck_ai.setChecked(True)
        l.addWidget(self.ck_ai)
        r = QHBoxLayout(); r.addWidget(label("Engine level", "dim"))
        self.lv = QSlider(Qt.Orientation.Horizontal); self.lv.setRange(1, 4); self.lv.setValue(2)
        r.addWidget(self.lv, 1); l.addLayout(r)
        self.moves = QListWidget(); self.moves.setMaximumHeight(px(150)); l.addWidget(self.moves)
        row = QHBoxLayout()
        for text, fn, attr in [("New game", self.new, "b_new"), ("Undo", self.undo, "b_undo"), ("Flip", self.flip, "b_flip"),
                               ("Best move", self.show_hint, "b_hint")]:
            b = make_button(text); b.clicked.connect(fn); row.addWidget(b)
            setattr(self, attr, b)                           # also shown on the lamp screen
        l.addLayout(row)
        self.pos = QPlainTextEdit(); self.pos.setPlaceholderText("Paste a FEN or a PGN here (for example the PGN of your chess.com game)")
        self.pos.setMaximumHeight(px(90)); l.addWidget(self.pos)
        row = QHBoxLayout()
        b = make_button("Load position", "primary", "open"); b.clicked.connect(self.load)
        b2 = make_button("Copy FEN", None, "copy"); b2.clicked.connect(lambda: QApplication.clipboard().setText(self.board.fen()))
        row.addWidget(b); row.addWidget(b2); l.addLayout(row)
        b = make_button("Open chess.com in the app", "green", "globe"); b.clicked.connect(self.open_site)
        l.addWidget(b); l.addStretch(1)
        c.setMaximumWidth(px(420))
        root.addWidget(c, 1)
        self._refresh()

    # ---- game flow ----
    def _stockfish(self):
        return self.ctx.prefs.get("stockfish_path", "")

    def _player_move(self, mv):
        self.board.push(mv); self.view.last = mv; self._refresh()
        if self.ck_ai.isChecked() and not self.board.is_game_over() and self.board.turn == chess.BLACK:
            self.status.setText("Engine is thinking...")
            fen = self.board.fen(); depth = self.lv.value() + 1
            run_async(lambda: chess_ai.best_move(chess.Board(fen), depth, self._stockfish()), self._engine_done)

    def _engine_done(self, res, err):
        if err or not res or res[0] is None:
            return self.status.setText(f"Engine problem: {err}")
        if self.board.turn == chess.BLACK:
            self.board.push(res[0]); self.view.last = res[0]
        self._refresh()

    def _refresh(self):
        b = self.board
        self.moves.clear()
        tmp = b.root()
        for i, m in enumerate(b.move_stack):
            self.moves.addItem(f"{i // 2 + 1}{'.' if i % 2 == 0 else '...'} {tmp.san(m)}"); tmp.push(m)
        self.moves.scrollToBottom()
        if b.is_checkmate():
            self.status.setText("Checkmate - " + ("Black" if b.turn else "White") + " wins.")
        elif b.is_game_over():
            self.status.setText("Draw (" + (b.outcome().termination.name.replace("_", " ").lower() if b.outcome() else "") + ").")
        else:
            self.status.setText(("White" if b.turn else "Black") + " to move" + ("  -  check!" if b.is_check() else ""))
        self.view.sel = None; self.view.update()

    def new(self):
        self.board = chess.Board(); self.view.board = self.board
        self.view.last = self.view.hint = None; self._refresh()

    def undo(self):
        for _ in range(2 if self.ck_ai.isChecked() and len(self.board.move_stack) >= 2 else 1):
            if self.board.move_stack:
                self.board.pop()
        self.view.last = self.board.peek() if self.board.move_stack else None; self.view.hint = None; self._refresh()

    def flip(self):
        self.view.flip = not self.view.flip; self.view.update()

    def show_hint(self):
        if self.board.is_game_over():
            return
        self.status.setText("Looking for the best move...")
        fen = self.board.fen(); depth = self.lv.value() + 1

        def done(res, err):
            if err or not res or res[0] is None:
                return self.status.setText(f"Engine problem: {err}")
            mv, score, name = res
            self.view.hint = mv; self.view.update()
            self.status.setText(f"Best move: {chess.Board(fen).san(mv)}   (score {score:+.1f}, {name})")
        run_async(lambda: chess_ai.best_move(chess.Board(fen), depth, self._stockfish()), done)

    def load(self):
        try:
            b = chess_ai.load_position(self.pos.toPlainText())
        except Exception as e:                                # noqa: BLE001
            return self.status.setText(f"Could not load it: {e}")
        self.board = b
        self.view.board = b
        self.view.last = b.peek() if b.move_stack else None
        self.view.hint = None
        self._refresh()

    def open_site(self):
        from .websearch import HAVE_WEB
        if HAVE_WEB:
            self.ctx.pending_url = "https://www.chess.com/play/online"; self.ctx.go("web")
        else:
            import webbrowser
            webbrowser.open("https://www.chess.com/play/online")
