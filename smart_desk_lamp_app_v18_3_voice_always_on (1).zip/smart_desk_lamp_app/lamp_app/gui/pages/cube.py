"""Rubik's cube solver: scan the 6 faces under the lamp, check what was understood, get the moves."""
import os
from collections import deque
from datetime import datetime

import cv2
import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QComboBox, QHBoxLayout, QSlider, QStackedWidget, QVBoxLayout, QWidget)

from ... import config
from ...core.cube_solver import solve_cube
from ...features.rubiks import (CUBE_FAR_SIDE, FACE_NAMES, FACELET_ORDER, FAR_SIDE_ROT, FROM_START_TEXT,
                                SCAN_ORDER, STEP_TEXT, classify_cube, describe_move, grid_box,
                                orient_grid, sample_face)
from ..services import run_async
from ..theme import px
from ..widgets import CameraView, GlassCard, NetView, label, make_button
from ..fx import Cube3D
from .base import Page


def _card_layout(card):
    lay = QVBoxLayout(card)
    m = px(20)
    lay.setContentsMargins(m, m, m, m)
    lay.setSpacing(px(10))
    return lay


class CubePage(Page):
    key, title, uses_camera = "cube", "Cube solver", True
    # scan step / review step / solution step: only the controls of the step that is open are shown
    tft_names = ('lb_step', 'net_scan', ('b_scan', 'b_undo', 'b_restart'),
                 'net_understood', ('b_solve', 'b_rescan', 'b_cancel'),
                 'lb_count', 'lb_move', ('b_prev', 'b_next', 'b_say'), 'b_again')

    def __init__(self, ctx):
        super().__init__(ctx)
        self.faces, self.raw = {}, {}
        self.queue = list(SCAN_ORDER)
        self.rescan = False
        self.recent = deque(maxlen=3)
        self.geo = {"frac": 0.5, "dx": 0.0, "dy": 0.0}
        self.mode = "scan"
        self.facelets, self.moves, self.step = None, [], 0
        self.session = os.path.join(config.SAVE_DIR, datetime.now().strftime("cube_%Y%m%d_%H%M%S"))

        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(self.gap())

        # ---- left: camera and the guide grid controls ----
        left = QVBoxLayout()
        left.setSpacing(px(10))
        self.cam = CameraView()
        left.addWidget(self.cam, 1)
        sl = GlassCard(radius=18)
        sll = QHBoxLayout(sl)
        sll.setContentsMargins(px(16), px(10), px(16), px(10))
        self.s_size = self._slider(20, 95, int(self.geo["frac"] * 100))
        self.s_dx = self._slider(-40, 40, 0)
        self.s_dy = self._slider(-40, 40, 0)
        for text, s in (("Grid size", self.s_size), ("Left / right", self.s_dx), ("Up / down", self.s_dy)):
            sll.addWidget(label(text, "dim"))
            sll.addWidget(s, 1)
        left.addWidget(sl)
        root.addLayout(left, 5)

        # ---- right: three steps in a stack ----
        self.stack = QStackedWidget()
        root.addWidget(self.stack, 4)
        self.stack.addWidget(self._build_scan())
        self.stack.addWidget(self._build_review())
        self.stack.addWidget(self._build_solution())

        self.bind_camera(self.cam, self._frame)
        for s in (self.s_size, self.s_dx, self.s_dy):
            s.valueChanged.connect(self._geo_changed)
        self._refresh_scan()

    @staticmethod
    def _slider(lo, hi, v):
        s = QSlider(Qt.Orientation.Horizontal)
        s.setRange(lo, hi)
        s.setValue(v)
        return s

    # ------------------------------------------------------------------ views
    def _build_scan(self):
        card = GlassCard()
        lay = _card_layout(card)
        self.lb_step = label("", "h2")
        lay.addWidget(self.lb_step)
        self.lb_help = label("", wrap=True)
        lay.addWidget(self.lb_help)
        self.cube_idle = Cube3D()                       # shiny exploded cube that plays by itself
        lay.addWidget(self.cube_idle, 2)
        self.net_scan = NetView()
        lay.addWidget(self.net_scan, 1)
        row = QHBoxLayout()
        row.addWidget(label("Far side of the desk is the", "dim"))
        self.far = QComboBox()
        for text, k in (("top of the video", "u"), ("bottom of the video", "d"), ("left of the video", "l"), ("right of the video", "r")):
            self.far.addItem(text, k)
        self.far.setCurrentIndex(max(0, self.far.findData(self.ctx.prefs.get("cube_far", CUBE_FAR_SIDE))))
        row.addWidget(self.far, 1)
        lay.addLayout(row)
        btns = QHBoxLayout()
        self.b_scan = make_button("Scan this face", "primary", "camera")
        self.b_scan.setMinimumHeight(px(54))
        self.b_undo = make_button("Undo", None, "back")
        self.b_restart = make_button("Start over", None, "reload")
        btns.addWidget(self.b_scan, 2); btns.addWidget(self.b_undo, 1); btns.addWidget(self.b_restart, 1)
        lay.addLayout(btns)
        self.lb_scan_msg = label("", "dim", wrap=True)
        lay.addWidget(self.lb_scan_msg)
        self.b_scan.clicked.connect(self.scan)
        self.b_undo.clicked.connect(self.undo)
        self.b_restart.clicked.connect(self.reset)
        self.far.currentIndexChanged.connect(lambda _: self.ctx.prefs.set("cube_far", self.far.currentData()))
        return card

    def _build_review(self):
        card = GlassCard()
        lay = _card_layout(card)
        lay.addWidget(label("Check what was understood", "h2"))
        self.lb_review = label("", wrap=True)
        lay.addWidget(self.lb_review)
        self.cube_rev = Cube3D()                        # drag to turn it and compare with your real cube
        self.cube_rev.setMinimumHeight(px(170))
        lay.addWidget(self.cube_rev, 2)
        lay.addWidget(label("Measured by the camera  (click a face to mark it for rescanning)", "dim"))
        self.net_measured = NetView()
        self.net_measured.selectable = True
        lay.addWidget(self.net_measured, 1)
        lay.addWidget(label("Understood by the solver  (compare with your real cube)", "dim"))
        self.net_understood = NetView()
        lay.addWidget(self.net_understood, 1)
        btns = QHBoxLayout()
        self.b_solve = make_button("It matches - solve it", "green", "check")
        self.b_solve.setMinimumHeight(px(54))
        self.b_rescan = make_button("Rescan marked faces", "orange", "camera")
        self.b_cancel = make_button("Start over", None, "reload")
        btns.addWidget(self.b_solve, 2); btns.addWidget(self.b_rescan, 2); btns.addWidget(self.b_cancel, 1)
        lay.addLayout(btns)
        self.b_solve.clicked.connect(self.solve)
        self.b_rescan.clicked.connect(self.rescan_marked)
        self.b_cancel.clicked.connect(self.reset)
        return card

    def _build_solution(self):
        card = GlassCard()
        lay = _card_layout(card)
        lay.addWidget(label("Solution", "h2"))
        self.lb_start = label("Start with the first scanned face on TOP and the front face toward you.", "dim", wrap=True)
        lay.addWidget(self.lb_start)
        self.lb_count = label("", "h3", align=Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self.lb_count)
        self.lb_move = label("", align=Qt.AlignmentFlag.AlignCenter)
        self.lb_move.setStyleSheet(f"font-size: {px(64)}px; font-weight: 800; color: #34D399;")
        self.cube_sol = Cube3D()                        # turns the layer for every move
        lay.addWidget(self.cube_sol, 4)
        lay.addWidget(self.lb_move, 1)
        self.lb_desc = label("", "h3", wrap=True, align=Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self.lb_desc)
        self.lb_all = label("", "dim", wrap=True)
        lay.addWidget(self.lb_all)
        btns = QHBoxLayout()
        self.b_prev = make_button("Previous", None, "back")
        self.b_next = make_button("Next move", "primary", "forward")
        self.b_next.setMinimumHeight(px(54))
        self.b_say = make_button("Read aloud", None, "speaker")
        self.b_again = make_button("Scan another cube", None, "reload")
        btns.addWidget(self.b_prev); btns.addWidget(self.b_next, 2); btns.addWidget(self.b_say)
        lay.addLayout(btns)
        lay.addWidget(self.b_again)
        self.b_prev.clicked.connect(lambda: self._goto(self.step - 1))
        self.b_next.clicked.connect(lambda: self._goto(self.step + 1))
        self.b_say.clicked.connect(self._say_move)
        self.b_again.clicked.connect(self.reset)
        return card

    # ------------------------------------------------------------------ camera / guide grid
    def _geo_changed(self):
        self.geo["frac"] = self.s_size.value() / 100.0
        self.geo["dx"] = self.s_dx.value() / 100.0
        self.geo["dy"] = self.s_dy.value() / 100.0
        self._show_grid()

    def _show_grid(self):
        if self.mode != "scan":
            self.cam.set_grid(None)
            return
        h, w = (self.last_frame.shape[:2]) if self.last_frame is not None else (240, 320)
        self.cam.set_grid(grid_box(w, h, self.geo))

    def _frame(self, img):
        self.recent.append(img)
        self._show_grid()

    def on_enter(self):
        super().on_enter()
        self._show_grid()

    # ------------------------------------------------------------------ scanning
    def far_k(self):
        return FAR_SIDE_ROT[self.far.currentData()]

    def _refresh_scan(self):
        self.mode = "scan"
        self.stack.setCurrentIndex(0)
        face = self.queue[0]
        done = len(self.faces)
        if self.rescan:
            self.lb_step.setText(f"Rescan  {FACE_NAMES[face]} ({face})")
            self.lb_help.setText(FROM_START_TEXT[face])
        else:
            self.lb_step.setText(f"Face {done + 1} of 6:  {FACE_NAMES[face]} ({face})")
            self.lb_help.setText(STEP_TEXT[face])
        self.net_scan.set_faces(dict(self.faces), current=face)
        self.b_undo.setEnabled(not self.rescan and done > 0)
        self._show_grid()

    def scan(self):
        if not self.recent:
            self.lb_scan_msg.setText("No picture from the camera yet. Check that the lamp is connected (or that the laptop camera is allowed).")
            return
        face = self.queue[0]
        frames = list(self.recent)
        self.faces[face] = orient_grid(sample_face(frames, self.geo), self.far_k(), face)
        self.raw[face] = frames[-1].copy()
        self._save_raw(face)
        print(f"  face {face} ({FACE_NAMES[face]}) scanned")
        self.queue.pop(0)
        self.lb_scan_msg.setText("")
        if self.queue:
            self._refresh_scan()
        else:
            self.rescan = False
            self._review()

    def undo(self):
        if self.rescan or not self.faces:
            return
        last = SCAN_ORDER[len(self.faces) - 1]
        self.faces.pop(last, None)
        self.queue.insert(0, last)
        self._refresh_scan()

    def reset(self):
        self.faces.clear(); self.raw.clear()
        self.queue = list(SCAN_ORDER)
        self.rescan = False
        self.facelets, self.moves, self.step = None, [], 0
        self.cube_sol.show_metal(); self.cube_rev.show_metal()
        self.session = os.path.join(config.SAVE_DIR, datetime.now().strftime("cube_%Y%m%d_%H%M%S"))
        self.lb_scan_msg.setText("")
        self._refresh_scan()

    def _save_raw(self, face):
        os.makedirs(self.session, exist_ok=True)
        cv2.imwrite(os.path.join(self.session, f"face_{face}.jpg"), self.raw[face])

    # ------------------------------------------------------------------ review
    def _review(self):
        self.mode = "review"
        self.stack.setCurrentIndex(1)
        self.cam.set_grid(None)
        self.net_measured.selected.clear()
        self.net_measured.set_faces(dict(self.faces))
        try:
            self.facelets, labels = classify_cube(self.faces)
        except ValueError as e:
            self.facelets = None
            self.lb_review.setText(str(e) + "\nClick the faces to rescan and press 'Rescan marked faces'.")
            self.net_understood.set_faces({})
            self.b_solve.setEnabled(False)
            return
        understood = {f: np.array([[self.faces[labels[f][r][c]][1, 1] for c in range(3)] for r in range(3)])
                      for f in FACELET_ORDER}
        self.net_understood.set_faces(understood)
        self.cube_rev.show_cube(self.facelets)
        self.lb_review.setText("Does the lower picture match your real cube?  If yes, press Solve. "
                               "If a sticker is wrong, click that face above and rescan it.")
        self.b_solve.setEnabled(True)

    def rescan_marked(self):
        marked = [f for f in FACELET_ORDER if f in self.net_measured.selected]
        if not marked:
            self.lb_review.setText("Click the face(s) you want to rescan in the top picture first.")
            return
        self.queue, self.rescan = marked, True
        self._refresh_scan()

    # ------------------------------------------------------------------ solving
    def solve(self):
        if not self.facelets:
            return
        if self.facelets == "".join(f * 9 for f in FACELET_ORDER):
            self.lb_review.setText("This cube is already solved!")
            return
        self.b_solve.setEnabled(False)
        self.lb_review.setText("Solving... (it searches for a short solution for a few seconds)")
        print("\nSolving... (it searches for a short solution for a few seconds)")
        facelets = self.facelets
        run_async(lambda: solve_cube(facelets), self._solved)

    def _solved(self, moves, err):
        self.b_solve.setEnabled(True)
        if err or not moves:
            why = f"This is not a possible cube: {err}" if isinstance(err, ValueError) else f"The solver failed: {err}"
            self.lb_review.setText(why + "\nThis almost always means one colour was read wrong or a face was scanned "
                                         "in the wrong orientation. Rescan the faces with even light and no glare.")
            return
        self.moves, self.step = moves, 0
        self.cube_sol.show_cube(self.facelets, moves)
        print(f"\nSOLUTION ({len(moves)} moves):\n\n   " + " ".join(moves) + "\n")
        os.makedirs(self.session, exist_ok=True)
        with open(os.path.join(self.session, "solution.txt"), "w") as fh:
            fh.write(f"cube: {self.facelets}\nmoves ({len(moves)}): {' '.join(moves)}\n")
        self.mode = "solution"
        self.stack.setCurrentIndex(2)
        self.lb_all.setText("All moves:  " + "  ".join(moves) +
                            "\nLetter = face (U top, D bottom, F front, B back, L left, R right).  "
                            "Plain = clockwise quarter turn, ' = counter-clockwise, 2 = half turn.")
        self._goto(0)

    def _goto(self, i):
        n = len(self.moves)
        i = max(0, min(n, i))
        self.step = i
        self.cube_sol.goto(i)
        if i < n:
            self.lb_count.setText(f"Move {i + 1} of {n}")
            self.lb_move.setText(self.moves[i])
            self.lb_desc.setText(describe_move(self.moves[i]))
            self.b_next.setText("Next move")
        else:
            self.lb_count.setText("All done")
            self.lb_move.setText("Solved!")
            self.lb_desc.setText("")
            self.b_next.setText("Finish")
        self.b_prev.setEnabled(i > 0)

    def _say_move(self):
        if self.step < len(self.moves):
            self.ctx.speak(describe_move(self.moves[self.step]))
