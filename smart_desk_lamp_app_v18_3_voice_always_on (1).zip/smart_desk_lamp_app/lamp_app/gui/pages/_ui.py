"""Small layout helpers shared by the new pages."""
from PySide6.QtWidgets import QVBoxLayout

from ..theme import px
from ..widgets import GlassCard, label


def vcard(title=None, sub=None, margin=20, spacing=10):
    """A glass card with a vertical layout (and an optional heading) -> (card, layout)."""
    c = GlassCard()
    l = QVBoxLayout(c)
    l.setContentsMargins(px(margin), px(margin - 3), px(margin), px(margin - 3))
    l.setSpacing(px(spacing))
    if title:
        l.addWidget(label(title, "h2"))
    if sub:
        l.addWidget(label(sub, "dim", wrap=True))
    return c, l


def restyle(widget):
    st = widget.style()
    st.unpolish(widget)
    st.polish(widget)
