import cv2
import numpy as np
from PySide6.QtCore import QBuffer, QByteArray, QIODevice


def qimage_to_bgr(qi):
    """QImage -> OpenCV BGR array (goes through PNG: slow-ish but works with every Qt binding)."""
    ba = QByteArray()
    buf = QBuffer(ba)
    buf.open(QIODevice.OpenModeFlag.WriteOnly)
    qi.save(buf, "PNG")
    buf.close()
    arr = np.frombuffer(bytes(ba.data()), np.uint8)
    return cv2.imdecode(arr, cv2.IMREAD_COLOR)


def read_image_file(path):
    """cv2.imread that also works with non-ASCII Windows paths."""
    data = np.fromfile(path, np.uint8)
    return cv2.imdecode(data, cv2.IMREAD_COLOR)
