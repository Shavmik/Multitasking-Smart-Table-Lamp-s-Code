"""Reusable glass-style widgets: cards, art tiles, sidebar buttons, camera view, cube net."""
import cv2
import numpy as np
from PySide6.QtCore import Qt, QRectF, QPointF, QSize, Signal
from PySide6.QtGui import (QColor, QFont, QImage, QLinearGradient, QPainter, QPainterPath, QPen,
                           QPixmap, QRadialGradient)
from PySide6.QtWidgets import QAbstractButton, QFrame, QLabel, QPushButton, QSizePolicy, QWidget

from . import theme
from .icons import art_pixmap, draw_icon, has_icon
from .theme import px

AA = QPainter.RenderHint.Antialiasing
SMOOTH = QPainter.RenderHint.SmoothPixmapTransform


def rounded(rect, radius):
    path = QPainterPath()
    path.addRoundedRect(rect, radius, radius)
    return path


def make_button(text="", variant=None, icon=None, tooltip=None, parent=None):
    b = QPushButton(text, parent)
    if variant:
        b.setProperty("variant", variant)
    if icon:
        b.setIcon(icon_qicon(icon))
        b.setIconSize(QSize(px(20), px(20)))
    if tooltip:
        b.setToolTip(tooltip)
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    return b


def icon_qicon(kind, color=None, size=64):
    color = color or theme.icon_on()
    from PySide6.QtGui import QIcon
    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    draw_icon(p, kind, QRectF(size * .1, size * .1, size * .8, size * .8), color, 0.09)
    p.end()
    return QIcon(pm)


def label(text="", name=None, wrap=False, align=None):
    lb = QLabel(text)
    if name:
        lb.setObjectName(name)
    lb.setWordWrap(wrap)
    if align:
        lb.setAlignment(align)
    return lb


class GlassCard(QFrame):
    """A translucent rounded panel."""

    def __init__(self, parent=None, radius=22, strength=1.0):
        super().__init__(parent)
        self._radius = radius
        self._strength = strength

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(.5, .5, -.5, -.5)
        g = QLinearGradient(r.topLeft(), r.bottomRight())
        if theme.is_dark():
            g.setColorAt(0, QColor(255, 255, 255, int(30 * self._strength)))
            g.setColorAt(1, QColor(255, 255, 255, int(11 * self._strength)))
        else:                                       # light: white cards with a soft edge, like the reference
            g.setColorAt(0, QColor(255, 255, 255, int(235 * min(1, self._strength))))
            g.setColorAt(1, QColor(255, 255, 255, int(190 * min(1, self._strength))))
        path = rounded(r, px(self._radius))
        p.fillPath(path, g)
        p.setPen(QPen(QColor(255, 255, 255, 46) if theme.is_dark() else QColor(20, 20, 30, 30), 1))
        p.drawPath(path)


class Background(QWidget):
    """Window background: gradient + coloured light blobs, cached as a pixmap."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._pm = None
        self._key = None

    def paintEvent(self, e):
        dpr = self.devicePixelRatioF()
        key = (self.width(), self.height(), dpr, theme.MODE)
        if key != self._key:
            self._pm = theme.background_pixmap(self.width(), self.height(), dpr)
            self._key = key
        p = QPainter(self)
        p.drawPixmap(0, 0, self._pm)


class ArtTile(QAbstractButton):
    """Dashboard tile: dark glass, accent glow, art on the right (or a vector icon badge)."""
    fx_ripple = True

    def __init__(self, title, subtitle="", accent="purple", art=None, icon=None, parent=None):
        super().__init__(parent)
        self.title, self.subtitle = title, subtitle
        self.accent = QColor(theme.ACCENT.get(accent, accent))
        self.art_name = art
        self.icon_kind = icon
        self.extra = None                       # optional callable(painter, rect) for live content
        self._hover = False
        self._cache = (None, None)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMouseTracking(True)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMinimumSize(px(150), px(112))
        self.setToolTip(title)

    def enterEvent(self, e):
        self._hover = True
        self.update()

    def leaveEvent(self, e):
        self._hover = False
        self.update()

    def _art(self, box, dpr):
        key = (box.width(), box.height(), dpr)
        if self._cache[0] != key:
            src = art_pixmap(self.art_name)
            pm = src.scaled(int(box.width() * dpr), int(box.height() * dpr),
                            Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            pm.setDevicePixelRatio(dpr)
            self._cache = (key, pm)
        return self._cache[1]

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        p.setRenderHint(SMOOTH)
        down = self.isDown()
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        if down:
            r = r.adjusted(2, 2, -2, -2)
        h, w = r.height(), r.width()
        path = rounded(r, px(26))
        p.fillPath(path, QColor(18, 16, 36, 205))
        glow = QRadialGradient(r.topRight() if self.art_name else r.topLeft(), w * 0.95)
        c1 = QColor(self.accent); c1.setAlpha(120 if self._hover else 84)
        c0 = QColor(self.accent); c0.setAlpha(0)
        glow.setColorAt(0, c1); glow.setColorAt(1, c0)
        p.fillPath(path, glow)

        p.save()
        p.setClipPath(path)
        if self.art_name:
            pm = art_pixmap(self.art_name)
            ratio = pm.width() / max(1, pm.height())
            ah = h * 0.86
            aw = ah * ratio
            if aw > w * 0.62:
                aw = w * 0.62
                ah = aw / ratio
            box = QRectF(r.right() - aw - w * 0.03, r.bottom() - ah - h * 0.06, aw, ah)
            p.drawPixmap(box.topLeft(), self._art(box.size().toSize(), self.devicePixelRatioF()))
        elif self.icon_kind:
            side = min(h * 0.40, w * 0.34)
            badge = QRectF(r.left() + w * 0.07, r.top() + h * 0.10, side, side)
            gg = QLinearGradient(badge.topLeft(), badge.bottomRight())
            a, b = QColor(self.accent), QColor(self.accent).darker(150)
            gg.setColorAt(0, a); gg.setColorAt(1, b)
            p.fillPath(rounded(badge, side * 0.3), gg)
            draw_icon(p, self.icon_kind, badge.adjusted(side * .2, side * .2, -side * .2, -side * .2), "#FFFFFF", 0.085)
        fade = QLinearGradient(0, r.bottom() - h * 0.6, 0, r.bottom())
        fade.setColorAt(0, QColor(8, 6, 20, 0)); fade.setColorAt(1, QColor(8, 6, 20, 215))
        p.fillRect(r, fade)
        if self.extra:
            self.extra(p, r)
        p.restore()

        p.setPen(QPen(QColor(255, 255, 255, 96 if self._hover else 52), 1.2))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPath(path)
        if self.hasFocus():
            p.setPen(QPen(QColor("#B9A8FF"), 2))
            p.drawPath(rounded(r.adjusted(2, 2, -2, -2), px(24)))

        pad = w * 0.07
        tsize = max(px(15), min(px(30), h * 0.135))
        f = QFont(self.font()); f.setPixelSize(int(tsize)); f.setBold(True)
        p.setFont(f)
        p.setPen(QColor("#FFFFFF"))
        ty = r.bottom() - h * 0.07
        if self.subtitle:
            sf = QFont(self.font()); sf.setPixelSize(int(max(px(11), tsize * 0.55)))
            p.setFont(sf); p.setPen(QColor(255, 255, 255, 170))
            p.drawText(QPointF(r.left() + pad, ty), self.subtitle)
            ty -= tsize * 1.0
            p.setFont(f); p.setPen(QColor("#FFFFFF"))
        p.drawText(QPointF(r.left() + pad, ty), self.title)


class NavButton(QAbstractButton):
    """Sidebar button: vector icon or a round picture, highlighted pill when selected."""

    def __init__(self, tip, icon=None, art=None, parent=None):
        super().__init__(parent)
        self.icon_kind, self.art_name = icon, art
        self.setCheckable(True)
        self.setToolTip(tip)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setFixedSize(px(46), px(46))
        self._hover = False
        self.setMouseTracking(True)

    def enterEvent(self, e):
        self._hover = True; self.update()

    def leaveEvent(self, e):
        self._hover = False; self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA); p.setRenderHint(SMOOTH)
        r = QRectF(self.rect()).adjusted(3, 3, -3, -3)
        if self.isChecked():
            g = QLinearGradient(r.topLeft(), r.bottomRight())
            g.setColorAt(0, QColor(139, 92, 246, 235)); g.setColorAt(1, QColor(59, 130, 246, 235))
            p.fillPath(rounded(r, px(17)), g)
        elif self._hover:
            p.fillPath(rounded(r, px(17)), theme.fg_color(34))
        inner = r.adjusted(r.width() * .2, r.height() * .2, -r.width() * .2, -r.height() * .2)
        if self.art_name:
            side = inner.width()
            pm = art_pixmap(self.art_name).scaled(int(side * 2 * self.devicePixelRatioF()), int(side * 2 * self.devicePixelRatioF()),
                                                  Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            pm.setDevicePixelRatio(self.devicePixelRatioF())
            sz = pm.size() / self.devicePixelRatioF()
            p.drawPixmap(QPointF(inner.center().x() - sz.width() / 2, inner.center().y() - sz.height() / 2), pm)
        elif self.icon_kind:
            draw_icon(p, self.icon_kind, inner, theme.icon_on() if self.isChecked() else theme.icon_off(), 0.09)


class IconButton(QAbstractButton):
    """Round/rounded button with a vector icon (transport controls, toolbar)."""
    fx_ripple = True

    def __init__(self, kind, tip="", size=44, filled=False, parent=None):
        super().__init__(parent)
        self.kind, self.filled = kind, filled
        self.setToolTip(tip)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setFixedSize(px(size), px(size))
        self._hover = False
        self.setMouseTracking(True)

    def enterEvent(self, e):
        self._hover = True; self.update()

    def leaveEvent(self, e):
        self._hover = False; self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(2, 2, -2, -2)
        if self.isDown():
            r = r.adjusted(2, 2, -2, -2)
        if self.filled:
            g = QLinearGradient(r.topLeft(), r.bottomRight())
            g.setColorAt(0, QColor("#9D74FF")); g.setColorAt(1, QColor("#3B82F6"))
            p.setBrush(g); p.setPen(Qt.PenStyle.NoPen); p.drawEllipse(r)
        else:
            p.setBrush(theme.fg_color(52 if self._hover else 26))
            p.setPen(QPen(theme.fg_color(50), 1)); p.drawEllipse(r)
        col = theme.icon_on() if self.isEnabled() else "#8c8ca5"
        draw_icon(p, self.kind, r.adjusted(r.width() * .22, r.height() * .22, -r.width() * .22, -r.height() * .22), col, 0.09)
        if self.hasFocus():
            p.setBrush(Qt.BrushStyle.NoBrush); p.setPen(QPen(QColor("#B9A8FF"), 2)); p.drawEllipse(r.adjusted(-1, -1, 1, 1))


class CameraView(QWidget):
    """Live picture, scaled smoothly, with crisp vector overlays (QR outline, cube guide grid)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMinimumSize(px(320), px(240))
        self._frame = None
        self._qi = None
        self._img_rect = QRectF()
        self._poly = None
        self._grid = None            # (x0, y0, side) in image pixels
        self._msg = "Waiting for the camera..."
        self._badge = ""

    def set_message(self, text):
        self._msg = text
        if self._frame is None:
            self.update()

    def set_badge(self, text):
        self._badge = text
        self.update()

    def clear(self, msg=None):
        self._frame = self._qi = None
        if msg is not None:
            self._msg = msg
        self.update()

    def set_polygon(self, pts):
        self._poly = pts
        self.update()

    def set_grid(self, box):
        self._grid = box
        self.update()

    def set_frame(self, bgr):
        self._frame = bgr
        self._rebuild()
        self.update()

    def resizeEvent(self, e):
        self._rebuild()

    def _rebuild(self):
        f = self._frame
        if f is None or self.width() < 10:
            return
        m = px(8)
        aw, ah = self.width() - 2 * m, self.height() - 2 * m
        ih, iw = f.shape[:2]
        k = min(aw / iw, ah / ih)
        dw, dh = max(1, int(iw * k)), max(1, int(ih * k))
        dpr = self.devicePixelRatioF()
        tw, th = max(1, int(dw * dpr)), max(1, int(dh * dpr))
        inter = cv2.INTER_CUBIC if tw > iw else cv2.INTER_AREA
        rgb = np.ascontiguousarray(cv2.cvtColor(cv2.resize(f, (tw, th), interpolation=inter), cv2.COLOR_BGR2RGB))
        qi = QImage(rgb.data, tw, th, tw * 3, QImage.Format.Format_RGB888).copy()
        qi.setDevicePixelRatio(dpr)
        self._qi = qi
        self._img_rect = QRectF((self.width() - dw) / 2, (self.height() - dh) / 2, dw, dh)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA); p.setRenderHint(SMOOTH)
        r = QRectF(self.rect()).adjusted(.5, .5, -.5, -.5)
        card = rounded(r, px(22))
        p.fillPath(card, QColor(0, 0, 0, 120))
        if self._qi is None:
            p.setPen(QColor(255, 255, 255, 150))
            f = QFont(self.font()); f.setPixelSize(px(16)); p.setFont(f)
            p.drawText(r.adjusted(px(24), 0, -px(24), 0), int(Qt.AlignmentFlag.AlignCenter) | int(Qt.TextFlag.TextWordWrap), self._msg)
        else:
            p.save()
            p.setClipPath(rounded(self._img_rect, px(16)))
            p.drawImage(self._img_rect.topLeft(), self._qi)
            p.restore()
            ir = self._img_rect
            iw, ih = self._frame.shape[1], self._frame.shape[0]
            k = ir.width() / iw
            if self._grid:
                x0, y0, s = self._grid
                gx, gy, gs = ir.left() + x0 * k, ir.top() + y0 * k, s * k
                pen = QPen(QColor(52, 255, 160, 235), 2.4); p.setPen(pen)
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawRoundedRect(QRectF(gx, gy, gs, gs), 6, 6)
                pen.setWidthF(1.2); p.setPen(pen)
                for i in (1, 2):
                    p.drawLine(QPointF(gx + gs * i / 3, gy), QPointF(gx + gs * i / 3, gy + gs))
                    p.drawLine(QPointF(gx, gy + gs * i / 3), QPointF(gx + gs, gy + gs * i / 3))
                p.setBrush(QColor(255, 235, 59)); p.setPen(Qt.PenStyle.NoPen)
                for rr in range(3):
                    for cc in range(3):
                        p.drawEllipse(QPointF(gx + gs * (cc + .5) / 3, gy + gs * (rr + .5) / 3), 3.5, 3.5)
            if self._poly is not None and len(self._poly) >= 3:
                pts = [QPointF(ir.left() + float(x) * k, ir.top() + float(y) * k) for x, y in self._poly]
                path = QPainterPath(pts[0])
                for pt in pts[1:]:
                    path.lineTo(pt)
                path.closeSubpath()
                p.setPen(QPen(QColor(52, 255, 160), 4, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                p.setBrush(QColor(52, 255, 160, 40))
                p.drawPath(path)
        if self._badge:
            f = QFont(self.font()); f.setPixelSize(px(13)); f.setBold(True); p.setFont(f)
            tw = p.fontMetrics().horizontalAdvance(self._badge) + px(24)
            br = QRectF(r.left() + px(16), r.top() + px(14), tw, px(28))
            p.fillPath(rounded(br, px(14)), QColor(0, 0, 0, 150))
            p.setPen(QColor("#FFFFFF"))
            p.drawText(br, int(Qt.AlignmentFlag.AlignCenter), self._badge)


class NetView(QWidget):
    """The unfolded cube (U on top, L F R B in the middle, D below) painted from sticker colours."""

    POS = {"U": (1, 0), "L": (0, 1), "F": (1, 1), "R": (2, 1), "B": (3, 1), "D": (1, 2)}
    faceToggled = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.faces = {}
        self.selectable = False
        self.selected = set()
        self.current = None
        self.setMinimumSize(px(240), px(180))
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.setCursor(Qt.CursorShape.ArrowCursor)

    def set_faces(self, faces, current=None):
        self.faces = faces
        self.current = current
        self.update()

    def _cell(self):
        return max(4.0, min(self.width() / 12.4, self.height() / 9.4))

    def _origin(self, cell):
        return (self.width() - cell * 12) / 2, (self.height() - cell * 9) / 2

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        cell = self._cell()
        ox, oy = self._origin(cell)
        gap = max(1.0, cell * .06)
        for f, (fx, fy) in self.POS.items():
            g = self.faces.get(f)
            for r in range(3):
                for c in range(3):
                    x, y = ox + (fx * 3 + c) * cell, oy + (fy * 3 + r) * cell
                    rect = QRectF(x + gap, y + gap, cell - 2 * gap, cell - 2 * gap)
                    col = QColor(70, 70, 90, 150) if g is None else QColor(int(g[r][c][2]), int(g[r][c][1]), int(g[r][c][0]))
                    p.setBrush(col); p.setPen(QPen(QColor(0, 0, 0, 120), 1))
                    p.drawRoundedRect(rect, cell * .16, cell * .16)
            fr = QRectF(ox + fx * 3 * cell, oy + fy * 3 * cell, cell * 3, cell * 3)
            if f == self.current:
                p.setBrush(Qt.BrushStyle.NoBrush); p.setPen(QPen(QColor("#34D399"), 3))
                p.drawRoundedRect(fr, cell * .2, cell * .2)
            if f in self.selected:
                p.setBrush(Qt.BrushStyle.NoBrush); p.setPen(QPen(QColor("#FF8A3D"), 3.5))
                p.drawRoundedRect(fr, cell * .2, cell * .2)

    def mousePressEvent(self, e):
        if not self.selectable:
            return
        cell = self._cell()
        ox, oy = self._origin(cell)
        pos = e.position()
        for f, (fx, fy) in self.POS.items():
            if QRectF(ox + fx * 3 * cell, oy + fy * 3 * cell, cell * 3, cell * 3).contains(pos):
                if f in self.selected:
                    self.selected.discard(f)
                else:
                    self.selected.add(f)
                self.update()
                self.faceToggled.emit(f)
                return
