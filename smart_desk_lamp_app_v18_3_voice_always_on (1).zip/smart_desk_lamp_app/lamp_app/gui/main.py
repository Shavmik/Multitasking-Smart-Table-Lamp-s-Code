"""Starts the new full-screen interface."""
import atexit
import sys

# Qt WebEngine (the ERP page) must be imported BEFORE the QApplication exists.
try:
    from PySide6 import QtWebEngineWidgets  # noqa: F401
except Exception:                                       # noqa: BLE001 - ERP page falls back to the browser
    pass
from PySide6.QtCore import QCoreApplication, Qt
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import QApplication

from .. import config
from . import fx, theme
from .services import AppContext, init_dispatcher
from .window import MainWindow
from ..core.winutil import set_taskbar_visible


def run(args):
    QCoreApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)
    QGuiApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication(sys.argv[:1])
    app.setApplicationName("Smart Desk Lamp")
    app.setOrganizationName("SmartDeskLamp")
    theme.set_scale(app.primaryScreen().availableGeometry().height() / 900.0)
    init_dispatcher()
    ctx = AppContext(args)
    theme.set_mode(ctx.prefs.get("theme", "dark"))
    app.setStyleSheet(theme.build_qss())
    fx.install_button_fx(app)                           # shine + ripple + busy loader on every button
    config.LANGUAGES = ctx.prefs.get("ocr_langs", "en").split(",")
    win = MainWindow(ctx)
    from .voicelink import VoiceLink
    ctx.voice = VoiceLink(ctx)                           # lets the voice listener wake / steer this app
    set_taskbar_visible(True)                           # in case an earlier run ended without giving the taskbar back
    win.present()                                       # true full screen (F11 toggles it) - or the cardboard cut-out desktop
    win._was_max = False

    from ..core.winutil import hide_console, show_console
    hide_console()                                      # the PowerShell/cmd window that launched us stays
                                                          # running (so errors can still be printed) but is hidden
    _prev_hook = sys.excepthook

    def _hook(etype, value, tb):
        show_console()                                   # an unhandled error: bring the console back so it's visible
        _prev_hook(etype, value, tb)
    sys.excepthook = _hook
    atexit.register(set_taskbar_visible, True)
    app.aboutToQuit.connect(lambda: (set_taskbar_visible(True), ctx.modes.stop(silent=True), ctx.stop_speaking(), ctx.lamp.shutdown()))

    if not getattr(args, "no_lamp", False):
        port = getattr(args, "port", None) or ctx.prefs.get("lamp_port", "") or None
        ctx.lamp.connect_lamp(port)
    print("Smart Desk Lamp is running. Results of reading / translating are also printed here.")
    try:
        return app.exec()
    except Exception:
        from ..core.winutil import show_console
        show_console()                                   # bring the console back so a crash is still visible
        raise
