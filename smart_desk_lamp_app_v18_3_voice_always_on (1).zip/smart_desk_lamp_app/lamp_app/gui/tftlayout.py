"""Re-flows the main controls of a page so they fill the lamp's small 320x240 screen.

Why: a page's controls are often one wide, short strip (e.g. the Settings connection row is ~830 x 150 px).
Scaling such a strip down to 320 px wide leaves a thin line of unreadable text.  Instead every control
("tile") is cut out separately and the tiles are packed into several rows, so the whole screen is used and
the text stays as big as possible.

No Qt in here: tiles are plain (w, h) sizes, so this file can be tested on its own.

A *unit* is a list of tile sizes that must stay together in one row (a single control = a unit with one tile).
Units keep their order; the packer decides where the rows break (best = biggest scale).
"""
from itertools import product

GAP = 6          # TFT pixels between tiles
MARGIN = 4       # TFT pixels around everything
MAX_SCALE = 1.7  # do not blow small things up more than this (they get blurry)


def _unit_size(unit, gap_src):
    w = sum(t[0] for t in unit) + gap_src * (len(unit) - 1)
    h = max(t[1] for t in unit)
    return w, h


def _best_split(sizes, W, H, gap, margin, max_scale):
    """Try every way of cutting the ordered units into rows; return (scale, rows) with the biggest scale."""
    n = len(sizes)
    best = None
    for cuts in product((0, 1), repeat=n - 1):
        rows, cur = [], [0]
        for i, c in enumerate(cuts, start=1):
            if c:
                rows.append(cur)
                cur = []
            cur.append(i)
        rows.append(cur)
        aw, ah = W - 2 * margin, H - 2 * margin
        s = max_scale
        total_h = 0
        for r in rows:
            rw = sum(sizes[i][0] for i in r)
            rh = max(sizes[i][1] for i in r)
            fixed = gap * (len(r) - 1)
            if rw <= 0 or rh <= 0:
                continue
            s = min(s, (aw - fixed) / rw)
            total_h += rh
        s = min(s, (ah - gap * (len(rows) - 1)) / max(1, total_h))
        # prefer fewer rows when the scale is practically the same
        key = (round(s, 2), -len(rows))
        if best is None or key > best[0]:
            best = (key, s, rows)
    return best[1], best[2]


def pack(units, W=320, H=240, gap=GAP, margin=MARGIN, max_scale=MAX_SCALE, gap_src=8, reserve_bottom=0):
    """units: list of units, each a list of (w, h) tile sizes in source pixels.

    Returns (scale, placements) where placements[u][t] = (x, y, w, h) in TFT pixels for tile t of unit u.
    `reserve_bottom` keeps that many TFT rows free (the small camera box on camera pages).
    """
    units = [u for u in units if u]
    if not units:
        return 1.0, []
    H_use = H - reserve_bottom
    sizes = [_unit_size(u, gap_src) for u in units]
    s, rows = _best_split(sizes, W, H_use, gap, margin, max_scale)
    # row geometry in TFT pixels
    row_info = []
    for r in rows:
        rw = sum(sizes[i][0] * s for i in r) + gap * (len(r) - 1)
        rh = max(sizes[i][1] * s for i in r)
        row_info.append((rw, rh))
    block_h = sum(h for _, h in row_info) + gap * (len(rows) - 1)
    y = margin + max(0, (H_use - 2 * margin - block_h) / 2)
    placed = {}
    for r, (rw, rh) in zip(rows, row_info):
        x = max(margin, (W - rw) / 2)
        for i in r:
            uw, uh = sizes[i]
            ux = x
            unit = units[i]
            # tiles of one unit side by side, centred on the row's height
            inner = sum(t[0] for t in unit) * s + gap_src * s * (len(unit) - 1)
            ux = x + (uw * s - inner) / 2
            tiles = []
            for t in unit:
                tw, th = t[0] * s, t[1] * s
                tiles.append((int(round(ux)), int(round(y + (rh - th) / 2)), max(1, int(round(tw))), max(1, int(round(th)))))
                ux += tw + gap_src * s
            placed[i] = tiles
            x += uw * s + gap
        y += rh + gap
    return s, [placed[i] for i in range(len(units))]
