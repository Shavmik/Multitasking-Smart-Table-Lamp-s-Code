"""Everything the main-menu search bar can find: pages and quick actions, with extra keywords."""
# key, title, one-line description, keywords
PAGES = [
    ("home", "Home", "Main menu", "dashboard menu start"),
    ("modes", "Modes", "Study, Focus and Gaming modes with app and website blocking", "study focus gaming block distraction discord steam youtube instagram notifications dnd"),
    ("timers", "Timers & Tracker", "Stopwatch, countdown timer, activity tracker", "stopwatch timer pomodoro tracker lap countdown alarm time ocr"),
    ("planner", "Smart Planner", "Timetable, time estimates and AI day plan (scikit-learn)", "schedule timetable estimate plan ai learn tasks homework ml"),
    ("gaming", "Gaming hub", "Rubik's cube, chess and sudoku solvers", "games play puzzle rubik chess sudoku"),
    ("cube", "Rubik's cube solver", "Scan 6 faces and solve step by step", "rubik cube solve puzzle"),
    ("chess", "Chess", "Play the engine, analyse a position, open chess.com", "chess.com board stockfish fen pgn analyse"),
    ("sudoku", "Sudoku solver", "Type or scan a sudoku and solve it", "sudoku puzzle grid solve numbers"),
    ("web", "Google Search", "Google inside the app (also opens when you search scanned text)", "google search browser web internet lens"),
    ("osiris", "Osiris AI", "Assistant chat and Osiris dashboard", "ai assistant chat osiris llm ollama ask"),
    ("ocr", "Read text", "Scan printed text with Tesseract / EasyOCR", "ocr scan read picture tesseract easyocr text camera"),
    ("reader", "Read aloud", "Big-text reader for low vision", "speak tts voice read aloud"),
    ("translate", "Translator", "Instant translation", "translate language hindi english"),
    ("qr", "QR scanner", "Scan and open links", "qr code scan link"),
    ("hand", "Handwriting", "Write, then read", "handwriting pen draw write"),
    ("calc", "Calculator", "Sums and history", "calculator math sum"),
    ("clock", "Clock (IST)", "India Standard Time", "clock time ist date"),
    ("spotify", "Spotify", "Open and control music", "music song play spotify"),
    ("erp", "College ERP", "erp.psit.ac.in", "college erp attendance psit"),
    ("profile", "Profile", "Level, XP, badges and study stats", "profile level xp badges stats name steam"),
    ("settings", "Settings", "Lamp, voice, OCR engine, theme", "settings lamp port voice ocr engine tesseract path theme dark light"),
]
ACTIONS = [
    ("action:dark", "Switch to Dark mode", "Theme", "theme night black"),
    ("action:light", "Switch to Light mode", "Theme", "theme day white bright"),
    ("action:study", "Start Study mode", "Blocks distractions", "begin on study"),
    ("action:focus", "Start Focus mode", "Blocks distractions", "begin on focus pomodoro"),
    ("action:gaming", "Start Gaming mode", "Unlocks the games", "begin on gaming play"),
    ("action:normal", "Stop current mode", "Back to normal", "end off stop"),
]


def search(query, limit=7):
    q = query.strip().lower()
    if not q:
        return []
    scored = []
    for key, title, desc, kw in PAGES + ACTIONS:
        tl = title.lower()
        score = 0
        if tl.startswith(q):
            score = 100
        elif q in tl:
            score = 80
        elif any(w.startswith(q) for w in kw.split()):
            score = 60
        elif q in kw or q in desc.lower():
            score = 40
        elif all(part in (tl + " " + kw + " " + desc.lower()) for part in q.split()):
            score = 30
        if score:
            scored.append((score, key, title, desc))
    scored.sort(key=lambda r: -r[0])
    return [(k, t, d) for _, k, t, d in scored[:limit]]
