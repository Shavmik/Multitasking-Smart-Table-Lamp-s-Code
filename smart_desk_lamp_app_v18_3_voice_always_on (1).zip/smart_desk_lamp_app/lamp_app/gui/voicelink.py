"""The app's side of the voice control: a tiny server on 127.0.0.1 (this computer only) that the voice listener talks to."""
from PySide6.QtCore import QObject, Qt, QTimer
from PySide6.QtNetwork import QHostAddress, QTcpServer
from PySide6.QtWidgets import QApplication

from .. import config
from ..tftui.engine import FEATURES
from ..voice.protocol import parse


class VoiceLink(QObject):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.server = QTcpServer(self)
        self.ok = self.server.listen(QHostAddress.SpecialAddress.LocalHost, config.VOICE_PORT)
        if self.ok:
            self.server.newConnection.connect(self._accept)
        else:
            print(f"[voice] port {config.VOICE_PORT} is busy: voice commands cannot reach this app ({self.server.errorString()})")

    def _accept(self):
        while self.server.hasPendingConnections():
            sock = self.server.nextPendingConnection()
            sock.readyRead.connect(lambda s=sock: self._read(s))
            sock.disconnected.connect(sock.deleteLater)

    def _read(self, sock):
        replied = False
        while sock.canReadLine():
            line = bytes(sock.readLine()).decode("utf-8", "replace").strip()
            sock.write((self.handle(line) + "\n").encode("utf-8"))
            replied = True
        if replied:
            sock.flush()
            sock.disconnectFromHost()

    # ------------------------------------------------------------------ commands
    def handle(self, line):
        verb, arg = parse(line)
        if verb is None:
            return "ERR unknown command"
        if verb == "PING":
            return "PONG"
        ctx = self.ctx
        print(f"[voice] {verb} {arg}".strip())
        try:
            if verb == "SLEEP":
                ctx.lamp.display(False)
                return "OK"
            if verb == "QUIT":
                QTimer.singleShot(200, QApplication.quit)
                return "OK"
            if not ctx.lamp.screen_on:                           # any other command wakes the lamp screen
                ctx.lamp.display(True)
            if verb == "WAKE":
                self._to_front()
                return "OK"
            if verb == "MODE":
                ctx.set_mode(arg)
                self._refresh()
                return "OK"
            if verb == "GO":
                return self._go(arg)
            if verb == "TAP":
                ui = ctx.tft.ui
                if ui is None:
                    return "ERR no lamp interface"
                ui._activate(arg)
                self._refresh()
                return "OK"
        except Exception as e:                                   # noqa: BLE001 - tell the listener, keep the app running
            print(f"[voice] {verb} {arg}: {e}")
            return f"ERR {e}"
        return "ERR"

    def _go(self, name):
        ui = self.ctx.tft.ui
        if ui is None:
            return "ERR no lamp interface"
        if name == "home":
            ui._activate("home")
        else:
            index = next((i for i, f in enumerate(FEATURES) if name in (f[4], f[3])), None)
            if index is None:
                return "ERR no such screen"
            ui._activate(f"tile{index}")                         # same as touching that tile on the lamp
        self._refresh()
        return "OK"

    def _refresh(self):
        link = self.ctx.tft
        if hasattr(link, "_native_refresh"):
            link._native_refresh()

    def _to_front(self):
        win = self.ctx.window
        if win is None:
            return
        if win.isMinimized():
            win.setWindowState((win.windowState() & ~Qt.WindowState.WindowMinimized) | Qt.WindowState.WindowActive)
        win.raise_()
        win.activateWindow()
