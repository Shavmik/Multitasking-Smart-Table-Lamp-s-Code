"""Main window: glass sidebar, top bar, page stack. Opens in true full screen; F11 toggles it."""
from PySide6.QtCore import QEvent, Qt
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import (QApplication, QButtonGroup, QHBoxLayout, QLabel, QLineEdit, QListWidget, QMainWindow,
                               QPushButton, QStackedWidget, QVBoxLayout, QWidget)

from ..core.clock import ampm, time_text
from .pages.calculator import CalculatorPage
from .pages.clock_page import ClockPage
from .pages.cube import CubePage
from .pages.erp import ErpPage
from .pages.handwriting import HandwritingPage
from .pages.home import HomePage
from .pages.ocr import OcrPage
from .pages.qr import QrPage
from .pages.reader import ReaderPage
from .pages.chess_page import ChessPage
from .pages.gaming import GamingPage
from .pages.modes import ModesPage
from .pages.osiris import OsirisPage
from .pages.planner import PlannerPage
from .pages.settings import SettingsPage
from .pages.sudoku import SudokuPage
from .pages.timers import TimersPage
from .pages.websearch import WebSearchPage
from .pages.spotify import SpotifyPage
from .pages.translate_page import TranslatePage
from . import registry, theme
from ..core.timers import fmt_hms
from .theme import px
from .widgets import Background, GlassCard, IconButton, NavButton, label
from .fx import ExpandSearch, GlassToggle, GlowNav, Loader, busy_hub
from .pages.profile import ProfilePage
from PySide6.QtCore import QPropertyAnimation
from PySide6.QtWidgets import QGraphicsOpacityEffect

# key, tooltip, vector icon, picture  (the sidebar; every other page opens from Home, the search bar or a hub)
NAV = [("home", "Home", "home", None), ("modes", "Modes", "check", None), ("timers", "Timers & Tracker", "clock", None),
       ("planner", "Smart Planner", "folder", None), ("gaming", "Gaming hub", None, "art_cube.png"),
       ("osiris", "Osiris AI", "translate", None), ("ocr", "Read text", "ocr", None), ("web", "Google Search", "search", None),
       ("translate", "Translator", None, "art_translate.png"), ("calc", "Calculator", "calc", None),
       ("clock", "Clock (IST)", None, "art_clock.png"), ("settings", "Settings", "gear", None)]
GAME_PAGES = {"gaming", "cube", "chess", "sudoku"}


class MainWindow(QMainWindow):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        ctx.window = self
        ctx.go = self.go
        self.setWindowTitle("Smart Desk Lamp")
        self.setMinimumSize(px(1000), px(620))
        self._was_max = True
        self._cutout = False                 # True while Home shows the cardboard cut-out desktop (see set_cutout)
        self._restore = "full"               # how to show the window again when the cut-out ends
        self._normal_geo = None

        central = Background()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        m = px(18)
        self._root = root
        self._margin = m
        root.setContentsMargins(m, m, m, m)
        root.setSpacing(px(16))

        # ---- sidebar ----
        side = GlassCard(radius=28)
        side.setFixedWidth(px(74))
        self.side = side
        sl = QVBoxLayout(side)
        sl.setContentsMargins(px(8), px(12), px(8), px(12))
        sl.setSpacing(px(4))
        self.group = QButtonGroup(self)
        self.group.setExclusive(True)
        self.nav = {}
        for key, tip, icon, art in NAV:
            b = GlowNav(tip, icon, art)
            b.clicked.connect(lambda _=False, k=key: self.go(k))
            self.group.addButton(b)
            sl.addWidget(b, 0, Qt.AlignmentFlag.AlignHCenter)
            self.nav[key] = b
        sl.addStretch(1)
        root.addWidget(side)

        # ---- right side ----
        col = QVBoxLayout()
        col.setSpacing(px(14))
        self.topbar = QWidget()
        top = QHBoxLayout(self.topbar)
        top.setContentsMargins(0, 0, 0, 0)
        self.lb_title = label("Home", "h1")
        top.addWidget(self.lb_title)
        top.addStretch(1)
        self.searchbar = ExpandSearch("Search features...   Ctrl+K")      # search button that grows into the bar (Ctrl+K)
        self.search = self.searchbar.edit
        top.addWidget(self.searchbar)
        top.addStretch(1)
        self.busy = Loader("circle", 26)                  # spins while any background job runs
        self.busy.setToolTip("Working...")
        self.busy.setVisible(False)
        busy_hub().changed.connect(lambda n: self.busy.setVisible(n > 0))
        top.addWidget(self.busy)
        self.b_mode = QPushButton("")
        self.b_mode.setObjectName("chip")
        self.b_mode.setCursor(Qt.CursorShape.PointingHandCursor)
        self.b_mode.clicked.connect(lambda: self.go("modes"))
        top.addWidget(self.b_mode)
        self.t_theme = GlassToggle(theme.is_dark())       # animated glass light / dark switch
        self.t_theme.modeRequested.connect(self.set_theme)
        top.addWidget(self.t_theme)
        self.lb_time = QLabel("")
        self.lb_time.setObjectName("chip")
        top.addWidget(self.lb_time)
        self.b_lamp = QPushButton("Lamp: not connected")
        self.b_lamp.setObjectName("chip")
        self.b_lamp.setCursor(Qt.CursorShape.PointingHandCursor)
        self.b_lamp.clicked.connect(lambda: self.go("settings"))
        top.addWidget(self.b_lamp)
        self.b_full = IconButton("fullscreen", "Full screen (F11)", 42)
        self.b_full.clicked.connect(self.toggle_fullscreen)
        top.addWidget(self.b_full)
        col.addWidget(self.topbar)
        self.stack = QStackedWidget()
        col.addWidget(self.stack, 1)
        root.addLayout(col, 1)

        self.hidden_nav = GlowNav("", None, None)       # selected when the page has no sidebar button
        self.hidden_nav.setVisible(False)
        self.group.addButton(self.hidden_nav)
        self.results = QListWidget(central)             # floating search results
        self.results.setVisible(False)
        self.results.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.results.itemClicked.connect(lambda it: self._pick(it.data(Qt.ItemDataRole.UserRole)))
        self.search.textChanged.connect(self._search)
        self.search.returnPressed.connect(self._search_enter)
        self.search.installEventFilter(self)
        QShortcut(QKeySequence("Ctrl+K"), self, activated=self._open_search)

        self.pages = {}
        for cls in (HomePage, ModesPage, TimersPage, PlannerPage, GamingPage, CubePage, ChessPage, SudokuPage, OsirisPage,
                    OcrPage, WebSearchPage, ReaderPage, TranslatePage, QrPage, HandwritingPage,
                    CalculatorPage, ClockPage, SpotifyPage, ErpPage, ProfilePage, SettingsPage):
            page = cls(ctx)
            self.pages[page.key] = page
            self.stack.addWidget(page)
        self.current = None

        QShortcut(QKeySequence("F11"), self, activated=self.toggle_fullscreen)
        ctx.clock.tick.connect(self._tick)
        ctx.lamp.status.connect(self._lamp)
        self._tick(ctx.clock.now())
        self._lamp(False, "")
        ctx.mode_changed.connect(lambda m: self._mode_chip())
        self.t_theme.set_dark(theme.is_dark(), animate=False)
        self._mode_chip()
        self._fades = []
        self.go("home")

    # ---- navigation ----
    def go(self, key):
        if key == self.current and key == "home":          # e.g. picked 'Home' after the search bar opened the plain window
            self.pages["home"].show_desktop()
            return
        if key == self.current or key not in self.pages:
            return
        if key in GAME_PAGES and not self.ctx.modes.allows_games():     # Study / Focus lock the games
            self.ctx.modes.notify("Locked", f"Games are locked in {self.ctx.modes.current.title()} mode.")
            key = "modes"
        old = self.pages.get(self.current)
        cut_before = self._cutout
        snap = None
        if old and key not in ("erp", "web") and self.current not in ("erp", "web"):
            snap = self.stack.grab()
        if old:
            old.on_leave()
        page = self.pages[key]
        self.current = key
        self.stack.setCurrentWidget(page)
        self.lb_title.setText(page.title)
        (self.nav.get(key) or self.hidden_nav).setChecked(True)
        page.on_enter()
        if snap is not None and cut_before == self._cutout:      # no fade when the window itself changed shape
            self._fade_over(snap, self.stack.geometry(), 260)
        self.ctx.tft.start(page, self.centralWidget())   # the TFT shows the page's main controls; touches work

    # ---- theme ----
    def _fade_over(self, pm, geo, ms):
        """Shows the old picture on top and fades it away (page change, light/dark change)."""
        lb = QLabel(self.centralWidget())
        lb.setPixmap(pm)
        lb.setGeometry(geo)
        lb.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        eff = QGraphicsOpacityEffect(lb)
        lb.setGraphicsEffect(eff)
        lb.show(); lb.raise_()
        a = QPropertyAnimation(eff, b"opacity", lb)
        a.setDuration(ms); a.setStartValue(1.0); a.setEndValue(0.0)
        self._fades.append(a)
        def fin():
            lb.deleteLater()
            if a in self._fades:
                self._fades.remove(a)
        a.finished.connect(fin)
        a.start()

    def set_theme(self, mode):
        snap = None if self._cutout else self.centralWidget().grab()
        theme.set_mode(mode)
        self.ctx.prefs.set("theme", mode)
        QApplication.instance().setStyleSheet(theme.build_qss())
        for wdg in QApplication.allWidgets():
            wdg.update()
        self.t_theme.set_dark(theme.is_dark())
        if snap is not None:
            self._fade_over(snap, self.centralWidget().rect(), 520)

    def _mode_chip(self):
        m = self.ctx.modes.current
        self.b_mode.setText("Mode: Normal" if m == "normal" else f"\u25CF {m.title()} mode")
        self.b_mode.setStyleSheet("" if m == "normal" else "color:#34D399;" if m == "gaming" else "color:#FFC83D;")

    # ---- menu search bar ----
    def _search(self, text):
        hits = registry.search(text)
        self.results.clear()
        if not hits:
            self.results.setVisible(False)
            return
        for key, title, desc in hits:
            it = self.results.addItem(f"{title}\n{desc}")
            item = self.results.item(self.results.count() - 1)
            item.setData(Qt.ItemDataRole.UserRole, key)
        self.results.setCurrentRow(0)
        p = self.searchbar.mapTo(self.centralWidget(), self.searchbar.rect().bottomLeft())
        self.results.setGeometry(p.x(), p.y() + px(6), max(self.searchbar.width(), px(380)), px(58) * self.results.count() + px(12))
        self.results.raise_()
        self.results.setVisible(True)

    def _search_enter(self):
        it = self.results.currentItem()
        if it:
            self._pick(it.data(Qt.ItemDataRole.UserRole))

    def _pick(self, key):
        self.results.setVisible(False)
        self.searchbar.close_()
        if key.startswith("action:"):
            act = key.split(":")[1]
            if act in ("dark", "light"):
                self.set_theme(act)
            else:
                self.ctx.set_mode(act)
                self.go("gaming" if act == "gaming" else "modes")
        else:
            self.go(key)

    def eventFilter(self, obj, ev):
        if obj is self.search and ev.type() == QEvent.Type.KeyPress and self.results.isVisible():
            k = ev.key()
            if k in (Qt.Key.Key_Down, Qt.Key.Key_Up):
                row = self.results.currentRow() + (1 if k == Qt.Key.Key_Down else -1)
                self.results.setCurrentRow(max(0, min(self.results.count() - 1, row)))
                return True
            if k == Qt.Key.Key_Escape:
                self.results.setVisible(False)
                return True
        return super().eventFilter(obj, ev)

    # ---- full screen ----
    def toggle_fullscreen(self):
        if self._cutout:                          # the cardboard desktop sizes the window itself
            return
        if self.isFullScreen():
            (self.showMaximized if self._was_max else self.showNormal)()
        else:
            self._was_max = self.isMaximized()
            self.showFullScreen()

    # ---- cardboard cut-out desktop ----
    def _open_search(self):
        if self._cutout:                          # the search bar lives in the top bar, which the cut-out hides
            home = self.pages.get("home")
            if home:
                home.leave_cutout_temp()
        self.searchbar.open()
        self.search.selectAll()

    def _chrome(self, on):
        """Sidebar + top bar + margins: on for normal pages, off while the cardboard desktop is shown."""
        self.side.setVisible(on)
        self.topbar.setVisible(on)
        m = self._margin if on else 0
        self._root.setContentsMargins(m, m, m, m)

    def set_cutout(self, on):
        """on=True: true full screen (so the taskbar is covered / hidden), kept above other programs; Home then clips the
        window to the cardboard pieces (set_cutout_mask) so the real desktop shows through the holes.  The window is
        never re-created (no flag changes), so entering / leaving Home does not flicker.  on=False: normal window."""
        on = bool(on)
        if on == self._cutout:
            return
        self._cutout = on
        vis = self.isVisible()
        from ..core import winutil
        if on:
            if vis:
                self._restore = "full" if self.isFullScreen() else "max" if self.isMaximized() else "normal"
                if self._restore == "normal":
                    self._normal_geo = self.geometry()
            else:
                self._restore = "full"
            self.setUpdatesEnabled(False)
            self._chrome(False)
            self.setMinimumSize(0, 0)
            if vis and not self.isFullScreen():
                self.showFullScreen()
            self.setUpdatesEnabled(True)
            if vis:
                winutil.set_topmost(int(self.winId()), True)
                if self.ctx.prefs.get("hide_taskbar", True):
                    winutil.set_taskbar_visible(False)
        else:
            winutil.set_taskbar_visible(True)
            self.clearMask()
            self.setUpdatesEnabled(False)
            if vis:
                winutil.set_topmost(int(self.winId()), False)
            self.setMinimumSize(px(1000), px(620))
            self._chrome(True)
            if vis and self._restore != "full":
                if self._restore == "max":
                    self.showMaximized()
                else:
                    self.showNormal()
                    if self._normal_geo is not None:
                        self.setGeometry(self._normal_geo)
            self.setUpdatesEnabled(True)

    def present(self):
        """First show (called by main.py).  Always true full screen; the cut-out then adds the mask + topmost."""
        self.showFullScreen()
        if self._cutout:
            from ..core import winutil
            winutil.set_topmost(int(self.winId()), True)
            if self.ctx.prefs.get("hide_taskbar", True):
                winutil.set_taskbar_visible(False)

    def set_taskbar_hidden(self, hide):
        """Hide / show the Windows taskbar while the cardboard is up (Settings can switch hiding off)."""
        if self._cutout:
            from ..core import winutil
            winutil.set_taskbar_visible(not (hide and self.ctx.prefs.get("hide_taskbar", True)))

    def set_cutout_mask(self, region):
        """The window is only the cardboard pieces; the holes are not part of it (clicks go to the desktop)."""
        if self._cutout and not region.isEmpty():
            self.setMask(region)

    # ---- top bar ----
    def _tick(self, now):
        s = time_text(now, self.ctx.clock.h24, True)
        self.lb_time.setText(f"IST  {s}" + ("" if self.ctx.clock.h24 else f" {ampm(now)}"))

    def _lamp(self, ok, msg):
        self.b_lamp.setText("\u25CF  Lamp connected" if ok else "\u25CB  Lamp not connected")
        self.b_lamp.setStyleSheet(f"color: {'#34D399' if ok else '#FF9A9E'};")
        self.b_lamp.setToolTip(msg or "Click to open the lamp settings")

    def closeEvent(self, e):
        try:
            self.ctx.modes.stop(silent=True)
            self.ctx.stop_speaking()
            self.ctx.tft.stop()
            self.ctx.lamp.shutdown()
        finally:
            super().closeEvent(e)
