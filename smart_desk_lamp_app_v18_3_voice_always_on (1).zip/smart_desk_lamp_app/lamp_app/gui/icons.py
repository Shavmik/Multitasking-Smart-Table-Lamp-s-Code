"""Crisp vector icons (drawn with QPainter, so they stay sharp at any size / screen scaling)."""
import math

from PySide6.QtCore import Qt, QPointF, QRectF
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen, QPolygonF, QPixmap

from ..core.assets import asset_path


def _poly(*pts):
    return QPolygonF(list(pts))


def _path(*pts):
    path = QPainterPath()
    path.moveTo(pts[0])
    for pt in pts[1:]:
        path.lineTo(pt)
    return path


def _box(P, a, b, c, d):
    return QRectF(P(a, b), P(c, d))


def _fill_on(p, c):
    p.setBrush(c)
    p.setPen(Qt.PenStyle.NoPen)


def _home(p, P, s, c):
    p.drawPath(_path(P(.14, .5), P(.5, .18), P(.86, .5)))
    p.drawPath(_path(P(.25, .44), P(.25, .82), P(.75, .82), P(.75, .44)))
    p.drawPath(_path(P(.43, .82), P(.43, .6), P(.57, .6), P(.57, .82)))


def _ocr(p, P, s, c):
    for cx, cy, dx, dy in ((.16, .16, 1, 1), (.84, .16, -1, 1), (.16, .84, 1, -1), (.84, .84, -1, -1)):
        p.drawPath(_path(P(cx + dx * .17, cy), P(cx, cy), P(cx, cy + dy * .17)))
    for y, x1 in ((.38, .7), (.5, .7), (.62, .55)):
        p.drawLine(P(.3, y), P(x1, y))


def _speaker_body(p, P, ox=0.0):
    p.drawPolygon(_poly(P(.14 + ox, .4), P(.3 + ox, .4), P(.48 + ox, .24), P(.48 + ox, .76), P(.3 + ox, .6), P(.14 + ox, .6)))


def _speaker(p, P, s, c):
    _speaker_body(p, P)
    for r in (.17, .31):
        p.drawArc(_box(P, .48 - r * .55, .5 - r, .48 + r * 1.45, .5 + r), -45 * 16, 90 * 16)


def _vol(p, P, s, c, kind):
    _speaker_body(p, P, -0.02)
    if kind == "up":
        p.drawLine(P(.66, .5), P(.88, .5)); p.drawLine(P(.77, .39), P(.77, .61))
    elif kind == "down":
        p.drawLine(P(.66, .5), P(.88, .5))
    else:
        p.drawLine(P(.66, .38), P(.88, .62)); p.drawLine(P(.88, .38), P(.66, .62))


def _calc(p, P, s, c):
    p.drawRoundedRect(_box(P, .2, .12, .8, .88), s * .08, s * .08)
    p.drawRoundedRect(_box(P, .3, .22, .7, .38), s * .03, s * .03)
    p.save()
    _fill_on(p, c)
    for v in (.52, .65, .78):
        for u in (.36, .5, .64):
            p.drawEllipse(P(u, v), s * .035, s * .035)
    p.restore()


def _globe(p, P, s, c):
    p.drawEllipse(_box(P, .14, .14, .86, .86))
    p.drawEllipse(_box(P, .34, .14, .66, .86))
    p.drawLine(P(.14, .5), P(.86, .5))
    p.drawLine(P(.22, .32), P(.78, .32))
    p.drawLine(P(.22, .68), P(.78, .68))


def _gear(p, P, s, c):
    for k in range(8):
        a = k * math.pi / 4
        p.drawLine(P(.5 + .31 * math.cos(a), .5 + .31 * math.sin(a)), P(.5 + .41 * math.cos(a), .5 + .41 * math.sin(a)))
    p.drawEllipse(_box(P, .2, .2, .8, .8))
    p.drawEllipse(_box(P, .37, .37, .63, .63))


def _next(p, P, s, c):
    _fill_on(p, c)
    p.drawPolygon(_poly(P(.24, .24), P(.66, .5), P(.24, .76)))
    p.drawRoundedRect(_box(P, .68, .24, .79, .76), s * .03, s * .03)


def _prev(p, P, s, c):
    _fill_on(p, c)
    p.drawPolygon(_poly(P(.76, .24), P(.34, .5), P(.76, .76)))
    p.drawRoundedRect(_box(P, .21, .24, .32, .76), s * .03, s * .03)


def _play(p, P, s, c):
    _fill_on(p, c)
    p.drawPolygon(_poly(P(.32, .2), P(.8, .5), P(.32, .8)))


def _pause(p, P, s, c):
    _fill_on(p, c)
    p.drawRoundedRect(_box(P, .27, .2, .42, .8), s * .04, s * .04)
    p.drawRoundedRect(_box(P, .58, .2, .73, .8), s * .04, s * .04)


def _playpause(p, P, s, c):
    _fill_on(p, c)
    p.drawPolygon(_poly(P(.16, .26), P(.52, .5), P(.16, .74)))
    p.drawRoundedRect(_box(P, .6, .26, .7, .74), s * .03, s * .03)
    p.drawRoundedRect(_box(P, .76, .26, .86, .74), s * .03, s * .03)


def _stop(p, P, s, c):
    _fill_on(p, c)
    p.drawRoundedRect(_box(P, .24, .24, .76, .76), s * .08, s * .08)


def _back(p, P, s, c):
    p.drawPath(_path(P(.62, .2), P(.32, .5), P(.62, .8)))


def _forward(p, P, s, c):
    p.drawPath(_path(P(.38, .2), P(.68, .5), P(.38, .8)))


def _reload(p, P, s, c):
    p.drawArc(_box(P, .2, .2, .8, .8), 40 * 16, 280 * 16)
    p.drawPath(_path(P(.72, .12), P(.74, .32), P(.54, .3)))


def _fullscreen(p, P, s, c):
    for cx, cy, dx, dy in ((.18, .18, 1, 1), (.82, .18, -1, 1), (.18, .82, 1, -1), (.82, .82, -1, -1)):
        p.drawPath(_path(P(cx + dx * .2, cy), P(cx, cy), P(cx, cy + dy * .2)))


def _copy(p, P, s, c):
    p.drawRoundedRect(_box(P, .3, .3, .8, .84), s * .07, s * .07)
    p.drawPath(_path(P(.2, .66), P(.2, .16), P(.62, .16)))


def _search(p, P, s, c):
    p.drawEllipse(_box(P, .16, .16, .62, .62))
    p.drawLine(P(.54, .54), P(.84, .84))


def _save(p, P, s, c):
    p.drawPath(_path(P(.18, .6), P(.18, .84), P(.82, .84), P(.82, .6)))
    p.drawLine(P(.5, .16), P(.5, .66))
    p.drawPath(_path(P(.3, .5), P(.5, .68), P(.7, .5)))


def _trash(p, P, s, c):
    p.drawLine(P(.2, .26), P(.8, .26))
    p.drawPath(_path(P(.4, .26), P(.4, .16), P(.6, .16), P(.6, .26)))
    p.drawPath(_path(P(.28, .26), P(.32, .86), P(.68, .86), P(.72, .26)))


def _open(p, P, s, c):
    p.drawPath(_path(P(.44, .2), P(.2, .2), P(.2, .8), P(.8, .8), P(.8, .56)))
    p.drawLine(P(.5, .5), P(.84, .16))
    p.drawPath(_path(P(.58, .16), P(.84, .16), P(.84, .42)))


def _close(p, P, s, c):
    p.drawLine(P(.24, .24), P(.76, .76))
    p.drawLine(P(.76, .24), P(.24, .76))


def _plus(p, P, s, c):
    p.drawLine(P(.5, .2), P(.5, .8)); p.drawLine(P(.2, .5), P(.8, .5))


def _minus(p, P, s, c):
    p.drawLine(P(.2, .5), P(.8, .5))


def _camera(p, P, s, c):
    p.drawRoundedRect(_box(P, .12, .28, .88, .8), s * .08, s * .08)
    p.drawPath(_path(P(.34, .28), P(.4, .18), P(.6, .18), P(.66, .28)))
    p.drawEllipse(_box(P, .36, .4, .64, .68))


def _folder(p, P, s, c):
    p.drawPath(_path(P(.12, .24), P(.12, .8), P(.88, .8), P(.88, .34), P(.48, .34), P(.4, .24), P(.12, .24)))


def _check(p, P, s, c):
    p.drawPath(_path(P(.2, .54), P(.42, .74), P(.8, .28)))


def _translate(p, P, s, c):                              # two speech bubbles
    p.drawRoundedRect(_box(P, .12, .14, .6, .6), s * .08, s * .08)
    p.drawRoundedRect(_box(P, .4, .4, .88, .86), s * .08, s * .08)
    p.drawLine(P(.28, .3), P(.44, .3)); p.drawLine(P(.36, .26), P(.36, .3)); p.drawLine(P(.3, .42), P(.42, .34))
    p.drawPath(_path(P(.56, .74), P(.64, .5), P(.72, .74))); p.drawLine(P(.59, .67), P(.69, .67))


def _clock(p, P, s, c):
    p.drawEllipse(_box(P, .14, .14, .86, .86))
    p.drawPath(_path(P(.5, .28), P(.5, .5), P(.66, .6)))


def _qr(p, P, s, c):
    for x, y in ((.16, .16), (.58, .16), (.16, .58)):
        p.drawRoundedRect(_box(P, x, y, x + .26, y + .26), s * .03, s * .03)
    p.save(); _fill_on(p, c)
    for x, y in ((.62, .62), (.76, .62), (.62, .76), (.76, .76)):
        p.drawRect(_box(P, x, y, x + .09, y + .09))
    p.restore()


def _cube(p, P, s, c):
    p.drawPath(_path(P(.5, .12), P(.84, .3), P(.84, .7), P(.5, .88), P(.16, .7), P(.16, .3), P(.5, .12)))
    p.drawPath(_path(P(.16, .3), P(.5, .48), P(.84, .3)))
    p.drawLine(P(.5, .48), P(.5, .88))


def _pen(p, P, s, c):
    p.drawPath(_path(P(.18, .82), P(.24, .6), P(.66, .18), P(.82, .34), P(.4, .76), P(.18, .82)))
    p.drawLine(P(.58, .26), P(.74, .42))


def _music(p, P, s, c):
    p.drawPath(_path(P(.38, .72), P(.38, .2), P(.8, .12), P(.8, .64)))
    p.drawEllipse(_box(P, .18, .62, .4, .84)); p.drawEllipse(_box(P, .6, .54, .82, .76))


_ICONS = {
    "home": _home, "ocr": _ocr, "speaker": _speaker, "calc": _calc, "globe": _globe, "gear": _gear,
    "next": _next, "prev": _prev, "play": _play, "pause": _pause, "playpause": _playpause, "stop": _stop,
    "back": _back, "forward": _forward, "reload": _reload, "fullscreen": _fullscreen, "copy": _copy,
    "search": _search, "save": _save, "trash": _trash, "open": _open, "close": _close, "plus": _plus,
    "minus": _minus, "camera": _camera, "folder": _folder, "check": _check, "translate": _translate,
    "clock": _clock, "qr": _qr, "cube": _cube, "pen": _pen, "music": _music,
    "volup": lambda p, P, s, c: _vol(p, P, s, c, "up"),
    "voldown": lambda p, P, s, c: _vol(p, P, s, c, "down"),
    "mute": lambda p, P, s, c: _vol(p, P, s, c, "mute"),
}


def draw_icon(p, kind, rect, color="#FFFFFF", weight=0.08):
    fn = _ICONS.get(kind)
    if fn is None:
        return
    rect = QRectF(rect)
    s = min(rect.width(), rect.height())
    x0, y0 = rect.center().x() - s / 2, rect.center().y() - s / 2

    def P(u, v):
        return QPointF(x0 + u * s, y0 + v * s)

    col = QColor(color)
    p.save()
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    pen = QPen(col, max(1.5, s * weight))
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    p.setPen(pen)
    p.setBrush(Qt.BrushStyle.NoBrush)
    fn(p, P, s, col)
    p.restore()


def has_icon(kind):
    return kind in _ICONS


_img_cache = {}


def art_pixmap(name):
    if name not in _img_cache:
        _img_cache[name] = QPixmap(asset_path(name))
    return _img_cache[name]
