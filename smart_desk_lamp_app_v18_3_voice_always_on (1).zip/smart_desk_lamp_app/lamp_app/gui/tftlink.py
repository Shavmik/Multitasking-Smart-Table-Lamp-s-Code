"""The lamp's touchscreen <-> the app.

While any page is open:
  * the page is drawn on the lamp's TFT (what you see on the laptop is what the TFT shows), and
  * finger / stylus touches on the TFT are turned into real mouse events on that page, so the
    canvas draws, and the page's buttons (Read / Undo / Clear) can be pressed from the TFT.
Everything is computed on the laptop. The board only shows pictures and reports touches.
"""
import math
import queue
import threading
import time
import zlib

import cv2
import numpy as np
from PySide6.QtCore import QEvent, QObject, QPoint, QPointF, QRect, Qt, QTimer
from PySide6.QtGui import QImage, QMouseEvent
from PySide6.QtWidgets import QAbstractButton, QAbstractSlider, QAbstractSpinBox, QApplication, QComboBox

from .. import config
from ..core import nativemenu
from . import tftlayout
from ..tftui.native import NativeRunner, NativeUi
from .services import on_main

W, H = config.TFT_W, config.TFT_H
BG = (24, 18, 14)           # BGR colour used when the page background cannot be sampled
SNAP_TFT_PX = 16            # a tap this close to a button (in TFT pixels) still presses it
CAM_X, CAM_Y, CAM_W, CAM_H = config.TFT_CAM_BOX   # small live-camera box (bottom right), same place as the board's own always-on box


class _Tile:
    """One control cut out of the page and placed on the TFT."""
    __slots__ = ("w", "src", "x", "y", "dw", "dh", "s")

    def __init__(self, w, src, x, y, dw, dh, s):
        self.w, self.src, self.x, self.y, self.dw, self.dh, self.s = w, src, x, y, dw, dh, s


class TftLink(QObject):
    def __init__(self, lamp):
        super().__init__()
        self.lamp = lamp
        self.page = None
        self.root = None              # window area the pictures are grabbed from (keeps the page background)
        self._cam = None              # newest camera picture (BGR): shown in a small box on camera pages
        lamp.frame.connect(self._on_cam)
        self._gen = 0                 # changes on every start/stop: old touch threads end themselves
        self._quit = False
        self._down = False
        self._swallow = False         # this touch was used by the page itself (no mouse event)
        self._target = None
        self._tiles = []              # tiles currently drawn on the TFT (for touch mapping)
        self._tile = None             # tile the current touch started on
        self._lp = None               # last position inside that tile's widget (QPoint)
        self._local = None            # last position on the page (QPointF)
        self._prev = None             # last TFT point of a pen stroke
        self._hash = None
        self._pending = False
        self._native_active = False    # True = the current page is drawn as native colour boxes
        self._native_buttons = []      # the buttons last sent, for local touch hit-testing
        self._native_key = None        # cheap "did anything change" fingerprint (skips lambdas)
        self._native_hit = None        # button the current touch went down on
        self._clock_last = None        # last clock text sent (skip resends of the same second)
        self.ui = None                 # v14 touchscreen interface (lamp_app/tftui), set by attach_ui()
        self._ui_hash = None
        self._ui_timer = None
        self._runner = None            # v15: sends the lamp's own button screens (no pictures)
        self._native_timer = None
        self._q = queue.Queue()
        self._timer = QTimer(self)
        self._timer.setInterval(config.TFT_REFRESH_MS)   # the TFT is slow: redraw only every few seconds
        self._timer.timeout.connect(self._push)
        self._clock_timer = QTimer(self)
        self._clock_timer.setInterval(200)     # checked often so a new second is never missed
        self._clock_timer.timeout.connect(self._tick_clock)
        self._clock_timer.start()
        threading.Thread(target=self._worker, daemon=True).start()
        lamp.status.connect(lambda ok, msg: setattr(self, "_hash", None))   # (re)connected: draw again

    # ------------------------------------------------------------------ v14 interface (own buttons on the lamp screen)
    def attach_ui(self, ui):
        """The lamp screen draws its own buttons (Home, Clock, Read text...). Desktop pages without a TFT screen are
        still mirrored the old way; a small HOME chip in the corner brings the buttons back."""
        self.ui = ui
        self._ui_timer = QTimer(self)
        self._ui_timer.setInterval(config.TFT_UI_MS)
        self._ui_timer.timeout.connect(self._push_ui)
        self._ui_timer.start()
        self.lamp.status.connect(lambda ok, msg: setattr(self, "_ui_hash", None))
        self.lamp.screen_changed.connect(self._on_screen)
        if config.TFT_NATIVE and isinstance(ui, NativeUi):
            self._runner = NativeRunner(lambda: self.lamp.board, self.native_on,
                                        lambda bid: on_main(lambda b=bid: self._native_tap(b)), self._touch_flags)
            self._native_timer = QTimer(self)
            self._native_timer.setInterval(config.TFT_NATIVE_MS)
            self._native_timer.timeout.connect(self._native_refresh)
            self._native_timer.start()
            self.lamp.status.connect(lambda ok, msg: self._runner.forget())

    # ------------------------------------------------------------------ v15: the board draws its own buttons
    def _screen_off(self):
        return not getattr(self.lamp, "screen_on", True)

    def _on_screen(self, on):
        if not on:
            return
        self._hash = None
        self._ui_hash = None
        if self._runner is not None:
            self._runner.forget()
        self._native_refresh()
        self._push()
        self._push_ui(force=True)

    def native_on(self):
        """True while the lamp draws the button screens itself (new firmware + a screen of ours, not a mirrored page)."""
        board = self.lamp.board
        return bool(self._runner is not None and self.ui is not None and not self.ui.mirror
                    and board is not None and getattr(board, "native_ok", False) and not self._screen_off())

    @staticmethod
    def _touch_flags():
        return (1 if config.TOUCH_FLIP_X else 0) | (2 if config.TOUCH_FLIP_Y else 0) | (4 if config.TOUCH_SWAP_XY else 0)

    def _native_refresh(self):
        if self._runner is not None and self.native_on() and self.page is not None:
            self._runner.submit(self.ui.build())

    def _native_tap(self, bid):
        if self.ui is None or self.ui.mirror:
            return
        if config.TFT_DEBUG:
            print(f"[tft-native] tap {bid}")
        self.ui.tap(bid)
        self._native_refresh()                                  # show the result at once, not at the next timer tick

    def _ui_owns(self):
        return self.ui is not None and not self.ui.mirror

    def _push_ui(self, force=False):
        board = self.lamp.board
        ui = self.ui
        if ui is None or board is None or self.page is None or ui.mirror or (self._pending and not force) or self._screen_off():
            return
        if self.native_on():
            return                                              # the board draws this screen itself
        frame = ui.render()
        digest = zlib.adler32(frame.tobytes())
        if digest == self._ui_hash:
            return
        self._ui_hash = digest
        self._pending = True
        self._q.put(("frame", frame))

    def _ui_touch(self, kind, x, y):
        x, y = self._flip(x, y)
        if self.ui.touch(kind, x, y):
            self._push_ui(force=True)

    @staticmethod
    def _flip(x, y):
        if config.TOUCH_SWAP_XY:
            x, y = y, x
        if config.TOUCH_FLIP_X:
            x = W - 1 - x
        if config.TOUCH_FLIP_Y:
            y = H - 1 - y
        return x, y

    # ------------------------------------------------------------------ start / stop
    def start(self, page, root=None):
        self.stop()
        self.page = page
        self.root = root
        self._cam = None
        self._hash = None
        self._native_active = False
        self._native_buttons = []
        self._native_key = None
        self._clock_last = None
        self._ui_hash = None
        if self.ui is not None:
            self.ui.sync_page(getattr(page, "key", ""))
        if self._runner is not None:
            self._runner.forget()
        gen = self._gen
        self._timer.start()
        threading.Thread(target=self._poll, args=(gen,), daemon=True).start()
        self._push()
        self._push_ui(force=True)
        self._native_refresh()

    def stop(self):
        self._gen += 1
        self._timer.stop()
        if self._down:
            self._finish()
        self.page = None
        self._tiles = []
        self._down = False
        self._native_active = False
        self._native_buttons = []
        self._native_key = None
        self._clock_last = None
        self._ui_hash = None

    def refresh(self):
        """Force the lamp screen to be redrawn now (not after the usual multi-second delay) -
        used after a native menu's own state changes, e.g. PREV/NEXT."""
        self._push()

    # ------------------------------------------------------------------ geometry
    def _layout(self):
        """Cut the page's main controls out and pack them into the 320x240 screen -> list of _Tile."""
        page = self.page
        if page is None:
            return []
        raw = page.tft_units() or [[(page, None)]]
        units, keep = [], []
        for unit in raw:
            u, k = [], []
            for w, r in unit:
                rect = (r if r is not None else w.rect()).intersected(w.rect())
                if rect.width() > 4 and rect.height() > 4:
                    u.append((rect.width(), rect.height()))
                    k.append((w, rect))
            if u:
                units.append(u)
                keep.append(k)
        if not units:
            units, keep = [[(page.width(), page.height())]], [[(page, page.rect())]]
        reserve = CAM_H + 8 if (page.uses_camera or config.TFT_CAM_ALWAYS) else 0
        scale, placed = tftlayout.pack(units, W, H, reserve_bottom=reserve)
        tiles = []
        for k, pl in zip(keep, placed):
            for (w, rect), (x, y, dw, dh) in zip(k, pl):
                tiles.append(_Tile(w, rect, x, y, dw, dh, dw / max(1, rect.width())))
        return tiles

    def _to_page(self, x, y):
        """TFT pixel -> (point on the page, scale, tile, point inside the tile's widget).
        None = the tap was on the empty bars, away from every control."""
        if config.TOUCH_SWAP_XY:
            x, y = y, x
        if config.TOUCH_FLIP_X:
            x = W - 1 - x
        if config.TOUCH_FLIP_Y:
            y = H - 1 - y
        best, best_d = None, 1e9
        for t in self._tiles:
            dx = max(t.x - x, 0, x - (t.x + t.dw - 1))
            dy = max(t.y - y, 0, y - (t.y + t.dh - 1))
            d = math.hypot(dx, dy)
            if d < best_d:
                best, best_d = t, d
        if best is None or best_d > 10:
            return None
        t = best
        fx = min(max((x - t.x) / t.s, 0), t.src.width() - 1)
        fy = min(max((y - t.y) / t.s, 0), t.src.height() - 1)
        lp = QPoint(int(t.src.x() + fx), int(t.src.y() + fy))
        page = self.page
        pt = QPointF(t.w.mapTo(page, lp)) if (t.w is page or page.isAncestorOf(t.w)) else None
        return pt, t.s, t, lp

    # ------------------------------------------------------------------ live clock (fastest path)
    def _tick_clock(self):
        board = self.lamp.board
        page = self.page
        if page is None or board is None or self._ui_owns():
            return
        fn = getattr(page, "tft_clock", None)
        text = fn() if callable(fn) else None
        if text is None:
            return
        self._native_active = False   # the clock owns the screen directly - not the pixel mirror
        if text == self._clock_last:
            return                    # same second already on screen: nothing to send
        self._clock_last = text
        self._q.put(("clock", text))

    # ------------------------------------------------------------------ native menu (fast path)
    @staticmethod
    def _fingerprint(title, buttons):
        """Cheap equality check that ignores the per-button on_tap callables (always new objects)."""
        return (title, tuple((b["x"], b["y"], b["w"], b["h"], b["label"], tuple(b.get("fill", ())),
                               tuple(b.get("fg", ())), b.get("font"), b.get("animated"))
                              for b in buttons))

    def _push_native(self, title, buttons):
        self._native_buttons = buttons
        key = self._fingerprint(title, buttons)
        if key != self._native_key:
            self._native_key = key
            self._q.put(("menu", (title, buttons)))
        self._native_active = True

    def _on_cam(self, img):
        if self.page is not None and self.page.uses_camera:
            self._cam = img

    # ------------------------------------------------------------------ page -> TFT
    def _push(self):
        board = self.lamp.board
        page = self.page
        if page is None or board is None or self._down or self._pending or not page.isVisible() or self._screen_off():
            return
        if self._ui_owns():
            return   # a v14 screen is on the lamp
        clock_fn = getattr(page, "tft_clock", None)
        if callable(clock_fn) and clock_fn() is not None:
            return   # the 1Hz clock ticker owns this screen - don't fight it with a pixel grab
        native = getattr(page, "tft_native", None)
        if callable(native):
            spec = native()
            if spec is not None:
                self._push_native(*spec)
                return
        self._native_active = False
        src = self.root or page
        tiles = self._layout()
        if not tiles:
            return
        self._tiles = tiles
        # one grab of the area that covers every tile, then cut the tiles out of it
        rects = []
        for t in tiles:
            tl = t.w.mapTo(src, t.src.topLeft()) if (t.w is src or src.isAncestorOf(t.w)) else QPoint(0, 0)
            rects.append(QRect(tl, t.src.size()))
        union = rects[0]
        for r in rects[1:]:
            union = union.united(r)
        union = union.intersected(src.rect())
        if union.isEmpty():
            return
        qi = src.grab(union).toImage().convertToFormat(QImage.Format.Format_RGB888)
        w, h, bpl = qi.width(), qi.height(), qi.bytesPerLine()
        arr = np.frombuffer(qi.constBits(), np.uint8)[:bpl * h].reshape(h, bpl)[:, :w * 3].reshape(h, w, 3)
        arr = cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)
        k = w / max(1, union.width())                        # device pixel ratio of the grab
        frame = np.empty((H, W, 3), np.uint8)
        frame[:] = self._page_colour(src, page)
        for t, r in zip(tiles, rects):
            x0, y0 = int((r.x() - union.x()) * k), int((r.y() - union.y()) * k)
            x1, y1 = min(w, int(round((r.right() + 1 - union.x()) * k))), min(h, int(round((r.bottom() + 1 - union.y()) * k)))
            if x1 - x0 < 2 or y1 - y0 < 2:
                continue
            crop = arr[max(0, y0):y1, max(0, x0):x1]
            shrink = t.dw < crop.shape[1]
            out = cv2.resize(crop, (t.dw, t.dh), interpolation=cv2.INTER_AREA if shrink else cv2.INTER_CUBIC)
            if shrink:                                        # small text stays crisp after shrinking
                soft = cv2.GaussianBlur(out, (0, 0), 0.9)
                out = cv2.addWeighted(out, 1.45, soft, -0.45, 0)
            fx0, fy0 = max(0, t.x), max(0, t.y)
            fx1, fy1 = min(W, t.x + t.dw), min(H, t.y + t.dh)
            if fx1 > fx0 and fy1 > fy0:
                frame[fy0:fy1, fx0:fx1] = out[fy0 - t.y:fy1 - t.y, fx0 - t.x:fx1 - t.x]
        if page.uses_camera and self._cam is not None:        # small camera box, bottom right
            small = cv2.resize(self._cam, (CAM_W, CAM_H), interpolation=cv2.INTER_AREA)
            x0, y0 = CAM_X, CAM_Y
            frame[y0 - 1:y0 + CAM_H + 1, x0 - 1:x0 + CAM_W + 1] = (255, 255, 255)
            frame[y0:y0 + CAM_H, x0:x0 + CAM_W] = small
        if self.ui is not None:                               # HOME chip: back to the lamp's own buttons
            cv2.rectangle(frame, (0, H - 22), (62, H), (40, 30, 24), -1)
            cv2.rectangle(frame, (0, H - 22), (62, H - 1), (255, 255, 255), 1)
            cv2.putText(frame, "< HOME", (6, H - 7), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)
        if config.TFT_QUALITY < 1.0:                          # low resolution: much smaller picture, quick and complete
            f = max(0.3, config.TFT_QUALITY)
            frame = cv2.resize(cv2.resize(frame, (int(W * f), int(H * f)), interpolation=cv2.INTER_AREA), (W, H), interpolation=cv2.INTER_LINEAR)
        digest = zlib.adler32(frame.tobytes())
        if digest == self._hash:
            return
        self._hash = digest
        self._pending = True
        self._q.put(("frame", frame))

    @staticmethod
    def _page_colour(src, page):
        """Colour of the page background (so the bars around the controls match the app, light or dark)."""
        try:
            tl = page.mapTo(src, QPoint(2, 2)) if (page is src or src.isAncestorOf(page)) else QPoint(2, 2)
            qi = src.grab(QRect(tl, QPoint(tl.x() + 5, tl.y() + 5))).toImage().convertToFormat(QImage.Format.Format_RGB888)
            px_ = qi.pixelColor(qi.width() // 2, qi.height() // 2)
            return (px_.blue(), px_.green(), px_.red())
        except Exception:                                      # noqa: BLE001
            return BG

    def _worker(self):
        """Sends pictures and pen lines to the board, one after the other (never on the GUI thread)."""
        while not self._quit:
            kind, arg = self._q.get()
            board = self.lamp.board
            try:
                if board is not None and not (kind == "frame" and self.native_on()) and not self._screen_off():
                    if kind == "line":
                        board.line(*arg)
                    elif kind == "menu":
                        board.show_menu(*arg)
                    elif kind == "clock":
                        board.clock(arg)
                    else:
                        board.show_image(arg)
            except Exception:                                    # noqa: BLE001 - try again next tick
                if kind == "frame":
                    self._hash = None
            finally:
                if kind == "frame":
                    self._pending = False

    # ------------------------------------------------------------------ TFT touch -> page
    def _poll(self, gen):
        """Background thread: asks the board 'is the screen touched?' about 80 times a second."""
        held, misses = False, 0
        while gen == self._gen and not self._quit:
            board = self.lamp.board
            if board is None:
                time.sleep(0.3)
                continue
            if self._screen_off():                               # screen is off: nothing to touch
                held, misses = False, 0
                time.sleep(0.2)
                continue
            if self.native_on():                                 # the board handles the finger itself on its own screens
                held, misses = False, 0
                time.sleep(0.05)
                continue
            try:
                pressed, x, y = board.touch()
            except Exception:                                    # noqa: BLE001 - busy / unplugged
                time.sleep(0.1)
                continue
            if pressed and (x, y) != (0, 0):
                misses = 0
                kind = "move" if held else "down"
                held = True
                on_main(lambda k=kind, a=x, b=y, g=gen: self._touch(g, k, a, b))
            elif held:
                misses += 1                                      # one empty reading is just noise
                if misses >= 2:
                    held, misses = False, 0
                    on_main(lambda g=gen: self._touch(g, "up", 0, 0))
            time.sleep(0.008)

    def _touch(self, gen, kind, x, y):
        page = self.page
        if gen != self._gen or page is None:
            return
        if self.ui is not None:
            if self._ui_owns():
                self._ui_touch(kind, x, y)
                return
            fx, fy = self._flip(x, y)
            if kind == "down" and fx < 64 and fy >= H - 24:       # HOME chip of a mirrored page
                self._swallow = True
                self.ui.go("home")
                self.ui.hook("open_page", "home")
                self._ui_hash = None
                self._push_ui(force=True)
                self._native_refresh()
                return
        if self._native_active:
            self._touch_native(kind, x, y)
            return
        if kind == "up":
            self._finish()
            return
        if kind == "down":
            self._swallow = False
            mapped = self._to_page(x, y)
            if config.TFT_DEBUG:
                if mapped is None:
                    print(f"[tft] touch {x},{y} -> outside")
                else:
                    print(f"[tft] touch {x},{y} -> {type(mapped[2].w).__name__} ({mapped[3].x()},{mapped[3].y()})")
            if mapped is None:
                self._swallow = True
                return
            if page.tft_touch_began():
                self._swallow = True
                return
            pt, scale, tile, lp = mapped
            if self._adjust(tile, pt, lp):                 # slider / spin box / drop-down: set it by tapping
                self._swallow = True
                return
            target = self._pick(page, pt, scale, tile)
            if target is None:
                self._swallow = True
                return
            self._target, self._local, self._prev, self._down = target, pt, (x, y), True
            self._tile, self._lp = tile, lp
            self._send(QEvent.Type.MouseButtonPress, pt)
            return
        # move
        if not self._down or self._swallow:
            return
        mapped = self._to_page(x, y)
        if mapped is None:
            return
        pt, scale, tile, lp = mapped
        self._local, self._lp, self._tile = pt, lp, tile
        self._send(QEvent.Type.MouseMove, pt)
        if self._target is getattr(page, "tft_ink", None) and self._prev is not None:
            width = max(2, int(round(config.INK_WIDTH * scale)))
            self._q.put(("line", (self._prev[0], self._prev[1], x, y, (15, 15, 25), width)))   # instant ink on the TFT
        self._prev = (x, y)

    def _touch_native(self, kind, x, y):
        """Taps on a native menu are resolved locally (no page-widget search needed) and fire
        on release, like a normal button - so dragging a finger off a tile cancels it."""
        if config.TOUCH_SWAP_XY:
            x, y = y, x
        if config.TOUCH_FLIP_X:
            x = W - 1 - x
        if config.TOUCH_FLIP_Y:
            y = H - 1 - y
        if kind == "down":
            self._native_hit = nativemenu.hit(x, y, self._native_buttons)
        elif kind == "up":
            b, self._native_hit = self._native_hit, None
            if b is not None:
                cb = b.get("on_tap")
                if cb:
                    cb()
        # "move": native taps don't track drags.

    def _finish(self):
        if self._down and self._target is not None:
            self._send(QEvent.Type.MouseButtonRelease, self._local)
        self._down, self._swallow, self._target, self._prev, self._tile = False, False, None, None, None
        self._hash = None                                        # draw the page again (clean strokes, new buttons)
        QTimer.singleShot(400, self._push)                       # show the result of the tap soon, not after 5 s

    @staticmethod
    def _chain(w, stop):
        while w is not None and w is not stop:
            yield w
            w = w.parentWidget()

    def _adjust(self, tile, pt, lp):
        """Tap on a slider / spin box / drop-down (no finger-sized parts of their own): set it directly."""
        page = self.page
        leaf = tile.w.childAt(lp) if tile.w is not None else None
        leaf = leaf or tile.w
        for w in self._chain(leaf, page.parentWidget()):
            if isinstance(w, QAbstractButton):
                return False                                     # a real button: normal press
            if isinstance(w, QAbstractSlider):
                loc = w.mapFrom(tile.w, lp) if (w is tile.w or tile.w.isAncestorOf(w)) else None
                if loc is not None:
                    span = max(1, w.width() - 1) if w.orientation() == Qt.Orientation.Horizontal else max(1, w.height() - 1)
                    frac = (loc.x() if w.orientation() == Qt.Orientation.Horizontal else w.height() - 1 - loc.y()) / span
                    w.setValue(int(round(w.minimum() + min(max(frac, 0.0), 1.0) * (w.maximum() - w.minimum()))))
                    return True
            if isinstance(w, QAbstractSpinBox):
                loc = w.mapFrom(tile.w, lp) if (w is tile.w or tile.w.isAncestorOf(w)) else None
                if loc is not None:
                    (w.stepDown if loc.x() < w.width() / 2 else w.stepUp)()      # left half = less, right half = more
                    return True
            if isinstance(w, QComboBox):
                n = w.count()
                if n > 1:
                    w.setCurrentIndex((w.currentIndex() + 1) % n)                # tap = next entry
                return True
        return False

    def _pick(self, page, pt, scale, tile):
        """The widget a tap should act on: the ink canvas, a button (also when the tap just misses it)."""
        w = tile.w
        if pt is None:                                           # control outside the page (top-bar switch)
            return w if isinstance(w, QAbstractButton) and w.isEnabled() else None
        child = page.childAt(pt.toPoint())
        ink = getattr(page, "tft_ink", None)
        if ink is not None and child is ink:
            return ink
        cur = child
        while cur is not None and cur is not page:
            if isinstance(cur, QAbstractButton) and cur.isEnabled():
                return cur
            cur = cur.parentWidget()
        if isinstance(w, QAbstractButton) and w.isEnabled():
            return w
        best, best_d = None, SNAP_TFT_PX / max(scale, 0.01)
        for b in page.findChildren(QAbstractButton):
            if not b.isVisible() or not b.isEnabled():
                continue
            br = QRect(b.mapTo(page, QPoint(0, 0)), b.size())
            dx = max(br.left() - pt.x(), 0, pt.x() - br.right())
            dy = max(br.top() - pt.y(), 0, pt.y() - br.bottom())
            d = math.hypot(dx, dy)
            if d <= best_d:
                best, best_d = b, d
        return best or child or page

    def _send(self, etype, pt):
        page, target, tile = self.page, self._target, self._tile
        if page is None or target is None:
            return
        if tile is not None and self._lp is not None and (target is tile.w or tile.w.isAncestorOf(target)):
            local = QPointF(target.mapFrom(tile.w, self._lp))
        elif pt is not None:
            local = QPointF(target.mapFrom(page, pt.toPoint()))
        else:
            return
        global_ = QPointF(target.mapToGlobal(local.toPoint()))
        left = Qt.MouseButton.LeftButton
        none = Qt.MouseButton.NoButton
        button = none if etype == QEvent.Type.MouseMove else left
        buttons = none if etype == QEvent.Type.MouseButtonRelease else left
        QApplication.sendEvent(target, QMouseEvent(etype, local, global_, button, buttons, Qt.KeyboardModifier.NoModifier))
