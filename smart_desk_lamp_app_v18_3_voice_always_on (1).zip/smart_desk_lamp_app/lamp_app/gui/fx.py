"""Animated, painted widgets built from the reference videos.  Everything is drawn with QPainter (no video playback),
so it stays sharp, follows the light/dark theme and costs nothing when hidden.

  Loader        - circle / dots / fade circles / bouncing ball / clock / wifi loaders   (loader pack video)
  ProgressRing  - gradient progress ring with a percentage                               (progress ring video)
  ExpandSearch  - search button that grows into a search bar                             (search button video)
  GlassToggle   - glass-bubble Light/Dark switch                                         (light/dark toggle video)
  GlowNav       - round icon with a rainbow rim light and a sliding label                (home button video)
  RollingNumber - odometer number with a glowing edge                                    (follower counter video)
  Cube3D        - exploded / spinning 3D Rubik's cube that plays the solution            (cube video)
  FrameSprite   - looping character / eye animation (frames made from the two anime videos)
  ButtonFx      - hover shine + press ripple + busy loader on EVERY button of the app
  DotRing, TechKey, Dock, RailButton, CalendarCard, InsightCard ... (dot dashboard, keyboard, desktop, graph pictures)
"""
import math
import os
import random
import time
import weakref

from PySide6.QtCore import (QCoreApplication, QElapsedTimer, QEasingCurve, QEvent, QObject, QPointF, QRectF, QSize, Qt,
                            QThread, QTimer, QVariantAnimation, Signal)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QFont, QFontMetricsF, QLinearGradient, QPainter, QPainterPath,
                           QPen, QPixmap, QPolygonF, QRadialGradient)
from PySide6.QtWidgets import QAbstractButton, QApplication, QLineEdit, QPushButton, QSizePolicy, QWidget

from ..core.assets import asset_path
from . import theme
from .icons import draw_icon
from .theme import px

AA = QPainter.RenderHint.Antialiasing
SMOOTH = QPainter.RenderHint.SmoothPixmapTransform
NOPEN = Qt.PenStyle.NoPen
NOBRUSH = Qt.BrushStyle.NoBrush


def _c(hexcol, alpha=None):
    c = QColor(hexcol)
    if alpha is not None:
        c.setAlpha(max(0, min(255, int(alpha))))
    return c


def _lerp(a, b, t):
    return a + (b - a) * t


def _mix(c1, c2, t):
    c1, c2 = QColor(c1), QColor(c2)
    return QColor(int(_lerp(c1.red(), c2.red(), t)), int(_lerp(c1.green(), c2.green(), t)),
                  int(_lerp(c1.blue(), c2.blue(), t)), int(_lerp(c1.alpha(), c2.alpha(), t)))


def _round_path(rect, r):
    p = QPainterPath()
    p.addRoundedRect(QRectF(rect), r, r)
    return p


def fx_asset(name):
    return asset_path(os.path.join("fx", name))


_pix_cache = {}


def fx_pixmap(name):
    if name not in _pix_cache:
        _pix_cache[name] = QPixmap(fx_asset(name))
    return _pix_cache[name]


def cover_rect(target, w, h):
    """Source rect (of a w x h picture) that fills `target` completely (CSS background-size: cover)."""
    k = max(target.width() / w, target.height() / h)
    sw, sh = target.width() / k, target.height() / k
    return QRectF((w - sw) / 2, (h - sh) / 2, sw, sh)


class AnimWidget(QWidget):
    """A widget that repaints ~60 times a second, but only while it is visible."""
    FPS = 60

    def __init__(self, parent=None):
        super().__init__(parent)
        self._clock = QElapsedTimer()
        self._clock.start()
        self._timer = QTimer(self)
        self._timer.setInterval(int(1000 / self.FPS))
        self._timer.timeout.connect(self._on_tick)

    def t(self):
        return self._clock.elapsed() / 1000.0

    def showEvent(self, e):
        self._timer.start()
        super().showEvent(e)

    def hideEvent(self, e):
        self._timer.stop()
        super().hideEvent(e)

    def _on_tick(self):
        self.advance()
        self.update()

    def advance(self):
        pass


# =====================================================================================================  LOADERS
LOADER_KINDS = ("circle", "dots", "fade", "ball", "clock", "wifi")


def paint_loader(p, kind, r, t, col):
    """One frame of a loader inside rect r at time t (seconds)."""
    s = min(r.width(), r.height())
    c = r.center()
    lw = max(1.6, s * 0.11)
    p.save()
    p.setRenderHint(AA)
    p.setBrush(NOBRUSH)
    pen = QPen(col, lw)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    box = QRectF(c.x() - s * .38, c.y() - s * .38, s * .76, s * .76)
    if kind == "circle":
        p.setPen(QPen(_c(col.name(), 45), lw))
        p.drawEllipse(box)
        p.setPen(pen)
        sweep = 50 + 200 * abs(math.sin(t * 1.5))
        p.drawArc(box, int((90 - t * 300) * 16), int(-sweep * 16))
    elif kind == "dots":
        p.setPen(NOPEN)
        for i in range(3):
            k = 0.5 + 0.5 * math.sin(2 * math.pi * (t * 1.2 - i / 3.0))
            d = s * (0.08 + 0.09 * k)
            cc = _c(col.name(), 90 + 165 * k)
            p.setBrush(cc)
            p.drawEllipse(QPointF(c.x() + (i - 1) * s * .3, c.y()), d, d)
    elif kind == "fade":
        for k in (0.0, 0.5):
            ph = (t * 0.9 + k) % 1.0
            rad = s * 0.46 * ph
            cc = _c(col.name(), 255 * (1 - ph))
            if k == 0.0:
                p.setPen(NOPEN); p.setBrush(cc)
            else:
                p.setBrush(NOBRUSH); p.setPen(QPen(cc, lw * .8))
            p.drawEllipse(c, rad, rad)
        p.setPen(NOPEN); p.setBrush(col)
        p.drawEllipse(c, s * .07, s * .07)
    elif kind == "ball":
        h = abs(math.sin(t * 3.2))
        rad = s * 0.12
        sq = 1 + 0.35 * (1 - h) ** 6
        y = r.bottom() - s * .14 - rad - h * s * .55
        p.setPen(NOPEN)
        p.setBrush(_c(col.name(), 50 * (1 - h) + 15))
        p.drawEllipse(QPointF(c.x(), r.bottom() - s * .12), s * (0.16 + 0.1 * (1 - h)), s * .035)
        p.setBrush(col)
        p.drawEllipse(QPointF(c.x(), y + rad * (1 - 1 / sq)), rad * sq, rad / sq)
    elif kind == "clock":
        p.setPen(QPen(col, lw * .85))
        p.drawEllipse(box)
        a1, a2 = t * 2 * math.pi * 0.9, t * 2 * math.pi * 0.9 / 12
        p.drawLine(c, QPointF(c.x() + math.sin(a1) * s * .30, c.y() - math.cos(a1) * s * .30))
        p.drawLine(c, QPointF(c.x() + math.sin(a2) * s * .18, c.y() - math.cos(a2) * s * .18))
    elif kind == "wifi":
        n = int(t * 2.6) % 4
        base = QPointF(c.x(), c.y() + s * .3)
        p.setPen(NOPEN); p.setBrush(col)
        p.drawEllipse(base, s * .06, s * .06)
        for i in range(3):
            rad = s * (0.2 + 0.2 * i)
            on = i < n
            p.setBrush(NOBRUSH)
            p.setPen(QPen(_c(col.name(), 255 if on else 55), lw * .9, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            p.drawArc(QRectF(base.x() - rad, base.y() - rad, rad * 2, rad * 2), int(52 * 16), int(76 * 16))
    p.restore()


class Loader(AnimWidget):
    def __init__(self, kind="circle", size=28, color=None, parent=None):
        super().__init__(parent)
        self.kind, self._color = kind, color
        self.setFixedSize(px(size), px(size))
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)

    def paintEvent(self, e):
        p = QPainter(self)
        paint_loader(p, self.kind, QRectF(self.rect()), self.t(), QColor(self._color or theme.icon_on()))


# =====================================================================================================  PROGRESS RING
RING_STYLES = {"purple": ("#C026D3", "#7C3AED", "#3B82F6"), "fire": ("#FF3B30", "#FF2D95", "#FF6A00"),
               "green": ("#16A34A", "#22C55E", "#06B6D4"), "ocean": ("#06B6D4", "#3B82F6", "#8B5CF6"),
               "sunset": ("#F59E0B", "#EF4444", "#EC4899")}


class ProgressRing(AnimWidget):
    """Gradient ring with a percentage in the middle (animates to every new value)."""
    FPS = 30

    def __init__(self, size=110, style="purple", text=None, thickness=0.12, parent=None):
        super().__init__(parent)
        self.colors = [QColor(x) for x in RING_STYLES.get(style, style)]
        self._value, self._text, self.thick = 0.0, text, thickness
        self.indeterminate = False
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(900)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(self._set)
        self.setFixedSize(px(size), px(size))

    def _set(self, v):
        self._value = float(v)
        self.update()

    def set_value(self, v, text=None):
        v = max(0.0, min(1.0, float(v)))
        if text is not None:
            self._text = text
        self._anim.stop()
        self._anim.setStartValue(self._value)
        self._anim.setEndValue(v)
        self._anim.start()

    def set_indeterminate(self, on):
        self.indeterminate = bool(on)
        if on:
            self._timer.start()
        else:
            self._timer.stop()
            self.update()

    def showEvent(self, e):
        if self.indeterminate:
            self._timer.start()
        super().showEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        s = min(self.width(), self.height())
        w = s * self.thick
        r = QRectF((self.width() - s) / 2 + w * 1.2, (self.height() - s) / 2 + w * 1.2, s - w * 2.4, s - w * 2.4)
        p.setPen(QPen(theme.fg_color(34), w))
        p.setBrush(NOBRUSH)
        p.drawEllipse(r)
        val = self._value
        start = 0.0
        if self.indeterminate:
            val, start = 0.28 + 0.12 * math.sin(self.t() * 2), self.t() * 280
        if val > 0.002:
            p.save()
            p.translate(r.center())
            p.rotate(-90 + start)
            local = QRectF(-r.width() / 2, -r.height() / 2, r.width(), r.height())
            g = QConicalGradient(0, 0, 0)
            n = len(self.colors)
            for i, col in enumerate(self.colors):
                g.setColorAt(max(0.0, min(1.0, 1 - i / max(1, n - 1))), col)
            glow = QPen(QBrush(g), w * 1.9)
            glow.setCapStyle(Qt.PenCapStyle.RoundCap)
            p.setOpacity(0.22)
            p.setPen(glow)
            p.drawArc(local, 0, int(-val * 360 * 16))
            p.setOpacity(1.0)
            pen = QPen(QBrush(g), w)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            p.setPen(pen)
            p.drawArc(local, 0, int(-val * 360 * 16))
            p.restore()
        txt = self._text if self._text is not None else f"{int(round(self._value * 100))}%"
        if txt:
            f = QFont(self.font())
            f.setBold(True)
            f.setPixelSize(int(s * (0.24 if len(txt) <= 4 else 0.17)))
            p.setFont(f)
            p.setPen(QColor(theme.icon_on()))
            p.drawText(QRectF(self.rect()), int(Qt.AlignmentFlag.AlignCenter), txt)


# =====================================================================================================  ROLLING NUMBER
class RollingNumber(AnimWidget):
    """Odometer counter: every digit is a vertical strip that rolls to the new value."""
    FPS = 40

    def __init__(self, value=0, size=34, color="#FFFFFF", suffix="", min_digits=1, parent=None):
        super().__init__(parent)
        self._cur, self._target = float(value), float(value)
        self.color, self.suffix, self.min_digits, self.size_px = QColor(color), suffix, min_digits, px(size)
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(1400)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(self._set)
        f = QFont("Consolas")
        f.setStyleHint(QFont.StyleHint.Monospace)
        f.setBold(True)
        f.setPixelSize(self.size_px)
        self._font = f
        self._fm = QFontMetricsF(f)
        self.setMinimumHeight(int(self.size_px * 1.25))
        self.setMinimumWidth(int(self._fm.horizontalAdvance("0") * 4))

    def _set(self, v):
        self._cur = float(v)
        self.update()

    def set_value(self, v):
        v = float(max(0, v))
        if abs(v - self._target) < 1e-9:
            return
        self._target = v
        self._anim.stop()
        self._anim.setStartValue(self._cur)
        self._anim.setEndValue(v)
        self._anim.start()
        self._timer.stop()

    def value(self):
        return self._target

    def showEvent(self, e):
        QWidget.showEvent(self, e)

    def hideEvent(self, e):
        QWidget.hideEvent(self, e)

    def sizeHint(self):
        n = max(self.min_digits, len(str(int(self._target))))
        return QSize(int(self._fm.horizontalAdvance("0") * (n + n // 3) + self._fm.horizontalAdvance(self.suffix) + 6),
                     int(self.size_px * 1.25))

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        p.setFont(self._font)
        cur = max(0.0, self._cur)
        n = max(self.min_digits, len(str(int(round(max(cur, self._target))))))
        adv, h = self._fm.horizontalAdvance("0"), self.size_px * 1.25
        x = 2.0
        for k in range(n - 1, -1, -1):
            dv = (cur / (10 ** k)) % 10
            shown = k < max(self.min_digits, len(str(int(round(cur)))))
            cell = QRectF(x, (self.height() - h) / 2, adv, h)
            p.save()
            p.setClipRect(cell)
            base = int(math.floor(dv))
            for j in (base, base + 1):
                off = (j - dv) * h
                a = max(0.0, 1.0 - abs(j - dv) * 0.95) * (1.0 if shown else 0.0)
                col = QColor(self.color)
                col.setAlphaF(a)
                p.setPen(col)
                p.drawText(QRectF(cell.left(), cell.top() + off, cell.width(), h), int(Qt.AlignmentFlag.AlignCenter), str(j % 10))
            p.restore()
            x += adv
            if k % 3 == 0 and k > 0:
                p.setPen(_c(self.color.name(), 150 if shown else 0))
                p.drawText(QRectF(x, (self.height() - h) / 2, adv * .6, h), int(Qt.AlignmentFlag.AlignCenter), ",")
                x += adv * .6
        if self.suffix:
            f2 = QFont(self._font)
            f2.setPixelSize(int(self.size_px * .5))
            p.setFont(f2)
            p.setPen(_c(self.color.name(), 170))
            p.drawText(QRectF(x + 4, (self.height() - h) / 2, 200, h), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignBottom), self.suffix)


# =====================================================================================================  DOT RING (dot-matrix dashboard)
class DotRing(AnimWidget):
    """Dotted circular gauge in the style of the dot-matrix dashboard (orange progress, white dots)."""
    FPS = 30

    def __init__(self, size=130, accent="#FF5A2E", label="", parent=None):
        super().__init__(parent)
        self.accent, self.label, self._value, self._shown, self.text = QColor(accent), label, 0.0, 0.0, ""
        self.setFixedSize(px(size), px(size))

    def set_value(self, v, text=""):
        self._value, self.text = max(0.0, min(1.0, v)), text
        self.update()

    def advance(self):
        self._shown += (self._value - self._shown) * 0.12

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        s = min(self.width(), self.height())
        c = QPointF(self.width() / 2, self.height() / 2)
        t = self.t()
        for ring, (rad, n, dsz) in enumerate(((0.44, 64, 0.022), (0.33, 44, 0.016), (0.22, 28, 0.012))):
            for i in range(n):
                a = 2 * math.pi * i / n - math.pi / 2
                frac = i / n
                on = frac < self._shown and ring == 0
                if on:
                    col, d = self.accent, s * dsz * 1.15
                else:
                    col, d = (QColor(255, 255, 255, 200 - ring * 50) if theme.is_dark() else QColor(40, 40, 60, 170 - ring * 40)), s * dsz
                    wave = 0.5 + 0.5 * math.sin(t * 2 + i * 0.35 + ring)
                    col.setAlpha(int(col.alpha() * (0.45 + 0.55 * wave)))
                p.setPen(NOPEN)
                p.setBrush(col)
                p.drawEllipse(QPointF(c.x() + math.cos(a) * s * rad, c.y() + math.sin(a) * s * rad), d, d)
        f = QFont("Consolas")
        f.setBold(True)
        f.setPixelSize(int(s * 0.2))
        p.setFont(f)
        p.setPen(QColor(theme.icon_on()))
        p.drawText(QRectF(0, c.y() - s * .17, self.width(), s * .26), int(Qt.AlignmentFlag.AlignCenter), self.text or f"{int(self._shown * 100)}%")
        if self.label:
            f.setPixelSize(int(s * 0.085))
            f.setBold(False)
            p.setFont(f)
            p.setPen(QColor(self.accent))
            p.drawText(QRectF(0, c.y() + s * .08, self.width(), s * .16), int(Qt.AlignmentFlag.AlignCenter), self.label.upper())


# =====================================================================================================  EXPANDING SEARCH BUTTON
class ExpandSearch(QWidget):
    """A round search button that grows into a search bar (click again on the X to fold it back)."""
    opened = Signal()
    closed = Signal()
    fx_skip = True

    def __init__(self, placeholder="Search features...   Ctrl+K", parent=None):
        super().__init__(parent)
        self.H, self.W0, self.W1 = px(46), px(46), px(430)
        self._p, self._open = 0.0, False
        self.edit = QLineEdit(self)
        self.edit.setFrame(False)
        self.edit.setPlaceholderText(placeholder)
        self.edit.setStyleSheet("QLineEdit { background: transparent; border: none; padding: 0px; }")
        self.edit.hide()
        self.edit.installEventFilter(self)
        self.setFixedSize(self.W0, self.H)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(460)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(self._step)
        self._anim.finished.connect(self._done)

    @property
    def is_open(self):
        return self._open

    def _go(self, target):
        self._anim.stop()
        self._anim.setStartValue(self._p)
        self._anim.setEndValue(target)
        self._anim.start()

    def open(self):
        if not self._open:
            self._open = True
            self._go(1.0)
            self.opened.emit()
        QTimer.singleShot(120, self._focus)

    def close_(self):
        if self._open:
            self._open = False
            self.edit.clear()
            self.edit.clearFocus()
            self._go(0.0)
            self.closed.emit()

    def _focus(self):
        if self._open:
            self.edit.show()
            self.edit.setFocus()

    def _done(self):
        if self._open:
            self.edit.setFocus()

    def _step(self, v):
        self._p = float(v)
        self.setFixedWidth(int(_lerp(self.W0, self.W1, self._p)))
        self.edit.setGeometry(int(self.H * 0.92), 0, max(0, self.width() - int(self.H * 1.85)), self.H)
        self.edit.setVisible(self._p > 0.55 and self._open or self._p > 0.55)
        self.update()

    def mousePressEvent(self, e):
        if not self._open:
            self.open()
        elif e.position().x() > self.width() - self.H:
            self.close_()
        else:
            self.edit.setFocus()

    def eventFilter(self, obj, ev):
        if obj is self.edit and ev.type() == QEvent.Type.FocusOut and not self.edit.text() and self._open:
            QTimer.singleShot(150, lambda: self._open and not self.edit.hasFocus() and not self.edit.text() and self.close_())
        elif obj is self.edit and ev.type() == QEvent.Type.KeyPress and ev.key() == Qt.Key.Key_Escape:
            self.close_()
            return True
        return super().eventFilter(obj, ev)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1.5, 1.5, -1.5, -1.5)
        k = self._p
        rad = _lerp(self.H * 0.38, self.H * 0.34, k)
        if theme.is_dark():
            fill, border, icon = _mix(QColor(255, 255, 255, 30), QColor(22, 20, 44, 238), k), QColor(255, 255, 255, int(_lerp(50, 70, k))), QColor("#FFFFFF")
        else:
            fill, border = _mix(QColor(22, 22, 28), QColor(255, 255, 255), k), QColor(20, 20, 30, int(_lerp(0, 40, k)))
            icon = _mix(QColor("#FFFFFF"), QColor("#16161C"), k)
        for i in range(4):                                       # soft shadow that fades in while open
            sh = QColor(0, 0, 0, int(14 * k * (4 - i)))
            p.setPen(NOPEN); p.setBrush(sh)
            p.drawRoundedRect(r.adjusted(-i, i * 1.5, i, i * 1.5 + 1), rad + i, rad + i)
        p.setBrush(fill); p.setPen(QPen(border, 1))
        p.drawRoundedRect(r, rad, rad)
        s = self.H
        draw_icon(p, "search", QRectF(s * .27, s * .27, s * .46, s * .46), icon, 0.1)
        if k > 0.6:
            ic = QColor(icon); ic.setAlphaF(min(1.0, (k - 0.6) / 0.4))
            draw_icon(p, "close", QRectF(self.width() - s * .72, s * .28, s * .44, s * .44), ic, 0.1)


# =====================================================================================================  LIGHT / DARK GLASS TOGGLE
class GlassToggle(QAbstractButton):
    """Glass bubble that slides between a moon (dark) and a sun (light) while stretching like a drop of water."""
    modeRequested = Signal(str)
    fx_skip = True

    def __init__(self, dark=True, parent=None):
        super().__init__(parent)
        self._dark = dark
        self._pos = 0.0 if dark else 1.0
        self.setFixedSize(px(138), px(46))
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(720)
        ec = QEasingCurve(QEasingCurve.Type.OutBack)
        ec.setOvershoot(1.15)
        self._anim.setEasingCurve(ec)
        self._anim.valueChanged.connect(self._move)
        self.clicked.connect(lambda: self.modeRequested.emit("light" if self._dark else "dark"))
        self._spin = QTimer(self)
        self._spin.setInterval(33)
        self._spin.timeout.connect(self.update)

    def showEvent(self, e):
        self._spin.start()
        super().showEvent(e)

    def hideEvent(self, e):
        self._spin.stop()
        super().hideEvent(e)

    def set_dark(self, dark, animate=True):
        self._dark = bool(dark)
        tgt = 0.0 if dark else 1.0
        if not animate:
            self._pos = tgt
            self.update()
            return
        self._anim.stop()
        self._anim.setStartValue(self._pos)
        self._anim.setEndValue(tgt)
        self._anim.start()

    def _move(self, v):
        self._pos = float(v)
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        W, H = self.width(), self.height()
        pos = max(0.0, min(1.0, self._pos))
        dark_ui = theme.is_dark()
        tr = QRectF(1, H * 0.14, W - 2, H * 0.72)
        g = QLinearGradient(tr.topLeft(), tr.bottomLeft())
        if dark_ui:
            g.setColorAt(0, QColor(255, 255, 255, 52)); g.setColorAt(1, QColor(255, 255, 255, 14))
        else:
            g.setColorAt(0, QColor(20, 20, 30, 70)); g.setColorAt(1, QColor(20, 20, 30, 26))
        p.setPen(QPen(QColor(255, 255, 255, 40) if dark_ui else QColor(20, 20, 30, 40), 1))
        p.setBrush(g)
        p.drawRoundedRect(tr, tr.height() / 2, tr.height() / 2)
        # labels: the one the bubble is NOT covering
        f = QFont(self.font()); f.setPixelSize(int(H * 0.30)); f.setWeight(QFont.Weight.DemiBold)
        p.setFont(f)
        txt = theme.icon_on()
        for name, x0, a in (("Light", W * 0.50, 1 - pos), ("Dark", W * 0.06, pos)):
            col = QColor(txt); col.setAlphaF(max(0.0, min(1.0, a)) * 0.95)
            p.setPen(col)
            p.drawText(QRectF(x0, 0, W * 0.44, H), int(Qt.AlignmentFlag.AlignCenter), name)
        # the bubble
        D = H * 0.98
        st = 4 * pos * (1 - pos)
        bw, bh = D * (1 + 0.42 * st), D * (1 - 0.10 * st)
        cx = _lerp(D / 2 + 1, W - D / 2 - 1, pos)
        b = QRectF(cx - bw / 2, H / 2 - bh / 2, bw, bh)
        glow = QRadialGradient(b.center(), bw * 0.95)
        glow.setColorAt(0.5, QColor(255, 255, 255, int((20 + 26 * pos) if dark_ui else 14)))
        glow.setColorAt(1, QColor(255, 255, 255, 0))
        p.setPen(NOPEN); p.setBrush(glow)
        p.drawEllipse(b.center(), bw * .95, bh * .95)
        body = QRadialGradient(b.center() + QPointF(-bw * .1, -bh * .18), bw * .75)
        if dark_ui:
            body.setColorAt(0, QColor(255, 255, 255, 18 + int(26 * pos))); body.setColorAt(0.7, QColor(255, 255, 255, 30))
            body.setColorAt(1, QColor(255, 255, 255, 120))
        else:
            body.setColorAt(0, QColor(255, 255, 255, 235)); body.setColorAt(1, QColor(210, 214, 232, 235))
        p.setBrush(body)
        p.setPen(QPen(QColor(255, 255, 255, 150) if dark_ui else QColor(20, 20, 30, 70), 1.2))
        p.drawEllipse(b)
        p.setPen(QPen(QColor(255, 255, 255, 170), max(1.2, H * .04), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))   # glint
        p.setBrush(NOBRUSH)
        p.drawArc(b.adjusted(bw * .12, bh * .1, -bw * .12, -bh * .1), int(110 * 16), int(55 * 16))
        # sun / moon
        c, ic = b.center(), H * 0.17
        col = QColor("#FFFFFF" if dark_ui else "#16161C")
        p.save()
        p.translate(c)
        sun_a, moon_a = pos, 1 - pos
        if sun_a > 0.02:
            q = QColor(col); q.setAlphaF(sun_a)
            p.setPen(QPen(q, max(1.4, ic * .22), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)); p.setBrush(q)
            p.save(); p.rotate(pos * 120)
            p.drawEllipse(QPointF(0, 0), ic * .52, ic * .52)
            for i in range(8):
                a = i * math.pi / 4
                p.drawLine(QPointF(math.cos(a) * ic * .85, math.sin(a) * ic * .85), QPointF(math.cos(a) * ic * 1.2, math.sin(a) * ic * 1.2))
            p.restore()
        if moon_a > 0.02:
            q = QColor(col); q.setAlphaF(moon_a)
            path = QPainterPath(); path.addEllipse(QPointF(0, 0), ic * .95, ic * .95)
            cut = QPainterPath(); cut.addEllipse(QPointF(ic * .55, -ic * .35), ic * .8, ic * .8)
            p.setPen(NOPEN); p.setBrush(q)
            p.rotate(-20 + (1 - moon_a) * -90)
            p.drawPath(path.subtracted(cut))
        p.restore()


# =====================================================================================================  ROUND NAV BUTTON WITH RAINBOW RIM
class _Pill(QWidget):
    """Small floating label that slides out next to a hovered nav button (shared by all of them)."""
    _inst = None

    @classmethod
    def get(cls):
        if cls._inst is None:
            cls._inst = _Pill()
        return cls._inst

    def __init__(self):
        super().__init__(None, Qt.WindowType.ToolTip | Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self._text = ""
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(200)
        self._anim.valueChanged.connect(self._tick)
        self._anim.finished.connect(self._fin)
        self._k = 0.0
        self._base = QPointF()

    def _tick(self, v):
        self._k = float(v)
        self.setWindowOpacity(self._k)
        self.move(int(self._base.x() + (self._k - 1) * px(10)), int(self._base.y()))

    def _fin(self):
        if self._k <= 0.01:
            self.hide()

    def show_at(self, text, gx, gy):
        if not text:
            return
        self._text = text
        f = QFont(self.font()); f.setPixelSize(px(15)); f.setWeight(QFont.Weight.DemiBold)
        w = QFontMetricsF(f).horizontalAdvance(text) + px(34)
        h = px(40)
        self.resize(int(w), h)
        self._base = QPointF(gx, gy - h / 2)
        self.setWindowOpacity(0.0)
        self.show()
        self._anim.stop(); self._anim.setStartValue(self._k); self._anim.setEndValue(1.0); self._anim.start()

    def hide_pill(self):
        self._anim.stop(); self._anim.setStartValue(self._k); self._anim.setEndValue(0.0); self._anim.start()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(2, 2, -2, -2)
        p.setPen(QPen(QColor(255, 255, 255, 70) if theme.is_dark() else QColor(20, 20, 30, 50), 1))
        p.setBrush(QColor(20, 18, 40, 240) if theme.is_dark() else QColor(255, 255, 255, 245))
        p.drawRoundedRect(r, r.height() / 2, r.height() / 2)
        f = QFont(self.font()); f.setPixelSize(px(15)); f.setWeight(QFont.Weight.DemiBold)
        p.setFont(f)
        p.setPen(QColor("#FFFFFF" if theme.is_dark() else "#16161C"))
        p.drawText(r, int(Qt.AlignmentFlag.AlignCenter), self._text)


_RAINBOW = [(0.00, "#FF3B30"), (0.14, "#FF9F0A"), (0.28, "#FFFFFF"), (0.42, "#32D2FF"), (0.58, "#3B5BFF"),
            (0.74, "#D646FF"), (0.88, "#FF6A3D"), (1.00, "#FF3B30")]


def paint_rainbow_ring(p, c, R, width, angle, strength):
    g = QConicalGradient(c, -angle)
    for pos, col in _RAINBOW:
        g.setColorAt(pos, _c(col, 255 * strength))
    p.setBrush(NOBRUSH)
    p.setPen(QPen(QBrush(g), width))
    p.drawEllipse(c, R, R)


class GlowNav(QAbstractButton):
    """Sidebar button: glass disc, rainbow rim light that wakes up on hover / when selected, label slides out."""
    fx_skip = True

    def __init__(self, tip, icon=None, art=None, parent=None):
        super().__init__(parent)
        self.icon_kind, self.art_name, self.label_text = icon, art, tip
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setFixedSize(px(50), px(50))
        self._g, self._hover = 0.0, False
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(320)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(self._gset)
        self._clk = QElapsedTimer(); self._clk.start()
        self._spin = QTimer(self); self._spin.setInterval(30); self._spin.timeout.connect(self.update)
        self.toggled.connect(lambda _: self._retarget())

    def _gset(self, v):
        self._g = float(v)
        if self._g > 0.02 and not self._spin.isActive() and self.isVisible():
            self._spin.start()
        elif self._g <= 0.02 and self._spin.isActive():
            self._spin.stop()
        self.update()

    def _retarget(self):
        self._anim.stop()
        self._anim.setStartValue(self._g)
        self._anim.setEndValue(1.0 if (self._hover or self.isChecked()) else 0.0)
        self._anim.start()

    def enterEvent(self, e):
        self._hover = True
        self._retarget()
        if self.label_text:
            gp = self.mapToGlobal(QPointF(self.width() + px(10), self.height() / 2).toPoint())
            _Pill.get().show_at(self.label_text, gp.x(), gp.y())
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._hover = False
        self._retarget()
        _Pill.get().hide_pill()
        super().leaveEvent(e)

    def hideEvent(self, e):
        self._spin.stop()
        super().hideEvent(e)

    def paintEvent(self, e):
        from .icons import art_pixmap
        p = QPainter(self)
        p.setRenderHint(AA)
        p.setRenderHint(SMOOTH)
        c = QPointF(self.width() / 2, self.height() / 2)
        R = min(self.width(), self.height()) / 2 - px(5)
        g = self._g
        press = 0.94 if self.isDown() else 1.0
        R *= press
        if g > 0.02:
            halo = QRadialGradient(c, R * 1.55)
            halo.setColorAt(0.5, QColor(255, 255, 255, int(34 * g))); halo.setColorAt(1, QColor(255, 255, 255, 0))
            p.setPen(NOPEN); p.setBrush(halo)
            p.drawEllipse(c, R * 1.55, R * 1.55)
        p.setPen(QPen(theme.fg_color(int(70 * (1 - g))), 1.2))
        p.setBrush(QColor(14, 14, 24, 220) if theme.is_dark() else QColor(255, 255, 255, 240))
        p.drawEllipse(c, R, R)
        if g > 0.02:
            ang = (self._clk.elapsed() / 1000.0 * 85) % 360
            paint_rainbow_ring(p, c, R, px(2.6) * (0.5 + 0.7 * g), ang, g)
            a = math.radians(ang)
            spot = QPointF(c.x() + math.cos(a) * R, c.y() - math.sin(a) * R)
            fl = QRadialGradient(spot, R * 0.9)
            fl.setColorAt(0, QColor(255, 255, 255, int(210 * g))); fl.setColorAt(1, QColor(255, 255, 255, 0))
            p.setPen(NOPEN); p.setBrush(fl)
            p.drawEllipse(spot, R * .9, R * .9)
        inner = QRectF(c.x() - R * .56, c.y() - R * .56, R * 1.12, R * 1.12)
        if self.art_name:
            pm = art_pixmap(self.art_name).scaled(int(inner.width() * 2 * self.devicePixelRatioF()), int(inner.height() * 2 * self.devicePixelRatioF()),
                                                  Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            pm.setDevicePixelRatio(self.devicePixelRatioF())
            sz = pm.size() / self.devicePixelRatioF()
            p.drawPixmap(QPointF(c.x() - sz.width() / 2, c.y() - sz.height() / 2), pm)
        elif self.icon_kind:
            col = ("#FFFFFF" if theme.is_dark() else "#16161C") if (self.isChecked() or g > .3) else theme.icon_off()
            draw_icon(p, self.icon_kind, inner, col, 0.1)


# =====================================================================================================  EVERY BUTTON: shine + ripple + busy loader
_LAST_PRESS = [None, 0.0]


class _BusyHub(QObject):
    changed = Signal(int)

    def __init__(self):
        super().__init__()
        self.count = 0


_HUB = None


def busy_hub():
    global _HUB
    if _HUB is None:
        _HUB = _BusyHub()
    return _HUB


def job_started():
    """Called by run_async: the button that was just pressed shows a loader until the job is done."""
    app = QCoreApplication.instance()
    if app is None or QThread.currentThread() != app.thread():
        return None
    h = busy_hub()
    h.count += 1
    h.changed.emit(h.count)
    tgt = None
    ref, t0 = _LAST_PRESS
    if ref is not None and time.monotonic() - t0 < 0.4:
        ov = ref()
        if ov is not None:
            ov.set_busy(+1)
            tgt = weakref.ref(ov)
    return (tgt,)


def job_finished(token):
    if token is None:
        return
    h = busy_hub()
    h.count = max(0, h.count - 1)
    h.changed.emit(h.count)
    if token[0] is not None:
        ov = token[0]()
        if ov is not None:
            ov.set_busy(-1)


class _BtnOverlay(QWidget):
    def __init__(self, btn):
        super().__init__(btn)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self.btn = btn
        self.shine, self.ripples, self.busy_n, self.busy_t0 = None, [], 0, 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._tick)
        self.setGeometry(btn.rect())
        btn.installEventFilter(self)
        self.show()
        self.raise_()

    def set_busy(self, d):
        self.busy_n = max(0, self.busy_n + d)
        if self.busy_n and d > 0:
            self.busy_t0 = time.monotonic()
        self._go()

    def _go(self):
        if not self._timer.isActive():
            self._timer.start()

    def eventFilter(self, obj, ev):
        t = ev.type()
        if t == QEvent.Type.Resize:
            self.setGeometry(obj.rect())
        elif t == QEvent.Type.Enter and obj.isEnabled():
            self.shine = time.monotonic()
            self._go()
        elif t == QEvent.Type.MouseButtonPress and obj.isEnabled():
            now = time.monotonic()
            self.ripples.append((ev.position().x(), ev.position().y(), now))
            _LAST_PRESS[0], _LAST_PRESS[1] = weakref.ref(self), now
            self._go()
        elif t == QEvent.Type.Show:
            self.raise_()
        return False

    def _tick(self):
        now = time.monotonic()
        self.ripples = [r for r in self.ripples if now - r[2] < 0.65]
        if self.shine is not None and now - self.shine > 0.7:
            self.shine = None
        if not (self.ripples or self.shine is not None or self.busy_n):
            self._timer.stop()
        self.update()

    def _radius(self):
        n = self.btn.__class__.__name__
        w, h = self.width(), self.height()
        if n in ("IconButton", "RailButton", "NavButton"):
            return min(w, h) / 2
        if n == "ArtTile":
            return px(26)
        if n == "TechKey":
            return px(12)
        return min(px(14), min(w, h) / 2)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        w, h = self.width(), self.height()
        p.setClipPath(_round_path(self.rect(), self._radius()))
        now = time.monotonic()
        if self.shine is not None:
            k = (now - self.shine) / 0.65
            if 0 <= k < 1:
                x = _lerp(-w * 0.45, w * 1.1, k)
                g = QLinearGradient(x, 0, x + w * 0.4, h * 0.5)
                g.setColorAt(0, QColor(255, 255, 255, 0)); g.setColorAt(0.5, QColor(255, 255, 255, 62)); g.setColorAt(1, QColor(255, 255, 255, 0))
                p.fillRect(self.rect(), g)
        for x, y, t0 in self.ripples:
            k = (now - t0) / 0.6
            if 0 <= k < 1:
                rad = max(w, h) * 1.15 * (1 - (1 - k) ** 3)
                g = QRadialGradient(QPointF(x, y), max(1.0, rad))
                g.setColorAt(0, QColor(255, 255, 255, int(110 * (1 - k)))); g.setColorAt(0.85, QColor(255, 255, 255, int(40 * (1 - k)))); g.setColorAt(1, QColor(255, 255, 255, 0))
                p.setPen(NOPEN); p.setBrush(g)
                p.drawEllipse(QPointF(x, y), rad, rad)
        if self.busy_n:
            p.fillRect(self.rect(), QColor(0, 0, 0, 105))
            s = min(h * 0.72, px(34))
            kind = LOADER_KINDS[abs(hash(self.btn.text() if hasattr(self.btn, "text") else "")) % len(LOADER_KINDS)]
            paint_loader(p, kind, QRectF((w - s) / 2, (h - s) / 2, s, s), now - self.busy_t0, QColor("#FFFFFF"))


class _Installer(QObject):
    def eventFilter(self, obj, ev):
        t = ev.type()
        if t in (QEvent.Type.Polish, QEvent.Type.Show) and isinstance(obj, QAbstractButton):
            if (isinstance(obj, QPushButton) or getattr(obj, "fx_ripple", False)) and not getattr(obj, "fx_skip", False) \
                    and not obj.property("_fxon"):
                obj.setProperty("_fxon", True)
                _BtnOverlay(obj)
        return False


_installer = None


def install_button_fx(app=None):
    """Gives every QPushButton / icon button / tile in the app the shine + ripple + busy-loader animation."""
    global _installer
    app = app or QApplication.instance()
    _installer = _Installer(app)
    app.installEventFilter(_installer)


# =====================================================================================================  TECH KEYS (keyboard picture)
class TechKey(QPushButton):
    """Calculator key in the style of the keyboard picture: dark plate, light corner brackets, orange edge light."""

    def __init__(self, text, kind="key", hint="", parent=None):
        super().__init__(text, parent)
        self.kind, self.hint = kind, hint
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._hover = False
        self.setMouseTracking(True)

    def enterEvent(self, e):
        self._hover = True; self.update(); super().enterEvent(e)

    def leaveEvent(self, e):
        self._hover = False; self.update(); super().leaveEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(2, 2, -2, -2)
        if self.isDown():
            r = r.adjusted(2, 2, -2, -2)
        dark = theme.is_dark()
        rad = min(r.height() * 0.2, px(14))
        g = QLinearGradient(r.topLeft(), r.bottomLeft())
        if self.kind == "op":
            top, bot = QColor("#FFA24D"), QColor("#E0620F")
        elif self.kind == "fn":
            top, bot = (QColor(70, 48, 28), QColor(30, 22, 16)) if dark else (QColor(255, 236, 214), QColor(246, 214, 176))
        else:
            top, bot = (QColor(58, 58, 66), QColor(20, 20, 26)) if dark else (QColor(255, 255, 255), QColor(226, 226, 236))
        if self._hover:
            top = top.lighter(118)
        g.setColorAt(0, top); g.setColorAt(1, bot)
        p.setPen(QPen(QColor(255, 255, 255, 60) if dark else QColor(20, 20, 30, 50), 1))
        p.setBrush(g)
        p.drawRoundedRect(r, rad, rad)
        L = r.height() * 0.24
        br = QPen(QColor(255, 255, 255, 215) if (dark or self.kind == "op") else QColor(30, 30, 40, 200), 1.7)
        br.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(br)
        p.setBrush(NOBRUSH)
        p.drawLine(QPointF(r.left() + rad * .5, r.top() + 1.5), QPointF(r.left() + L + rad * .5, r.top() + 1.5))
        p.drawLine(QPointF(r.left() + 1.5, r.top() + rad * .5), QPointF(r.left() + 1.5, r.top() + L + rad * .5))
        p.drawLine(QPointF(r.right() - L - rad * .5, r.bottom() - 1.5), QPointF(r.right() - rad * .5, r.bottom() - 1.5))
        p.drawLine(QPointF(r.right() - 1.5, r.bottom() - L - rad * .5), QPointF(r.right() - 1.5, r.bottom() - rad * .5))
        glow = QLinearGradient(r.left(), r.bottom(), r.right(), r.bottom())            # orange edge light under the key
        glow.setColorAt(0, QColor(255, 140, 40, 0)); glow.setColorAt(0.45, QColor(255, 140, 40, 230 if self.kind != "op" else 120)); glow.setColorAt(1, QColor(255, 140, 40, 0))
        p.setPen(QPen(QBrush(glow), 2.4))
        p.drawLine(QPointF(r.left() + rad, r.bottom() - 3), QPointF(r.right() - rad, r.bottom() - 3))
        if self.hint:
            f = QFont(self.font()); f.setPixelSize(max(8, int(r.height() * 0.17)))
            p.setFont(f)
            p.setPen(QColor(255, 255, 255, 150) if dark or self.kind == "op" else QColor(30, 30, 40, 150))
            p.drawText(QRectF(r.left(), r.top() + 3, r.width() - 8, r.height() * .3), int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop), self.hint)
        f = QFont(self.font()); f.setPixelSize(int(r.height() * 0.42)); f.setBold(True)
        p.setFont(f)
        p.setPen(QColor("#1b0d00") if self.kind == "op" else QColor("#FFFFFF" if dark else "#16161C"))
        p.drawText(r, int(Qt.AlignmentFlag.AlignCenter), self.text())


# =====================================================================================================  3D RUBIK'S CUBE
FACE_N = {"U": (0, 1, 0), "R": (1, 0, 0), "F": (0, 0, 1), "D": (0, -1, 0), "L": (-1, 0, 0), "B": (0, 0, -1)}
STICKER = {"U": "#F4F4F4", "R": "#E03A3E", "F": "#2FB36B", "D": "#F7D238", "L": "#FF8A2B", "B": "#2F6FE0"}
_I3 = ((1, 0, 0), (0, 1, 0), (0, 0, 1))


def facelet_pos(face, i):
    """World position (x right, y up, z toward you) of facelet i (0..8, row-major) of a face in URFDLB order."""
    r, c = divmod(i, 3)
    return {"U": (c - 1, 1, r - 1), "R": (1, 1 - r, 1 - c), "F": (c - 1, 1 - r, 1),
            "D": (c - 1, -1, 1 - r), "L": (-1, 1 - r, c - 1), "B": (1 - c, 1 - r, -1)}[face]


def _mv(M, v):
    return tuple(sum(M[i][j] * v[j] for j in range(3)) for i in range(3))


def _mm(A, B):
    return tuple(tuple(sum(A[i][k] * B[k][j] for k in range(3)) for j in range(3)) for i in range(3))


def quarter_matrix(n, s):
    """Integer rotation of 90 degrees * s about unit axis n (right-hand rule)."""
    nx, ny, nz = n
    cross = ((0, -nz, ny), (nz, 0, -nx), (-ny, nx, 0))
    return tuple(tuple(s * cross[i][j] + n[i] * n[j] for j in range(3)) for i in range(3))


def parse_move(m):
    """'R' -> ('R', quarter turns -1) ; "R'" -> +1 ; 'R2' -> 2.   A clockwise turn seen from outside is -90 deg about the face normal."""
    face = m[0]
    if face not in FACE_N:
        return None
    if m.endswith("2"):
        return face, 2
    return face, (1 if m.endswith("'") else -1)


def invert_move(m):
    return m if m.endswith("2") else (m[:-1] if m.endswith("'") else m + "'")


class CubeModel:
    """27 cubies, each with a position, an orientation and coloured stickers.  Qt-free so it can be unit-tested."""

    def __init__(self, facelets=None):
        self.set_facelets(facelets)

    def set_facelets(self, facelets):
        self.cubies = []
        pos_map = {}
        for x in (-1, 0, 1):
            for y in (-1, 0, 1):
                for z in (-1, 0, 1):
                    if (x, y, z) != (0, 0, 0):
                        cb = {"pos": (x, y, z), "M": _I3, "st": {}}
                        self.cubies.append(cb)
                        pos_map[(x, y, z)] = cb
        if facelets and len(facelets) == 54:
            for fi, face in enumerate("URFDLB"):
                for i in range(9):
                    pos_map[facelet_pos(face, i)]["st"][FACE_N[face]] = facelets[fi * 9 + i]
        self.coloured = bool(facelets and len(facelets) == 54)

    def layer(self, face):
        n = FACE_N[face]
        return [cb for cb in self.cubies if sum(cb["pos"][i] * n[i] for i in range(3)) == 1]

    def apply(self, move):
        pm = parse_move(move)
        if not pm:
            return
        face, k = pm
        n = FACE_N[face]
        q = quarter_matrix(n, -1 if k < 0 else 1)
        for _ in range(abs(k)):
            for cb in self.layer(face):
                cb["pos"] = _mv(q, cb["pos"])
                cb["M"] = _mm(q, cb["M"])

    def facelets(self):
        by_pos = {cb["pos"]: cb for cb in self.cubies}
        out = []
        for face in "URFDLB":
            for i in range(9):
                cb = by_pos[facelet_pos(face, i)]
                letter = "?"
                for ln, ch in cb["st"].items():
                    if _mv(cb["M"], ln) == FACE_N[face]:
                        letter = ch
                out.append(letter)
        return "".join(out)


def _axis_angle(n, a):
    c, s = math.cos(a), math.sin(a)
    x, y, z = n
    return ((c + x * x * (1 - c), x * y * (1 - c) - z * s, x * z * (1 - c) + y * s),
            (y * x * (1 - c) + z * s, c + y * y * (1 - c), y * z * (1 - c) - x * s),
            (z * x * (1 - c) - y * s, z * y * (1 - c) + x * s, c + z * z * (1 - c)))


def _mvf(M, v):
    return (M[0][0] * v[0] + M[0][1] * v[1] + M[0][2] * v[2], M[1][0] * v[0] + M[1][1] * v[1] + M[1][2] * v[2],
            M[2][0] * v[0] + M[2][1] * v[1] + M[2][2] * v[2])


_AXES = [((1, 0, 0), (0, 1, 0), (0, 0, 1)), ((0, 1, 0), (0, 0, 1), (1, 0, 0)), ((0, 0, 1), (1, 0, 0), (0, 1, 0))]


class Cube3D(AnimWidget):
    """Spinning cube whose layers slide apart and turn (the cube video).  Without a scanned cube it plays with itself in
    shiny black metal; with one it shows the real sticker colours and performs the solution move by move."""
    FPS = 50

    def __init__(self, parent=None):
        super().__init__(parent)
        self.model = CubeModel(None)
        self._initial, self._moves, self._applied = None, [], 0
        self.yaw, self.pitch = 35.0, 24.0
        self._drag, self._last_user = None, -10.0
        self._queue, self._cur, self._cur_t0, self._cur_dur = [], None, 0.0, 0.5
        self.explode_mode = "auto"           # "auto" breathing, "tight" for the solution view
        self._next_idle = 2.0
        self._dust = [((i * 73) % 100 / 100.0, (i * 37) % 100 / 100.0, 0.4 + (i % 5) * 0.25, i * 0.7) for i in range(46)]
        self._last_tick = self.t()
        self.setMinimumSize(px(200), px(200))
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setCursor(Qt.CursorShape.OpenHandCursor)

    # ---- state ----
    def show_metal(self):
        self._initial, self._moves, self._applied, self._queue, self._cur = None, [], 0, [], None
        self.model = CubeModel(None)
        self.explode_mode = "auto"

    def show_cube(self, facelets, moves=()):
        self._initial, self._moves, self._applied, self._queue, self._cur = facelets, list(moves), 0, [], None
        self.model = CubeModel(facelets)
        self.explode_mode = "tight"

    def goto(self, i):
        """Show the cube after the first i solution moves (animates one step, jumps otherwise)."""
        i = max(0, min(len(self._moves), i))
        if self._cur is not None or self._queue:
            self._finish_all()
        if i == self._applied + 1:
            self._queue.append(self._moves[self._applied])
        elif i == self._applied - 1 and i >= 0:
            self._queue.append(invert_move(self._moves[i]))
        elif i != self._applied:
            self.model = CubeModel(self._initial)
            for m in self._moves[:i]:
                self.model.apply(m)
        self._applied = i

    def _finish_all(self):
        if self._cur:
            self.model.apply(self._cur)
            self._cur = None
        for m in self._queue:
            self.model.apply(m)
        self._queue = []

    def turn(self, move):
        self._queue.append(move)

    # ---- animation ----
    def advance(self):
        now = self.t()
        dt = min(0.1, now - self._last_tick)
        self._last_tick = now
        if self._drag is None and now - self._last_user > 2.5:
            self.yaw = (self.yaw + dt * 22) % 360
        if self._cur is None and self._queue:
            self._cur, self._cur_t0 = self._queue.pop(0), now
            self._cur_dur = 0.62 if self._cur.endswith("2") else 0.42
        elif self._cur is None and not self.model.coloured and now > self._next_idle:
            self._queue.append(random.choice("UDLRFB") + random.choice(["", "'", "2"]))
            self._next_idle = now + 1.6
        if self._cur is not None and (now - self._cur_t0) >= self._cur_dur:
            self.model.apply(self._cur)
            self._cur = None

    def mousePressEvent(self, e):
        self._drag = e.position()
        self.setCursor(Qt.CursorShape.ClosedHandCursor)

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            d = e.position() - self._drag
            self._drag = e.position()
            self.yaw = (self.yaw + d.x() * 0.6) % 360
            self.pitch = max(-80, min(80, self.pitch + d.y() * 0.5))
            self._last_user = self.t()

    def mouseReleaseEvent(self, e):
        self._drag = None
        self._last_user = self.t()
        self.setCursor(Qt.CursorShape.OpenHandCursor)

    # ---- drawing ----
    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        W, H = self.width(), self.height()
        now = self.t()
        for dx, dy, sz, ph in self._dust:                           # floating dust of the video
            a = 0.5 + 0.5 * math.sin(now * 0.8 + ph)
            p.setPen(NOPEN); p.setBrush(QColor(255, 255, 255, int(70 * a) if theme.is_dark() else int(60 * a)))
            if not theme.is_dark():
                p.setBrush(QColor(60, 60, 90, int(50 * a)))
            p.drawEllipse(QPointF(dx * W, (dy * H + now * 4 * sz) % H), sz * 1.1, sz * 1.1)
        k = 0.0
        if self.explode_mode == "auto":
            k = 0.5 - 0.5 * math.cos(now * 0.85)
        sp = 1.0 + 0.075 + k * 0.62
        half = 0.455
        yaw, pitch = math.radians(self.yaw), math.radians(self.pitch)
        cy, sy, cp, sp_ = math.cos(yaw), math.sin(yaw), math.cos(pitch), math.sin(pitch)
        D = 11.0
        unit = min(W, H) / 8.6
        cx, cyy = W / 2, H / 2

        def view(v):
            x1 = cy * v[0] + sy * v[2]
            z1 = -sy * v[0] + cy * v[2]
            y1 = cp * v[1] - sp_ * z1
            z2 = sp_ * v[1] + cp * z1
            return x1, y1, z2

        def proj(v):
            s = D / (D - v[2])
            return QPointF(cx + v[0] * s * unit, cyy - v[1] * s * unit)

        layer_face, rot, ang = None, None, 0.0
        if self._cur:
            pm = parse_move(self._cur)
            if pm:
                layer_face, kq = pm
                u = (now - self._cur_t0) / self._cur_dur
                u = max(0.0, min(1.0, u))
                u = 0.5 - 0.5 * math.cos(math.pi * u)
                ang = math.radians(-90 if kq < 0 else 90) * (2 if abs(kq) == 2 else 1) * u
                rot = _axis_angle(FACE_N[layer_face], ang)
        in_layer = {id(cb) for cb in self.model.layer(layer_face)} if layer_face else set()
        polys = []
        L = (-0.35, 0.65, 0.68)
        dark = theme.is_dark()
        for cb in self.model.cubies:
            moving = id(cb) in in_layer
            centre = tuple(c * sp for c in cb["pos"])
            for ln in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)):
                nw = _mv(cb["M"], ln)
                axis = next(i for i in range(3) if ln[i] != 0)
                u_ax, v_ax = [a for a in range(3) if a != axis]
                verts, local_pts = [], []
                for su, sv in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                    lp = [0.0, 0.0, 0.0]
                    lp[axis] = ln[axis] * half
                    lp[u_ax], lp[v_ax] = su * half, sv * half
                    wp = _mvf(cb["M"], lp)
                    wp = (wp[0] + centre[0], wp[1] + centre[1], wp[2] + centre[2])
                    if moving and rot:
                        wp = _mvf(rot, wp)
                    verts.append(view(wp))
                nvec = _mvf(rot, nw) if (moving and rot) else nw
                nv = view(nvec)
                fc = tuple(sum(v[i] for v in verts) / 4 for i in range(3))
                if nv[0] * fc[0] + nv[1] * fc[1] + nv[2] * (fc[2] - D) >= 0:
                    continue
                lam = max(0.0, nv[0] * L[0] + nv[1] * L[1] + nv[2] * L[2])
                polys.append((fc[2], verts, lam, cb["st"].get(ln)))
        polys.sort(key=lambda it: it[0])
        for _, verts, lam, letter in polys:
            pts = [proj(v) for v in verts]
            poly = QPolygonF(pts)
            if self.model.coloured:
                body = QColor(26, 26, 32)
            else:
                body = QColor(34, 34, 40) if dark else QColor(58, 58, 66)
            shade = 0.5 + 0.5 * lam
            col = QColor(int(body.red() * shade), int(body.green() * shade), int(body.blue() * shade))
            spec = lam ** 9 * (0.85 if not self.model.coloured else 0.25)
            col = QColor(min(255, int(col.red() + 255 * spec)), min(255, int(col.green() + 255 * spec)), min(255, int(col.blue() + 255 * spec)))
            p.setPen(QPen(QColor(255, 255, 255, int(28 + 90 * lam)), 1.0))
            p.setBrush(col)
            p.drawPolygon(poly)
            if letter and letter in STICKER:
                cen = QPointF(sum(q.x() for q in pts) / 4, sum(q.y() for q in pts) / 4)
                inner = QPolygonF([QPointF(cen.x() + (q.x() - cen.x()) * 0.80, cen.y() + (q.y() - cen.y()) * 0.80) for q in pts])
                sc = QColor(STICKER[letter])
                f = 0.62 + 0.38 * lam
                sc = QColor(min(255, int(sc.red() * f + 255 * spec * .6)), min(255, int(sc.green() * f + 255 * spec * .6)), min(255, int(sc.blue() * f + 255 * spec * .6)))
                p.setPen(NOPEN)
                p.setBrush(sc)
                p.drawPolygon(inner)


# =====================================================================================================  FRAME ANIMATION (the two anime videos)
class FrameSprite(AnimWidget):
    """Plays a folder of frames in a rounded card (frames were cut from the reference videos by tools/prepare_fx_assets.py)."""
    FPS = 30

    def __init__(self, folder, fps=10, radius=26, pingpong=True, scan=False, parent=None):
        super().__init__(parent)
        self.folder, self.fps, self.radius, self.pingpong, self.scan = folder, fps, radius, pingpong, scan
        self._bytes, self._pm, self._idx = None, None, -1
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def _load(self):
        d = fx_asset(self.folder)
        names = sorted(n for n in os.listdir(d) if n.lower().endswith(".jpg")) if os.path.isdir(d) else []
        self._bytes = []
        for n in names:
            with open(os.path.join(d, n), "rb") as fh:
                self._bytes.append(fh.read())

    def showEvent(self, e):
        if self._bytes is None:
            self._load()
        super().showEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        p.setRenderHint(SMOOTH)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setClipPath(_round_path(r, px(self.radius)))
        p.fillRect(r, QColor(10, 6, 24))
        n = len(self._bytes or [])
        if n:
            step = int(self.t() * self.fps)
            idx = (n - 1 - abs((step % (2 * n - 2 or 1)) - (n - 1))) if self.pingpong and n > 1 else step % n
            if idx != self._idx:
                pm = QPixmap()
                pm.loadFromData(self._bytes[idx], "JPG")
                self._pm, self._idx = pm, idx
            pm = self._pm
            src = cover_rect(r, pm.width(), pm.height())
            p.drawPixmap(r, pm, src)
        if self.scan:                                              # scanning line over the eye
            y = r.top() + (0.5 + 0.5 * math.sin(self.t() * 1.3)) * r.height()
            g = QLinearGradient(0, y - 40, 0, y + 40)
            g.setColorAt(0, QColor(255, 60, 70, 0)); g.setColorAt(0.5, QColor(255, 80, 90, 70)); g.setColorAt(1, QColor(255, 60, 70, 0))
            p.fillRect(QRectF(r.left(), y - 40, r.width(), 80), g)
        v = QLinearGradient(0, r.bottom() - r.height() * .35, 0, r.bottom())
        v.setColorAt(0, QColor(8, 6, 20, 0)); v.setColorAt(1, QColor(8, 6, 20, 150))
        p.fillRect(r, v)
        p.setClipping(False)
        p.setBrush(NOBRUSH)
        p.setPen(QPen(QColor(255, 255, 255, 55), 1.2))
        p.drawPath(_round_path(r, px(self.radius)))


# =====================================================================================================  DESKTOP PIECES (main menu)
class RailButton(QAbstractButton):
    """Round glass app button of the left rail (rainbow rim on hover, bounce on click)."""
    fx_ripple = True

    def __init__(self, icon, tip, accent="#8B5CF6", art=None, parent=None):
        super().__init__(parent)
        self.icon_kind, self.accent, self.art, self.tip_text = icon, QColor(accent), art, tip
        self.setFixedSize(px(54), px(54))
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._g, self._t0 = 0.0, -9.0
        self._clk = QElapsedTimer(); self._clk.start()
        self._anim = QVariantAnimation(self); self._anim.setDuration(240)
        self._anim.valueChanged.connect(lambda v: (setattr(self, "_g", float(v)), self.update()))
        self._spin = QTimer(self); self._spin.setInterval(30); self._spin.timeout.connect(self.update)
        self.clicked.connect(self._bounce)

    def _bounce(self):
        self._t0 = self._clk.elapsed() / 1000.0
        self._spin.start()
        QTimer.singleShot(900, lambda: None if self._g > 0.02 else self._spin.stop())

    def enterEvent(self, e):
        self._anim.stop(); self._anim.setStartValue(self._g); self._anim.setEndValue(1.0); self._anim.start(); self._spin.start()
        gp = self.mapToGlobal(QPointF(self.width() + px(10), self.height() / 2).toPoint())
        _Pill.get().show_at(self.tip_text, gp.x(), gp.y())
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._anim.stop(); self._anim.setStartValue(self._g); self._anim.setEndValue(0.0); self._anim.start()
        _Pill.get().hide_pill()
        QTimer.singleShot(400, lambda: self._spin.stop() if self._g < 0.02 else None)
        super().leaveEvent(e)

    def paintEvent(self, e):
        from .icons import art_pixmap
        p = QPainter(self)
        p.setRenderHint(AA); p.setRenderHint(SMOOTH)
        now = self._clk.elapsed() / 1000.0
        bounce = max(0.0, 1 - (now - self._t0) / 0.6)
        dy = -abs(math.sin((now - self._t0) * 11)) * px(9) * bounce * bounce
        g = self._g
        c = QPointF(self.width() / 2, self.height() / 2 + dy)
        R = (min(self.width(), self.height()) / 2 - px(5)) * (1 + 0.08 * g) * (0.93 if self.isDown() else 1.0)
        grad = QLinearGradient(c.x(), c.y() - R, c.x(), c.y() + R)
        grad.setColorAt(0, self.accent.lighter(125)); grad.setColorAt(1, self.accent.darker(160))
        p.setPen(QPen(QColor(255, 255, 255, 70), 1.2))
        p.setBrush(grad)
        p.drawEllipse(c, R, R)
        if g > 0.02:
            paint_rainbow_ring(p, c, R + px(1.5), px(2.2), now * 90 % 360, g)
        inner = QRectF(c.x() - R * .52, c.y() - R * .52, R * 1.04, R * 1.04)
        if self.art:
            pm = art_pixmap(self.art)
            p.drawPixmap(inner.toRect(), pm.scaled(inner.size().toSize(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        else:
            draw_icon(p, self.icon_kind, inner, "#FFFFFF", 0.1)


class Dock(AnimWidget):
    """macOS-style dock: icons grow towards the mouse, bounce when opened, small dot under the open page."""
    launched = Signal(str)
    FPS = 60

    def __init__(self, items, parent=None):
        super().__init__(parent)
        self.items = items                       # (key, icon_kind|None, art|None, label, accent)
        n = len(items)
        self.base, self.gap = px(52), px(10)
        self.setFixedSize(int(n * (self.base + self.gap) * 1.0 + self.base * 1.6), int(self.base * 2.0))
        self._scale = [1.0] * n
        self._mx = None
        self._hover = -1
        self._bounce = [-9.0] * n
        self.active = "home"
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def set_active(self, key):
        self.active = key

    def tft_parts(self):
        """Resting rectangle of every icon (the lamp screen shows the icons as a grid of big touch targets)."""
        from PySide6.QtCore import QRect
        n = len(self.items)
        total = n * self.base + self.gap * (n - 1)
        x = (self.width() - total) / 2
        y = self.height() - px(16) - self.base
        pad = 3
        return [QRect(int(x + i * (self.base + self.gap)) - pad, int(y) - pad, int(self.base) + 2 * pad, int(self.base) + 2 * pad)
                for i in range(n)]

    def _rects(self):
        sizes = [self.base * s for s in self._scale]
        total = sum(sizes) + self.gap * (len(sizes) - 1)
        x = (self.width() - total) / 2
        out = []
        for sz in sizes:
            out.append(QRectF(x, self.height() - px(16) - sz, sz, sz))
            x += sz + self.gap
        return out

    def mouseMoveEvent(self, e):
        self._mx = e.position().x()

    def leaveEvent(self, e):
        self._mx = None
        super().leaveEvent(e)

    def advance(self):
        n = len(self.items)
        slot = self.base + self.gap
        x0 = (self.width() - n * slot) / 2
        self._hover = -1
        for i in range(n):
            tgt = 1.0
            if self._mx is not None:
                d = abs(self._mx - (x0 + slot * (i + 0.5))) / (slot * 2.4)
                tgt = 1.0 + 0.62 * max(0.0, math.cos(min(1.0, d) * math.pi / 2)) ** 2
            self._scale[i] += (tgt - self._scale[i]) * 0.28
        if self._mx is not None:
            for i, r in enumerate(self._rects()):
                if r.left() - self.gap / 2 <= self._mx <= r.right() + self.gap / 2:
                    self._hover = i

    def mousePressEvent(self, e):
        for i, r in enumerate(self._rects()):
            if r.adjusted(-self.gap / 2, -self.base, self.gap / 2, self.base).contains(e.position()):
                self._bounce[i] = self.t()
                self.launched.emit(self.items[i][0])
                return

    def paintEvent(self, e):
        from .icons import art_pixmap
        p = QPainter(self)
        p.setRenderHint(AA); p.setRenderHint(SMOOTH)
        bar = QRectF(px(4), self.height() - px(16) - self.base - px(10), self.width() - px(8), self.base + px(20))
        g = QLinearGradient(bar.topLeft(), bar.bottomLeft())
        if theme.is_dark():
            g.setColorAt(0, QColor(255, 255, 255, 40)); g.setColorAt(1, QColor(255, 255, 255, 16)); edge = QColor(255, 255, 255, 60)
        else:
            g.setColorAt(0, QColor(255, 255, 255, 190)); g.setColorAt(1, QColor(255, 255, 255, 130)); edge = QColor(255, 255, 255, 220)
        p.setPen(QPen(edge, 1.2)); p.setBrush(g)
        p.drawRoundedRect(bar, bar.height() * 0.34, bar.height() * 0.34)
        now = self.t()
        for i, (key, icon, art, label_text, accent) in enumerate(self.items):
            r = self._rects()[i]
            bp = max(0.0, 1 - (now - self._bounce[i]) / 0.7)
            r.translate(0, -abs(math.sin((now - self._bounce[i]) * 10)) * px(16) * bp * bp)
            rr = r.height() * 0.28
            ac = QColor(accent)
            tg = QLinearGradient(r.topLeft(), r.bottomRight())
            tg.setColorAt(0, ac.lighter(125)); tg.setColorAt(1, ac.darker(155))
            sh = QRadialGradient(QPointF(r.center().x(), r.bottom() + px(3)), r.width() * .6)
            sh.setColorAt(0, QColor(0, 0, 0, 80)); sh.setColorAt(1, QColor(0, 0, 0, 0))
            p.setPen(NOPEN); p.setBrush(sh)
            p.drawEllipse(QPointF(r.center().x(), r.bottom() + px(3)), r.width() * .5, px(5))
            p.setPen(QPen(QColor(255, 255, 255, 80), 1)); p.setBrush(tg)
            p.drawRoundedRect(r, rr, rr)
            inner = r.adjusted(r.width() * .2, r.height() * .2, -r.width() * .2, -r.height() * .2)
            if key == "__start__":                              # the Windows-style start button
                q = inner.width() * 0.47
                p.setPen(NOPEN); p.setBrush(QColor("#FFFFFF"))
                for dx in (0, 1):
                    for dy in (0, 1):
                        p.drawRoundedRect(QRectF(inner.left() + dx * (q + inner.width() * .06), inner.top() + dy * (q + inner.width() * .06), q, q), 2, 2)
            elif art:
                pm = art_pixmap(art).scaled(inner.size().toSize() * 2, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                tgt = QRectF(inner.center().x() - inner.width() / 2, inner.center().y() - inner.height() / 2, inner.width(), inner.height())
                p.drawPixmap(tgt.toRect(), pm)
            elif icon:
                draw_icon(p, icon, inner, "#FFFFFF", 0.1)
            if key == self.active:
                p.setPen(NOPEN); p.setBrush(QColor("#FFFFFF") if theme.is_dark() else QColor("#16161C"))
                p.drawEllipse(QPointF(r.center().x(), self.height() - px(8)), px(2.6), px(2.6))
            if i == self._hover:
                f = QFont(self.font()); f.setPixelSize(px(13)); f.setWeight(QFont.Weight.DemiBold)
                p.setFont(f)
                tw = QFontMetricsF(f).horizontalAdvance(label_text) + px(22)
                tr = QRectF(r.center().x() - tw / 2, r.top() - px(36), tw, px(26))
                tr.moveLeft(max(2, min(self.width() - tw - 2, tr.left())))
                p.setPen(QPen(QColor(255, 255, 255, 60), 1)); p.setBrush(QColor(20, 18, 40, 235))
                p.drawRoundedRect(tr, px(13), px(13))
                p.setPen(QColor("#FFFFFF"))
                p.drawText(tr, int(Qt.AlignmentFlag.AlignCenter), label_text)


class CalendarCard(QWidget):
    """Dark month calendar with today highlighted (like the one on the desktop picture)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        import datetime as _dt
        self._today = _dt.date.today()
        self.setMinimumSize(px(190), px(210))

    def set_date(self, d):
        if d != self._today:
            self._today = d
            self.update()

    def paintEvent(self, e):
        import calendar
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        p.setPen(QPen(QColor(255, 255, 255, 40), 1)); p.setBrush(QColor(22, 22, 28, 238))
        p.drawRoundedRect(r, px(20), px(20))
        d = self._today
        f = QFont(self.font()); f.setPixelSize(px(19)); f.setBold(True)
        p.setFont(f); p.setPen(QColor("#FFFFFF"))
        p.drawText(QRectF(r.left(), r.top() + px(10), r.width(), px(30)), int(Qt.AlignmentFlag.AlignCenter), d.strftime("%B"))
        p.setPen(QPen(QColor(255, 255, 255, 90), 1))
        p.drawLine(QPointF(r.left() + px(16), r.top() + px(44)), QPointF(r.right() - px(16), r.top() + px(44)))
        cal = calendar.Calendar(firstweekday=6).monthdayscalendar(d.year, d.month)
        cw, ch = (r.width() - px(24)) / 7, (r.height() - px(66)) / 7
        f.setPixelSize(px(11)); f.setBold(False); p.setFont(f)
        for i, h in enumerate("SMTWTFS"):
            p.setPen(QColor(255, 255, 255, 120))
            p.drawText(QRectF(r.left() + px(12) + i * cw, r.top() + px(50), cw, ch), int(Qt.AlignmentFlag.AlignCenter), h)
        for ri, week in enumerate(cal):
            for ci, day in enumerate(week):
                if not day:
                    continue
                cell = QRectF(r.left() + px(12) + ci * cw, r.top() + px(50) + (ri + 1) * ch, cw, ch)
                if day == d.day:
                    p.setPen(NOPEN); p.setBrush(QColor("#FFFFFF"))
                    p.drawRoundedRect(cell.adjusted(cw * .08, ch * .12, -cw * .08, -ch * .12), px(7), px(7))
                    p.setPen(QColor("#16161C")); f.setBold(True)
                else:
                    p.setPen(QColor(255, 255, 255, 215)); f.setBold(False)
                p.setFont(f)
                p.drawText(cell, int(Qt.AlignmentFlag.AlignCenter), str(day))
        p.setPen(NOPEN); p.setBrush(QColor(255, 255, 255, 190))
        p.drawRoundedRect(QRectF(r.center().x() - px(22), r.bottom() - px(9), px(44), px(4)), 2, 2)


# =====================================================================================================  GRAPH PICTURE (Smart Planner)
class _RedStat(QWidget):
    """Solid red box with a caption and a rolling number (the red boxes of the graph picture)."""

    def __init__(self, caption, suffix="", parent=None):
        super().__init__(parent)
        self.caption = caption
        from PySide6.QtWidgets import QVBoxLayout
        lay = QVBoxLayout(self)
        lay.setContentsMargins(px(14), px(26), px(14), px(8))
        lay.setSpacing(0)
        self.num = RollingNumber(0, size=30, color="#FFFFFF", suffix=suffix)
        lay.addWidget(self.num)
        self.setMinimumWidth(px(150))
        self.setFixedHeight(px(78))

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        g = QLinearGradient(r.topLeft(), r.bottomRight())
        g.setColorAt(0, QColor("#F1303F")); g.setColorAt(1, QColor("#B30F1F"))
        p.setPen(NOPEN); p.setBrush(g)
        p.drawRoundedRect(r, px(6), px(6))
        f = QFont("Consolas"); f.setPixelSize(px(11)); f.setBold(True)
        p.setFont(f); p.setPen(QColor(255, 255, 255, 215))
        p.drawText(QRectF(px(14), px(8), r.width(), px(16)), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter), self.caption.upper())


class InsightCard(AnimWidget):
    """The red graph picture as a live card: the picture is the backdrop, the red bars and lines are YOUR study minutes."""
    FPS = 30

    def __init__(self, parent=None):
        super().__init__(parent)
        from PySide6.QtWidgets import QHBoxLayout, QVBoxLayout
        self.values, self.labels, self._t0, self.today = [0.0] * 7, ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], self.t(), 6
        root = QHBoxLayout(self)
        root.setContentsMargins(px(22), px(20), px(22), px(20))
        col = QVBoxLayout(); col.setSpacing(px(12))
        self.stats = [_RedStat("Focus today", " min"), _RedStat("Open tasks"), _RedStat("Sessions logged")]
        for s in self.stats:
            col.addWidget(s)
        col.addStretch(1)
        root.addLayout(col)
        root.addStretch(1)
        self.setMinimumHeight(px(250))
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def set_data(self, values, labels, today_index, stats):
        self.values, self.labels, self.today = [float(v) for v in values], list(labels), today_index
        for box, v in zip(self.stats, stats):
            box.num.set_value(v)
        self._t0 = self.t()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA); p.setRenderHint(SMOOTH)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        clip = _round_path(r, px(24))
        p.setClipPath(clip)
        p.fillRect(r, QColor(6, 6, 10))
        pm = fx_pixmap("graph_photo.jpg")
        if not pm.isNull():
            p.drawPixmap(r, pm, cover_rect(r, pm.width(), pm.height()))
        g = QLinearGradient(r.left(), 0, r.right(), 0)
        g.setColorAt(0, QColor(4, 4, 8, 235)); g.setColorAt(0.5, QColor(4, 4, 8, 175)); g.setColorAt(1, QColor(4, 4, 8, 120))
        p.fillRect(r, g)
        # ---- bars ----
        left = r.left() + px(210)
        ch = QRectF(left, r.top() + px(20), r.right() - left - px(26), r.height() - px(40))
        n = len(self.values)
        slot = ch.width() / n
        bw = min(slot * 0.46, px(64))
        dx, dy = bw * 0.34, bw * 0.22
        base_y = ch.bottom() - px(30)
        maxv = max(max(self.values), 60.0)
        k = min(1.0, (self.t() - self._t0) / 1.2)
        pulse = 0.5 + 0.5 * math.sin(self.t() * 2.2)
        floor = QRadialGradient(QPointF(ch.center().x(), base_y + px(6)), ch.width() * .55)
        floor.setColorAt(0, QColor(255, 40, 60, 80)); floor.setColorAt(1, QColor(255, 40, 60, 0))
        p.setPen(NOPEN); p.setBrush(floor)
        p.drawEllipse(QPointF(ch.center().x(), base_y + px(6)), ch.width() * .55, px(34))
        p.setPen(QPen(QColor(120, 150, 220, 60), 1))
        for i in range(5):                                           # floor grid
            y = base_y + px(2) + i * px(5)
            p.drawLine(QPointF(ch.left() - i * px(5), y), QPointF(ch.right() + i * px(5), y))
        for i in range(n + 1):
            x = ch.left() + i * slot
            p.drawLine(QPointF(x, base_y + px(2)), QPointF(x + (x - ch.center().x()) * 0.08, base_y + px(22)))
        tops = []
        for i, v in enumerate(self.values):
            e_i = max(0.0, min(1.0, k * 1.5 - i * 0.09))
            e_i = 1 - (1 - e_i) ** 3
            hgt = max(px(5), (v / maxv) * (ch.height() - px(70))) * e_i if v > 0 else px(4) * e_i
            x = ch.left() + i * slot + (slot - bw) / 2
            top = base_y - hgt
            is_today = i == self.today
            a = 255 if is_today else 215
            front = QLinearGradient(x, top, x, base_y)
            front.setColorAt(0, QColor(255, 72, 72, a)); front.setColorAt(1, QColor(170, 12, 28, a))
            p.setPen(NOPEN)
            p.setBrush(front); p.drawRect(QRectF(x, top, bw, hgt))
            p.setBrush(QColor(255, 140, 140, a)); p.drawPolygon(QPolygonF([QPointF(x, top), QPointF(x + dx, top - dy), QPointF(x + bw + dx, top - dy), QPointF(x + bw, top)]))
            p.setBrush(QColor(120, 8, 20, a)); p.drawPolygon(QPolygonF([QPointF(x + bw, top), QPointF(x + bw + dx, top - dy), QPointF(x + bw + dx, base_y - dy), QPointF(x + bw, base_y)]))
            if is_today:
                gl = QRadialGradient(QPointF(x + bw / 2, top), bw * 1.4)
                gl.setColorAt(0, QColor(255, 80, 80, int(110 + 80 * pulse))); gl.setColorAt(1, QColor(255, 80, 80, 0))
                p.setBrush(gl); p.drawEllipse(QPointF(x + bw / 2, top), bw * 1.4, bw * 1.4)
            tops.append(QPointF(x + bw / 2 + dx / 2, top - dy / 2))
            f = QFont("Consolas"); f.setPixelSize(px(11)); f.setBold(True); p.setFont(f)
            p.setPen(QColor(255, 255, 255, 235 if is_today else 170))
            if v > 0 and e_i > 0.6:
                p.drawText(QRectF(x - px(10), top - dy - px(20), bw + px(20) + dx, px(16)), int(Qt.AlignmentFlag.AlignCenter), f"{int(v)}")
            lab = self.labels[i] if i < len(self.labels) else ""
            p.setPen(QColor(255, 255, 255, 235 if is_today else 150))
            p.drawText(QRectF(x - px(10), base_y + px(24), bw + px(20), px(16)), int(Qt.AlignmentFlag.AlignCenter), lab.upper())
        if len(tops) > 1:                                          # red network lines between the bar tops
            for off, alpha, wd in ((0.0, 230, 1.8), (-px(14), 80, 1.0)):
                path = QPainterPath(QPointF(tops[0].x(), tops[0].y() + off))
                for a, b in zip(tops, tops[1:]):
                    mid = (a.x() + b.x()) / 2
                    path.cubicTo(QPointF(mid, a.y() + off), QPointF(mid, b.y() + off), QPointF(b.x(), b.y() + off))
                p.setBrush(NOBRUSH); p.setPen(QPen(QColor(255, 60, 70, alpha), wd))
                p.drawPath(path)
            p.setPen(NOPEN); p.setBrush(QColor("#FFFFFF"))
            for t in tops:
                p.drawEllipse(t, px(2.6), px(2.6))
        if max(self.values) <= 0:
            f = QFont(self.font()); f.setPixelSize(px(13)); p.setFont(f)
            p.setPen(QColor(255, 255, 255, 190))
            p.drawText(QRectF(ch.left(), ch.top(), ch.width(), px(30)), int(Qt.AlignmentFlag.AlignCenter),
                       "Finish a task or a timer session and your week grows here.")
        p.setClipping(False)
        p.setBrush(NOBRUSH); p.setPen(QPen(QColor(255, 255, 255, 40), 1.2))
        p.drawPath(clip)


# =====================================================================================================  PICTURE HEADERS / PHOTO CARDS
class Banner(QWidget):
    """Rounded picture header for a card.  mode 'cover' fills the box, 'icon' shows a round icon on a glowing dark stage."""

    def __init__(self, name, mode="cover", height=120, accent="#8B5CF6", title="", parent=None):
        super().__init__(parent)
        self.name, self.mode, self.accent, self.title = name, mode, QColor(accent), title
        self.setFixedHeight(px(height))
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def paintEvent(self, e):
        from .icons import art_pixmap
        p = QPainter(self)
        p.setRenderHint(AA); p.setRenderHint(SMOOTH)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        clip = _round_path(r, px(18))
        p.setClipPath(clip)
        pm = art_pixmap(self.name)
        if self.mode == "cover" and not pm.isNull():
            p.drawPixmap(r, pm, cover_rect(r, pm.width(), pm.height()))
            v = QLinearGradient(0, r.top(), 0, r.bottom())
            v.setColorAt(0, QColor(8, 6, 20, 0)); v.setColorAt(1, QColor(8, 6, 20, 190))
            p.fillRect(r, v)
        else:
            bg = QLinearGradient(r.topLeft(), r.bottomRight())
            bg.setColorAt(0, QColor(18, 14, 36)); bg.setColorAt(1, QColor(8, 8, 18))
            p.fillRect(r, bg)
            gl = QRadialGradient(r.center(), r.width() * .45)
            gl.setColorAt(0, _c(self.accent.name(), 120)); gl.setColorAt(1, _c(self.accent.name(), 0))
            p.fillRect(r, gl)
            if not pm.isNull():
                s = r.height() * 0.84
                p.drawPixmap(QRectF(r.center().x() - s / 2, r.center().y() - s / 2, s, s), pm, QRectF(pm.rect()))
        if self.title:
            f = QFont(self.font()); f.setPixelSize(px(17)); f.setBold(True)
            p.setFont(f); p.setPen(QColor("#FFFFFF"))
            p.drawText(QRectF(px(14), 0, r.width() - px(28), r.height() - px(10)), int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignBottom), self.title)
        p.setClipping(False)
        p.setBrush(NOBRUSH); p.setPen(QPen(QColor(255, 255, 255, 50), 1))
        p.drawPath(clip)


class PhotoCard(QAbstractButton):
    """Picture card of the desktop (zooms slowly on hover)."""
    fx_ripple = True

    def __init__(self, name, title, sub="", parent=None):
        super().__init__(parent)
        self.name, self.title, self.sub, self._g = name, title, sub, 0.0
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMinimumSize(px(110), px(96))
        self._anim = QVariantAnimation(self); self._anim.setDuration(380); self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(lambda v: (setattr(self, "_g", float(v)), self.update()))

    def _to(self, v):
        self._anim.stop(); self._anim.setStartValue(self._g); self._anim.setEndValue(v); self._anim.start()

    def enterEvent(self, e):
        self._to(1.0); super().enterEvent(e)

    def leaveEvent(self, e):
        self._to(0.0); super().leaveEvent(e)

    def paintEvent(self, e):
        from .icons import art_pixmap
        p = QPainter(self)
        p.setRenderHint(AA); p.setRenderHint(SMOOTH)
        r = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        if self.isDown():
            r = r.adjusted(2, 2, -2, -2)
        clip = _round_path(r, px(20))
        p.setClipPath(clip)
        p.fillRect(r, QColor(14, 12, 30))
        pm = art_pixmap(self.name)
        if not pm.isNull():
            src = cover_rect(r, pm.width(), pm.height())
            z = 1.0 / (1 + 0.10 * self._g)
            src = QRectF(src.center().x() - src.width() * z / 2, src.center().y() - src.height() * z / 2, src.width() * z, src.height() * z)
            p.drawPixmap(r, pm, src)
        v = QLinearGradient(0, r.top() + r.height() * .35, 0, r.bottom())
        v.setColorAt(0, QColor(8, 6, 20, 0)); v.setColorAt(1, QColor(8, 6, 20, 215))
        p.fillRect(r, v)
        f = QFont(self.font()); f.setPixelSize(px(15)); f.setBold(True)
        p.setFont(f); p.setPen(QColor("#FFFFFF"))
        ty = r.bottom() - px(12) - (px(15) if self.sub else 0)
        p.drawText(QPointF(r.left() + px(12), ty), self.title)
        if self.sub:
            f.setPixelSize(px(11)); f.setBold(False); p.setFont(f); p.setPen(QColor(255, 255, 255, 170))
            p.drawText(QPointF(r.left() + px(12), r.bottom() - px(12)), self.sub)
        p.setClipping(False)
        p.setBrush(NOBRUSH); p.setPen(QPen(QColor(255, 255, 255, int(55 + 70 * self._g)), 1.2))
        p.drawPath(clip)
