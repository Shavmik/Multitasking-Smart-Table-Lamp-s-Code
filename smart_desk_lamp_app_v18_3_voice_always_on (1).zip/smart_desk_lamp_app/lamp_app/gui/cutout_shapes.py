"""Shapes and texture for the cardboard cut-out desktop.  No Qt in here, so it can be tested anywhere.

cut_outline()      points of a rectangle that looks cut out with scissors (slightly wobbly edges, rounded corners)
cardboard_array()  an RGBA numpy picture of corrugated cardboard (fine ridges + fibre speckles)
"""
import math
import random

import numpy as np

# (R, G, B) of the cardboard.  Dark theme = dark brown board, light theme = pale kraft paper.
BOARD_DARK = (112, 79, 49)
BOARD_LIGHT = (205, 164, 108)
UNDER_DARK = (74, 49, 29)          # the second, darker sheet that peeks out behind a piece
UNDER_LIGHT = (150, 108, 64)
INK = (43, 28, 17)                 # marker outline


def cut_outline(x, y, w, h, seed, step=44.0, jitter=2.0, corner=16.0):
    """Clockwise list of (x, y) points around the rectangle x, y, w, h.

    Every edge is split into pieces of about `step` pixels and each point is pushed sideways by up to `jitter`
    pixels, so the outline looks hand cut.  The four corners are small arcs.  The same seed gives the same shape."""
    rng = random.Random(seed)
    c = max(1.0, min(corner, w / 3.0, h / 3.0))
    pts = []

    def edge(ax, ay, bx, by, nx, ny):
        length = math.hypot(bx - ax, by - ay)
        n = max(1, int(length // step))
        for i in range(n):
            t = i / n
            j = rng.uniform(-jitter, jitter) if i else 0.0      # the first point sits at the end of the corner arc
            pts.append((ax + (bx - ax) * t + nx * j, ay + (by - ay) * t + ny * j))

    def arc(cx, cy, a0, a1):
        for k in range(4):                                     # the end point belongs to the next edge
            a = math.radians(a0 + (a1 - a0) * k / 4.0)
            r = c + rng.uniform(-jitter, jitter) * 0.35
            pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))

    edge(x + c, y, x + w - c, y, 0, 1)
    arc(x + w - c, y + c, -90, 0)
    edge(x + w, y + c, x + w, y + h - c, 1, 0)
    arc(x + w - c, y + h - c, 0, 90)
    edge(x + w - c, y + h, x + c, y + h, 0, 1)
    arc(x + c, y + h - c, 90, 180)
    edge(x, y + h - c, x, y + c, 1, 0)
    arc(x + c, y + c, 180, 270)
    return pts


def bounds(points):
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    return min(xs), min(ys), max(xs), max(ys)


def cardboard_array(w, h, dark, seed=1):
    """h x w x 4 uint8 (RGBA, opaque) corrugated cardboard.  Fine ridges run across the sheet, with soft
    large-scale blotches and sparse darker fibre specks like real recycled board."""
    w, h = max(2, int(w)), max(2, int(h))
    rng = np.random.default_rng(seed)
    base = np.array(BOARD_DARK if dark else BOARD_LIGHT, dtype=np.float32)
    y = np.arange(h, dtype=np.float32)[:, None]
    x = np.arange(w, dtype=np.float32)[None, :]
    ridges = 1.0 + 0.040 * np.sin(y * 0.62) + 0.018 * np.sin(y * 0.19 + 1.3)          # corrugation lines
    blotch = 1.0 + 0.030 * np.sin(x * 0.011 + y * 0.007 + seed) + 0.025 * np.sin(x * 0.017 - y * 0.013)
    shade = (ridges * blotch)[:, :, None]
    noise = rng.normal(0.0, 4.5, (h, w, 1)).astype(np.float32)
    img = base[None, None, :] * shade + noise
    specks = rng.random((h, w)) > 0.9915
    img[specks] *= 0.74
    out = np.empty((h, w, 4), dtype=np.uint8)
    out[:, :, :3] = np.clip(img, 0, 255).astype(np.uint8)
    out[:, :, 3] = 255
    return np.ascontiguousarray(out)
