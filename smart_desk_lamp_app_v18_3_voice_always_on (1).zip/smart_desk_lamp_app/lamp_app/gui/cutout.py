"""Cardboard cut-out desktop.

Instead of painting its own wallpaper, Home is now a few pieces of corrugated cardboard (a side panel, a dock strip and a
small tab) lying on top of your REAL Windows desktop.  Everything between the pieces is a hole: the window is clipped to the
pieces with QWidget.setMask(), so the desktop icons, your files, the taskbar and any other open program show through and
can be clicked as usual.  (Pixels outside a window's mask do not belong to the window at all - Windows sends the mouse to
whatever is underneath.)

MainWindow.set_cutout() makes the window frameless + always-on-top while this is shown, and puts everything back when you
leave Home.  Pieces are CardboardPiece widgets; CutoutDesktop lays them out and builds the mask from their outlines.
"""
from PySide6.QtCore import QPoint, QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QImage, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap, QPolygonF, QRegion
from PySide6.QtWidgets import QHBoxLayout, QPushButton, QVBoxLayout, QWidget

from . import theme
from .cutout_shapes import INK, UNDER_DARK, UNDER_LIGHT, cardboard_array, cut_outline
from .theme import px

AA = QPainter.RenderHint.Antialiasing
_TEX = {}                                              # (w, h, dark, seed) -> QPixmap, so Swap / Theme never rebuild it


def _poly(points, dx=0.0, dy=0.0):
    return QPolygonF([QPointF(x + dx, y + dy) for x, y in points])


class CardboardPiece(QWidget):
    """One cut-out piece of cardboard.  Put your widgets in `self.content` (a QVBoxLayout).

    Drawn from back to front: a darker second sheet peeking out below / right of the piece, the corrugated board itself,
    a marker outline (drawn twice, slightly off, like a hand-drawn line), a dashed 'cut here' guide and two bits of tape."""

    def __init__(self, seed, pad=(20, 18, 20, 18), parent=None):
        super().__init__(parent)
        self.seed = seed
        self.lift = px(7)                                   # how far the darker sheet shows
        self._shape_key, self._shapes, self._body_pts = None, None, []
        self._region_key, self._region = None, None
        l, t, r, b = (px(v) for v in pad)
        self.content = QVBoxLayout(self)
        self.content.setContentsMargins(l, t, r + self.lift, b + self.lift)
        self.content.setSpacing(px(10))

    # ---- outlines (local coordinates) ----
    def _body_size(self):
        return max(10, self.width() - self.lift), max(10, self.height() - self.lift)

    def shapes(self):
        """(under sheet, body, guide) as QPolygonF - cached per size."""
        key = (self.width(), self.height())
        if key != self._shape_key:
            w, h = self._body_size()
            kw = dict(step=px(46), jitter=px(2.1), corner=px(18))
            under = cut_outline(self.lift, self.lift, w - px(2), h - px(2), self.seed + 101, **kw)
            body = cut_outline(1, 1, w - 2, h - 2, self.seed, **kw)
            guide = cut_outline(px(9), px(9), w - px(18), h - px(18), self.seed + 7, step=px(60), jitter=px(1.1), corner=px(12))
            self._shapes = (_poly(under), _poly(body), _poly(guide))
            self._body_pts = body                           # plain (x, y) list, used for the second outline
            self._shape_key = key
        return self._shapes

    def region(self):
        """Pixels of this piece that belong to the window (the under sheet + the body), in this widget's coordinates."""
        under, body, _ = self.shapes()
        if self._region_key != self._shape_key or self._region is None:
            self._region = QRegion(under.toPolygon()).united(QRegion(body.toPolygon()))
            self._region_key = self._shape_key
        return self._region

    # ---- painting ----
    def _texture(self):
        w, h = self._body_size()
        key = (w, h, theme.is_dark(), self.seed)
        pm = _TEX.get(key)
        if pm is None:
            if len(_TEX) > 24:
                _TEX.clear()
            arr = cardboard_array(w, h, theme.is_dark(), self.seed)
            img = QImage(arr.data, w, h, w * 4, QImage.Format.Format_RGBA8888).copy()
            pm = _TEX[key] = QPixmap.fromImage(img)
        return pm

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(AA)
        dark = theme.is_dark()
        under, body, guide = self.shapes()
        ink = QColor(*INK)
        round_pen = lambda c, w: QPen(c, w, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)

        # 1. the darker sheet underneath
        p.setPen(round_pen(ink, px(2.4)))
        p.setBrush(QColor(*(UNDER_DARK if dark else UNDER_LIGHT)))
        p.drawPolygon(under)

        # 2. the cardboard
        path = QPainterPath()
        path.addPolygon(body)
        path.closeSubpath()
        p.save()
        p.setClipPath(path)
        p.drawPixmap(0, 0, self._texture())
        sheen = QLinearGradient(0, 0, 0, self.height())
        sheen.setColorAt(0.0, QColor(255, 235, 200, 38 if dark else 70))
        sheen.setColorAt(0.5, QColor(255, 235, 200, 0))
        sheen.setColorAt(1.0, QColor(30, 15, 5, 46 if dark else 34))
        p.fillRect(self.rect(), sheen)
        p.restore()

        # 3. marker outline, twice
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(round_pen(ink, px(2.6)))
        p.drawPolygon(body)
        p.setPen(round_pen(QColor(ink.red(), ink.green(), ink.blue(), 90), px(1.3)))
        p.drawPolygon(_poly(self._body_pts, 1.3, -1.1))

        # 4. dashed cut guide just inside the edge
        dash = QPen(QColor(ink.red(), ink.green(), ink.blue(), 120 if dark else 105), px(1.4), Qt.PenStyle.CustomDashLine)
        dash.setDashPattern([4.0, 3.0])
        p.setPen(dash)
        p.drawPolygon(guide)

        # 5. two bits of masking tape on the top corners (clipped to the board)
        p.save()
        p.setClipPath(path)
        p.setPen(Qt.PenStyle.NoPen)
        bw, _ = self._body_size()
        for cx, ang in ((px(46), -9.0), (bw - px(46), 8.0)):
            p.save()
            p.translate(cx, px(15))
            p.rotate(ang)
            p.setBrush(QColor(238, 214, 140, 205 if not dark else 170))
            p.drawRect(QRectF(-px(30), -px(9), px(60), px(18)))
            p.setBrush(QColor(255, 255, 255, 55))
            p.drawRect(QRectF(-px(30), -px(9), px(60), px(5)))
            p.restore()
        p.restore()


class CutoutDesktop(QWidget):
    """Full-size layer that places the pieces and keeps the window mask in step with them."""

    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self._active = False
        self._busy = False
        self._last = None                  # (geometries, visibility) of the last layout
        self._last_region = None
        self.collapsed = False
        self.panel = CardboardPiece(seed=11, pad=(22, 20, 22, 20), parent=self)      # clock, calendar, cards, player
        self.dockp = CardboardPiece(seed=23, pad=(18, 8, 18, 6), parent=self)         # the dock
        self.tab = CardboardPiece(seed=37, pad=(14, 12, 14, 10), parent=self)         # hide / swap side / theme / classic
        self.tab.content.setSpacing(px(6))
        row = QHBoxLayout()
        row.setSpacing(px(6))
        self.b_hide = self._chip("Hide", "Fold the cardboard away - only this tab stays, the whole desktop is free")
        self.b_swap = self._chip("Swap", "Move the cardboard to the other side of the screen")
        self.b_theme = self._chip("Theme", "Dark / light cardboard")
        self.b_classic = self._chip("Classic", "Back to the old look with the wallpaper inside the app")
        for b in (self.b_hide, self.b_swap, self.b_theme, self.b_classic):
            row.addWidget(b)
        self.tab.content.addLayout(row)
        self.b_hide.clicked.connect(self.toggle_collapse)
        self.b_swap.clicked.connect(self.swap_side)
        self.b_theme.clicked.connect(lambda: ctx.window.set_theme("light" if theme.is_dark() else "dark"))
        self.b_classic.clicked.connect(lambda: ctx.window.pages["home"].set_desktop_style("classic"))
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(0)
        self._timer.timeout.connect(self.relayout)

    @staticmethod
    def _chip(text, tip):
        b = QPushButton(text)
        b.setObjectName("chip")
        b.setToolTip(tip)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        return b

    # ---- state ----
    @property
    def side(self):
        return self.ctx.prefs.get("cardboard_side", "right")

    def activate(self):
        self._active = True
        self._last = self._last_region = None            # the mask was cleared when the cardboard was last left: apply it again
        self.relayout()
        self.schedule()                                  # and once more when the window has its final size

    def deactivate(self):
        self._active = False

    def schedule(self):
        self._timer.start()

    def toggle_collapse(self):
        self.collapsed = not self.collapsed
        self.b_hide.setText("Show" if self.collapsed else "Hide")
        self.relayout()                                    # straight away (not on a timer) so the mask never lags behind
        win = self.window()
        if hasattr(win, "set_taskbar_hidden"):
            win.set_taskbar_hidden(not self.collapsed)     # folded away = the whole desktop incl. taskbar is free

    def swap_side(self):
        self.ctx.prefs.set("cardboard_side", "left" if self.side == "right" else "right")
        self.relayout()

    # ---- layout ----
    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.relayout()

    def showEvent(self, e):
        super().showEvent(e)
        self.schedule()

    def _targets(self):
        W, H = self.width(), self.height()
        m, gap = px(14), px(10)
        right = self.side == "right"
        pw = px(352)
        tab_h = max(self.tab.content.sizeHint().height() + self.tab.lift + px(22), px(62))
        x_col = W - m - pw if right else m
        panel_y = m + tab_h + gap
        dock = self.dockp.content.itemAt(0).widget() if self.dockp.content.count() else None
        dw = (dock.width() if dock else px(700)) + px(36) + self.dockp.lift
        dh = (dock.height() if dock else px(104)) + px(14) + self.dockp.lift
        free_l = m if right else x_col + pw + gap
        free_r = x_col - gap if right else W - m
        dx = free_l + max(0, (free_r - free_l - dw) // 2)
        return {self.tab: (x_col, m, pw, tab_h),
                self.panel: (x_col, panel_y, pw, max(px(300), H - panel_y - m)),
                self.dockp: (dx, H - m - dh, dw, dh)}

    def relayout(self):
        """Moves the pieces AND the window mask in one go.  While pieces move or fold away the mask is briefly the union of
        the old and new shapes, so nothing is ever clipped mid-change; then it shrinks to the final shape."""
        if self._busy or self.width() < 50 or self.height() < 50:
            return
        tgt = self._targets()
        vis = {self.tab: True, self.panel: not self.collapsed, self.dockp: not self.collapsed}
        key = (tuple(tgt[p] for p in (self.tab, self.panel, self.dockp)), tuple(vis[p] for p in (self.tab, self.panel, self.dockp)))
        if key == self._last:
            return
        self._busy = True
        try:
            win = self.window()
            self.setUpdatesEnabled(False)
            for pc, g in tgt.items():                      # sizes first, so each piece can compute its own outline
                pc.setGeometry(*g)
            off = self.mapTo(win, QPoint(0, 0))
            new = QRegion()
            for pc, g in tgt.items():
                if vis[pc]:
                    new = new.united(pc.region().translated(off + pc.pos()))
            if self._active and self._last_region is not None and hasattr(win, "set_cutout_mask"):
                win.set_cutout_mask(self._last_region.united(new))      # nothing is cut while things move
            for pc in tgt:
                pc.setVisible(vis[pc])
            self.setUpdatesEnabled(True)
            for pc in tgt:                                 # paint now, in this same step
                if vis[pc]:
                    pc.repaint()
            if self._active and hasattr(win, "set_cutout_mask"):
                win.set_cutout_mask(new)
            self._last, self._last_region = key, new
        finally:
            self._busy = False
