"""Connects the Qt app to the Qt-free lamp touchscreen interface (lamp_app/tftui).

`install(ctx)` is called once by AppContext. It gives the TFT interface its `hooks`: small functions that do
the real work (say the time, take a photo, start Study mode, connect the lamp...) with the app's own services.
"""
import time
from datetime import datetime

from .. import config
from ..tftui import TftUi
from ..tftui.native import NativeUi
from . import theme
from .services import run_async


def _page(ctx, key):
    win = getattr(ctx, "window", None)
    return getattr(win, "pages", {}).get(key) if win is not None else None


def build_hooks(ctx, ui_ref):
    status = {"msg": ""}
    ctx.lamp.status.connect(lambda ok, msg: status.__setitem__("msg", msg))

    def say(msg, secs=3.0):
        ui = ui_ref()
        if ui is not None:
            ui.say(msg, secs)

    # ---- clock
    def say_time():
        n = ctx.clock.now()
        ctx.speak(f"The time in India is {n.strftime('%I').lstrip('0')} {n.strftime('%M')} {n.strftime('%p')}. "
                  f"{n.strftime('%A, %d %B %Y')}")

    def toggle_h24():
        ctx.clock.h24 = not ctx.clock.h24

    # ---- theme
    def set_dark(v):
        win = ctx.window
        if win is not None:
            win.set_theme("dark" if v else "light")

    # ---- lamp
    def _port():
        return ctx.prefs.get("lamp_port", "") or None

    def connect():
        ctx.lamp.connect_lamp(_port())

    def refresh():
        if not ctx.lamp.connected:
            ctx.lamp.connect_lamp(_port())
            return
        board = ctx.lamp.board

        def done(res, err):
            say("Lamp answered" if (res and not err) else "The lamp did not answer")
            ui = ui_ref()
            if ui is not None:
                ui.done("refresh")
        run_async(lambda: board.ping(), done)

    def calibrate():
        board = ctx.lamp.board
        if board is None:
            return
        run_async(board.calibrate, lambda _, err: say(f"Calibration failed: {err}" if err else "Calibration finished", 4))

    # ---- reading
    def capture():
        page = _page(ctx, "ocr")
        if page is not None:
            page.capture()

    def open_picture():
        page = _page(ctx, "ocr")
        if page is not None:
            page.open_picture()

    def ocr_busy():
        page = _page(ctx, "ocr")
        return bool(page is not None and getattr(page, "_busy", False))

    def translate(text, code, cb):
        from ..core.translate import translate as do_translate
        run_async(lambda: do_translate(text, code, "auto"), cb)

    # ---- modes + stats
    def stats():
        hist = ctx.sched.history
        today = datetime.now().date().isoformat()
        mins = sum(float(h.get("actual", 0)) for h in hist if str(h.get("when", "")).startswith(today))
        el = mode_elapsed()
        if el:
            mins += el
        return {"focus_min": mins, "open_tasks": len(ctx.sched.data.get("tasks", [])), "sessions": len(hist)}

    def mode_elapsed():
        st = ctx.modes.started
        return (time.time() - st) / 60.0 if (st and ctx.modes.current != "normal") else None

    # ---- cube
    def cube_faces():
        page = _page(ctx, "cube")
        faces = getattr(page, "faces", None) or {}
        out = {}
        for letter, arr in faces.items():
            try:
                out[letter] = [[(int(p[2]), int(p[1]), int(p[0])) for p in row] for row in arr]
            except Exception:                                    # noqa: BLE001
                pass
        return out

    # ---- calculator / spotify / timers (native lamp screens)
    def calc_press(k):
        page = _page(ctx, "calc")
        if page is not None:
            page.press(k)

    def calc_text():
        page = _page(ctx, "calc")
        return (page.lb_expr.text(), "") if page is not None else ("0", "")

    def spotify_key(name):
        page = _page(ctx, "spotify")
        btn = {"prev": "b_prev", "playpause": "b_play", "next": "b_next", "voldown": "b_vd", "mute": "b_mute",
               "volup": "b_vu", "open": "b_app"}.get(name)
        if page is not None and btn is not None:
            getattr(page, btn).click()

    def timer_state():
        page = _page(ctx, "timers")
        if page is None:
            return {"time": "25:00", "button": "Start"}
        return {"time": page.lb_tm.text(), "button": page.b_tm.text()}

    def timer_do(act):
        page = _page(ctx, "timers")
        if page is None:
            return
        if act.startswith("p") and act[1:].isdigit():
            page._tm_set(int(act[1:]) * 60)
        elif act == "toggle":
            page._tm_toggle()
        elif act == "reset":
            page._tm_reset()

    def native_ok():
        return bool(getattr(ctx.lamp.board, "native_ok", False))

    return {
        "native_ok": native_ok, "calc_press": calc_press, "calc_text": calc_text, "spotify_key": spotify_key,
        "timer_state": timer_state, "timer_do": timer_do,
        "now": ctx.clock.now, "h24": lambda: ctx.clock.h24, "toggle_h24": toggle_h24, "say_time": say_time,
        "dark": theme.is_dark, "set_dark": set_dark,
        "lamp_connected": lambda: ctx.lamp.connected, "lamp_connecting": lambda: ctx.lamp.connecting,
        "lamp_status": lambda: status["msg"], "connect": connect, "disconnect": ctx.lamp.disconnect_lamp,
        "refresh": refresh, "calibrate": calibrate,
        "capture": capture, "open_picture": open_picture, "ocr_busy": ocr_busy,
        "last_text": lambda: ctx.last_text, "speak": ctx.speak, "translate": translate,
        "stats": stats, "mode": lambda: ctx.modes.current, "mode_elapsed": mode_elapsed,
        "start_mode": lambda m: ctx.set_mode(m), "end_mode": ctx.end_mode,
        "cube_faces": cube_faces, "open_page": lambda key: ctx.go(key),
    }


def install(ctx):
    holder = {}
    cls = NativeUi if config.TFT_NATIVE else TftUi
    ui = cls(build_hooks(ctx, lambda: holder.get("ui")))
    holder["ui"] = ui
    ctx.tft.attach_ui(ui)
    ctx.lamp.ui_owns = ctx.tft.native_on
    return ui
