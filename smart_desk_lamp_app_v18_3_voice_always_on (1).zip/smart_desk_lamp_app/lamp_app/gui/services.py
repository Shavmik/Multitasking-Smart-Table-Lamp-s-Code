"""Things shared by every page: the lamp (serial board + camera thread), speech, clock, settings."""
import os
import sys
import threading
import time
import traceback

import cv2
from PySide6.QtCore import QObject, QSettings, QTimer, Signal

from .. import config
from ..core.board import Board, BoardError
from ..core.clock import ist_now
from ..core.ports import detect_port
from ..core.speech import Speaker

_dispatcher = None


class _Dispatcher(QObject):
    """Lets worker threads run a function on the GUI thread."""
    call = Signal(object)

    def __init__(self):
        super().__init__()
        self.call.connect(self._run)

    def _run(self, fn):
        try:
            fn()
        except Exception:
            traceback.print_exc()


def init_dispatcher():
    global _dispatcher
    _dispatcher = _Dispatcher()


def on_main(fn):
    if _dispatcher is not None:
        _dispatcher.call.emit(fn)


def run_async(fn, cb=None):
    """Run fn() in a thread; cb(result, error) is called on the GUI thread.
    The button that started it shows a loader (and the top bar a spinner) until it is done."""
    from . import fx
    token = fx.job_started()

    def work():
        try:
            res, err = fn(), None
        except Exception as e:                           # noqa: BLE001 - shown to the user
            res, err = None, e

        def done():
            fx.job_finished(token)
            if cb is not None:
                cb(res, err)
        on_main(done)
    threading.Thread(target=work, daemon=True).start()


class Prefs:
    def __init__(self):
        self.q = QSettings("SmartDeskLamp", "SmartDeskLamp")

    def get(self, key, default):
        v = self.q.value(key, default)
        try:
            if isinstance(default, bool):
                return str(v).lower() in ("true", "1", "yes")
            if isinstance(default, int):
                return int(v)
            if isinstance(default, float):
                return float(v)
        except (TypeError, ValueError):
            return default
        return v

    def set(self, key, value):
        self.q.setValue(key, value)


class ClockService(QObject):
    """Emits `tick` once per second with the current IST time."""
    tick = Signal(object)

    def __init__(self, prefs):
        super().__init__()
        self.prefs = prefs
        self._last = -1
        self._timer = QTimer(self)
        self._timer.setInterval(150)
        self._timer.timeout.connect(self._check)
        self._timer.start()

    @property
    def h24(self):
        return self.prefs.get("clock_24h", False)

    @h24.setter
    def h24(self, v):
        self.prefs.set("clock_24h", bool(v))
        self.tick.emit(ist_now())

    def now(self):
        return ist_now()

    def _check(self):
        now = ist_now()
        if now.second != self._last:
            self._last = now.second
            self.tick.emit(now)


class LampService(QObject):
    """The ESP32 lamp: serial link, live camera frames and the lamp's own screen."""
    status = Signal(bool, str)          # connected?, message
    frame = Signal(object)              # BGR numpy picture
    screen_changed = Signal(bool)       # the lamp screen was switched on / off (voice command)
    camera_state = Signal(str)          # '' = fine, otherwise a problem text

    def __init__(self):
        super().__init__()
        self.board = None
        self.port = None
        self.connecting = False
        self._owners = set()
        self._quit = False
        self._pause_until = 0.0
        self._webcam = None                 # cv2.VideoCapture of the laptop's own camera (only used while the lamp is NOT connected)
        self._webcam_lock = threading.Lock()
        threading.Thread(target=self._camera_loop, daemon=True).start()

    @property
    def connected(self):
        return self.board is not None

    @property
    def has_camera(self):
        """True when a camera can be used: the lamp's, or (fallback) the laptop's own."""
        return self.board is not None or bool(config.LAPTOP_CAMERA_FALLBACK)

    @property
    def camera_source(self):
        """'lamp' | 'laptop' | 'none'"""
        if self.board is not None:
            return "lamp"
        return "laptop" if config.LAPTOP_CAMERA_FALLBACK else "none"

    # ---- connection ----
    def connect_lamp(self, port=None):
        if self.connecting:
            return
        self.connecting = True
        self.disconnect_lamp(silent=True)
        self.status.emit(False, "Connecting to the lamp...")

        def work():
            p = port or detect_port()
            if not p:
                raise RuntimeError("No lamp found. Plug in the USB data cable, or choose the port in Settings.")
            try:
                board = Board(p, config.BAUD)
            except Exception as e:
                raise RuntimeError(f"Could not open {p}: {e}. Close the Arduino Serial Monitor and try again.")
            time.sleep(2.5)                              # the board may restart when the port opens
            info = board.ping()
            if info is None:
                board.close()
                raise RuntimeError("The board did not answer. Is lamp_firmware.ino uploaded and is this the right port?")
            return board, p, info

        def done(res, err):
            self.connecting = False
            if err:
                print(f"[lamp] {err}")
                self.status.emit(False, str(err))
                return
            self.board, self.port, info = res
            print(f"[lamp] connected on {self.port} ({info})")
            if "UI=1" not in str(info):
                print("[lamp] !! The board is running OLD firmware (its reply has no 'UI=1'). It cannot draw the touch interface.\n"
                      "[lamp] !! Upload lamp_firmware/lamp_firmware.ino from this project with the Arduino IDE, then restart the app.")
                self.status.emit(True, f"Lamp connected on {self.port} - OLD FIRMWARE: upload lamp_firmware.ino to get the touch interface")
            else:
                self.status.emit(True, f"Lamp connected on {self.port}")
            self.apply_cam_box()
            if getattr(self.board, "display_ok", False):         # the app is running: the lamp screen is on
                self.screen_on = True
                try:
                    self.board.display(True)
                except Exception:                                # noqa: BLE001
                    pass

        run_async(work, done)

    def disconnect_lamp(self, silent=False):
        b, self.board = self.board, None
        if b is not None:
            try:
                b.close()
            except Exception:
                pass
            if not silent:
                self.status.emit(False, "Lamp disconnected")

    # ---- camera ----
    def acquire(self, owner):
        self._owners.add(id(owner))

    def release(self, owner):
        self._owners.discard(id(owner))

    # ---- laptop camera (used automatically while the lamp is not connected) ----
    def _open_webcam(self):
        """Open the laptop's camera. Caller holds _webcam_lock. Returns True when it is open."""
        if self._webcam is not None and self._webcam.isOpened():
            return True
        self._close_webcam_locked()
        idx = config.LAPTOP_CAMERA_INDEX
        indexes = [idx] if idx is not None else [0, 1, 2]
        backends = [cv2.CAP_DSHOW, cv2.CAP_ANY] if sys.platform == "win32" else [cv2.CAP_ANY]
        for i in indexes:
            for be in backends:
                try:
                    cap = cv2.VideoCapture(i, be)
                except Exception:                                # noqa: BLE001
                    continue
                if cap is not None and cap.isOpened():
                    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
                    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
                    ok, _ = cap.read()                           # a camera that opens but gives nothing is useless
                    if ok:
                        self._webcam = cap
                        print(f"[lamp] using the laptop camera (index {i})")
                        return True
                if cap is not None:
                    cap.release()
        return False

    def _close_webcam_locked(self):
        cap, self._webcam = self._webcam, None
        if cap is not None:
            try:
                cap.release()
            except Exception:                                    # noqa: BLE001
                pass

    def _close_webcam(self):
        with self._webcam_lock:
            self._close_webcam_locked()

    def _webcam_read(self, flush=0):
        """One full-size BGR picture from the laptop camera, or None."""
        with self._webcam_lock:
            if not self._open_webcam():
                return None
            for _ in range(flush):                               # let auto-exposure settle
                self._webcam.read()
            ok, img = self._webcam.read()
            if not ok or img is None:
                self._close_webcam_locked()
                return None
            return img

    @staticmethod
    def _webcam_preview(img):
        """Centre-crop to 4:3 and shrink to at most 640x480 (same shape the lamp's live picture has)."""
        h, w = img.shape[:2]
        if w * 3 > h * 4:                                        # wider than 4:3 (16:9 laptop cameras)
            nw = h * 4 // 3
            x0 = (w - nw) // 2
            img = img[:, x0:x0 + nw]
        elif w * 3 < h * 4:
            nh = w * 3 // 4
            y0 = (h - nh) // 2
            img = img[y0:y0 + nh]
        if img.shape[1] > 640:
            img = cv2.resize(img, (640, 480), interpolation=cv2.INTER_AREA)
        return img

    def _camera_loop(self):
        errors = 0
        while not self._quit:
            board = self.board
            wanted = bool(self._owners) and time.time() >= self._pause_until

            if board is None:
                # lamp not connected -> laptop camera (unless switched off in config.py / still connecting)
                if not (wanted and config.LAPTOP_CAMERA_FALLBACK and not self.connecting):
                    if not self._owners and self._webcam is not None:
                        self._close_webcam()                     # nobody needs it: camera light off
                    errors = 0
                    time.sleep(0.05)
                    continue
                img = self._webcam_read()
                if img is None:
                    self._pause_until = time.time() + 3
                    self.camera_state.emit("No camera found. Plug in the lamp, or allow camera access for desktop apps "
                                           "(Windows Settings > Privacy > Camera) and close other programs using the camera.")
                else:
                    if errors:
                        self.camera_state.emit("")
                    errors = 0
                    self.frame.emit(self._webcam_preview(img))
                time.sleep(0.02)
                continue

            if self._webcam is not None:
                self._close_webcam()                             # the lamp is back: give the laptop camera up
            if not self._owners or time.time() < self._pause_until:
                errors = 0
                time.sleep(0.05)
                continue
            try:
                img = board.frame()
                if errors:
                    self.camera_state.emit("")
                errors = 0
                self.frame.emit(img)
            except (TimeoutError, BoardError):
                errors += 1
                if errors >= 8:
                    errors = 0
                    self._pause_until = time.time() + 2
                    self.camera_state.emit("Lost the camera. Check the USB cable...")
            except Exception as e:                       # noqa: BLE001
                self._pause_until = time.time() + 2
                self.camera_state.emit(f"Camera problem: {e}")
            time.sleep(0.004)

    def photo(self):
        """Blocking: full-size photo (BGR image, jpeg bytes). Call through run_async.
        Lamp camera when connected, otherwise the laptop's own camera."""
        if self.board is not None:
            return self.board.photo()
        if not config.LAPTOP_CAMERA_FALLBACK:
            raise RuntimeError("The lamp is not connected.")
        img = self._webcam_read(flush=5)
        if not self._owners:
            self._close_webcam()
        if img is None:
            raise RuntimeError("The lamp is not connected and no laptop camera could be opened.")
        ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 92])
        if not ok:
            raise RuntimeError("The laptop camera picture could not be saved.")
        return img, buf.tobytes()

    # ---- the lamp's own little screen ----
    screen_on = True

    def display(self, on):
        """Switch the lamp screen on (the interface is drawn again at once) or off (black)."""
        self.screen_on = bool(on)
        b = self.board
        if b is not None:
            try:
                b.display(self.screen_on)
            except Exception as e:                               # noqa: BLE001
                print(f"[lamp] screen: {e}")
        self.screen_changed.emit(self.screen_on)

    ui_owns = None            # set by the TFT link: returns True while the lamp draws its own button screens

    def tft_text(self, title, body=""):
        b = self.board
        if b is None or not self.screen_on or (self.ui_owns is not None and self.ui_owns()):
            return                # the button screens show the mode themselves; a text page would wipe them
        run_async(lambda: b.text(title, body))

    def apply_cam_box(self):
        """Switch the lamp screen's always-on camera box on (or off) as set in config.py."""
        b = self.board
        if b is None or not getattr(b, "cam_ok", False):
            return
        try:
            x, y, w, h = config.TFT_CAM_BOX if config.TFT_CAM_ALWAYS else (0, 0, 0, 0)
            b.cam_box(x, y, w, h, config.TFT_CAM_MS)
        except Exception as e:                                   # noqa: BLE001
            print(f"[lamp] camera box: {e}")

    def shutdown(self):
        self._quit = True
        self._close_webcam()
        b = self.board
        if b is not None:
            try:
                if getattr(b, "cam_ok", False):
                    b.cam_box(0, 0, 0, 0, 200)                   # the app is closing: stop drawing the camera
            except Exception:
                pass
            try:
                if config.TFT_OFF_WHEN_APP_CLOSES and getattr(b, "display_ok", False):
                    b.display(False)                             # screen off until the next "turn on the smart desk lamp"
                else:
                    b.text("Smart Desk Lamp", "App closed on the laptop.")
            except Exception:
                pass
        self.disconnect_lamp(silent=True)


class AppContext(QObject):
    speech_state = Signal(bool, str)     # speaking?, last error
    ocr_state_changed = Signal(str, str)  # 'idle' | 'loading' | 'ready' | 'error', message
    mode_changed = Signal(str)            # 'normal' | 'study' | 'focus' | 'gaming'

    def __init__(self, args=None):
        super().__init__()
        self.args = args
        self.prefs = Prefs()
        self.lamp = LampService()
        from .tftlink import TftLink
        self.tft = TftLink(self.lamp)       # lamp touchscreen <-> app (mirrors a page, turns touches into clicks)
        self.clock = ClockService(self.prefs)
        self.speaker = Speaker()
        self.speaker.rate = self.prefs.get("tts_rate", 170)
        self.speaker.volume = self.prefs.get("tts_volume", 100) / 100.0
        from ..core.modes import ModeController
        from ..core.osiris import OsirisClient
        from ..core.scheduler_ai import SmartScheduler
        data_dir = os.path.join(os.path.expanduser("~"), ".smart_desk_lamp")
        self.modes = ModeController(self.prefs)
        self.sched = SmartScheduler(os.path.join(data_dir, "planner.json"))
        self.osiris = OsirisClient(self.prefs)
        self.pending_url = ""            # a page the in-app browser should open (Google search of scanned text, etc.)
        self.go = lambda key: None       # replaced by the main window
        self.window = None
        self.last_text = ""
        self.pending_text = ""
        self.pending_translate_text = ""
        self.ocr_state = "idle"
        self._ocr_lock = threading.Lock()
        self._speaking = False
        self._t = QTimer(self)
        self._t.setInterval(250)
        self._t.timeout.connect(self._poll_speech)
        self._t.start()
        if config.TFT_UI:
            from .tftbridge import install
            install(self)                    # the lamp screen gets its own buttons (lamp_app/tftui)

    # ---- modes (shared by the Modes page, the planner and the menu search) ----
    def set_mode(self, mode, minutes=None):
        if mode == "normal":
            return self.end_mode()
        self.modes.start(mode, minutes)
        self.lamp.tft_text(f"{mode.title()} mode", "Stay focused" if mode != "gaming" else "Game on")
        self.mode_changed.emit(mode)

    def end_mode(self):
        """Stops the mode and teaches the planner: the time spent is logged as a session."""
        planned, blocked = self.modes.planned_min, self.modes.blocked
        mode, spent = self.modes.stop()
        if mode != "normal" and spent >= 1:
            self.sched.log_session(mode.title(), f"{mode} session", planned or spent, spent,
                                   focus=max(0.3, 1.0 - 0.05 * blocked), mode=mode)
        self.lamp.tft_text("Smart Desk Lamp", "Normal mode")
        self.mode_changed.emit("normal")
        return mode, spent

    # ---- speech ----
    def _poll_speech(self):
        s = self.speaker.speaking
        if s != self._speaking or (not s and self.speaker.last_error):
            self._speaking = s
            self.speech_state.emit(s, self.speaker.last_error)
            if not s:
                self.speaker.last_error = ""

    def speak(self, text):
        ok = self.speaker.speak(text)
        self._poll_speech()
        if not ok and self.speaker.last_error:
            self.speech_state.emit(False, self.speaker.last_error)
        return ok

    def stop_speaking(self):
        self.speaker.stop()
        self._poll_speech()

    # ---- OCR (EasyOCR is big: loaded once, in the background) ----
    def _set_ocr(self, state, msg=""):
        self.ocr_state = state
        self.ocr_state_changed.emit(state, msg)

    def warm_ocr(self):
        if self.ocr_state in ("loading", "ready"):
            return

        def work():
            from ..core.ocr_engine import get_reader
            with self._ocr_lock:
                return get_reader()

        def done(res, err):
            if err:
                print(f"[ocr] {err}")
                self._set_ocr("error", f"The text reader could not start: {err}")
            else:
                self._set_ocr("ready", "Text reader ready")

        self._set_ocr("loading", "Loading the text reader (the first time downloads its model)...")
        run_async(work, done)

    def reset_ocr(self):
        from ..core import ocr_engine
        ocr_engine._reader = None
        self.ocr_state = "idle"
        self.warm_ocr()

    def read_text_async(self, img_bgr, cb, paragraph=True):
        def work():
            from ..core import ocr_engine
            with self._ocr_lock:
                return ocr_engine.read(img_bgr, self.prefs.get("ocr_engine", "easyocr"), paragraph,
                                       self.prefs.get("tesseract_cmd", "")).strip()
        run_async(work, cb)
