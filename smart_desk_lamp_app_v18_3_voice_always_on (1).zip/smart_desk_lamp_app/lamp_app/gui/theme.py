"""Colours, scaling, the glass background and the global style sheet."""
from PySide6.QtCore import Qt, QRectF, QPointF
from PySide6.QtGui import QColor, QLinearGradient, QRadialGradient, QPainter, QPixmap

S = 1.0          # UI scale (set once from the screen height)


def set_scale(v):
    global S
    S = max(0.8, min(1.7, v))


def px(n):
    return max(1, int(round(n * S)))


ACCENT = {"orange": "#FF8A3D", "yellow": "#FFC83D", "green": "#34D399", "purple": "#8B5CF6",
          "blue": "#3B9BFF", "pink": "#FF5C8A", "teal": "#2DD4BF", "red": "#FF5A5F", "grey": "#8A8FA8"}
TEXT = "#F5F5FA"
MODE = "dark"                  # "dark" | "light"  (see the light/dark reference picture)


def set_mode(m):
    global MODE
    MODE = "light" if m == "light" else "dark"


def is_dark():
    return MODE == "dark"


def fg_color(alpha):
    """Translucent 'ink' used for card fills, borders and hover states (white on dark, black on light)."""
    return QColor(255, 255, 255, alpha) if is_dark() else QColor(20, 20, 30, int(alpha * 0.8))


def icon_on():
    return "#FFFFFF" if is_dark() else "#16161C"


def icon_off():
    return "#C9C9DD" if is_dark() else "#55556B"
FONT_FAMILY = '"Segoe UI Variable Text", "Segoe UI", "Helvetica Neue", Arial, sans-serif'


def rgba(r, g, b, a):
    return f"rgba({r},{g},{b},{a})"


def paint_background(p, w, h):
    """Dark gradient with soft coloured light blobs (the 'blurred photo' look of the reference)."""
    base = QLinearGradient(0, 0, w, h)
    if not is_dark():                                   # light: soft grey paper with faint colour
        base.setColorAt(0.0, QColor(236, 236, 241))
        base.setColorAt(1.0, QColor(246, 246, 249))
        p.fillRect(0, 0, w, h, base)
        for cx, cy, rad, (r, g, b, a) in [(0.1, 0.1, 0.55, (139, 92, 246, 38)), (0.9, 0.9, 0.5, (59, 155, 255, 34)),
                                          (0.85, 0.1, 0.4, (255, 138, 61, 26))]:
            grad = QRadialGradient(QPointF(cx * w, cy * h), rad * max(w, h))
            grad.setColorAt(0.0, QColor(r, g, b, a))
            grad.setColorAt(1.0, QColor(r, g, b, 0))
            p.fillRect(0, 0, w, h, grad)
        return
    base.setColorAt(0.0, QColor(13, 11, 32))
    base.setColorAt(1.0, QColor(10, 12, 28))
    p.fillRect(0, 0, w, h, base)
    blobs = [(0.12, 0.10, 0.60, (110, 70, 255, 120)), (0.88, 0.18, 0.50, (255, 120, 70, 80)),
             (0.70, 0.95, 0.55, (50, 140, 255, 90)), (0.05, 0.90, 0.45, (45, 212, 191, 55)),
             (0.50, 0.45, 0.40, (190, 70, 255, 40))]
    for cx, cy, rad, (r, g, b, a) in blobs:
        grad = QRadialGradient(QPointF(cx * w, cy * h), rad * max(w, h))
        grad.setColorAt(0.0, QColor(r, g, b, a))
        grad.setColorAt(1.0, QColor(r, g, b, 0))
        p.fillRect(0, 0, w, h, grad)


def background_pixmap(w, h, dpr):
    pm = QPixmap(int(w * dpr), int(h * dpr))
    pm.setDevicePixelRatio(dpr)
    pm.fill(Qt.GlobalColor.black)
    p = QPainter(pm)
    paint_background(p, w, h)
    p.end()
    return pm


def build_qss():
    f = lambda n: f"{px(n)}px"          # noqa: E731
    dark = is_dark()
    FG = "255,255,255" if dark else "20,20,30"          # ink colour for translucent fills
    TXT = TEXT if dark else "#16161C"
    INK = "rgba(0,0,0,70)" if dark else "rgba({FG},200)"   # text boxes
    POP = "#1b1930" if dark else "#FFFFFF"              # drop-down / tooltip background
    POPT = "white" if dark else "#16161C"
    return f"""
* {{ font-family: {FONT_FAMILY}; }}
QWidget {{ color: {TXT}; font-size: {f(14)}; }}
QMainWindow, QStackedWidget, QScrollArea, QScrollArea > QWidget > QWidget {{ background: transparent; }}
QLabel {{ background: transparent; }}
QLabel#h1 {{ font-size: {f(30)}; font-weight: 700; }}
QLabel#h2 {{ font-size: {f(20)}; font-weight: 650; }}
QLabel#h3 {{ font-size: {f(15)}; font-weight: 650; color: rgba({FG},235); }}
QLabel#dim {{ color: rgba({FG},150); }}
QLabel#chip {{ background: rgba({FG},22); border: 1px solid rgba({FG},40);
               border-radius: {f(16)}; padding: {f(5)} {f(14)}; font-weight: 600; }}
QLabel#status_ok {{ color: #34D399; font-weight: 600; }}
QLabel#status_bad {{ color: #FF7A7F; font-weight: 600; }}
QToolTip {{ background: {POP}; color: {POPT}; border: 1px solid rgba({FG},60); padding: {f(6)}; }}

QPushButton {{ background: rgba({FG},24); border: 1px solid rgba({FG},44);
              border-radius: {f(14)}; padding: {f(10)} {f(18)}; font-weight: 600; }}
QPushButton:hover {{ background: rgba({FG},44); }}
QPushButton:pressed {{ background: rgba({FG},14); }}
QPushButton:focus {{ border: 1px solid #A99BFF; }}
QPushButton:disabled {{ color: rgba({FG},90); background: rgba({FG},10); border-color: rgba({FG},20); }}
QPushButton[variant="primary"] {{ border: none; color: white;
    background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #8B5CF6, stop:1 #3B82F6); }}
QPushButton[variant="primary"]:hover {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #9D74FF, stop:1 #5A98FF); }}
QPushButton[variant="primary"]:disabled {{ background: rgba({FG},18); }}
QPushButton[variant="green"] {{ border: none; background: rgba(52,211,153,200); color: #06241a; }}
QPushButton[variant="green"]:hover {{ background: rgba(52,211,153,235); }}
QPushButton[variant="orange"] {{ border: none; background: rgba(255,138,61,215); color: #2b1100; }}
QPushButton[variant="orange"]:hover {{ background: rgba(255,138,61,245); }}
QPushButton[variant="danger"] {{ border: none; background: rgba(255,90,95,205); color: white; }}
QPushButton[variant="danger"]:hover {{ background: rgba(255,90,95,240); }}
QPushButton[variant="key"] {{ font-size: {f(22)}; font-weight: 600; border-radius: {f(18)}; padding: 0; }}
QTabBar::tab {{ background: rgba({FG},18); border-radius: {f(12)}; padding: {f(8)} {f(18)}; margin-right: {f(6)}; font-weight: 600; }}
QTabBar::tab:selected {{ background: #8B5CF6; color: white; }}
QTabWidget::pane {{ border: none; }}
QPushButton[variant="op"] {{ font-size: {f(22)}; font-weight: 700; border-radius: {f(18)}; padding: 0;
    background: rgba(139,92,246,150); border: 1px solid rgba(190,170,255,120); }}
QPushButton[variant="op"]:hover {{ background: rgba(139,92,246,200); }}

QTextEdit, QPlainTextEdit, QLineEdit, QListWidget {{ background: {INK}; border: 1px solid rgba({FG},38);
    border-radius: {f(14)}; padding: {f(8)} {f(12)}; selection-background-color: #6D5DFC; selection-color: white; }}
QTextEdit:focus, QPlainTextEdit:focus, QLineEdit:focus {{ border: 1px solid #A99BFF; }}
QListWidget::item {{ padding: {f(8)}; border-radius: {f(8)}; }}
QListWidget::item:hover {{ background: rgba({FG},24); }}
QListWidget::item:selected {{ background: rgba(139,92,246,150); }}

QComboBox {{ background: rgba({FG},24); border: 1px solid rgba({FG},44); border-radius: {f(12)};
    padding: {f(8)} {f(14)}; min-height: {f(22)}; }}
QComboBox:hover {{ background: rgba({FG},40); }}
QComboBox::drop-down {{ border: none; width: {f(28)}; }}
QComboBox QAbstractItemView {{ background: {POP}; color: {POPT}; border: 1px solid rgba({FG},60);
    selection-background-color: #6D5DFC; outline: none; padding: {f(4)}; }}

QSlider::groove:horizontal {{ height: {f(6)}; background: rgba({FG},40); border-radius: {f(3)}; }}
QSlider::sub-page:horizontal {{ background: #8B5CF6; border-radius: {f(3)}; }}
QSlider::handle:horizontal {{ background: white; width: {f(18)}; height: {f(18)}; margin: -{f(6)} 0; border-radius: {f(9)}; }}

QCheckBox {{ spacing: {f(10)}; background: transparent; }}
QCheckBox::indicator {{ width: {f(20)}; height: {f(20)}; border-radius: {f(6)}; border: 1px solid rgba({FG},90);
    background: {INK}; }}
QCheckBox::indicator:checked {{ background: #8B5CF6; border: 1px solid #B9A8FF; }}

QProgressBar {{ background: rgba({FG},24); border: none; border-radius: {f(3)}; max-height: {f(6)}; }}
QProgressBar::chunk {{ background: #8B5CF6; border-radius: {f(3)}; }}

QScrollBar:vertical {{ background: transparent; width: {f(10)}; margin: 2px; }}
QScrollBar::handle:vertical {{ background: rgba({FG},70); border-radius: {f(4)}; min-height: {f(30)}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}
QScrollBar:horizontal {{ background: transparent; height: {f(10)}; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: rgba({FG},70); border-radius: {f(4)}; min-width: {f(30)}; }}
"""
