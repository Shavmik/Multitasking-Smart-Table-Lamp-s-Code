"""Launcher: finds the board, opens the window, shows the touch menu."""
import argparse
import time
import traceback

import cv2

from . import config
from .core.board import Board, BoardError
from .core.context import Context
from .core.ui import UI, W, H, blank, button, in_rect, put, put_center, wrap
from .features import discover

PER_PAGE = 6
COLS, ROWS = 3, 2
TILE_W, TILE_H, GAP = 98, 84, 6


def find_port():
    import serial.tools.list_ports
    ports = list(serial.tools.list_ports.comports())
    for p in ports:
        if p.vid == 0x303A:                     # Espressif native USB
            return p.device
    if not ports:
        return None
    if len(ports) == 1:
        return ports[0].device
    print("Several serial ports found:")
    for i, p in enumerate(ports, 1):
        print(f"  {i}. {p.device}  -  {p.description}")
    while True:
        choice = input("Choose the port number for the ESP32: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(ports):
            return ports[int(choice) - 1].device


def tile_rect(slot):
    r, c = divmod(slot, COLS)
    return (GAP + c * (TILE_W + GAP), 34 + r * (TILE_H + GAP), TILE_W, TILE_H)


PREV_RECT, NEXT_RECT, QUIT_RECT = (6, 210, 70, 26), (84, 210, 70, 26), (244, 210, 70, 26)


def render_home(features, page, sd):
    img = blank()
    put(img, "SMART DESK LAMP", (8, 22), 0.65, (255, 255, 255), 2)
    put(img, "SD ok" if sd else "no SD", (262, 20), 0.4, (150, 150, 150))
    for slot, f in enumerate(features[page * PER_PAGE:(page + 1) * PER_PAGE]):
        rect = tile_rect(slot)
        x, y, w, h = rect
        cv2.rectangle(img, (x, y), (x + w - 1, y + h - 1), f.color, -1)
        cv2.rectangle(img, (x, y), (x + w - 1, y + h - 1), (230, 230, 230), 1)
        put_center(img, f.icon, (x, y + 4, w, 44), 1.0, (255, 255, 255), 2)
        lines = wrap(f.name, 12)[:2]
        for k, line in enumerate(lines):
            put_center(img, line, (x, y + 46 + 15 * k, w, 16), 0.42, (255, 255, 255))
        if f.key:
            put(img, f.key.upper(), (x + 5, y + 14), 0.4, (220, 220, 220))
    pages = max(1, -(-len(features) // PER_PAGE))
    if pages > 1:
        button(img, PREV_RECT, "<", (60, 60, 60))
        button(img, NEXT_RECT, ">", (60, 60, 60))
        put(img, f"{page + 1}/{pages}", (160, 228), 0.45, (200, 200, 200))
    button(img, QUIT_RECT, "QUIT", (40, 40, 140))
    return img


def run_feature(ctx, feature):
    ui = ctx.ui
    try:
        feature.run(ctx)
    except KeyboardInterrupt:
        raise
    except Exception as e:                      # one broken feature must not close the app
        print(f"\n*** '{feature.name}' stopped because of an error: {e}")
        traceback.print_exc()
        try:
            ctx.board.text("Error", str(e)[:150])
        except Exception:
            pass
        ui.pump(1500)
    ui.invalidate()
    ctx.board.set_hold(True)


def home(ctx, features):
    ui = ctx.ui
    page = 0
    pages = max(1, -(-len(features) // PER_PAGE))
    while not ui.closed():
        ui.show(render_home(features, page, ctx.board.sd))
        chosen = None
        for ev in ui.events():
            if ev.type == "key":
                if ev.key in ("esc", "q"):
                    return
                if ev.key in ("]", "."):
                    page = (page + 1) % pages
                elif ev.key in ("[", ","):
                    page = (page - 1) % pages
                else:
                    chosen = next((f for f in features if f.key == ev.key), None)
            elif ev.type == "down":
                if in_rect(ev.x, ev.y, QUIT_RECT):
                    return
                if pages > 1 and in_rect(ev.x, ev.y, NEXT_RECT):
                    page = (page + 1) % pages
                elif pages > 1 and in_rect(ev.x, ev.y, PREV_RECT):
                    page = (page - 1) % pages
                else:
                    for slot, f in enumerate(features[page * PER_PAGE:(page + 1) * PER_PAGE]):
                        if in_rect(ev.x, ev.y, tile_rect(slot)):
                            chosen = f
            if chosen:
                break
        if chosen:
            run_feature(ctx, chosen)
        time.sleep(0.005)


def main(argv=None):
    ap = argparse.ArgumentParser(description="Smart Desk Lamp app")
    ap.add_argument("--port", help="serial port, e.g. COM6 or /dev/ttyACM0 (default: find it automatically)")
    ap.add_argument("--baud", type=int, default=config.BAUD)
    ap.add_argument("--classic", action="store_true", help="use the old 320x240 OpenCV window")
    ap.add_argument("--no-lamp", action="store_true", help="start the new interface without the lamp hardware")
    args = ap.parse_args(argv)

    if config.VOICE_SINGLE_INSTANCE and not args.classic:           # already running? then just wake that one
        from .voice import client
        if client.is_running(config.VOICE_PORT):
            print("Smart Desk Lamp is already running - waking it up.")
            client.send("WAKE", config.VOICE_PORT)
            return 0

    if not args.classic:
        try:
            from .gui.main import run
        except ImportError as e:
            print(f"The new interface needs PySide6 ({e}).")
            print("Run 'Install first time.bat' (or: pip install PySide6 pyttsx3 deep-translator).")
            print("Starting the classic window instead...\n")
        else:
            return run(args)

    print("=" * 56)
    print("  SMART DESK LAMP  -  ESP32-S3 camera + touchscreen")
    print("=" * 56)
    port = args.port or find_port()
    if not port:
        print("No serial port found. Check the USB cable (it must be a DATA cable).")
        return
    print(f"Connecting to {port} ...")
    try:
        board = Board(port, args.baud)
    except Exception as e:
        print(f"Could not open {port}: {e}")
        print("Close the Arduino Serial Monitor and try again.")
        return
    time.sleep(2.5)                              # the board may restart when the port opens
    status = board.ping()
    if status is None:
        print("The board did not answer. Is lamp_firmware.ino uploaded? Is the right port selected?")
        board.close()
        return
    print(f"Board connected ({status}).")

    try:
        ui = UI(board)
    except cv2.error:
        print("\nYour OpenCV install cannot open windows (the 'headless' version is installed).")
        print("Fix:  pip uninstall -y opencv-python opencv-python-headless")
        print("      pip install opencv-python")
        board.close()
        return

    features = discover()
    print("Features: " + ", ".join(f.name for f in features))
    print("Use the touchscreen, the mouse or the keys shown on the tiles. Q / ESC on the menu = quit.\n")
    ctx = Context(board, ui)
    try:
        home(ctx, features)
    except KeyboardInterrupt:
        print("\nStopped.")
    except Exception:
        print("\n*** The app hit an error. Please send this text: ***\n")
        traceback.print_exc()
    finally:
        try:
            board.text("Smart Desk Lamp", "App closed on the laptop.")
        except Exception:
            pass
        board.close()
        cv2.destroyAllWindows()
        print("Goodbye.")
