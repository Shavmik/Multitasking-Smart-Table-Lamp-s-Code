"""Settings you may want to change."""

LANGUAGES = ["en"]          # OCR languages, e.g. ["en", "hi"]
USE_GPU = False
BAUD = 115200               # ignored by the ESP32-S3 native USB, kept for completeness

SAVE_DIR = "captures"       # photos, cube scans and notes.txt are saved here
WINDOW = "Smart Desk Lamp"

TFT_W, TFT_H = 320, 240     # the lamp screen (landscape)
SCALE = 2                   # the laptop window shows everything 2x bigger

MAX_IMAGE_BYTES = 5_000_000
MAX_UI_JPEG = 60_000        # largest picture sent to the TFT (firmware limit is 65536)
MAX_TFT_CHARS = 400
MAX_QUERY_LEN = 300

# ---- new interface ----
ERP_URL = "https://erp.psit.ac.in/"     # opened inside the app (Chromium web view)
DEFAULT_TARGET_LANG = "hi"              # translator default (Hindi); change in the Translate page

# ---- lamp touchscreen (TFT) ----
# If drawing on the TFT goes the wrong way, first run Settings > "Calibrate the lamp's touch screen".
# Still mirrored / rotated? Change these (no re-flashing needed):
TOUCH_FLIP_X = False        # left <-> right
TOUCH_FLIP_Y = False        # up <-> down
TOUCH_SWAP_XY = False       # x <-> y (screen turned 90 degrees)
TFT_REFRESH_MS = 5000       # the lamp screen is redrawn every 5 s (a tap or pen stroke redraws it after ~0.4 s)
TFT_QUALITY = 0.75          # picture detail sent to the TFT: 1.0 = full 320x240, 0.75 = 240x180, 0.5 = 160x120 (lighter, faster)
TFT_TARGET_BYTES = 16000    # aim for pictures this small (the board draws small files fast and completely)
INK_WIDTH = 6               # pen width of the handwriting canvas, in window pixels (matches the canvas pen)
TFT_DEBUG = False           # True = print every touch in the terminal (to check the wiring)

# ---- v14 lamp touchscreen interface ----
TFT_UI = True               # True = the lamp screen has its own buttons (Home, Clock, Read text, Translate, Modes, Lamp, Cube).
                            # False = the old way: the desktop page is mirrored on the lamp screen.
# ---- voice: "turn on the smart desk lamp" (see voice_listener.py / README v17) ----
VOICE_PORT = 47831                  # the app listens on this port of THIS computer only (127.0.0.1) for the voice listener
VOICE_CONFIDENCE = 0.70             # 0..1: how sure Windows must be about a phrase (higher = fewer false wake-ups)
VOICE_SPEAK = True                  # the listener says "Okay" when it understood a command
VOICE_SINGLE_INSTANCE = True        # starting the app while it is already running just wakes the running one
TFT_OFF_WHEN_APP_CLOSES = True      # closing the app switches the lamp screen off (needs the new firmware)
TFT_NATIVE = True           # v15: the lamp draws its buttons and texts ITSELF (no pictures) - needs the new firmware (re-flash once).
                            # Old firmware is detected automatically and the picture version above is used instead.
TFT_CAM_ALWAYS = True       # v16: a small LIVE camera picture is always shown in a corner of the lamp screen (drawn by the board itself)
TFT_CAM_BOX = (252, 188, 64, 48)   # x, y, width, height of that picture on the 320x240 screen (bottom right)
TFT_CAM_MS = 200            # how often the board refreshes it (milliseconds; 200 = 5 pictures a second)
TFT_NATIVE_MS = 100         # how often the laptop looks whether a text on the lamp screen changed (taps are collected every ~12 ms)
TFT_UI_MS = 250             # how often the lamp picture is checked for changes (only changed pictures are sent)

# ---- laptop camera fallback ----
LAPTOP_CAMERA_FALLBACK = True   # True = while the lamp is NOT connected, camera pages (Read text, QR, Cube, Sudoku...) use the laptop's own camera.
                                # The lamp's camera is used again as soon as the lamp connects. False = lamp camera only.
LAPTOP_CAMERA_INDEX = None      # None = try camera 0, 1, 2 automatically. Set 1 (or 2...) to pick another camera, e.g. an external webcam.
