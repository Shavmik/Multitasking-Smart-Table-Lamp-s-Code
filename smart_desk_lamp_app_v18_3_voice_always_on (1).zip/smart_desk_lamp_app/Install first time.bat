@echo off
cd /d "%~dp0"
title Smart Desk Lamp - first-time setup
where py >nul 2>nul
if %errorlevel%==0 (set PY=py -3) else (set PY=python)
%PY% --version
if errorlevel 1 goto nopython

echo.
echo Installing the libraries (this is a big download, please wait)...
%PY% -m pip install -r requirements.txt
if errorlevel 1 goto failed

echo.
echo Fixing OpenCV (EasyOCR installs a version that cannot open windows)...
%PY% -m pip uninstall -y opencv-python opencv-python-headless
%PY% -m pip install opencv-python
if errorlevel 1 goto failed

echo.
echo Creating a desktop shortcut...
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Smart Desk Lamp.lnk'); $s.TargetPath='%~dp0Smart Desk Lamp.bat'; $s.WorkingDirectory='%~dp0'; $s.Save()"

echo.
echo All done. Double-click "Smart Desk Lamp" on your desktop to start.
pause
exit /b 0

:nopython
echo.
echo Python was not found. Install Python 3.10, 3.11 or 3.12 from python.org
echo and tick "Add python.exe to PATH" in the installer, then run this file again.
pause
exit /b 1

:failed
echo.
echo The installation failed. Check your internet connection and run this file again.
pause
exit /b 1
