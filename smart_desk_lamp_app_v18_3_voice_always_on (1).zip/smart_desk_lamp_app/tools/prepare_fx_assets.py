"""Rebuilds lamp_app/assets/fx/* from the original reference videos / pictures.
Needs ffmpeg on PATH + Pillow + opencv.   Usage:  python tools/prepare_fx_assets.py <folder with the originals>
The generated files are already included in the project; run this only to change them."""
import glob, os, shutil, subprocess, sys
import cv2
import numpy as np
from PIL import Image, ImageDraw

SRC = sys.argv[1] if len(sys.argv) > 1 else "."
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "lamp_app", "assets", "fx")
os.makedirs(OUT, exist_ok=True)


def find(part):
    hits = glob.glob(os.path.join(SRC, f"*{part}*"))
    if not hits:
        raise SystemExit(f"missing: *{part}*")
    return hits[0]


def frames(video, folder, fps, seconds, vf):
    d = os.path.join(OUT, folder)
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d)
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-t", str(seconds), "-i", video, "-vf", f"fps={fps},{vf}",
                    "-q:v", "4", os.path.join(d, "%03d.jpg")], check=True)
    print(folder, len(os.listdir(d)), "frames")


# ---- videos that stay videos (character loops) ----
frames(find("1030691064701754755"), "chibi", 10, 10, "scale=300:300")                  # purple chibi turning around
frames(find("617837642698060238"), "eye", 10, 8, "crop=720:860:0:150,scale=360:-2")    # red eye

# ---- pictures ----
def save(img, name, **kw):
    img.save(os.path.join(OUT, name), **kw)

# desktop wallpaper: the blurred city of the Windows-11 anime desktop
im = cv2.imread(find("Ui_design_win_11"))
big = cv2.resize(im, (1920, 1080), interpolation=cv2.INTER_CUBIC)
big = cv2.GaussianBlur(big, (0, 0), 38)
hsv = cv2.cvtColor(big, cv2.COLOR_BGR2HSV).astype(np.float32)
hsv[..., 1] *= 1.15
big = cv2.cvtColor(np.clip(hsv, 0, 255).astype(np.uint8), cv2.COLOR_HSV2BGR)
cv2.imwrite(os.path.join(OUT, "wallpaper_city.jpg"), big, [cv2.IMWRITE_JPEG_QUALITY, 82])

# the graph photo (planner), the sniper (focus mode), the lamp sketch (lamp card)
Image.open(find("download__17_")).convert("RGB").save(os.path.join(OUT, "graph_photo.jpg"), quality=88)
sn = Image.open(find("download__18_")).convert("RGB")
save(sn.crop((0, 120, sn.width, 120 + int(sn.width * 0.62))), "focus_banner.jpg", quality=88)
lamp = Image.open(find("WhatsApp_Image")).convert("RGB")
lamp.thumbnail((1100, 1100))
save(lamp, "lamp_sketch.jpg", quality=88)

# round app icons: Discord-flame (gaming) and anime Google-Translate (translator)
def rounded_icon(path, name, radius_frac, crop=None, size=512):
    img = Image.open(path).convert("RGBA")
    if crop:
        img = img.crop(crop)
    img = img.resize((size, size), Image.LANCZOS)
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, size - 1, size - 1), int(size * radius_frac), fill=255)
    img.putalpha(mask)
    save(img, name)

rounded_icon(find("Discord_Diluc"), "icon_discord.png", 0.5)
rounded_icon(find("download__15_"), "icon_translate.png", 0.22)
print("done ->", os.path.abspath(OUT))
