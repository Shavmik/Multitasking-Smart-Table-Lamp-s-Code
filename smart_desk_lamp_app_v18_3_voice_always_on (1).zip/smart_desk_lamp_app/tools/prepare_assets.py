"""Builds lamp_app/assets/*.png from the original pictures (run once; the results are shipped).

Every picture is upscaled with Lanczos + a light sharpen, and dark/white backgrounds are turned
into transparency so the art sits cleanly on the glass tiles.  Usage:
    python tools/prepare_assets.py <folder with the original pictures>
"""
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

SRC = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
OUT = Path(__file__).resolve().parent.parent / "lamp_app" / "assets"
OUT.mkdir(parents=True, exist_ok=True)


def find(part):
    for p in SRC.iterdir():
        if part in p.name:
            return p
    raise FileNotFoundError(part)


def upscale(im, factor, sharpen=True):
    im = im.resize((int(im.width * factor), int(im.height * factor)), Image.LANCZOS)
    if sharpen:
        im = im.filter(ImageFilter.UnsharpMask(radius=1.6, percent=70, threshold=2))
    return im


def key_dark(im, lo=12, hi=60, bg=None):
    """Turn a dark background into transparency (soft edge)."""
    a = np.asarray(im.convert("RGB")).astype(np.float32)
    ref = np.array(bg if bg else (0, 0, 0), np.float32)
    dist = np.abs(a - ref).max(axis=2)
    alpha = np.clip((dist - lo) / (hi - lo), 0, 1) ** 0.85
    out = np.dstack([a, alpha * 255]).astype(np.uint8)
    return Image.fromarray(out, "RGBA")


def key_white(im, lo=6, hi=40):
    a = np.asarray(im.convert("RGB")).astype(np.float32)
    dist = (255 - a).max(axis=2)
    alpha = np.clip((dist - lo) / (hi - lo), 0, 1)
    out = np.dstack([a, alpha * 255]).astype(np.uint8)
    return Image.fromarray(out, "RGBA")


def trim(im, pad=0):
    box = im.getchannel("A").point(lambda v: 255 if v > 8 else 0).getbbox()
    if box:
        l, t, r, b = box
        im = im.crop((max(l - pad, 0), max(t - pad, 0), min(r + pad, im.width), min(b + pad, im.height)))
    return im


def save(im, name):
    im.save(OUT / name, optimize=True)
    print(f"{name:22s} {im.width}x{im.height}")


# clock  <- the picture with the clock and the red-eyed character
save(upscale(key_dark(Image.open(find("download__11_")), 14, 70), 2.2), "art_clock.png")
# QR scanner  <- QR code with the girl
save(upscale(key_dark(Image.open(find("53aa26510e82")), 14, 70), 1.3), "art_qr.png")
# Rubik's cube  <- cube on the chalkboard (flat grey 34,34,34 background)
save(upscale(key_dark(Image.open(find("image.png")).convert("RGB"), 6, 46, bg=(34, 34, 34)), 4.0), "art_cube.png")
# notebook + pen  <- handwriting
save(upscale(key_dark(Image.open(find("Блокнот")), 14, 70), 2.0), "art_notebook.png")
# translate icon  <- blue app icon on white: crop to the icon and give it clean rounded corners
from PIL import ImageDraw
ti = Image.open(find("images.png")).convert("RGB")
nz = np.asarray(ti).astype(np.int16)
ys, xs = np.where((255 - nz).max(axis=2) > 40)
ti = ti.crop((xs.min(), ys.min(), xs.max() + 1, ys.max() + 1))
ti = upscale(ti, 3.0)
rm = Image.new("L", ti.size, 0)
ImageDraw.Draw(rm).rounded_rectangle((0, 0, ti.width - 1, ti.height - 1), radius=int(ti.width * 0.22), fill=255)
ti.putalpha(rm.filter(ImageFilter.GaussianBlur(1.0)))
save(ti, "art_translate.png")
# Spotify (Miku logo): round it, background -> transparent
m = Image.open(find("Miku_themed")).convert("RGB")
m = upscale(m, 2.0)
mask = Image.new("L", m.size, 0)
from PIL import ImageDraw
d = ImageDraw.Draw(mask)
cx, cy = m.width / 2, m.height / 2
r = min(m.size) * 0.455
d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=255)
mask = mask.filter(ImageFilter.GaussianBlur(1.2))
m.putalpha(mask)
save(trim(m), "art_spotify.png")
# music wall  <- background of the Spotify page (stays a JPEG; it is shown dimmed)
w = upscale(Image.open(find("download__13_")).convert("RGB"), 1.6, sharpen=False)
w.save(OUT / "art_musicwall.jpg", quality=90)
print("art_musicwall.jpg", w.size)
