@echo off
cd /d "%~dp0"
title Smart Desk Lamp
where py >nul 2>nul
if %errorlevel%==0 (set PY=py -3) else (set PY=python)
%PY% -m lamp_app %*
echo.
echo The app has closed. Press any key to close this window.
pause >nul
