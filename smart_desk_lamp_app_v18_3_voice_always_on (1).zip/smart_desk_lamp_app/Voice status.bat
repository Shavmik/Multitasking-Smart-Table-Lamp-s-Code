@echo off
title Smart Desk Lamp - voice status
echo Is the voice listener running? (SmartDeskLampVoice.exe or pythonw.exe / python.exe)
powershell -NoProfile -Command "$p=Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*voice_listener*' -or $_.Name -eq 'SmartDeskLampVoice.exe' }; if($p){$p | Select-Object ProcessId,Name | Format-Table -AutoSize}else{'  voice listener is NOT running'}"
echo.
echo Last lines of the log (what it heard):
powershell -NoProfile -Command "Get-Content \"$env:APPDATA\SmartDeskLamp\voice.log\" -Tail 15 -ErrorAction SilentlyContinue"
echo.
echo Tip: Windows 10/11 shows a microphone icon in the system tray while a program records.
pause
