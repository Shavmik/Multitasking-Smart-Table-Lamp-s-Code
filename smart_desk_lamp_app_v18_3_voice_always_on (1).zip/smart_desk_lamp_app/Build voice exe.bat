@echo off
cd /d "%~dp0"
title Smart Desk Lamp - build the voice listener .exe
where py >nul 2>nul
if %errorlevel%==0 (set PY=py -3) else (set PY=python)
%PY% -m pip install pyinstaller
%PY% -m PyInstaller --noconfirm --clean --noconsole --name SmartDeskLampVoice --distpath voice_exe --workpath build_voice --specpath build_voice --paths "%~dp0." --add-data "%~dp0lamp_app\voice\win_recognizer.ps1;lamp_app\voice" voice_listener.py
if errorlevel 1 goto failed
echo.
echo Done: voice_exe\SmartDeskLampVoice\SmartDeskLampVoice.exe  (small, no PyTorch)
echo Now run "Install voice autostart.bat" - it will use this .exe, and the Task Manager will show it as SmartDeskLampVoice.exe.
pause
exit /b 0
:failed
echo The build failed - the normal pythonw voice listener still works.
pause
