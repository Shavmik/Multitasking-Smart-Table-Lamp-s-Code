"""Entry point used when the app is packed into an .exe (see build_exe.bat)."""
from lamp_app.app import main

if __name__ == "__main__":
    main()
