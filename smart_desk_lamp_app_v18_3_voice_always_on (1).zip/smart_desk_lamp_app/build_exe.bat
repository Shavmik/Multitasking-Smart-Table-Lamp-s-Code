@echo off
rem EXPERIMENTAL: packs the app into dist\SmartDeskLamp\SmartDeskLamp.exe
rem Needs "Install first time.bat" to have been run once. The result is very large (several GB)
rem because EasyOCR brings PyTorch with it. If it fails, keep using "Smart Desk Lamp.bat".
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set PY=py -3) else (set PY=python)
%PY% -m pip install pyinstaller
%PY% -m PyInstaller --noconfirm --clean --name SmartDeskLamp --console --collect-submodules lamp_app --collect-all easyocr --collect-all PySide6 --add-data "lamp_app/assets;lamp_app/assets" run_lamp.py
echo.
echo If there were no errors above, start:  dist\SmartDeskLamp\SmartDeskLamp.exe
echo (Copy the whole dist\SmartDeskLamp folder if you move it - the exe needs the files next to it.)
pause
