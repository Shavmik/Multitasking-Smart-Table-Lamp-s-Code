@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set PY=py -3) else (set PY=python)
set EXE=%~dp0voice_exe\SmartDeskLampVoice\SmartDeskLampVoice.exe
if exist "%EXE%" (
  set TARGET=%EXE%
  set ARGS=
  set NAME=SmartDeskLampVoice.exe
) else (
  for /f "delims=" %%i in ('%PY% -c "import sys,os;print(os.path.join(os.path.dirname(sys.executable),'pythonw.exe'))"') do set TARGET=%%i
  set ARGS=\"%~dp0voice_listener.py\"
  set NAME=pythonw.exe
)
if not exist "%TARGET%" (
  echo Could not find the voice program. Is Python installed?
  pause
  exit /b 1
)
powershell -NoProfile -Command "$ws=New-Object -ComObject WScript.Shell; $l=$ws.CreateShortcut([Environment]::GetFolderPath('Startup')+'\Smart Desk Lamp Voice.lnk'); $l.TargetPath='%TARGET%'; $l.Arguments='%ARGS%'; $l.WorkingDirectory='%~dp0'; $l.WindowStyle=7; $l.Save()"
echo.
echo Done. Windows will start the voice listener (hidden) every time you sign in, as %NAME%.
echo It keeps listening until you end it: Task Manager ^> Details ^> %NAME% ^> End task.
echo Start it right now with "Start voice listener.bat" or sign out and in again.
pause
