@echo off
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Smart Desk Lamp Voice.lnk" 2>nul
echo The voice listener will no longer start with Windows.
pause
